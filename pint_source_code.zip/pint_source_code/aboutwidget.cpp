#include "aboutwidget.h"
#include "ui_aboutwidget.h"
#include "textstyle.h"
#include <QTextDocument>
#include <QDesktopServices>

aboutWidget::aboutWidget(QWidget *parent, double sF) :
    QWidget(parent),scaleFactor(sF),
    ui(new Ui::aboutWidget)
{
    ui->setupUi(this);
    checkUpdates();
    connect(ui->citationLabel, SIGNAL(anchorClicked(const QUrl &)), this, SLOT(anchorClicked(const QUrl &)));
    setupCosmeticChanges();
    if(scaleFactor!=1.0)
        scaleWidget();
}

aboutWidget::~aboutWidget()
{
    delete ui;
}

void aboutWidget::on_closeButton_clicked()
{
    emit goBack();
}

void aboutWidget::setupCosmeticChanges()
{
    //Text shadow effect
    textStyle *style = new textStyle(this);
    textStyle *style2 = new textStyle(this);//Intentional, QGraphicsDropShadowEffect does not allow for multiple renders at once
    ui->labelPINT->setGraphicsEffect(style->shadow);
    ui->labelVersion->setGraphicsEffect(style2->shadow);
}

void aboutWidget::scaleWidget()
{
    //Buttons
    ui->closeButton->setMinimumSize(ui->closeButton->minimumSize().width()*scaleFactor, ui->closeButton->minimumSize().height()*scaleFactor);
    ui->closeButton->setMaximumSize(ui->closeButton->minimumSize());
    ui->closeButton->setIconSize(ui->closeButton->iconSize()*scaleFactor);

    //Labels
    ui->labelPINT->setFont(scaleFont(ui->labelPINT->font()));
    ui->closeLabel->setFont(scaleFont(ui->closeLabel->font()));
    ui->labelVersion->setFont(scaleFont(ui->labelVersion->font()));
    ui->textLabel->setFont(scaleFont(ui->textLabel->font()));
}

QFont aboutWidget::scaleFont(QFont fnt)
{
    fnt.setPointSizeF(fnt.pointSizeF()*scaleFactor);
    return fnt;
}

void aboutWidget::checkUpdates()
{
    //Checks online for citation source
    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)),this, SLOT(replyFinished(QNetworkReply*)));
    manager->get(QNetworkRequest(QUrl("http://www.liu.se/forskning/foass/tidigare-foass/patrik-lundstrom/software?l=en#PINT")));
}

void aboutWidget::replyFinished(QNetworkReply* reply)
{
    QByteArray bts = reply->readAll();
    QString str(bts);
    QString cite("Cite PINT as:");

    if(str.size()>0 && str.contains(cite))
    {
        QString tmp("");
        for(int i(0); i<str.size()-14; i++)
        {
            if(str.mid(i,13)=="Cite PINT as:")
            {
                int pos1(i+13);
                int pos2(pos1);
                for(int j(pos1); j<str.size()-12; j++)
                {
                    if(str.mid(j,8)=="Binaries")
                    {
                        pos2=j-1;
                        break;
                    }
                }
                if(pos1!=pos2)
                {
                    tmp=str.mid(pos1,pos2-pos1);
                }
                break;
            }
        }
        cite=cite+"<br>"+tmp;
    }
    else
    {
        cite="Please check:<br><a href=\"http://www.liu.se/forskning/foass/tidigare-foass/patrik-lundstrom/software?l=en#PINT\">http://www.liu.se/forskning/foass/tidigare-foass/patrik-lundstrom/software?l=en#PINT</a><br>for citation information.";
    }
    ui->citationLabel->setHtml(cite);
}

void aboutWidget::anchorClicked(const QUrl &url)
{
    QDesktopServices::openUrl(QUrl(url));
}
