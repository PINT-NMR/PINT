#include "hintdialog.h"
#include "ui_hintdialog.h"
#include <QShortcut>


hintDialog::hintDialog(QWidget *parent) :
    QDialog(parent, Qt::FramelessWindowHint | Qt::WindowSystemMenuHint),
    ui(new Ui::hintDialog)
{
    ui->setupUi(this);
    QShortcut *closeDlg = new QShortcut(this);
#ifdef Q_OS_MAC
    closeDlg->setKey(Qt::Key_F8);
#else
    closeDlg->setKey(Qt::Key_F12);
#endif
    connect(closeDlg, SIGNAL(activated()), this, SLOT(accept()));
#ifdef Q_OS_MAC //Ctrl key is Cmd key on Mac, but is still handled with Qt::Ctrl modifier
//  ui->redoLabel->setPixmap(QPixmap(":/img/cmdy.png"));
//  ui->undoLabel->setPixmap(QPixmap(":/img/cmdz.png"));
    ui->foldLabel->setPixmap(QPixmap(":/img/ctrlf.png"));
    ui->cLabel_2->setPixmap(QPixmap(":/img/ctrlc.png"));
    ui->oLabel->setPixmap(QPixmap(":/img/ctrlo.png"));
    ui->hideHintLabel->setText("<html><head/><body><p align=\"right\"><span style=\" color:#ffffff;\">Hide hints (fn+F8)</span></p></body></html>");
#endif
}

hintDialog::~hintDialog()
{
    delete ui;
}

void hintDialog::on_hideHintButton_clicked()
{
    accept();
}
