#include "cancelvar.h"
bool cancelVar = false;
