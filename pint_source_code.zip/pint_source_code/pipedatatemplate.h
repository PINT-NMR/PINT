#ifndef PIPEDATATEMPLATE_H
#define PIPEDATATEMPLATE_H
#include <vector>
using namespace std;
class pipeDataTemplate
{
public:
    pipeDataTemplate();
    ~pipeDataTemplate();
    float header[512];
    int sizeF2;
    double swF2;
    double obsF2;
    double origF2;
    int sizeF1;
    double swF1;
    double obsF1;
    double origF1;
    double deltaF1;
    double deltaF2;
    double firstF1;
    double firstF2;
    vector<double> f1;
    vector<double> f2;
    vector<double> y;
    int imin;
    int jmin;
    int imax;
    int jmax;
    float _F1;
    float _F2;
    float _y;
    int nPlane;
    int xDimF1;
    int xDimF2;
    int xDimF3;
    int nc_proc;
};

#endif // PIPEDATATEMPLATE_H
