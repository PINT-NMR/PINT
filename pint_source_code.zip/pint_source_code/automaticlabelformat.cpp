#include "automaticlabelformat.h"
#include "ui_automaticlabelformat.h"
#include <QMessageBox>


automaticLabelFormat::automaticLabelFormat(QWidget *parent, int arg, int arg2, QString arg3, QString arg4) :
    QDialog(parent), autBase(1000), autIncrement(1), autPrefix(""), autSuffix("N-HN"),
    ui(new Ui::automaticLabelFormat), character1(-1), character2(-1), illegalChars (" /?<>\\:*|\".,^:;+()[]%¤#!@£$€{}'´`~¨")
{
    ui->setupUi(this);
    connect(ui->baseBox, SIGNAL(valueChanged(int)), this, SLOT(updateLabels()));
    connect(ui->incrementBox, SIGNAL(valueChanged(int)), this, SLOT(updateLabels()));
    connect(ui->prefixEdit, SIGNAL(textChanged(QString)), this, SLOT(updateLabels()));
    connect(ui->suffixEdit, SIGNAL(textChanged(QString)), this, SLOT(updateLabels()));
    ui->baseBox->setValue(arg);
    ui->incrementBox->setValue(arg2);
    ui->prefixEdit->setText(arg3);
    ui->suffixEdit->setText(arg4);
}

automaticLabelFormat::~automaticLabelFormat()
{
    delete ui;
}


void automaticLabelFormat::on_cancelButton_clicked()
{
    reject();
}

void automaticLabelFormat::on_okButton_clicked()
{
    //Check errors
    if(!errors())
    {
        autPrefix = ui->prefixEdit->text();
        autSuffix= ui->suffixEdit->text();
        autBase = ui->baseBox->value();
        autIncrement = ui->incrementBox->value();
        accept();
    }
    else
    {
        QMessageBox::StandardButton dlg;
        QString msg("Illegal character(s) found ('");
        if(character1!=-1)
        {
            msg+=illegalChars[character1];
            if(character2!=-1)
            {
                msg+="' and '";
                msg+=illegalChars[character2];
            }
        }
        else
            msg+=illegalChars[character2];
        msg+="')";
        dlg = QMessageBox::warning(this, "PINT", msg, QMessageBox::Ok);
        Q_UNUSED(dlg)
        return;
    }
}

bool automaticLabelFormat::errors()
{
    character1=-1;
    character2=-1;
    bool prefixLegal(checkLegal(ui->prefixEdit->text(),1));
    bool suffixLegal(checkLegal(ui->suffixEdit->text(),2));
    if(!prefixLegal || !suffixLegal)
        return true;
    else
        return false;
}

bool automaticLabelFormat::checkLegal(QString str, int type)
{
    for(int i(0); i<str.size(); i++)
        for(int j(0); j<illegalChars.size(); j++)
            if(str[i]==illegalChars[j])
            {
                if(type==1)
                    character1=j;
                else
                    character2=j;
                return false;
            }
    return true;
}

void automaticLabelFormat::updateLabels()
{
    QString str1, str2;
    QString label("<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">%1</span></p></body></html>");
    str1 = ui->prefixEdit->text() + QString::number(ui->baseBox->value()) + ui->suffixEdit->text();
    str2 = ui->prefixEdit->text() + QString::number(ui->baseBox->value()+ui->incrementBox->value()) + ui->suffixEdit->text();

    ui->ex1Label->setText(label.arg(str1));
    ui->ex2Label->setText(label.arg(str2));
}
