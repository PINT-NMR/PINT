#include "customitemproperties.h"

customItemProperties::customItemProperties(QObject *parent)
    : QObject(parent), pointerAnimation(0), targetItem(0), nonselectedLabel(0),
      selectedLabel(0), labelScaling(QVector3D(0,0,0)), targetScaling(QVector3D(0,0,0))
{}

customItemProperties::~customItemProperties()
{}
