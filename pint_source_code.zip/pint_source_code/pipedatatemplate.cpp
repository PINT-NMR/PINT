#include "pipedatatemplate.h"


pipeDataTemplate::pipeDataTemplate() :
    sizeF2(0), swF2(.0), obsF2(.0), origF2(.0), sizeF1(0),
    swF1(.0), obsF1(.0), origF1(.0), deltaF1(.0), deltaF2(.0),
    firstF1(.0), firstF2(.0), f1(0), f2(0), y(0), imin(0), jmin(0),
    imax(0), jmax(0), _F1(.0), _F2(.0), _y(.0), nPlane(0), xDimF1(0),
    xDimF2(0), xDimF3(0), nc_proc(0)
{
    for(int i(0); i<512; ++i) header[i]=.0;
}

pipeDataTemplate::~pipeDataTemplate()
{

}
