#ifndef CUSTOMMAGNIFIER_H
#define CUSTOMMAGNIFIER_H
#include <qwt/qwt_plot_magnifier.h>
#include <qwt/qwt_scale_div.h>
#include <qwt/qwt_plot.h>
#include <qobject.h>



class customMagnifier: public QwtPlotMagnifier
{
    Q_OBJECT
    double minF2;
    double minF1;
    double maxF2;
    double maxF1;
public:
    customMagnifier( QWidget *canvas,double minX,double maxX,double minY,double maxY):
        QwtPlotMagnifier ( canvas ), minF2(minX), minF1(minY), maxF2(maxX), maxF1(maxY)
    {}
    ~customMagnifier()
    {
    }

    virtual void rescale(double factor)
    {
        QwtPlot* plt = plot();
        if ( plt == NULL )
            return;
        factor = qAbs( factor );
        if ( factor == 1.0 || factor == 0.0 )
            return;
        bool doReplot = false;
        const bool autoReplot = plt->autoReplot();
        plt->setAutoReplot( false );
        bool maxedOutX(false);
        bool maxedOutY(false);

        for ( int axisId = 0; axisId < QwtPlot::axisCnt-1; axisId++ )
        {
            const QwtScaleDiv &scaleDiv = plt->axisScaleDiv( axisId );
            if ( isAxisEnabled( axisId ) )
            {
                const double center = scaleDiv.lowerBound() + scaleDiv.range() / 2;
                const double width_2 = scaleDiv.range() / 2 * (1/factor);

                if(axisId == 0) //F1
                {
                    doReplot = true;
                    if(center + width_2<minF1 && center - width_2>maxF1)
                        maxedOutY=true;
                    plt->setAxisScale( axisId, center - width_2, center + width_2 );
                }
                else if(axisId == 2) //F2
                {
                    doReplot = true;
                    if(center + width_2<minF2 && center - width_2>maxF2)
                        maxedOutX =true;
                    plt->setAxisScale( axisId, center - width_2, center + width_2 );
                }
            }
        }
        if(maxedOutX && maxedOutY)
        {
            plt->setAxisScale( 0, maxF1, minF1 );
            plt->setAxisScale( 2, maxF2, minF2 );
        }
        plt->setAutoReplot( autoReplot );

        if ( doReplot )
            plt->replot();
        emit zoomed();
    }
signals:
    void zoomed();
};

#endif // CUSTOMMAGNIFIER_H
