#ifndef LOADPROJECTWIDGET_H
#define LOADPROJECTWIDGET_H

#include <QWidget>
#include "projecttemplate.h"

namespace Ui {
class loadProjectWidget;
}

class loadProjectWidget : public QWidget
{
    Q_OBJECT

public:
    explicit loadProjectWidget(QWidget *parent = 0, double sF = 1.0);
    ~loadProjectWidget();
    double scaleFactor;
    void scaleWidget();

signals:
    void goBack();
    void subChanged();
    void openProject(projectTemplate);


private:
    QString previousDir;
    bool includeSub;
    QString errMsg;
    bool lockAndLoad;
    Ui::loadProjectWidget *ui;

private slots:
    void on_cancelButton_clicked();
    void setupCosmeticChanges();
    void on_subButton_clicked();
    void makeConnections();
    void toggleSubs();
    void on_browseButton_clicked();
    void updateTable();
    void createFilesTable();
    void openFileOfItem(int row, int col);
    void displayError();
    QFont scaleFont(QFont fnt);
    bool validateTemplate(projectTemplate &tmplate, QString fname);
    QVector<QString> checkFile(QVector<QString> vec);
};

#endif // LOADPROJECTWIDGET_H
