/********************************************************************************
** Form generated from reading UI file 'tooldialog.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOOLDIALOG_H
#define UI_TOOLDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_toolDialog
{
public:
    QGridLayout *gridLayout;
    QLabel *toolLabel;

    void setupUi(QWidget *toolDialog)
    {
        if (toolDialog->objectName().isEmpty())
            toolDialog->setObjectName(QStringLiteral("toolDialog"));
        toolDialog->resize(477, 444);
        gridLayout = new QGridLayout(toolDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        toolLabel = new QLabel(toolDialog);
        toolLabel->setObjectName(QStringLiteral("toolLabel"));
        toolLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/zoomTool.png")));
        toolLabel->setScaledContents(true);

        gridLayout->addWidget(toolLabel, 0, 0, 1, 1);


        retranslateUi(toolDialog);

        QMetaObject::connectSlotsByName(toolDialog);
    } // setupUi

    void retranslateUi(QWidget *toolDialog)
    {
        toolDialog->setWindowTitle(QApplication::translate("toolDialog", "Form", 0));
        toolLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class toolDialog: public Ui_toolDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOOLDIALOG_H
