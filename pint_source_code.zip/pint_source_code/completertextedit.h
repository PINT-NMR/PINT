#ifndef COMPLETERTEXTEDIT_H
#define COMPLETERTEXTEDIT_H
#include <QTextEdit>
#include "customcompleter.h"

class completerTextEdit : public QTextEdit
{
    Q_OBJECT

public:
    completerTextEdit(QWidget *parent = 0);
    ~completerTextEdit();

    void setCompleter(customCompleter *c);
    customCompleter *completer() const;

protected:
    void keyPressEvent(QKeyEvent *e) Q_DECL_OVERRIDE;
    void mousePressEvent(QMouseEvent *e) Q_DECL_OVERRIDE;
    void focusInEvent(QFocusEvent *e) Q_DECL_OVERRIDE;

private slots:
    void insertCompletion(const QString &completion);

private:
    QString textUnderCursor() const;

private:
    customCompleter *c;
};

#endif // COMPLETERTEXTEDIT_H
