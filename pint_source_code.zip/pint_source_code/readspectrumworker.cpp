#include "readspectrumworker.h"
#include <iostream>
#include <cstdlib>
#include <QIODevice>
#include <QFile>
#include <QTime>
#include <math.h>

readSpectrumWorker::readSpectrumWorker(pipeDataTemplate argument, pipeDataTemplate argument2, QObject* parent, int s, QString fnam, bool type, bool planeBoxEnabled, int planeBoxVal, int dim) :
    QObject(parent), pipe((pipeDataTemplate)argument), moddedPipe(argument2), skip(s), fname(fnam), nmrpipe(type), planeEnabled(planeBoxEnabled),
    planeVal(planeBoxVal), nDim(dim), maxF1(-9.0e99), maxF2(-9.0e99), minF1(9.0e99), minF2(9.0e99), cutoffSliderMin(9.0e99), cutoffSliderMax(-9.0e99)
{
}

readSpectrumWorker::~readSpectrumWorker()
{
}

void readSpectrumWorker::process()
{
    if(nmrpipe)
    {
        int u(0);
        int f1Max(0),f2Max(0);
        if(pipe.firstF1!= moddedPipe.firstF1)
        {
            while(pipe.firstF1+pipe.deltaF1*u>moddedPipe.firstF1)
                u+=skip;
            f1Max = u;
        }
        if(pipe.firstF2!= moddedPipe.firstF2)
        {
            u=0;
            while(pipe.firstF2+pipe.deltaF2*u>moddedPipe.firstF2)
                u+=skip;
            f2Max = u;
        }
        pipe.imin=f1Max;
        pipe.jmin=f2Max;
        pipe.imax=pipe.sizeF1;
        pipe.jmax=pipe.sizeF2;
        bool mmap(true); //Memory mapping is much faster but will use more memory!
        if(mmap)
        {
            if(nDim==2 ||nDim==3)
            {
                QFile fp(fname);
                fp.open(QIODevice::ReadOnly);
                int cnt=1;
                if(planeEnabled)
                    cnt=planeVal;
                const int page_size = pipe.sizeF1*pipe.sizeF2*sizeof(float);
                long off(0);
                bool isBigEndian(true);
                union
                {
                    uint32_t i;
                    char c[4];
                } bigint = {0x01020304};

                if(bigint.c[0] != 1)
                    isBigEndian=false;
                int endian(-1);
                int endianStart(3);
                if(isBigEndian) // Big endian byte ordering
                {
                    endian = 1;
                    endianStart = 0;
                }
                off=2048; //skip header
                off+= page_size*(cnt-1); //Skip planes if needed
                uchar *memory = fp.map(off,page_size);
                if(memory)
                {
                    for (int i(pipe.imin); i<pipe.imax; i+=skip)
                    {
                        for (int j=pipe.jmin; j<pipe.jmax; j+=skip)
                        {
                            int u(i*pipe.sizeF2*sizeof(float)+j*sizeof(float));
                            union test
                            {
                                unsigned char buf[4];
                                float number;
                            }tt;
                            tt.buf[endianStart]= memory[u+3];
                            tt.buf[endianStart+endian]= memory[u+2];
                            tt.buf[endianStart+2*endian]= memory[u+1];
                            tt.buf[endianStart+3*endian]= memory[u];
                            pipe._y = tt.number;

                            pipe._F1 = (pipe.firstF1 + (i)*pipe.deltaF1)/pipe.obsF1;
                            pipe._F2 = (pipe.firstF2 + (j)*pipe.deltaF2)/pipe.obsF2;
                            pipe.f1.push_back(pipe._F1);
                            if(pipe._F1>maxF1)
                                maxF1 = pipe._F1;
                            if(pipe._F1<minF1)
                                minF1 = pipe._F1;
                            pipe.f2.push_back(pipe._F2);
                            if(pipe._F2>maxF2)
                                maxF2 = pipe._F2;
                            if(pipe._F2<minF2)
                                minF2 = pipe._F2;
                            pipe.y.push_back(pipe._y);
                            if(pipe._y>cutoffSliderMax)
                                cutoffSliderMax = pipe._y;
                            if(pipe._y<cutoffSliderMin)
                                cutoffSliderMin = pipe._y;
                            if(pipe.f1.size()%moddedPipe.sizeF2 == 0)
                            {
                                break;
                            }
                        }
                        if(pipe.f1.size()%(moddedPipe.sizeF1*moddedPipe.sizeF2) == 0)
                        {
                            break;
                        }
                    }
                    fp.unmap(memory);
                }
                fp.close();
            }
        }
        else
        {
            FILE *fp;
            fp = fopen(fname.toStdString().c_str(), "rb");
            int cnt=1;
            if(planeEnabled)
                cnt=planeVal;
            if(nDim==2 ||nDim==3)
            {
                for (int i(pipe.imin); i<pipe.imax; i+=skip)
                {
                    for (int j=pipe.jmin; j<pipe.jmax; j+=skip)
                    {
                        fseek(fp, 2048+ (cnt-1)*pipe.sizeF1*pipe.sizeF2*4 + i*pipe.sizeF2*4+j*4, 0);
                        fread(&pipe._y, 4, 1, fp);
                        pipe._F1 = (pipe.firstF1 + (i)*pipe.deltaF1)/pipe.obsF1;
                        pipe._F2 = (pipe.firstF2 + (j)*pipe.deltaF2)/pipe.obsF2;
                        pipe.f1.push_back(pipe._F1);
                        if(pipe._F1>maxF1)
                            maxF1 = pipe._F1;
                        if(pipe._F1<minF1)
                            minF1 = pipe._F1;
                        pipe.f2.push_back(pipe._F2);
                        if(pipe._F2>maxF2)
                            maxF2 = pipe._F2;
                        if(pipe._F2<minF2)
                            minF2 = pipe._F2;
                        pipe.y.push_back(pipe._y);
                        if(pipe._y>cutoffSliderMax)
                            cutoffSliderMax = pipe._y;
                        if(pipe._y<cutoffSliderMin)
                            cutoffSliderMin = pipe._y;
                        if(pipe.f1.size()%moddedPipe.sizeF2 == 0)
                        {
                            break;
                        }
                    }
                    if(pipe.f1.size()%(moddedPipe.sizeF1*moddedPipe.sizeF2) == 0)
                    {
                        break;
                    }
                }
            }
            fclose(fp);
        }
        pipe.swF1 = -pipe.deltaF1*(double)moddedPipe.sizeF1*skip;
        pipe.swF2 = -pipe.deltaF2*(double)moddedPipe.sizeF2*skip;
        pipe.firstF1 = moddedPipe.firstF1;
        pipe.firstF2 = moddedPipe.firstF2;
        pipe.sizeF1 = moddedPipe.sizeF1;
        pipe.sizeF2 = moddedPipe.sizeF2;
    }
    else //Topspin
    {
        int u(0);
        int f1Max(0),f2Max(0);
        if(pipe.firstF1!= moddedPipe.firstF1)
        {
            while(pipe.firstF1+pipe.deltaF1*u>moddedPipe.firstF1)
                u+=skip;
            f1Max = u;
        }
        if(pipe.firstF2!= moddedPipe.firstF2)
        {
            u=0;
            while(pipe.firstF2+pipe.deltaF2*u>moddedPipe.firstF2)
                u+=skip;
            f2Max = u;
        }

        pipe.imin=0;
        pipe.jmin=0;
        pipe.imax=pipe.sizeF1;
        pipe.jmax=pipe.sizeF2;
        if(!pipe.nc_proc)
            pipe.nc_proc=1;
        //bool mmap(false);
        //mmap = true;

        if(nDim==2 || nDim==3)
        {
            //Sequential reading through memory map subcubes
            QString ext("/2rr");
            if(nDim==3)
                ext="/3rrr";
            QFile fp(fname+ext);
            fp.open(QIODevice::ReadOnly);

            int a;
            int submatrixF1 = pipe.sizeF1/pipe.xDimF1;
            int submatrixF2 = pipe.sizeF2/pipe.xDimF2;

            const int page_size = pipe.xDimF1*pipe.xDimF2*pipe.xDimF3*sizeof(int);
            long off(0);
            int cnt=1;
            if(planeEnabled)
                cnt=planeVal;

            pipe.f1 = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);
            pipe.f2 = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);
            pipe.y = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);

            bool isBigEndian(true);
            union
            {
                uint32_t i;
                char c[4];
            } bigint = {0x01020304};

            if(bigint.c[0] != 1)
                isBigEndian=false;
            vector<double> tmp_y = vector<double>(pipe.sizeF1/skip*pipe.sizeF2/skip);
            int endian(-1);
            int endianStart(3);
            if(isBigEndian) // Big endian byte ordering
            {
                endian = 1;
                endianStart = 0;
            }
            int cc(0);
            off= page_size*submatrixF2*submatrixF1 *(int)(floor)((cnt-1)/pipe.xDimF3); //Skip submatrix in F3 if needed
            off+=sizeof(int)*pipe.xDimF2*pipe.xDimF1*(cnt-1-pipe.xDimF3*(int)(floor)((cnt-1)/pipe.xDimF3)); //Skip planes in submatrix if needed
            while(off<fp.size())
            {
                uchar *memory = fp.map(off,page_size);
                if(memory)
                {
                    int count(0);
                    for(ulong i(endianStart); i<pipe.xDimF1*pipe.xDimF2*sizeof(int);i+=4*skip)
                    {
                        a = memory[i];
                        a = a*256 + memory[i+endian];
                        a = a*256 + memory[i+2*endian];
                        a = a*256 + memory[i+3*endian];
                        a = (int)((double) a * (double)pow(2,pipe.nc_proc)+0.5f); //Compensate for the 2^N Bruker scaling factor
                        tmp_y[cc++] = a;
                        count+=skip;
                        if(count%pipe.xDimF2 == 0)
                        {
                            count = 0;
                            i+=pipe.xDimF2*4*(skip-1);
                        }
                    }
                    fp.unmap(memory);
                }
                off+=page_size;
                if(cc==(int)tmp_y.size())
                    break;
            }
            fp.close();
            int countingF2(0);
            cc=0;
            for(ulong i(f2Max/skip+f1Max/skip*((int)pipe.sizeF2/skip)); i<tmp_y.size(); ++i)
            {
                int v = i + (pipe.xDimF2/skip * pipe.xDimF1/skip - pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip/(double)pipe.xDimF2)))
                        + (pipe.xDimF2/skip-submatrixF2*pipe.xDimF1/skip*pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip/(double)pipe.sizeF2)))
                        + ((submatrixF2-1)*pipe.xDimF1/skip*pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip*skip/(double)(pipe.sizeF2*pipe.xDimF1))));

                pipe.y[cc] = tmp_y[v];
                pipe.f1[cc] = (pipe.firstF1 + ((int)(floor)(i*skip/pipe.sizeF2))*skip*pipe.deltaF1)/pipe.obsF1;
                pipe.f2[cc] = (pipe.firstF2 + (i*skip - pipe.sizeF2*(int)(floor)(i*skip/pipe.sizeF2))*pipe.deltaF2)/pipe.obsF2;
                if(pipe.f1[cc]>maxF1)
                    maxF1 = pipe.f1[cc];
                if(pipe.f1[cc]<minF1)
                    minF1 = pipe.f1[cc];
                if(pipe.f2[cc]>maxF2)
                    maxF2 = pipe.f2[cc];
                if(pipe.f2[cc]<minF2)
                    minF2 = pipe.f2[cc];
                if((float) pipe.y[cc]>cutoffSliderMax)
                    cutoffSliderMax = (float) pipe.y[cc];
                if((float) pipe.y[cc]<cutoffSliderMin)
                    cutoffSliderMin = (float) pipe.y[cc];
                ++countingF2;
                ++cc;
                if(cc==(int)pipe.y.size())
                    break;
                if(countingF2==moddedPipe.sizeF2)
                {
                    i+=pipe.sizeF2/skip-countingF2;
                    countingF2=0;
                }
            }
            pipe.swF1 = -pipe.deltaF1*(double)moddedPipe.sizeF1*skip;
            pipe.swF2 = -pipe.deltaF2*(double)moddedPipe.sizeF2*skip;
            pipe.firstF1 = moddedPipe.firstF1;
            pipe.firstF2 = moddedPipe.firstF2;
            pipe.sizeF1 = moddedPipe.sizeF1;
            pipe.sizeF2 = moddedPipe.sizeF2;
        }

        /*
        if(nDim==2)
        {
            if(mmap)
            {
                //Sequential reading through memory map subcubes
                QFile fp((QString)(fname+"/2rr"));
                fp.open(QIODevice::ReadOnly);

                int a;
                int submatrixF1 = pipe.sizeF1/pipe.xDimF1;
                int submatrixF2 = pipe.sizeF2/pipe.xDimF2;

                const int page_size = pipe.xDimF1*pipe.xDimF2*sizeof(int);
                long off(0);
                int cnt=1;
                if(planeEnabled)
                    cnt=planeVal;

                pipe.f1 = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);
                pipe.f2 = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);
                pipe.y = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);

                bool isBigEndian(true);
                union
                {
                    uint32_t i;
                    char c[4];
                } bigint = {0x01020304};

                if(bigint.c[0] != 1)
                    isBigEndian=false;
                vector<double> tmp_y = vector<double>(pipe.sizeF1/skip*pipe.sizeF2/skip);
                int endian(-1);
                int endianStart(3);
                if(isBigEndian) // Big endian byte ordering
                {
                    endian = 1;
                    endianStart = 0;
                }
                int cc(0);
                off= page_size*submatrixF2*submatrixF1 *(int)(floor)((cnt-1)/pipe.xDimF3); //Skip submatrix in F3 if needed
                off+=sizeof(int)*pipe.xDimF2*pipe.xDimF1*(cnt-1-pipe.xDimF3*(int)(floor)((cnt-1)/pipe.xDimF3)); //Skip planes in submatrix if needed
                while(off<fp.size())
                {
                    uchar *memory = fp.map(off,page_size);
                    if(memory)
                    {
                        int count(0);
                        for(int i(endianStart); i<pipe.xDimF1*pipe.xDimF2*sizeof(int);i+=4*skip)
                        {
                            a = memory[i];
                            a = a*256 + memory[i+endian];
                            a = a*256 + memory[i+2*endian];
                            a = a*256 + memory[i+3*endian];
                            a = (int)((double) a * (double)pow(2,pipe.nc_proc)+0.5f); //Compensate for the 2^N Bruker scaling factor
                            tmp_y[cc++] = a;
                            count+=skip;
                            if(count%pipe.xDimF2 == 0)
                            {
                                count = 0;
                                i+=pipe.xDimF2*4*(skip-1);
                            }
                        }
                        fp.unmap(memory);
                    }
                    off+=page_size;
                    if(cc==tmp_y.size())
                        break;
                }
                fp.close();
                int countingF2(0);
                cc=0;
                for(int i(f2Max/skip+f1Max/skip*((int)pipe.sizeF2/skip)); i<tmp_y.size(); ++i)
                {
                    int v = i + (pipe.xDimF2/skip * pipe.xDimF1/skip - pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip/(double)pipe.xDimF2)))
                            + (pipe.xDimF2/skip-submatrixF2*pipe.xDimF1/skip*pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip/(double)pipe.sizeF2)))
                            + ((submatrixF2-1)*pipe.xDimF1/skip*pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip*skip/(double)(pipe.sizeF2*pipe.xDimF1))));

                    pipe.y[cc] = tmp_y[v];
                    pipe.f1[cc] = (pipe.firstF1 + ((int)(floor)(i*skip/pipe.sizeF2))*skip*pipe.deltaF1)/pipe.obsF1;
                    pipe.f2[cc] = (pipe.firstF2 + (i*skip - pipe.sizeF2*(int)(floor)(i*skip/pipe.sizeF2))*pipe.deltaF2)/pipe.obsF2;
                    if(pipe.f1[cc]>maxF1)
                        maxF1 = pipe.f1[cc];
                    if(pipe.f1[cc]<minF1)
                        minF1 = pipe.f1[cc];
                    if(pipe.f2[cc]>maxF2)
                        maxF2 = pipe.f2[cc];
                    if(pipe.f2[cc]<minF2)
                        minF2 = pipe.f2[cc];
                    if((float) pipe.y[cc]>cutoffSliderMax)
                        cutoffSliderMax = (float) pipe.y[cc];
                    if((float) pipe.y[cc]<cutoffSliderMin)
                        cutoffSliderMin = (float) pipe.y[cc];
                    ++countingF2;
                    ++cc;
                    if(cc==pipe.y.size())
                        break;
                    if(countingF2==moddedPipe.sizeF2)
                    {
                        i+=pipe.sizeF2/skip-countingF2;
                        countingF2=0;
                    }
                }
            }
            else
            {
                FILE *fp;
                fp = fopen((fname.toStdString()+"/2rr").c_str(), "rb");
                int a;
                int submatrixF2 = pipe.sizeF2/pipe.xDimF2;
                int countingF2(0);

                for (int i=f2Max+f1Max*((int)pipe.sizeF2); (int)pipe.f1.size() < (int) moddedPipe.sizeF1*moddedPipe.sizeF2; i+=(int)skip)
                {
                    int v = i - pipe.xDimF2 * (int)((floor)((double)((double)i/(double)pipe.xDimF2))) + pipe.xDimF1 * pipe.xDimF2 * (int)((floor)((double)((double)i/(double)pipe.xDimF2)))
                            - pipe.xDimF2 * (pipe.xDimF1 * submatrixF2-1) * (int)((floor)((double)((double)i/(double)(pipe.xDimF2 * submatrixF2))))
                            + pipe.xDimF2 * pipe.xDimF1 * (submatrixF2-1) * (int)((floor)((double)((double)i/(double)(pipe.xDimF2 * pipe.xDimF1 * submatrixF2))));
                    fseek(fp, v*4, 0);
                    fread(&a, sizeof(int), 1, fp);
                    pipe._F1 = (pipe.firstF1 + ((int)(floor)(v/pipe.sizeF2))*pipe.deltaF1)/pipe.obsF1;
                    pipe._F2 = (pipe.firstF2 + (v - pipe.sizeF2*(int)(floor)(v/pipe.sizeF2))*pipe.deltaF2)/pipe.obsF2;
                    pipe.f1.push_back(pipe._F1);
                    if(pipe._F1>maxF1)
                        maxF1 = pipe._F1;
                    if(pipe._F1<minF1)
                        minF1 = pipe._F1;
                    pipe.f2.push_back(pipe._F2);
                    if(pipe._F2>maxF2)
                        maxF2 = pipe._F2;
                    if(pipe._F2<minF2)
                        minF2 = pipe._F2;
                    a = (int)((double) a * (double)pow(2,pipe.nc_proc)+0.5f); //Compensate for the 2^N Bruker scaling factor
                    pipe.y.push_back((float) a);
                    if((float) a>cutoffSliderMax)
                        cutoffSliderMax = (float) a;
                    if((float) a<cutoffSliderMin)
                        cutoffSliderMin = (float) a;
                    countingF2++;
                    if(countingF2==moddedPipe.sizeF2)
                    {
                        i+=(pipe.sizeF2-skip)-(skip*countingF2+f2Max);
                        i+=(skip-1)*pipe.sizeF2+f2Max+skip;
                        countingF2=0;
                    }
                }
                fclose(fp);
            }
            pipe.swF1 = -pipe.deltaF1*(double)moddedPipe.sizeF1*skip;
            pipe.swF2 = -pipe.deltaF2*(double)moddedPipe.sizeF2*skip;
            pipe.firstF1 = moddedPipe.firstF1;
            pipe.firstF2 = moddedPipe.firstF2;
            pipe.sizeF1 = moddedPipe.sizeF1;
            pipe.sizeF2 = moddedPipe.sizeF2;
        }
        else if(nDim==3)
        {
            if(mmap)
            {
                //Sequential reading through memory map subcubes
                QFile fp((QString)(fname+"/3rrr"));
                fp.open(QIODevice::ReadOnly);

                int a;
                int submatrixF1 = pipe.sizeF1/pipe.xDimF1;
                int submatrixF2 = pipe.sizeF2/pipe.xDimF2;

                const int page_size = pipe.xDimF1*pipe.xDimF2*pipe.xDimF3*sizeof(int);
                long off(0);
                int cnt=1;
                if(planeEnabled)
                    cnt=planeVal;

                pipe.f1 = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);
                pipe.f2 = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);
                pipe.y = vector<double>(moddedPipe.sizeF1*moddedPipe.sizeF2);

                bool isBigEndian(true);
                union
                {
                    uint32_t i;
                    char c[4];
                } bigint = {0x01020304};

                if(bigint.c[0] != 1)
                    isBigEndian=false;
                vector<double> tmp_y = vector<double>(pipe.sizeF1/skip*pipe.sizeF2/skip);
                int endian(-1);
                int endianStart(3);
                if(isBigEndian) // Big endian byte ordering
                {
                    endian = 1;
                    endianStart = 0;
                }
                int cc(0);
                off= page_size*submatrixF2*submatrixF1 *(int)(floor)((cnt-1)/pipe.xDimF3); //Skip submatrix in F3 if needed
                off+=sizeof(int)*pipe.xDimF2*pipe.xDimF1*(cnt-1-pipe.xDimF3*(int)(floor)((cnt-1)/pipe.xDimF3)); //Skip planes in submatrix if needed
                while(off<fp.size())
                {
                    uchar *memory = fp.map(off,page_size);
                    if(memory)
                    {
                        int count(0);
                        for(int i(endianStart); i<pipe.xDimF1*pipe.xDimF2*sizeof(int);i+=4*skip)
                        {
                            a = memory[i];
                            a = a*256 + memory[i+endian];
                            a = a*256 + memory[i+2*endian];
                            a = a*256 + memory[i+3*endian];
                            a = (int)((double) a * (double)pow(2,pipe.nc_proc)+0.5f); //Compensate for the 2^N Bruker scaling factor
                            tmp_y[cc++] = a;
                            count+=skip;
                            if(count%pipe.xDimF2 == 0)
                            {
                                count = 0;
                                i+=pipe.xDimF2*4*(skip-1);
                            }
                        }
                        fp.unmap(memory);
                    }
                    off+=page_size;
                    if(cc==tmp_y.size())
                        break;
                }
                fp.close();
                int countingF2(0);
                cc=0;
                for(int i(f2Max/skip+f1Max/skip*((int)pipe.sizeF2/skip)); i<tmp_y.size(); ++i)
                {
                    int v = i + (pipe.xDimF2/skip * pipe.xDimF1/skip - pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip/(double)pipe.xDimF2)))
                            + (pipe.xDimF2/skip-submatrixF2*pipe.xDimF1/skip*pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip/(double)pipe.sizeF2)))
                            + ((submatrixF2-1)*pipe.xDimF1/skip*pipe.xDimF2/skip)*(int)((floor)((double)((double)i*skip*skip/(double)(pipe.sizeF2*pipe.xDimF1))));

                    pipe.y[cc] = tmp_y[v];
                    pipe.f1[cc] = (pipe.firstF1 + ((int)(floor)(i*skip/pipe.sizeF2))*skip*pipe.deltaF1)/pipe.obsF1;
                    pipe.f2[cc] = (pipe.firstF2 + (i*skip - pipe.sizeF2*(int)(floor)(i*skip/pipe.sizeF2))*pipe.deltaF2)/pipe.obsF2;
                    if(pipe.f1[cc]>maxF1)
                        maxF1 = pipe.f1[cc];
                    if(pipe.f1[cc]<minF1)
                        minF1 = pipe.f1[cc];
                    if(pipe.f2[cc]>maxF2)
                        maxF2 = pipe.f2[cc];
                    if(pipe.f2[cc]<minF2)
                        minF2 = pipe.f2[cc];
                    if((float) pipe.y[cc]>cutoffSliderMax)
                        cutoffSliderMax = (float) pipe.y[cc];
                    if((float) pipe.y[cc]<cutoffSliderMin)
                        cutoffSliderMin = (float) pipe.y[cc];
                    ++countingF2;
                    ++cc;
                    if(cc==pipe.y.size())
                        break;
                    if(countingF2==moddedPipe.sizeF2)
                    {
                        i+=pipe.sizeF2/skip-countingF2;
                        countingF2=0;
                    }
                }
            }
            else // Random reading directly converting to PINT vector format WORKS!
            {
                FILE *fp;
                fp = fopen((fname.toStdString()+"/3rrr").c_str(), "rb");

                int a;
                int submatrixF1 = pipe.sizeF1/pipe.xDimF1;
                int submatrixF2 = pipe.sizeF2/pipe.xDimF2;
                //int submatrixF3 = pipe.nPlane/pipe.xDimF3;

                int countingF2(0);
                //int freqF2(f2Max);
                int cnt=1;
                if(planeEnabled)
                    cnt=planeVal;
                int planeSkip  = (cnt-1)*pipe.xDimF2*pipe.xDimF1 + (int)((floor)((double)((double)(cnt-1)/(double)pipe.xDimF3)))
                        * (-pipe.xDimF3*pipe.xDimF2*pipe.xDimF1 + pipe.xDimF1*pipe.xDimF2*pipe.xDimF3*submatrixF2*submatrixF1);
                int b((pipe.xDimF1*pipe.xDimF2*pipe.xDimF3-pipe.xDimF2));
                int c(pipe.xDimF2 - pipe.xDimF2*pipe.xDimF1*pipe.xDimF3*submatrixF2);
                int d(pipe.sizeF2*pipe.xDimF1);
                int e((pipe.xDimF1*pipe.xDimF2*pipe.xDimF3*submatrixF2 - pipe.xDimF1*pipe.xDimF2));
                for (int i=f2Max+f1Max*((int)pipe.sizeF2); (int)pipe.f1.size() < (int) moddedPipe.sizeF1*moddedPipe.sizeF2; i+=(int)skip)
                {
                    int v = planeSkip + i + (int)((floor)((double)((double)i/(double)pipe.xDimF2))) * b
                            + (int)((floor)((double)((double)i/(double)pipe.sizeF2))) * c
                            + (int)((floor)((double)((double)i/(double)d))) * e;
                    //int v = planeSkip + i + (int)((floor)((double)((double)i/(double)pipe.xDimF2))) * (pipe.xDimF1*pipe.xDimF2*pipe.xDimF3-pipe.xDimF2)
                    //      + (int)((floor)((double)((double)i/(double)pipe.sizeF2))) * (- pipe.xDimF2*pipe.xDimF1*pipe.xDimF3*submatrixF2 + pipe.xDimF2)
                    //    + (int)((floor)((double)((double)i/(double)(pipe.sizeF2*pipe.xDimF1)))) * (pipe.xDimF1*pipe.xDimF2*pipe.xDimF3*submatrixF2 - pipe.xDimF1*pipe.xDimF2);

                    fseek(fp, v*4, 0);
                    fread(&a, sizeof(int), 1, fp);
                    pipe._F1 = (pipe.firstF1 + ((int)(floor)(i/pipe.sizeF2))*pipe.deltaF1)/pipe.obsF1;
                    pipe._F2 = (pipe.firstF2 + (i - pipe.sizeF2*(int)(floor)(i/pipe.sizeF2))*pipe.deltaF2)/pipe.obsF2;
                    pipe.f1.push_back(pipe._F1);
                    if(pipe._F1>maxF1)
                        maxF1 = pipe._F1;
                    if(pipe._F1<minF1)
                        minF1 = pipe._F1;
                    pipe.f2.push_back(pipe._F2);
                    if(pipe._F2>maxF2)
                        maxF2 = pipe._F2;
                    if(pipe._F2<minF2)
                        minF2 = pipe._F2;
                    a = (int)((double) a * (double)pow(2,pipe.nc_proc)+0.5f); //Compensate for the 2^N Bruker scaling factor
                    pipe.y.push_back((float) a);
                    if((float) a>cutoffSliderMax)
                        cutoffSliderMax = (float) a;
                    if((float) a<cutoffSliderMin)
                        cutoffSliderMin = (float) a;

                    countingF2++;
                    if(countingF2==moddedPipe.sizeF2)
                    {
                        i+=(pipe.sizeF2-skip)-(skip*countingF2+f2Max);
                        i+=(skip-1)*pipe.sizeF2+f2Max+skip;
                        countingF2=0;
                    }
                }
                fclose(fp);
            }
            pipe.swF1 = -pipe.deltaF1*(double)moddedPipe.sizeF1*skip;
            pipe.swF2 = -pipe.deltaF2*(double)moddedPipe.sizeF2*skip;
            pipe.firstF1 = moddedPipe.firstF1;
            pipe.firstF2 = moddedPipe.firstF2;
            pipe.sizeF1 = moddedPipe.sizeF1;
            pipe.sizeF2 = moddedPipe.sizeF2;
        }
        */
    }
    emit finished(pipe, minF1, maxF1, minF2, maxF2, cutoffSliderMin, cutoffSliderMax);
}
