#ifndef NEWPROJECTWIDGET_H
#define NEWPROJECTWIDGET_H

#include <QWidget>
#include "projecttemplate.h"

namespace Ui {
class newProjectWidget;
}

class newProjectWidget : public QWidget
{
    Q_OBJECT

public:
    explicit newProjectWidget(QWidget *parent = 0, double sF = 1.0);
    ~newProjectWidget();
    double scaleFactor;
    void scaleWidget();

signals:
    void goBack();
    void loadWorkspace(projectTemplate);

private:
    QString previousDir;
    QMovie *movie;
    Ui::newProjectWidget *ui;

private slots:
    void on_cancelButton_clicked();
    void setupCosmeticChanges();
    void on_okButton_clicked();
    int checkTemplateErrors(projectTemplate tmplate);
    bool removeDir(const QString & dirName);
    void on_browseButton_clicked();
    QFont scaleFont(QFont fnt);
};

#endif // NEWPROJECTWIDGET_H
