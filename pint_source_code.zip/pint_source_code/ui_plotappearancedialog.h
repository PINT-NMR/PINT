/********************************************************************************
** Form generated from reading UI file 'plotappearancedialog.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLOTAPPEARANCEDIALOG_H
#define UI_PLOTAPPEARANCEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_plotAppearanceDialog
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_16;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_14;
    QHBoxLayout *horizontalLayout_13;
    QLabel *loadPresetName;
    QComboBox *loadPresetBox;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *loadPresetButton;
    QSpacerItem *horizontalSpacer_6;
    QLabel *loadLabel;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_7;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *deletePresetButton;
    QSpacerItem *horizontalSpacer_8;
    QLabel *deletePresetButton_2;
    QFrame *line_2;
    QHBoxLayout *horizontalLayout;
    QLabel *presetNameLabel;
    QLineEdit *presetNameEdit;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QPushButton *savePresetButton;
    QSpacerItem *horizontalSpacer_2;
    QLabel *savePresetLabel;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *cancelButton;
    QSpacerItem *horizontalSpacer_4;
    QLabel *cancelLabel;
    QFrame *line_3;
    QHBoxLayout *horizontalLayout_33;
    QSpacerItem *horizontalSpacer_29;
    QHBoxLayout *horizontalLayout_39;
    QVBoxLayout *verticalLayout_12;
    QHBoxLayout *horizontalLayout_12;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *labelBgColorButton;
    QLabel *labelBgColorLabel;
    QHBoxLayout *horizontalLayout_8;
    QPushButton *labelBorderColorButton;
    QLabel *labelBorderColorLabel;
    QSpacerItem *horizontalSpacer_13;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer_9;
    QLabel *exampleLabelLabel;
    QSpacerItem *horizontalSpacer_10;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_11;
    QLabel *exampleLabel;
    QSpacerItem *horizontalSpacer_12;
    QFrame *line_4;
    QHBoxLayout *horizontalLayout_15;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout_16;
    QPushButton *foldedBgColorButton;
    QLabel *foldedBgColorLabel;
    QHBoxLayout *horizontalLayout_17;
    QPushButton *foldedBorderColorButton;
    QLabel *foldedBorderColorLabel_2;
    QSpacerItem *horizontalSpacer_14;
    QVBoxLayout *verticalLayout_9;
    QHBoxLayout *horizontalLayout_19;
    QSpacerItem *horizontalSpacer_15;
    QLabel *foldedExampleLabelLabel;
    QSpacerItem *horizontalSpacer_16;
    QHBoxLayout *horizontalLayout_20;
    QSpacerItem *horizontalSpacer_17;
    QLabel *foldedExampleLabel;
    QSpacerItem *horizontalSpacer_18;
    QFrame *line_5;
    QHBoxLayout *horizontalLayout_21;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_22;
    QPushButton *selectedBgColorButton;
    QLabel *selectedBgColorLabel;
    QHBoxLayout *horizontalLayout_23;
    QPushButton *selectedBorderColorButton;
    QLabel *selectedBorderColorLabel;
    QSpacerItem *horizontalSpacer_19;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_25;
    QSpacerItem *horizontalSpacer_20;
    QLabel *selectedExampleLabelLabel;
    QSpacerItem *horizontalSpacer_21;
    QHBoxLayout *horizontalLayout_26;
    QSpacerItem *horizontalSpacer_22;
    QLabel *selectedExampleLabel;
    QSpacerItem *horizontalSpacer_23;
    QFrame *line_6;
    QHBoxLayout *horizontalLayout_27;
    QVBoxLayout *verticalLayout_13;
    QHBoxLayout *horizontalLayout_28;
    QPushButton *moveBgColorButton;
    QLabel *moveBgColorLabel;
    QHBoxLayout *horizontalLayout_29;
    QPushButton *moveBorderColorButton;
    QLabel *moveBorderColorLabel;
    QSpacerItem *horizontalSpacer_24;
    QVBoxLayout *verticalLayout_14;
    QHBoxLayout *horizontalLayout_31;
    QSpacerItem *horizontalSpacer_25;
    QLabel *moveExampleLabelLabel;
    QSpacerItem *horizontalSpacer_26;
    QHBoxLayout *horizontalLayout_32;
    QSpacerItem *horizontalSpacer_27;
    QLabel *moveExampleLabel;
    QSpacerItem *horizontalSpacer_28;
    QFrame *line;
    QHBoxLayout *horizontalLayout_37;
    QHBoxLayout *horizontalLayout_34;
    QPushButton *selectionColorButton;
    QLabel *selectionColorLabel;
    QSpacerItem *horizontalSpacer_33;
    QVBoxLayout *verticalLayout_15;
    QHBoxLayout *horizontalLayout_35;
    QSpacerItem *horizontalSpacer_35;
    QLabel *selectionExampleLabel;
    QSpacerItem *horizontalSpacer_34;
    QHBoxLayout *horizontalLayout_36;
    QSpacerItem *horizontalSpacer_37;
    QLabel *selectionPointerLabel;
    QSpacerItem *horizontalSpacer_36;
    QFrame *line_10;
    QHBoxLayout *horizontalLayout_24;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *markerButton;
    QLabel *labelBorderColorLabel_2;
    QSpacerItem *horizontalSpacer_44;
    QVBoxLayout *verticalLayout_19;
    QHBoxLayout *horizontalLayout_48;
    QSpacerItem *horizontalSpacer_39;
    QLabel *markerExampleLabel;
    QSpacerItem *horizontalSpacer_40;
    QHBoxLayout *horizontalLayout_18;
    QSpacerItem *horizontalSpacer_41;
    QLabel *markerLabel;
    QSpacerItem *horizontalSpacer_43;
    QFrame *line_8;
    QVBoxLayout *verticalLayout_17;
    QHBoxLayout *horizontalLayout_38;
    QVBoxLayout *verticalLayout_18;
    QHBoxLayout *horizontalLayout_41;
    QHBoxLayout *horizontalLayout_40;
    QPushButton *gradientButton;
    QLabel *gradientLabel_2;
    QSpacerItem *horizontalSpacer_42;
    QHBoxLayout *horizontalLayout_42;
    QPushButton *gridlineColorButton;
    QLabel *gridlineColorLabel;
    QSpacerItem *horizontalSpacer_46;
    QHBoxLayout *horizontalLayout_43;
    QPushButton *gridBgColorButton;
    QLabel *gridBgColorLabel;
    QSpacerItem *horizontalSpacer_47;
    QHBoxLayout *horizontalLayout_44;
    QPushButton *areaColorButton;
    QLabel *areaColorLabel;
    QSpacerItem *horizontalSpacer_48;
    QSpacerItem *horizontalSpacer_38;
    QVBoxLayout *verticalLayout_20;
    QHBoxLayout *horizontalLayout_45;
    QPushButton *axisColorButton;
    QLabel *axisLabel;
    QSpacerItem *horizontalSpacer_49;
    QHBoxLayout *horizontalLayout_46;
    QPushButton *axisTextColorButton;
    QLabel *axisTextLabel;
    QSpacerItem *horizontalSpacer_50;
    QHBoxLayout *horizontalLayout_47;
    QRadioButton *boxButton;
    QSpacerItem *horizontalSpacer_31;
    QFrame *line_9;
    QLabel *foldedExampleLabelLabel_2;
    QWidget *exampleSpectrumWidget;
    QSpacerItem *horizontalSpacer_30;
    QFrame *line_7;

    void setupUi(QDialog *plotAppearanceDialog)
    {
        if (plotAppearanceDialog->objectName().isEmpty())
            plotAppearanceDialog->setObjectName(QStringLiteral("plotAppearanceDialog"));
        plotAppearanceDialog->resize(1329, 728);
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(plotAppearanceDialog->sizePolicy().hasHeightForWidth());
        plotAppearanceDialog->setSizePolicy(sizePolicy);
        plotAppearanceDialog->setMaximumSize(QSize(16777215, 16777215));
        plotAppearanceDialog->setStyleSheet(QStringLiteral("QDialog#plotAppearanceDialog {background-image: url(:/img/bgui.png);}"));
        gridLayout = new QGridLayout(plotAppearanceDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setObjectName(QStringLiteral("verticalLayout_16"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        loadPresetName = new QLabel(plotAppearanceDialog);
        loadPresetName->setObjectName(QStringLiteral("loadPresetName"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(loadPresetName->sizePolicy().hasHeightForWidth());
        loadPresetName->setSizePolicy(sizePolicy1);
        loadPresetName->setMinimumSize(QSize(0, 0));
        QFont font;
        font.setFamily(QStringLiteral("Myriad Pro"));
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(50);
        loadPresetName->setFont(font);

        horizontalLayout_13->addWidget(loadPresetName);

        loadPresetBox = new QComboBox(plotAppearanceDialog);
        loadPresetBox->setObjectName(QStringLiteral("loadPresetBox"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(loadPresetBox->sizePolicy().hasHeightForWidth());
        loadPresetBox->setSizePolicy(sizePolicy2);
        loadPresetBox->setMinimumSize(QSize(0, 0));
        loadPresetBox->setStyleSheet(QLatin1String("QComboBox#loadPresetBox{\n"
"color: white;\n"
"background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));\n"
"border-color: rgba(71,78,81,255);\n"
"border-width: 2px;\n"
"border-style: solid;\n"
"padding: 1px 0px 1px 3px;\n"
"}"));

        horizontalLayout_13->addWidget(loadPresetBox);


        horizontalLayout_14->addLayout(horizontalLayout_13);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer_5 = new QSpacerItem(13, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_5);

        loadPresetButton = new QPushButton(plotAppearanceDialog);
        loadPresetButton->setObjectName(QStringLiteral("loadPresetButton"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(loadPresetButton->sizePolicy().hasHeightForWidth());
        loadPresetButton->setSizePolicy(sizePolicy3);
        loadPresetButton->setMinimumSize(QSize(30, 30));
        loadPresetButton->setMaximumSize(QSize(30, 30));
        loadPresetButton->setStyleSheet(QLatin1String("QPushButton#loadPresetButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#loadPresetButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#loadPresetButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/img/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        loadPresetButton->setIcon(icon);
        loadPresetButton->setIconSize(QSize(25, 25));

        horizontalLayout_2->addWidget(loadPresetButton);

        horizontalSpacer_6 = new QSpacerItem(13, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_6);


        verticalLayout_3->addLayout(horizontalLayout_2);

        loadLabel = new QLabel(plotAppearanceDialog);
        loadLabel->setObjectName(QStringLiteral("loadLabel"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(loadLabel->sizePolicy().hasHeightForWidth());
        loadLabel->setSizePolicy(sizePolicy4);
        loadLabel->setMinimumSize(QSize(20, 0));
        loadLabel->setMaximumSize(QSize(1000, 1000));
        QFont font1;
        font1.setFamily(QStringLiteral("Myriad Pro"));
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(50);
        loadLabel->setFont(font1);

        verticalLayout_3->addWidget(loadLabel);


        horizontalLayout_14->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        horizontalSpacer_7 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_7);

        deletePresetButton = new QPushButton(plotAppearanceDialog);
        deletePresetButton->setObjectName(QStringLiteral("deletePresetButton"));
        sizePolicy3.setHeightForWidth(deletePresetButton->sizePolicy().hasHeightForWidth());
        deletePresetButton->setSizePolicy(sizePolicy3);
        deletePresetButton->setMinimumSize(QSize(30, 30));
        deletePresetButton->setMaximumSize(QSize(30, 30));
        deletePresetButton->setStyleSheet(QLatin1String("QPushButton#deletePresetButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(155, 57, 57, 255), stop:1 rgba(188, 82, 83, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"color: white;\n"
"}\n"
"QPushButton#deletePresetButton:pressed {\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(107, 36, 37, 255), stop:1 rgba(167, 58, 60, 255));\n"
" border-style: inset;\n"
"color: white;\n"
"}\n"
"QPushButton#deletePresetButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(222, 82, 82, 255), stop:1 rgba(238, 105, 105, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"color: white;\n"
"}"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/img/trash.png"), QSize(), QIcon::Normal, QIcon::Off);
        deletePresetButton->setIcon(icon1);
        deletePresetButton->setIconSize(QSize(25, 25));

        horizontalLayout_7->addWidget(deletePresetButton);

        horizontalSpacer_8 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_8);


        verticalLayout_4->addLayout(horizontalLayout_7);

        deletePresetButton_2 = new QLabel(plotAppearanceDialog);
        deletePresetButton_2->setObjectName(QStringLiteral("deletePresetButton_2"));
        sizePolicy4.setHeightForWidth(deletePresetButton_2->sizePolicy().hasHeightForWidth());
        deletePresetButton_2->setSizePolicy(sizePolicy4);
        deletePresetButton_2->setMinimumSize(QSize(20, 0));
        deletePresetButton_2->setMaximumSize(QSize(1000, 1000));
        deletePresetButton_2->setFont(font1);

        verticalLayout_4->addWidget(deletePresetButton_2);


        horizontalLayout_14->addLayout(verticalLayout_4);

        line_2 = new QFrame(plotAppearanceDialog);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);

        horizontalLayout_14->addWidget(line_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        presetNameLabel = new QLabel(plotAppearanceDialog);
        presetNameLabel->setObjectName(QStringLiteral("presetNameLabel"));
        sizePolicy1.setHeightForWidth(presetNameLabel->sizePolicy().hasHeightForWidth());
        presetNameLabel->setSizePolicy(sizePolicy1);
        presetNameLabel->setMinimumSize(QSize(0, 0));
        presetNameLabel->setFont(font);

        horizontalLayout->addWidget(presetNameLabel);

        presetNameEdit = new QLineEdit(plotAppearanceDialog);
        presetNameEdit->setObjectName(QStringLiteral("presetNameEdit"));
        sizePolicy2.setHeightForWidth(presetNameEdit->sizePolicy().hasHeightForWidth());
        presetNameEdit->setSizePolicy(sizePolicy2);
        presetNameEdit->setMaximumSize(QSize(400, 16777215));

        horizontalLayout->addWidget(presetNameEdit);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(13, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        savePresetButton = new QPushButton(plotAppearanceDialog);
        savePresetButton->setObjectName(QStringLiteral("savePresetButton"));
        sizePolicy3.setHeightForWidth(savePresetButton->sizePolicy().hasHeightForWidth());
        savePresetButton->setSizePolicy(sizePolicy3);
        savePresetButton->setMinimumSize(QSize(30, 30));
        savePresetButton->setMaximumSize(QSize(30, 30));
        savePresetButton->setStyleSheet(QLatin1String("QPushButton#savePresetButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#savePresetButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#savePresetButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/img/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        savePresetButton->setIcon(icon2);
        savePresetButton->setIconSize(QSize(25, 25));

        horizontalLayout_3->addWidget(savePresetButton);

        horizontalSpacer_2 = new QSpacerItem(13, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_3);

        savePresetLabel = new QLabel(plotAppearanceDialog);
        savePresetLabel->setObjectName(QStringLiteral("savePresetLabel"));
        savePresetLabel->setFont(font1);

        verticalLayout->addWidget(savePresetLabel);


        horizontalLayout_5->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalSpacer_3 = new QSpacerItem(13, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_3);

        cancelButton = new QPushButton(plotAppearanceDialog);
        cancelButton->setObjectName(QStringLiteral("cancelButton"));
        sizePolicy3.setHeightForWidth(cancelButton->sizePolicy().hasHeightForWidth());
        cancelButton->setSizePolicy(sizePolicy3);
        cancelButton->setMinimumSize(QSize(30, 30));
        cancelButton->setMaximumSize(QSize(30, 30));
        cancelButton->setStyleSheet(QLatin1String("QPushButton#cancelButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(155, 57, 57, 255), stop:1 rgba(188, 82, 83, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"color: white;\n"
"}\n"
"QPushButton#cancelButton:pressed {\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(107, 36, 37, 255), stop:1 rgba(167, 58, 60, 255));\n"
" border-style: inset;\n"
"color: white;\n"
"}\n"
"QPushButton#cancelButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(222, 82, 82, 255), stop:1 rgba(238, 105, 105, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"color: white;\n"
"}"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/img/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        cancelButton->setIcon(icon3);
        cancelButton->setIconSize(QSize(25, 25));

        horizontalLayout_4->addWidget(cancelButton);

        horizontalSpacer_4 = new QSpacerItem(13, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_4);


        verticalLayout_2->addLayout(horizontalLayout_4);

        cancelLabel = new QLabel(plotAppearanceDialog);
        cancelLabel->setObjectName(QStringLiteral("cancelLabel"));
        sizePolicy1.setHeightForWidth(cancelLabel->sizePolicy().hasHeightForWidth());
        cancelLabel->setSizePolicy(sizePolicy1);
        cancelLabel->setMinimumSize(QSize(0, 0));
        cancelLabel->setMaximumSize(QSize(1000, 1000));
        cancelLabel->setFont(font1);

        verticalLayout_2->addWidget(cancelLabel);


        horizontalLayout_5->addLayout(verticalLayout_2);


        horizontalLayout->addLayout(horizontalLayout_5);


        horizontalLayout_14->addLayout(horizontalLayout);


        verticalLayout_7->addLayout(horizontalLayout_14);

        line_3 = new QFrame(plotAppearanceDialog);
        line_3->setObjectName(QStringLiteral("line_3"));
        sizePolicy2.setHeightForWidth(line_3->sizePolicy().hasHeightForWidth());
        line_3->setSizePolicy(sizePolicy2);
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout_7->addWidget(line_3);


        verticalLayout_16->addLayout(verticalLayout_7);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setObjectName(QStringLiteral("horizontalLayout_33"));
        horizontalSpacer_29 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_33->addItem(horizontalSpacer_29);

        horizontalLayout_39 = new QHBoxLayout();
        horizontalLayout_39->setObjectName(QStringLiteral("horizontalLayout_39"));
        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        labelBgColorButton = new QPushButton(plotAppearanceDialog);
        labelBgColorButton->setObjectName(QStringLiteral("labelBgColorButton"));
        sizePolicy3.setHeightForWidth(labelBgColorButton->sizePolicy().hasHeightForWidth());
        labelBgColorButton->setSizePolicy(sizePolicy3);
        labelBgColorButton->setMinimumSize(QSize(30, 30));
        labelBgColorButton->setMaximumSize(QSize(30, 30));
        labelBgColorButton->setStyleSheet(QLatin1String("QPushButton#labelBgColorButton {\n"
"background-color: rgb(255, 255, 255);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#labelBgColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#labelBgColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        labelBgColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_6->addWidget(labelBgColorButton);

        labelBgColorLabel = new QLabel(plotAppearanceDialog);
        labelBgColorLabel->setObjectName(QStringLiteral("labelBgColorLabel"));
        sizePolicy1.setHeightForWidth(labelBgColorLabel->sizePolicy().hasHeightForWidth());
        labelBgColorLabel->setSizePolicy(sizePolicy1);
        labelBgColorLabel->setMinimumSize(QSize(0, 0));
        labelBgColorLabel->setMaximumSize(QSize(16777215, 16777215));
        labelBgColorLabel->setFont(font);

        horizontalLayout_6->addWidget(labelBgColorLabel);


        verticalLayout_5->addLayout(horizontalLayout_6);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        labelBorderColorButton = new QPushButton(plotAppearanceDialog);
        labelBorderColorButton->setObjectName(QStringLiteral("labelBorderColorButton"));
        sizePolicy3.setHeightForWidth(labelBorderColorButton->sizePolicy().hasHeightForWidth());
        labelBorderColorButton->setSizePolicy(sizePolicy3);
        labelBorderColorButton->setMinimumSize(QSize(30, 30));
        labelBorderColorButton->setMaximumSize(QSize(30, 30));
        labelBorderColorButton->setStyleSheet(QLatin1String("QPushButton#labelBorderColorButton {\n"
"background-color: rgb(0, 0, 0);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#labelBorderColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#labelBorderColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        labelBorderColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_8->addWidget(labelBorderColorButton);

        labelBorderColorLabel = new QLabel(plotAppearanceDialog);
        labelBorderColorLabel->setObjectName(QStringLiteral("labelBorderColorLabel"));
        sizePolicy1.setHeightForWidth(labelBorderColorLabel->sizePolicy().hasHeightForWidth());
        labelBorderColorLabel->setSizePolicy(sizePolicy1);
        labelBorderColorLabel->setMinimumSize(QSize(0, 0));
        labelBorderColorLabel->setMaximumSize(QSize(16777215, 16777215));
        labelBorderColorLabel->setFont(font);

        horizontalLayout_8->addWidget(labelBorderColorLabel);


        verticalLayout_5->addLayout(horizontalLayout_8);


        horizontalLayout_12->addLayout(verticalLayout_5);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_13);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_9);

        exampleLabelLabel = new QLabel(plotAppearanceDialog);
        exampleLabelLabel->setObjectName(QStringLiteral("exampleLabelLabel"));
        sizePolicy1.setHeightForWidth(exampleLabelLabel->sizePolicy().hasHeightForWidth());
        exampleLabelLabel->setSizePolicy(sizePolicy1);
        exampleLabelLabel->setMinimumSize(QSize(0, 0));
        exampleLabelLabel->setMaximumSize(QSize(16777215, 16777215));
        exampleLabelLabel->setFont(font);

        horizontalLayout_10->addWidget(exampleLabelLabel);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_10);


        verticalLayout_6->addLayout(horizontalLayout_10);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_11);

        exampleLabel = new QLabel(plotAppearanceDialog);
        exampleLabel->setObjectName(QStringLiteral("exampleLabel"));
        QSizePolicy sizePolicy5(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(exampleLabel->sizePolicy().hasHeightForWidth());
        exampleLabel->setSizePolicy(sizePolicy5);
        exampleLabel->setMinimumSize(QSize(110, 30));
        exampleLabel->setMaximumSize(QSize(110, 30));
        exampleLabel->setFont(font);
        exampleLabel->setStyleSheet(QLatin1String("QLabel#exampleLabel{\n"
"background-color: rgb(255, 255, 255);\n"
"border-style: outset;\n"
"border-radius: 5px;\n"
"border-width: 3px;\n"
"border-color: rgb(0,0,0);\n"
"}"));

        horizontalLayout_11->addWidget(exampleLabel);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_12);


        verticalLayout_6->addLayout(horizontalLayout_11);


        horizontalLayout_12->addLayout(verticalLayout_6);


        verticalLayout_12->addLayout(horizontalLayout_12);

        line_4 = new QFrame(plotAppearanceDialog);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout_12->addWidget(line_4);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        foldedBgColorButton = new QPushButton(plotAppearanceDialog);
        foldedBgColorButton->setObjectName(QStringLiteral("foldedBgColorButton"));
        sizePolicy3.setHeightForWidth(foldedBgColorButton->sizePolicy().hasHeightForWidth());
        foldedBgColorButton->setSizePolicy(sizePolicy3);
        foldedBgColorButton->setMinimumSize(QSize(30, 30));
        foldedBgColorButton->setMaximumSize(QSize(30, 30));
        foldedBgColorButton->setStyleSheet(QLatin1String("QPushButton#foldedBgColorButton {\n"
"background-color: rgb(111, 137, 160);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#foldedBgColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#foldedBgColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        foldedBgColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_16->addWidget(foldedBgColorButton);

        foldedBgColorLabel = new QLabel(plotAppearanceDialog);
        foldedBgColorLabel->setObjectName(QStringLiteral("foldedBgColorLabel"));
        sizePolicy1.setHeightForWidth(foldedBgColorLabel->sizePolicy().hasHeightForWidth());
        foldedBgColorLabel->setSizePolicy(sizePolicy1);
        foldedBgColorLabel->setMinimumSize(QSize(0, 0));
        foldedBgColorLabel->setMaximumSize(QSize(16777215, 16777215));
        foldedBgColorLabel->setFont(font);

        horizontalLayout_16->addWidget(foldedBgColorLabel);


        verticalLayout_8->addLayout(horizontalLayout_16);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        foldedBorderColorButton = new QPushButton(plotAppearanceDialog);
        foldedBorderColorButton->setObjectName(QStringLiteral("foldedBorderColorButton"));
        sizePolicy3.setHeightForWidth(foldedBorderColorButton->sizePolicy().hasHeightForWidth());
        foldedBorderColorButton->setSizePolicy(sizePolicy3);
        foldedBorderColorButton->setMinimumSize(QSize(30, 30));
        foldedBorderColorButton->setMaximumSize(QSize(30, 30));
        foldedBorderColorButton->setStyleSheet(QLatin1String("QPushButton#foldedBorderColorButton {\n"
"background-color: rgb(0, 0, 0);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#foldedBorderColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#foldedBorderColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        foldedBorderColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_17->addWidget(foldedBorderColorButton);

        foldedBorderColorLabel_2 = new QLabel(plotAppearanceDialog);
        foldedBorderColorLabel_2->setObjectName(QStringLiteral("foldedBorderColorLabel_2"));
        sizePolicy1.setHeightForWidth(foldedBorderColorLabel_2->sizePolicy().hasHeightForWidth());
        foldedBorderColorLabel_2->setSizePolicy(sizePolicy1);
        foldedBorderColorLabel_2->setMinimumSize(QSize(0, 0));
        foldedBorderColorLabel_2->setMaximumSize(QSize(16777215, 16777215));
        foldedBorderColorLabel_2->setFont(font);

        horizontalLayout_17->addWidget(foldedBorderColorLabel_2);


        verticalLayout_8->addLayout(horizontalLayout_17);


        horizontalLayout_15->addLayout(verticalLayout_8);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_14);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_15);

        foldedExampleLabelLabel = new QLabel(plotAppearanceDialog);
        foldedExampleLabelLabel->setObjectName(QStringLiteral("foldedExampleLabelLabel"));
        sizePolicy1.setHeightForWidth(foldedExampleLabelLabel->sizePolicy().hasHeightForWidth());
        foldedExampleLabelLabel->setSizePolicy(sizePolicy1);
        foldedExampleLabelLabel->setMinimumSize(QSize(0, 0));
        foldedExampleLabelLabel->setMaximumSize(QSize(16777215, 16777215));
        foldedExampleLabelLabel->setFont(font);

        horizontalLayout_19->addWidget(foldedExampleLabelLabel);

        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_16);


        verticalLayout_9->addLayout(horizontalLayout_19);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_20->addItem(horizontalSpacer_17);

        foldedExampleLabel = new QLabel(plotAppearanceDialog);
        foldedExampleLabel->setObjectName(QStringLiteral("foldedExampleLabel"));
        sizePolicy5.setHeightForWidth(foldedExampleLabel->sizePolicy().hasHeightForWidth());
        foldedExampleLabel->setSizePolicy(sizePolicy5);
        foldedExampleLabel->setMinimumSize(QSize(110, 30));
        foldedExampleLabel->setMaximumSize(QSize(110, 30));
        foldedExampleLabel->setFont(font);
        foldedExampleLabel->setStyleSheet(QLatin1String("QLabel#foldedExampleLabel{\n"
"background-color: rgb(111, 137, 160);\n"
"border-style: outset;\n"
"border-radius: 5px;\n"
"border-width: 3px;\n"
"border-color: rgb(0,0,0);\n"
"}"));

        horizontalLayout_20->addWidget(foldedExampleLabel);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_20->addItem(horizontalSpacer_18);


        verticalLayout_9->addLayout(horizontalLayout_20);


        horizontalLayout_15->addLayout(verticalLayout_9);


        verticalLayout_12->addLayout(horizontalLayout_15);

        line_5 = new QFrame(plotAppearanceDialog);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        verticalLayout_12->addWidget(line_5);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        selectedBgColorButton = new QPushButton(plotAppearanceDialog);
        selectedBgColorButton->setObjectName(QStringLiteral("selectedBgColorButton"));
        sizePolicy3.setHeightForWidth(selectedBgColorButton->sizePolicy().hasHeightForWidth());
        selectedBgColorButton->setSizePolicy(sizePolicy3);
        selectedBgColorButton->setMinimumSize(QSize(30, 30));
        selectedBgColorButton->setMaximumSize(QSize(30, 30));
        selectedBgColorButton->setStyleSheet(QLatin1String("QPushButton#selectedBgColorButton{\n"
"background-color: rgb(255, 0, 0);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#selectedBgColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#selectedBgColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        selectedBgColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_22->addWidget(selectedBgColorButton);

        selectedBgColorLabel = new QLabel(plotAppearanceDialog);
        selectedBgColorLabel->setObjectName(QStringLiteral("selectedBgColorLabel"));
        sizePolicy1.setHeightForWidth(selectedBgColorLabel->sizePolicy().hasHeightForWidth());
        selectedBgColorLabel->setSizePolicy(sizePolicy1);
        selectedBgColorLabel->setMinimumSize(QSize(0, 0));
        selectedBgColorLabel->setMaximumSize(QSize(16777215, 16777215));
        selectedBgColorLabel->setFont(font);

        horizontalLayout_22->addWidget(selectedBgColorLabel);


        verticalLayout_10->addLayout(horizontalLayout_22);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        selectedBorderColorButton = new QPushButton(plotAppearanceDialog);
        selectedBorderColorButton->setObjectName(QStringLiteral("selectedBorderColorButton"));
        sizePolicy3.setHeightForWidth(selectedBorderColorButton->sizePolicy().hasHeightForWidth());
        selectedBorderColorButton->setSizePolicy(sizePolicy3);
        selectedBorderColorButton->setMinimumSize(QSize(30, 30));
        selectedBorderColorButton->setMaximumSize(QSize(30, 30));
        selectedBorderColorButton->setStyleSheet(QLatin1String("QPushButton#selectedBorderColorButton {\n"
"background-color: rgb(255, 255, 255);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#selectedBorderColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#selectedBorderColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        selectedBorderColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_23->addWidget(selectedBorderColorButton);

        selectedBorderColorLabel = new QLabel(plotAppearanceDialog);
        selectedBorderColorLabel->setObjectName(QStringLiteral("selectedBorderColorLabel"));
        sizePolicy1.setHeightForWidth(selectedBorderColorLabel->sizePolicy().hasHeightForWidth());
        selectedBorderColorLabel->setSizePolicy(sizePolicy1);
        selectedBorderColorLabel->setMinimumSize(QSize(0, 0));
        selectedBorderColorLabel->setMaximumSize(QSize(16777215, 16777215));
        selectedBorderColorLabel->setFont(font);

        horizontalLayout_23->addWidget(selectedBorderColorLabel);


        verticalLayout_10->addLayout(horizontalLayout_23);


        horizontalLayout_21->addLayout(verticalLayout_10);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_19);

        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_25->addItem(horizontalSpacer_20);

        selectedExampleLabelLabel = new QLabel(plotAppearanceDialog);
        selectedExampleLabelLabel->setObjectName(QStringLiteral("selectedExampleLabelLabel"));
        sizePolicy1.setHeightForWidth(selectedExampleLabelLabel->sizePolicy().hasHeightForWidth());
        selectedExampleLabelLabel->setSizePolicy(sizePolicy1);
        selectedExampleLabelLabel->setMinimumSize(QSize(0, 0));
        selectedExampleLabelLabel->setMaximumSize(QSize(16777215, 16777215));
        selectedExampleLabelLabel->setFont(font);

        horizontalLayout_25->addWidget(selectedExampleLabelLabel);

        horizontalSpacer_21 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_25->addItem(horizontalSpacer_21);


        verticalLayout_11->addLayout(horizontalLayout_25);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setObjectName(QStringLiteral("horizontalLayout_26"));
        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_26->addItem(horizontalSpacer_22);

        selectedExampleLabel = new QLabel(plotAppearanceDialog);
        selectedExampleLabel->setObjectName(QStringLiteral("selectedExampleLabel"));
        sizePolicy5.setHeightForWidth(selectedExampleLabel->sizePolicy().hasHeightForWidth());
        selectedExampleLabel->setSizePolicy(sizePolicy5);
        selectedExampleLabel->setMinimumSize(QSize(110, 30));
        selectedExampleLabel->setMaximumSize(QSize(110, 30));
        selectedExampleLabel->setFont(font);
        selectedExampleLabel->setStyleSheet(QLatin1String("QLabel#selectedExampleLabel{\n"
"background-color: rgb(255,0,0);\n"
"border-style: outset;\n"
"border-radius: 5px;\n"
"border-width: 3px;\n"
"border-color: rgb(255,255,255);\n"
"}"));

        horizontalLayout_26->addWidget(selectedExampleLabel);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_26->addItem(horizontalSpacer_23);


        verticalLayout_11->addLayout(horizontalLayout_26);


        horizontalLayout_21->addLayout(verticalLayout_11);


        verticalLayout_12->addLayout(horizontalLayout_21);

        line_6 = new QFrame(plotAppearanceDialog);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        verticalLayout_12->addWidget(line_6);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setObjectName(QStringLiteral("horizontalLayout_27"));
        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QStringLiteral("horizontalLayout_28"));
        moveBgColorButton = new QPushButton(plotAppearanceDialog);
        moveBgColorButton->setObjectName(QStringLiteral("moveBgColorButton"));
        sizePolicy3.setHeightForWidth(moveBgColorButton->sizePolicy().hasHeightForWidth());
        moveBgColorButton->setSizePolicy(sizePolicy3);
        moveBgColorButton->setMinimumSize(QSize(30, 30));
        moveBgColorButton->setMaximumSize(QSize(30, 30));
        moveBgColorButton->setStyleSheet(QLatin1String("QPushButton#moveBgColorButton{\n"
"background-color: rgb(239, 216, 168);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#moveBgColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#moveBgColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        moveBgColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_28->addWidget(moveBgColorButton);

        moveBgColorLabel = new QLabel(plotAppearanceDialog);
        moveBgColorLabel->setObjectName(QStringLiteral("moveBgColorLabel"));
        sizePolicy1.setHeightForWidth(moveBgColorLabel->sizePolicy().hasHeightForWidth());
        moveBgColorLabel->setSizePolicy(sizePolicy1);
        moveBgColorLabel->setMinimumSize(QSize(0, 0));
        moveBgColorLabel->setMaximumSize(QSize(16777215, 16777215));
        moveBgColorLabel->setFont(font);

        horizontalLayout_28->addWidget(moveBgColorLabel);


        verticalLayout_13->addLayout(horizontalLayout_28);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setObjectName(QStringLiteral("horizontalLayout_29"));
        moveBorderColorButton = new QPushButton(plotAppearanceDialog);
        moveBorderColorButton->setObjectName(QStringLiteral("moveBorderColorButton"));
        sizePolicy3.setHeightForWidth(moveBorderColorButton->sizePolicy().hasHeightForWidth());
        moveBorderColorButton->setSizePolicy(sizePolicy3);
        moveBorderColorButton->setMinimumSize(QSize(30, 30));
        moveBorderColorButton->setMaximumSize(QSize(30, 30));
        moveBorderColorButton->setStyleSheet(QLatin1String("QPushButton#moveBorderColorButton {\n"
"background-color: rgb(0,0,0);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#moveBorderColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#moveBorderColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        moveBorderColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_29->addWidget(moveBorderColorButton);

        moveBorderColorLabel = new QLabel(plotAppearanceDialog);
        moveBorderColorLabel->setObjectName(QStringLiteral("moveBorderColorLabel"));
        sizePolicy1.setHeightForWidth(moveBorderColorLabel->sizePolicy().hasHeightForWidth());
        moveBorderColorLabel->setSizePolicy(sizePolicy1);
        moveBorderColorLabel->setMinimumSize(QSize(0, 0));
        moveBorderColorLabel->setMaximumSize(QSize(16777215, 16777215));
        moveBorderColorLabel->setFont(font);

        horizontalLayout_29->addWidget(moveBorderColorLabel);


        verticalLayout_13->addLayout(horizontalLayout_29);


        horizontalLayout_27->addLayout(verticalLayout_13);

        horizontalSpacer_24 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_27->addItem(horizontalSpacer_24);

        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setObjectName(QStringLiteral("horizontalLayout_31"));
        horizontalSpacer_25 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_25);

        moveExampleLabelLabel = new QLabel(plotAppearanceDialog);
        moveExampleLabelLabel->setObjectName(QStringLiteral("moveExampleLabelLabel"));
        sizePolicy1.setHeightForWidth(moveExampleLabelLabel->sizePolicy().hasHeightForWidth());
        moveExampleLabelLabel->setSizePolicy(sizePolicy1);
        moveExampleLabelLabel->setMinimumSize(QSize(0, 0));
        moveExampleLabelLabel->setMaximumSize(QSize(16777215, 16777215));
        moveExampleLabelLabel->setFont(font);

        horizontalLayout_31->addWidget(moveExampleLabelLabel);

        horizontalSpacer_26 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_26);


        verticalLayout_14->addLayout(horizontalLayout_31);

        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setObjectName(QStringLiteral("horizontalLayout_32"));
        horizontalSpacer_27 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_32->addItem(horizontalSpacer_27);

        moveExampleLabel = new QLabel(plotAppearanceDialog);
        moveExampleLabel->setObjectName(QStringLiteral("moveExampleLabel"));
        sizePolicy5.setHeightForWidth(moveExampleLabel->sizePolicy().hasHeightForWidth());
        moveExampleLabel->setSizePolicy(sizePolicy5);
        moveExampleLabel->setMinimumSize(QSize(110, 30));
        moveExampleLabel->setMaximumSize(QSize(110, 30));
        moveExampleLabel->setFont(font);
        moveExampleLabel->setStyleSheet(QLatin1String("QLabel#moveExampleLabel{\n"
"background-color: rgb(239,216,168);\n"
"border-style: outset;\n"
"border-radius: 5px;\n"
"border-width: 3px;\n"
"border-color: rgb(0,0,0);\n"
"}"));

        horizontalLayout_32->addWidget(moveExampleLabel);

        horizontalSpacer_28 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_32->addItem(horizontalSpacer_28);


        verticalLayout_14->addLayout(horizontalLayout_32);


        horizontalLayout_27->addLayout(verticalLayout_14);


        verticalLayout_12->addLayout(horizontalLayout_27);

        line = new QFrame(plotAppearanceDialog);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_12->addWidget(line);

        horizontalLayout_37 = new QHBoxLayout();
        horizontalLayout_37->setObjectName(QStringLiteral("horizontalLayout_37"));
        horizontalLayout_34 = new QHBoxLayout();
        horizontalLayout_34->setObjectName(QStringLiteral("horizontalLayout_34"));
        selectionColorButton = new QPushButton(plotAppearanceDialog);
        selectionColorButton->setObjectName(QStringLiteral("selectionColorButton"));
        sizePolicy3.setHeightForWidth(selectionColorButton->sizePolicy().hasHeightForWidth());
        selectionColorButton->setSizePolicy(sizePolicy3);
        selectionColorButton->setMinimumSize(QSize(30, 30));
        selectionColorButton->setMaximumSize(QSize(30, 30));
        selectionColorButton->setStyleSheet(QLatin1String("QPushButton#selectionColorButton{\n"
"background-color: rgb(255, 0, 0);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#selectionColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#selectionColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        selectionColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_34->addWidget(selectionColorButton);

        selectionColorLabel = new QLabel(plotAppearanceDialog);
        selectionColorLabel->setObjectName(QStringLiteral("selectionColorLabel"));
        sizePolicy1.setHeightForWidth(selectionColorLabel->sizePolicy().hasHeightForWidth());
        selectionColorLabel->setSizePolicy(sizePolicy1);
        selectionColorLabel->setMinimumSize(QSize(0, 0));
        selectionColorLabel->setMaximumSize(QSize(16777215, 16777215));
        selectionColorLabel->setFont(font);

        horizontalLayout_34->addWidget(selectionColorLabel);


        horizontalLayout_37->addLayout(horizontalLayout_34);

        horizontalSpacer_33 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_37->addItem(horizontalSpacer_33);

        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setObjectName(QStringLiteral("verticalLayout_15"));
        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setObjectName(QStringLiteral("horizontalLayout_35"));
        horizontalSpacer_35 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_35->addItem(horizontalSpacer_35);

        selectionExampleLabel = new QLabel(plotAppearanceDialog);
        selectionExampleLabel->setObjectName(QStringLiteral("selectionExampleLabel"));
        sizePolicy1.setHeightForWidth(selectionExampleLabel->sizePolicy().hasHeightForWidth());
        selectionExampleLabel->setSizePolicy(sizePolicy1);
        selectionExampleLabel->setMinimumSize(QSize(0, 0));
        selectionExampleLabel->setMaximumSize(QSize(16777215, 16777215));
        selectionExampleLabel->setFont(font);

        horizontalLayout_35->addWidget(selectionExampleLabel);

        horizontalSpacer_34 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_35->addItem(horizontalSpacer_34);


        verticalLayout_15->addLayout(horizontalLayout_35);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setObjectName(QStringLiteral("horizontalLayout_36"));
        horizontalSpacer_37 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_36->addItem(horizontalSpacer_37);

        selectionPointerLabel = new QLabel(plotAppearanceDialog);
        selectionPointerLabel->setObjectName(QStringLiteral("selectionPointerLabel"));
        sizePolicy5.setHeightForWidth(selectionPointerLabel->sizePolicy().hasHeightForWidth());
        selectionPointerLabel->setSizePolicy(sizePolicy5);
        selectionPointerLabel->setMinimumSize(QSize(70, 45));
        selectionPointerLabel->setMaximumSize(QSize(70, 45));
        selectionPointerLabel->setFont(font);
        selectionPointerLabel->setStyleSheet(QLatin1String("QLabel#selectionPointerLabel{\n"
"background-color: rgb(255,0,0);\n"
"}"));
        selectionPointerLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/pointers.png")));
        selectionPointerLabel->setScaledContents(true);

        horizontalLayout_36->addWidget(selectionPointerLabel);

        horizontalSpacer_36 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_36->addItem(horizontalSpacer_36);


        verticalLayout_15->addLayout(horizontalLayout_36);


        horizontalLayout_37->addLayout(verticalLayout_15);


        verticalLayout_12->addLayout(horizontalLayout_37);

        line_10 = new QFrame(plotAppearanceDialog);
        line_10->setObjectName(QStringLiteral("line_10"));
        line_10->setFrameShape(QFrame::HLine);
        line_10->setFrameShadow(QFrame::Sunken);

        verticalLayout_12->addWidget(line_10);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        markerButton = new QPushButton(plotAppearanceDialog);
        markerButton->setObjectName(QStringLiteral("markerButton"));
        sizePolicy3.setHeightForWidth(markerButton->sizePolicy().hasHeightForWidth());
        markerButton->setSizePolicy(sizePolicy3);
        markerButton->setMinimumSize(QSize(30, 30));
        markerButton->setMaximumSize(QSize(30, 30));
        markerButton->setStyleSheet(QLatin1String("QPushButton#markerButton {\n"
"background-color: rgb(0, 0, 0);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#markerButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#markerButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        markerButton->setIconSize(QSize(35, 35));

        horizontalLayout_9->addWidget(markerButton);

        labelBorderColorLabel_2 = new QLabel(plotAppearanceDialog);
        labelBorderColorLabel_2->setObjectName(QStringLiteral("labelBorderColorLabel_2"));
        sizePolicy1.setHeightForWidth(labelBorderColorLabel_2->sizePolicy().hasHeightForWidth());
        labelBorderColorLabel_2->setSizePolicy(sizePolicy1);
        labelBorderColorLabel_2->setMinimumSize(QSize(0, 0));
        labelBorderColorLabel_2->setMaximumSize(QSize(16777215, 16777215));
        labelBorderColorLabel_2->setFont(font);

        horizontalLayout_9->addWidget(labelBorderColorLabel_2);


        horizontalLayout_24->addLayout(horizontalLayout_9);

        horizontalSpacer_44 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_24->addItem(horizontalSpacer_44);

        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setObjectName(QStringLiteral("verticalLayout_19"));
        horizontalLayout_48 = new QHBoxLayout();
        horizontalLayout_48->setObjectName(QStringLiteral("horizontalLayout_48"));
        horizontalSpacer_39 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_48->addItem(horizontalSpacer_39);

        markerExampleLabel = new QLabel(plotAppearanceDialog);
        markerExampleLabel->setObjectName(QStringLiteral("markerExampleLabel"));
        sizePolicy1.setHeightForWidth(markerExampleLabel->sizePolicy().hasHeightForWidth());
        markerExampleLabel->setSizePolicy(sizePolicy1);
        markerExampleLabel->setMinimumSize(QSize(0, 0));
        markerExampleLabel->setMaximumSize(QSize(16777215, 16777215));
        markerExampleLabel->setFont(font);

        horizontalLayout_48->addWidget(markerExampleLabel);

        horizontalSpacer_40 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_48->addItem(horizontalSpacer_40);


        verticalLayout_19->addLayout(horizontalLayout_48);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        horizontalSpacer_41 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_41);

        markerLabel = new QLabel(plotAppearanceDialog);
        markerLabel->setObjectName(QStringLiteral("markerLabel"));
        sizePolicy5.setHeightForWidth(markerLabel->sizePolicy().hasHeightForWidth());
        markerLabel->setSizePolicy(sizePolicy5);
        markerLabel->setMinimumSize(QSize(45, 45));
        markerLabel->setMaximumSize(QSize(45, 45));
        markerLabel->setFont(font);
        markerLabel->setStyleSheet(QLatin1String("QLabel#markerLabel{\n"
"background-color: rgb(0,0,0);\n"
"}"));
        markerLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/marker.png")));
        markerLabel->setScaledContents(true);

        horizontalLayout_18->addWidget(markerLabel);

        horizontalSpacer_43 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_43);


        verticalLayout_19->addLayout(horizontalLayout_18);


        horizontalLayout_24->addLayout(verticalLayout_19);


        verticalLayout_12->addLayout(horizontalLayout_24);


        horizontalLayout_39->addLayout(verticalLayout_12);

        line_8 = new QFrame(plotAppearanceDialog);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::VLine);
        line_8->setFrameShadow(QFrame::Sunken);

        horizontalLayout_39->addWidget(line_8);

        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setObjectName(QStringLiteral("verticalLayout_17"));
        horizontalLayout_38 = new QHBoxLayout();
        horizontalLayout_38->setObjectName(QStringLiteral("horizontalLayout_38"));
        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setObjectName(QStringLiteral("verticalLayout_18"));
        horizontalLayout_41 = new QHBoxLayout();
        horizontalLayout_41->setObjectName(QStringLiteral("horizontalLayout_41"));
        horizontalLayout_40 = new QHBoxLayout();
        horizontalLayout_40->setObjectName(QStringLiteral("horizontalLayout_40"));
        gradientButton = new QPushButton(plotAppearanceDialog);
        gradientButton->setObjectName(QStringLiteral("gradientButton"));
        sizePolicy3.setHeightForWidth(gradientButton->sizePolicy().hasHeightForWidth());
        gradientButton->setSizePolicy(sizePolicy3);
        gradientButton->setMinimumSize(QSize(30, 30));
        gradientButton->setMaximumSize(QSize(30, 30));
        gradientButton->setStyleSheet(QLatin1String("QPushButton#gradientButton {\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgb(255,255,255), stop:0.05 rgb(255, 255, 255), stop:0.1 rgb(0, 255, 0), stop:0.4 rgb(255, 255, 0), stop:0.6 rgb(255, 0, 0), stop:1 rgb(165, 0, 0));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#gradientButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#gradientButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        gradientButton->setIconSize(QSize(35, 35));

        horizontalLayout_40->addWidget(gradientButton);

        gradientLabel_2 = new QLabel(plotAppearanceDialog);
        gradientLabel_2->setObjectName(QStringLiteral("gradientLabel_2"));
        sizePolicy1.setHeightForWidth(gradientLabel_2->sizePolicy().hasHeightForWidth());
        gradientLabel_2->setSizePolicy(sizePolicy1);
        gradientLabel_2->setMinimumSize(QSize(0, 0));
        gradientLabel_2->setMaximumSize(QSize(16777215, 16777215));
        gradientLabel_2->setFont(font);

        horizontalLayout_40->addWidget(gradientLabel_2);


        horizontalLayout_41->addLayout(horizontalLayout_40);

        horizontalSpacer_42 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_41->addItem(horizontalSpacer_42);


        verticalLayout_18->addLayout(horizontalLayout_41);

        horizontalLayout_42 = new QHBoxLayout();
        horizontalLayout_42->setObjectName(QStringLiteral("horizontalLayout_42"));
        gridlineColorButton = new QPushButton(plotAppearanceDialog);
        gridlineColorButton->setObjectName(QStringLiteral("gridlineColorButton"));
        sizePolicy3.setHeightForWidth(gridlineColorButton->sizePolicy().hasHeightForWidth());
        gridlineColorButton->setSizePolicy(sizePolicy3);
        gridlineColorButton->setMinimumSize(QSize(30, 30));
        gridlineColorButton->setMaximumSize(QSize(30, 30));
        gridlineColorButton->setStyleSheet(QLatin1String("QPushButton#gridlineColorButton {\n"
"background-color: rgb(0,0,0);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#gridlineColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#gridlineColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        gridlineColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_42->addWidget(gridlineColorButton);

        gridlineColorLabel = new QLabel(plotAppearanceDialog);
        gridlineColorLabel->setObjectName(QStringLiteral("gridlineColorLabel"));
        sizePolicy1.setHeightForWidth(gridlineColorLabel->sizePolicy().hasHeightForWidth());
        gridlineColorLabel->setSizePolicy(sizePolicy1);
        gridlineColorLabel->setMinimumSize(QSize(0, 0));
        gridlineColorLabel->setMaximumSize(QSize(16777215, 16777215));
        gridlineColorLabel->setFont(font);

        horizontalLayout_42->addWidget(gridlineColorLabel);

        horizontalSpacer_46 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_42->addItem(horizontalSpacer_46);


        verticalLayout_18->addLayout(horizontalLayout_42);

        horizontalLayout_43 = new QHBoxLayout();
        horizontalLayout_43->setObjectName(QStringLiteral("horizontalLayout_43"));
        gridBgColorButton = new QPushButton(plotAppearanceDialog);
        gridBgColorButton->setObjectName(QStringLiteral("gridBgColorButton"));
        sizePolicy3.setHeightForWidth(gridBgColorButton->sizePolicy().hasHeightForWidth());
        gridBgColorButton->setSizePolicy(sizePolicy3);
        gridBgColorButton->setMinimumSize(QSize(30, 30));
        gridBgColorButton->setMaximumSize(QSize(30, 30));
        gridBgColorButton->setStyleSheet(QLatin1String("QPushButton#gridBgColorButton {\n"
"background-color: rgb(255, 255, 255);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#gridBgColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#gridBgColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        gridBgColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_43->addWidget(gridBgColorButton);

        gridBgColorLabel = new QLabel(plotAppearanceDialog);
        gridBgColorLabel->setObjectName(QStringLiteral("gridBgColorLabel"));
        sizePolicy1.setHeightForWidth(gridBgColorLabel->sizePolicy().hasHeightForWidth());
        gridBgColorLabel->setSizePolicy(sizePolicy1);
        gridBgColorLabel->setMinimumSize(QSize(0, 0));
        gridBgColorLabel->setMaximumSize(QSize(16777215, 16777215));
        gridBgColorLabel->setFont(font);

        horizontalLayout_43->addWidget(gridBgColorLabel);

        horizontalSpacer_47 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_43->addItem(horizontalSpacer_47);


        verticalLayout_18->addLayout(horizontalLayout_43);

        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setObjectName(QStringLiteral("horizontalLayout_44"));
        areaColorButton = new QPushButton(plotAppearanceDialog);
        areaColorButton->setObjectName(QStringLiteral("areaColorButton"));
        sizePolicy3.setHeightForWidth(areaColorButton->sizePolicy().hasHeightForWidth());
        areaColorButton->setSizePolicy(sizePolicy3);
        areaColorButton->setMinimumSize(QSize(30, 30));
        areaColorButton->setMaximumSize(QSize(30, 30));
        areaColorButton->setStyleSheet(QLatin1String("QPushButton#areaColorButton {\n"
"background-color: rgb(255, 255, 255);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#areaColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#areaColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        areaColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_44->addWidget(areaColorButton);

        areaColorLabel = new QLabel(plotAppearanceDialog);
        areaColorLabel->setObjectName(QStringLiteral("areaColorLabel"));
        sizePolicy1.setHeightForWidth(areaColorLabel->sizePolicy().hasHeightForWidth());
        areaColorLabel->setSizePolicy(sizePolicy1);
        areaColorLabel->setMinimumSize(QSize(0, 0));
        areaColorLabel->setMaximumSize(QSize(16777215, 16777215));
        areaColorLabel->setFont(font);

        horizontalLayout_44->addWidget(areaColorLabel);

        horizontalSpacer_48 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_44->addItem(horizontalSpacer_48);


        verticalLayout_18->addLayout(horizontalLayout_44);


        horizontalLayout_38->addLayout(verticalLayout_18);

        horizontalSpacer_38 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_38->addItem(horizontalSpacer_38);

        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setObjectName(QStringLiteral("verticalLayout_20"));
        horizontalLayout_45 = new QHBoxLayout();
        horizontalLayout_45->setObjectName(QStringLiteral("horizontalLayout_45"));
        axisColorButton = new QPushButton(plotAppearanceDialog);
        axisColorButton->setObjectName(QStringLiteral("axisColorButton"));
        sizePolicy3.setHeightForWidth(axisColorButton->sizePolicy().hasHeightForWidth());
        axisColorButton->setSizePolicy(sizePolicy3);
        axisColorButton->setMinimumSize(QSize(30, 30));
        axisColorButton->setMaximumSize(QSize(30, 30));
        axisColorButton->setStyleSheet(QLatin1String("QPushButton#axisColorButton {\n"
"background-color: rgb(255, 255, 255);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#axisColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#axisColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        axisColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_45->addWidget(axisColorButton);

        axisLabel = new QLabel(plotAppearanceDialog);
        axisLabel->setObjectName(QStringLiteral("axisLabel"));
        sizePolicy1.setHeightForWidth(axisLabel->sizePolicy().hasHeightForWidth());
        axisLabel->setSizePolicy(sizePolicy1);
        axisLabel->setMinimumSize(QSize(0, 0));
        axisLabel->setMaximumSize(QSize(16777215, 16777215));
        axisLabel->setFont(font);

        horizontalLayout_45->addWidget(axisLabel);

        horizontalSpacer_49 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_45->addItem(horizontalSpacer_49);


        verticalLayout_20->addLayout(horizontalLayout_45);

        horizontalLayout_46 = new QHBoxLayout();
        horizontalLayout_46->setObjectName(QStringLiteral("horizontalLayout_46"));
        axisTextColorButton = new QPushButton(plotAppearanceDialog);
        axisTextColorButton->setObjectName(QStringLiteral("axisTextColorButton"));
        sizePolicy3.setHeightForWidth(axisTextColorButton->sizePolicy().hasHeightForWidth());
        axisTextColorButton->setSizePolicy(sizePolicy3);
        axisTextColorButton->setMinimumSize(QSize(30, 30));
        axisTextColorButton->setMaximumSize(QSize(30, 30));
        axisTextColorButton->setStyleSheet(QLatin1String("QPushButton#axisTextColorButton {\n"
"background-color: rgb(0, 0, 0);\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#axisTextColorButton:pressed {\n"
" border-style: inset;\n"
"}\n"
"QPushButton#axisTextColorButton:hover:!pressed {\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        axisTextColorButton->setIconSize(QSize(35, 35));

        horizontalLayout_46->addWidget(axisTextColorButton);

        axisTextLabel = new QLabel(plotAppearanceDialog);
        axisTextLabel->setObjectName(QStringLiteral("axisTextLabel"));
        sizePolicy1.setHeightForWidth(axisTextLabel->sizePolicy().hasHeightForWidth());
        axisTextLabel->setSizePolicy(sizePolicy1);
        axisTextLabel->setMinimumSize(QSize(0, 0));
        axisTextLabel->setMaximumSize(QSize(16777215, 16777215));
        axisTextLabel->setFont(font);

        horizontalLayout_46->addWidget(axisTextLabel);

        horizontalSpacer_50 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_46->addItem(horizontalSpacer_50);


        verticalLayout_20->addLayout(horizontalLayout_46);

        horizontalLayout_47 = new QHBoxLayout();
        horizontalLayout_47->setObjectName(QStringLiteral("horizontalLayout_47"));
        boxButton = new QRadioButton(plotAppearanceDialog);
        boxButton->setObjectName(QStringLiteral("boxButton"));
        sizePolicy1.setHeightForWidth(boxButton->sizePolicy().hasHeightForWidth());
        boxButton->setSizePolicy(sizePolicy1);
        boxButton->setMinimumSize(QSize(0, 0));
        boxButton->setMaximumSize(QSize(16777215, 16777215));
        QFont font2;
        font2.setFamily(QStringLiteral("Myriad Pro"));
        font2.setPointSize(11);
        boxButton->setFont(font2);
        boxButton->setLayoutDirection(Qt::RightToLeft);
        boxButton->setStyleSheet(QLatin1String("QRadioButton{\n"
"color: white;\n"
"}\n"
"QRadioButton::indicator {\n"
"    width: 25px;\n"
"    height: 25px;\n"
"}\n"
"QRadioButton::indicator::unchecked {\n"
"	image: url(:/img/radio_unchecked.png);\n"
"}\n"
"\n"
"QRadioButton::indicator:unchecked:hover {\n"
"    image: url(:/img/radio_unchecked_hover.png);\n"
"}\n"
"\n"
"QRadioButton::indicator::checked {\n"
"	image: url(:/img/radio_checked.png);\n"
"}"));
        boxButton->setChecked(true);

        horizontalLayout_47->addWidget(boxButton);

        horizontalSpacer_31 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_47->addItem(horizontalSpacer_31);


        verticalLayout_20->addLayout(horizontalLayout_47);


        horizontalLayout_38->addLayout(verticalLayout_20);


        verticalLayout_17->addLayout(horizontalLayout_38);

        line_9 = new QFrame(plotAppearanceDialog);
        line_9->setObjectName(QStringLiteral("line_9"));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);

        verticalLayout_17->addWidget(line_9);

        foldedExampleLabelLabel_2 = new QLabel(plotAppearanceDialog);
        foldedExampleLabelLabel_2->setObjectName(QStringLiteral("foldedExampleLabelLabel_2"));
        sizePolicy5.setHeightForWidth(foldedExampleLabelLabel_2->sizePolicy().hasHeightForWidth());
        foldedExampleLabelLabel_2->setSizePolicy(sizePolicy5);
        foldedExampleLabelLabel_2->setMinimumSize(QSize(0, 0));
        foldedExampleLabelLabel_2->setMaximumSize(QSize(16777215, 16777215));
        foldedExampleLabelLabel_2->setFont(font);

        verticalLayout_17->addWidget(foldedExampleLabelLabel_2);

        exampleSpectrumWidget = new QWidget(plotAppearanceDialog);
        exampleSpectrumWidget->setObjectName(QStringLiteral("exampleSpectrumWidget"));
        QSizePolicy sizePolicy6(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(exampleSpectrumWidget->sizePolicy().hasHeightForWidth());
        exampleSpectrumWidget->setSizePolicy(sizePolicy6);
        exampleSpectrumWidget->setMinimumSize(QSize(0, 0));
        exampleSpectrumWidget->setMaximumSize(QSize(16277750, 16277750));
        exampleSpectrumWidget->setStyleSheet(QLatin1String("QWidget #spectrum2DWidget{\n"
"border-style: solid;\n"
"border-width: 3px;\n"
"border-radius: 7px;\n"
"border-color: rgba(71,78,81,255);\n"
"}"));

        verticalLayout_17->addWidget(exampleSpectrumWidget);


        horizontalLayout_39->addLayout(verticalLayout_17);


        horizontalLayout_33->addLayout(horizontalLayout_39);

        horizontalSpacer_30 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_33->addItem(horizontalSpacer_30);


        verticalLayout_16->addLayout(horizontalLayout_33);

        line_7 = new QFrame(plotAppearanceDialog);
        line_7->setObjectName(QStringLiteral("line_7"));
        sizePolicy2.setHeightForWidth(line_7->sizePolicy().hasHeightForWidth());
        line_7->setSizePolicy(sizePolicy2);
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);

        verticalLayout_16->addWidget(line_7);


        gridLayout->addLayout(verticalLayout_16, 0, 0, 1, 1);


        retranslateUi(plotAppearanceDialog);

        QMetaObject::connectSlotsByName(plotAppearanceDialog);
    } // setupUi

    void retranslateUi(QDialog *plotAppearanceDialog)
    {
        plotAppearanceDialog->setWindowTitle(QApplication::translate("plotAppearanceDialog", "Plot appearance", 0));
        loadPresetName->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Load theme</span></p></body></html>", 0));
        loadPresetBox->clear();
        loadPresetBox->insertItems(0, QStringList()
         << QApplication::translate("plotAppearanceDialog", "PINT [built-in]", 0)
         << QApplication::translate("plotAppearanceDialog", "Dark gray [built-in]", 0)
         << QApplication::translate("plotAppearanceDialog", "Light gray [built-in]", 0)
         << QApplication::translate("plotAppearanceDialog", "Black [built-in]", 0)
        );
        loadPresetButton->setText(QString());
        loadLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Load</span></p></body></html>", 0));
        deletePresetButton->setText(QString());
        deletePresetButton_2->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Delete</span></p></body></html>", 0));
        presetNameLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"right\"><span style=\" color:#ffffff;\">Theme name</span></p></body></html>", 0));
        presetNameEdit->setText(QApplication::translate("plotAppearanceDialog", "Custom", 0));
        savePresetButton->setText(QString());
        savePresetLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Save &amp; Close</span></p></body></html>", 0));
        cancelButton->setText(QString());
        cancelLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Cancel</span></p></body></html>", 0));
        labelBgColorButton->setText(QString());
        labelBgColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Label background color</span></p></body></html>", 0));
        labelBorderColorButton->setText(QString());
        labelBorderColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Label text &amp; border color</span></p></body></html>", 0));
        exampleLabelLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Label example</span></p></body></html>", 0));
        exampleLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#000000;\">Peak Name</span></p></body></html>", 0));
        foldedBgColorButton->setText(QString());
        foldedBgColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Folded label background color</span></p></body></html>", 0));
        foldedBorderColorButton->setText(QString());
        foldedBorderColorLabel_2->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Folded label text &amp; border color</span></p></body></html>", 0));
        foldedExampleLabelLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Folded label example</span></p></body></html>", 0));
        foldedExampleLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#000000;\">Folded Peak</span></p></body></html>", 0));
        selectedBgColorButton->setText(QString());
        selectedBgColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Selected label background color</span></p></body></html>", 0));
        selectedBorderColorButton->setText(QString());
        selectedBorderColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Selected label text &amp; border color</span></p></body></html>", 0));
        selectedExampleLabelLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Selected label example</span></p></body></html>", 0));
        selectedExampleLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#ffffff;\">Selected Peak</span></p></body></html>", 0));
        moveBgColorButton->setText(QString());
        moveBgColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Move mode label background color</span></p></body></html>", 0));
        moveBorderColorButton->setText(QString());
        moveBorderColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Move mode label text &amp; border color</span></p></body></html>", 0));
        moveExampleLabelLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Move mode label example</span></p></body></html>", 0));
        moveExampleLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#000000;\">Move Mode</span></p></body></html>", 0));
        selectionColorButton->setText(QString());
        selectionColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Selection pointer color</span></p></body></html>", 0));
        selectionExampleLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Selection pointer example</span></p></body></html>", 0));
        selectionPointerLabel->setText(QString());
        markerButton->setText(QString());
        labelBorderColorLabel_2->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Contour plot label marker</span></p></body></html>", 0));
        markerExampleLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Marker example</span></p></body></html>", 0));
        markerLabel->setText(QString());
        gradientButton->setText(QString());
        gradientLabel_2->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">3D plot gradient</span></p></body></html>", 0));
        gridlineColorButton->setText(QString());
        gridlineColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Grid line color</span></p></body></html>", 0));
        gridBgColorButton->setText(QString());
        gridBgColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Grid background color</span></p></body></html>", 0));
        areaColorButton->setText(QString());
        areaColorLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Plot area background color</span></p></body></html>", 0));
        axisColorButton->setText(QString());
        axisLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Axis label color</span></p></body></html>", 0));
        axisTextColorButton->setText(QString());
        axisTextLabel->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Axis label text &amp; border color</span></p></body></html>", 0));
        boxButton->setText(QApplication::translate("plotAppearanceDialog", "Boxed axis labels", 0));
        foldedExampleLabelLabel_2->setText(QApplication::translate("plotAppearanceDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Plot example</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class plotAppearanceDialog: public Ui_plotAppearanceDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLOTAPPEARANCEDIALOG_H
