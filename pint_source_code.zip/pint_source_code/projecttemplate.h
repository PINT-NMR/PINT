#ifndef PROJECTTEMPLATE_H
#define PROJECTTEMPLATE_H
#include <QString>
#include <QVector>
#include <QStringList>
#include "peaklistclass.h"
class projectTemplate
{
public:
    projectTemplate();
    ~projectTemplate();
    QString projectName;
    QString saveFile;
    QString projectRootDirectory;
    bool pipeData; //False for topspin
    QString paramFile;
    QString outDirectory;
    QString tmpOutDirectory;
    QString plotDirectory;
    QString tmpPlotDirectory;
    QString projectDirectory;
    QVector<QString> spectrumFiles;
    QVector<QString> peaklistFiles;
    QVector<QString> otherFiles;
    QString peakCenterParamFile;
    QString centerPeakList;
    QString integratePeakList;
    QVector<peaklistClass> pintPeaklists;
    QString currentPeakID;
    QVector<QStringList> overlapVec;
    int planeMax;
    int spD;
    int prD;
    int peD;
};

#endif // PROJECTTEMPLATE_H
