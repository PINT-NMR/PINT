#include "pintworker.h"
#include <QTimer>
#include <QStringList>
#include <iostream>
#include "cancelvar.h"


//pintWorker::pintWorker(void *argument, QObject* parent, int ID)
pintWorker::pintWorker(PeakFitType *argument, QObject* parent, int ID) :
    QObject(parent), p((PeakFitType *)argument), ID_no(ID), plot(new PlotType(p->plotDir, p->plotMode))
{}

pintWorker::~pintWorker()
{
}

void pintWorker::process()
{
    QString msg("");
    for(ulong i(0); i<p->peak.size(); ++i)
        msg+=QString::fromStdString(p->peak.at(i).assi.c_str()) + " ";
    extern bool cancelVar;
    p->fit(p->parser.planeToFitFirst);
    if(cancelVar)
    {
        delete plot;
        plot = NULL;
        emit removeString(msg);
        emit finished("");
        return;
    }
    plot->plot(*p, p->error_msg);
    if(cancelVar)
    {
        delete plot;
        plot = NULL;
        emit removeString(msg);
        emit finished("");
        return;
    }
    p->makeFinalParam(p->peak);
    EsdType esd(p->outDir);
    esd.calcEsd(p->peak);
    p->setVolumeEsd();
    OutputType output(p->outDir, p->parser, p->spectrum);
    output.printResult(p->peak, p->error_msg);
    if(cancelVar)
    {
        delete plot;
        plot = NULL;
        emit removeString(msg);
        emit finished("");
        return;
    }
    string str("");
    if(p->convFlag)
    {
        str+="Done integrating peak(s): ";
        for (Uint i=0; i<p->peak.size(); i++)
            str+=p->peak[i].assi + " ";
        stringstream conv;
        conv << p->peak.size();
        str+="(" + conv.str() + ")\t";
        if (!p->convFlag)
            str+="OK!\n";
        else if (p->convFlag == 1)
            str+="FAIL! No convergence\n";
        else if (p->convFlag == 2)
            str+="FAIL! Cannot calculate line width!\n";
        else if (p->convFlag == 3)
            str+="FAIL! Peak moves too much in F1\n";
        else if (p->convFlag == 4)
            str+="FAIL! Peak moves too much in F2\n";
        else if (p->convFlag == 5)
            str+="FAIL! Too large linewidth in F1\n";
        else if (p->convFlag == 6)
            str+="FAIL! Too large linewidth in F2\n";
        else if (p->convFlag == 7)
            str+="FAIL! Too small linewidth in F1\n";
        else if (p->convFlag == 8)
            str+="FAIL! Too small linewidth in F2\n";
        else
            str+="FAIL! Unknown reason\n";
    }
    delete plot;
    plot = NULL;
    emit removeString(msg);
    emit finished(QString::fromUtf8(str.c_str()));
}
