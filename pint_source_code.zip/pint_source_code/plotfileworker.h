#ifndef PLOTFILEWORKER_H
#define PLOTFILEWORKER_H

#include <QStringList>
#include <QObject>
using namespace std;

class plotFileWorker : public QObject
{
    Q_OBJECT
public:
    plotFileWorker(QObject* parent = 0, QString arg1="", int arg2=0, QString arg3="");
    ~plotFileWorker();

private:
    QString fname;
    int rowNo;
    QString dir;

public slots:
    void process();

signals:
    void finished(QStringList);
};
#endif // PLOTFILEWORKER_H
