#ifndef INTEGRATIONSTATUSDIALOG_H
#define INTEGRATIONSTATUSDIALOG_H

#include <QDialog>
#include <QTime>
#include <QObject>
#include <QTimer>
#include <QStringList>

namespace Ui {
class integrationStatusDialog;
}

class integrationStatusDialog : public QDialog
{
    Q_OBJECT

public:
    explicit integrationStatusDialog(QWidget *parent = 0);
    QString elapsed;
    ~integrationStatusDialog();
    QTimer *updateTimer;
    QTime progressTimer;

private slots:
    void on_abortButton_clicked();

private:
    Ui::integrationStatusDialog *ui;
    QStringList lst;

public slots:
    void hideProgressBar();
    void updateLabel(QString str);
    void updateProgress(int value);
    void elapsedUpdate();
    void updateProgressString(QString str);
    void removeProgressString(QString str);
    void updateLabels();
    void hideElements();
};

#endif // INTEGRATIONSTATUSDIALOG_H
