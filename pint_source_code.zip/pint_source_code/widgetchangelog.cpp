#include "widgetchangelog.h"
#include "ui_widgetchangelog.h"
#include "textstyle.h"


widgetChangelog::widgetChangelog(QWidget *parent, double sF) :
    QWidget(parent),scaleFactor(sF),
    ui(new Ui::widgetChangelog)
{
    ui->setupUi(this);
    setupCosmeticChanges();
    if(scaleFactor!=1.0)
        scaleWidget();
}

widgetChangelog::~widgetChangelog()
{
    delete ui;
}

void widgetChangelog::on_closeButton_clicked()
{
    emit goBack();
}

void widgetChangelog::setupCosmeticChanges()
{
    //Text shadow effect
    textStyle *style= new textStyle(this);
    textStyle *style2= new textStyle(this); //Intentional, QGraphicsDropShadowEffect does not allow for multiple renders at once
    ui->labelPINT->setGraphicsEffect(style->shadow);
    ui->labelVersion->setGraphicsEffect(style2->shadow);
}

void widgetChangelog::scaleWidget()
{
    //Buttons
    ui->closeButton->setMinimumSize(ui->closeButton->minimumSize().width()*scaleFactor, ui->closeButton->minimumSize().height()*scaleFactor);
    ui->closeButton->setMaximumSize(ui->closeButton->minimumSize());
    ui->closeButton->setIconSize(ui->closeButton->iconSize()*scaleFactor);

    //Labels
    ui->labelPINT->setFont(scaleFont(ui->labelPINT->font()));
    ui->closeLabel->setFont(scaleFont(ui->closeLabel->font()));
    ui->labelVersion->setFont(scaleFont(ui->labelVersion->font()));
}

QFont widgetChangelog::scaleFont(QFont fnt)
{
    fnt.setPointSizeF(fnt.pointSizeF()*scaleFactor);
    return fnt;
}
