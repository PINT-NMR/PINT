#ifndef WIDGETCHANGELOG_H
#define WIDGETCHANGELOG_H

#include <QWidget>

namespace Ui {
class widgetChangelog;
}

class widgetChangelog : public QWidget
{
    Q_OBJECT

public:
    explicit widgetChangelog(QWidget *parent = 0, double sF = 1.0);
    ~widgetChangelog();
    double scaleFactor;
    void scaleWidget();

private:
    Ui::widgetChangelog *ui;

signals:
    void goBack();

private slots:
    void on_closeButton_clicked();
    void setupCosmeticChanges();
    QFont scaleFont(QFont fnt);
};

#endif // WIDGETCHANGELOG_H
