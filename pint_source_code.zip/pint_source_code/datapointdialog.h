#ifndef DATAPOINTDIALOG_H
#define DATAPOINTDIALOG_H

#include <QDialog>

namespace Ui {
class datapointDialog;
}

class datapointDialog : public QDialog
{
    Q_OBJECT

public:
    explicit datapointDialog(QWidget *parent = 0);
    ~datapointDialog();
    int sizeF1;
    int sizeF2;
    double firstF1;
    double firstF2;
    double deltaF1;
    double deltaF2;
    double obsF1;
    double obsF2;
    double swF1;
    double swF2;
    double f1max, f1min, f2max, f2min;
    int skipVal;

public slots:
    void setupLimits();

private slots:
    void on_okButton_clicked();
    void on_cancelButton_clicked();
    void updateCount();

    void on_skipBox_currentIndexChanged(int index);

private:
    Ui::datapointDialog *ui;
};

#endif // DATAPOINTDIALOG_H
