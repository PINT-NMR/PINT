/********************************************************************************
** Form generated from reading UI file 'syntaxhelpdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SYNTAXHELPDIALOG_H
#define UI_SYNTAXHELPDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_syntaxHelpDialog
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout_22;
    QSpacerItem *horizontalSpacer_22;
    QLabel *hideHintLabel;
    QPushButton *hideHintButton;
    QTextBrowser *textBrowser;

    void setupUi(QWidget *syntaxHelpDialog)
    {
        if (syntaxHelpDialog->objectName().isEmpty())
            syntaxHelpDialog->setObjectName(QStringLiteral("syntaxHelpDialog"));
        syntaxHelpDialog->resize(572, 429);
        syntaxHelpDialog->setStyleSheet(QLatin1String("QDialog#syntaxHelpDialog {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
"}"));
        gridLayout = new QGridLayout(syntaxHelpDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_22);

        hideHintLabel = new QLabel(syntaxHelpDialog);
        hideHintLabel->setObjectName(QStringLiteral("hideHintLabel"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(hideHintLabel->sizePolicy().hasHeightForWidth());
        hideHintLabel->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QStringLiteral("Myriad Pro"));
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(50);
        hideHintLabel->setFont(font);

        horizontalLayout_22->addWidget(hideHintLabel);

        hideHintButton = new QPushButton(syntaxHelpDialog);
        hideHintButton->setObjectName(QStringLiteral("hideHintButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(hideHintButton->sizePolicy().hasHeightForWidth());
        hideHintButton->setSizePolicy(sizePolicy1);
        hideHintButton->setMinimumSize(QSize(30, 30));
        hideHintButton->setMaximumSize(QSize(30, 30));
        hideHintButton->setStyleSheet(QLatin1String("QPushButton#hideHintButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(155, 57, 57, 255), stop:1 rgba(188, 82, 83, 255));\n"
" border-style: outset;\n"
"border-radius: 5px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"color: white;\n"
"}\n"
"QPushButton#hideHintButton:pressed {\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(107, 36, 37, 255), stop:1 rgba(167, 58, 60, 255));\n"
" border-style: inset;\n"
"color: white;\n"
"}\n"
"QPushButton#hideHintButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(222, 82, 82, 255), stop:1 rgba(238, 105, 105, 255));\n"
" border-style: outset;\n"
"border-radius: 5px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"color: white;\n"
"}"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/img/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        hideHintButton->setIcon(icon);
        hideHintButton->setIconSize(QSize(25, 25));

        horizontalLayout_22->addWidget(hideHintButton);


        gridLayout->addLayout(horizontalLayout_22, 0, 0, 1, 1);

        textBrowser = new QTextBrowser(syntaxHelpDialog);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        QFont font1;
        font1.setFamily(QStringLiteral("Myriad Pro"));
        font1.setPointSize(12);
        textBrowser->setFont(font1);

        gridLayout->addWidget(textBrowser, 1, 0, 1, 1);


        retranslateUi(syntaxHelpDialog);

        QMetaObject::connectSlotsByName(syntaxHelpDialog);
    } // setupUi

    void retranslateUi(QWidget *syntaxHelpDialog)
    {
        syntaxHelpDialog->setWindowTitle(QApplication::translate("syntaxHelpDialog", "Form", 0));
        hideHintLabel->setText(QApplication::translate("syntaxHelpDialog", "<html><head/><body><p align=\"right\"><span style=\" color:#ffffff;\">Hide</span></p></body></html>", 0));
        hideHintButton->setText(QString());
        textBrowser->setHtml(QApplication::translate("syntaxHelpDialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Myriad Pro'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" text-decoration: underline;\">Customizing labels</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">PINT enables HTML syntax for the customization of title and axes labels.</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Below are some common basic examples. N.B. PINT is not limited to the listed examples.</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0p"
                        "x; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Bold text</span>: &lt;b&gt;TEXT&lt;/b&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-style:italic;\">Italics</span>: &lt;i&gt;TEXT&lt;/i&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" text-decoration: underline;\">Underline</span>: &lt;u&gt;TEXT&lt;/u&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Superscript<span style=\" vertical-align:super;\">Superscript</span>: &lt;sup&gt;TEXT&lt;/sup&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px"
                        "; -qt-block-indent:0; text-indent:0px;\">Subscript<span style=\" vertical-align:sub;\">Subscript</span>: &lt;sub&gt;TEXT&lt;/sub&gt;</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" text-decoration: underline;\">Greek letters</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">The syntax for symbols and letters:</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Uppercase letters (<span style=\" font-family:'Verdana,sans-serif'; font-size:22px; color:#000000; background-color:#ffffff;\">\316\251</span>): &amp;Omega; </p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right"
                        ":0px; -qt-block-indent:0; text-indent:0px;\">Lowercase letters (<span style=\" font-family:'Verdana,sans-serif'; font-size:22px; color:#000000; background-color:#ffffff;\">\317\211</span>): &amp;omega;</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class syntaxHelpDialog: public Ui_syntaxHelpDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SYNTAXHELPDIALOG_H
