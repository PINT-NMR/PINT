#include "customspinbox.h"
#include <QStyleOptionSpinBox>
#include <QMouseEvent>


customSpinBox::customSpinBox(QWidget *parent) : QSpinBox(parent)
{
}

customSpinBox::~customSpinBox()
{
}

void customSpinBox::mousePressEvent(QMouseEvent* event)
{
     QSpinBox::mousePressEvent(event);

    QStyleOptionSpinBox opt;
    this->initStyleOption(&opt);

    if( this->style()->subControlRect(QStyle::CC_SpinBox, &opt, QStyle::SC_SpinBoxUp).contains(event->pos()) )
        emit editingFinished();
    else if( this->style()->subControlRect(QStyle::CC_SpinBox, &opt, QStyle::SC_SpinBoxDown).contains(event->pos()))
        emit editingFinished();
}
