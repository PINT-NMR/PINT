#include "datapointdialog.h"
#include "ui_datapointdialog.h"


datapointDialog::datapointDialog(QWidget *parent) :
    QDialog(parent), sizeF1(0), sizeF2(0), firstF1(.0), firstF2(.0),
    obsF1(.0), obsF2(.0), swF1(.0), swF2(.0), f1max(.0), f1min(.0),
    f2max(.0), f2min(.0), skipVal(1),ui(new Ui::datapointDialog)
{

    ui->setupUi(this);
    ui->okButton->setEnabled(false);
}

datapointDialog::~datapointDialog()
{
    delete ui;
}

void datapointDialog::setupLimits()
{
    ui->f1MaxBox->setMaximum(firstF1/obsF1);
    ui->f1minBox->setMaximum(firstF1/obsF1);
    ui->f2MaxBox->setMaximum(firstF2/obsF2);
    ui->f2MinBox->setMaximum(firstF2/obsF2);
    ui->f1minBox->setMinimum((firstF1+deltaF1*(sizeF1-1))/obsF1);
    ui->f1MaxBox->setMinimum((firstF1+deltaF1*(sizeF1-1))/obsF1);
    ui->f2MinBox->setMinimum((firstF2+deltaF2*(sizeF2-1))/obsF2);
    ui->f2MaxBox->setMinimum((firstF2+deltaF2*(sizeF2-1))/obsF2);
    ui->f1MaxBox->setSingleStep((ui->f1MaxBox->maximum()-ui->f1MaxBox->minimum())/10.0);
    ui->f1minBox->setSingleStep((ui->f1MaxBox->maximum()-ui->f1MaxBox->minimum())/10.0);
    ui->f2MaxBox->setSingleStep((ui->f2MaxBox->maximum()-ui->f2MaxBox->minimum())/10.0);
    ui->f2MinBox->setSingleStep((ui->f2MaxBox->maximum()-ui->f2MaxBox->minimum())/10.0);

    ui->f1DatapointLabel->setText(QString::number(sizeF1));
    ui->f2DatapointLabel->setText(QString::number(sizeF2));
    ui->totalLabel->setText(QString::number(sizeF1*sizeF2));
    if(ui->totalLabel->text().toInt() <= 2e6 && ui->totalLabel->text().toInt() > 128)
        ui->okButton->setEnabled(true);
    QFont fnt("Myriad Pro", 11);
    ui->f1DatapointLabel->setFont(fnt);
    ui->f2DatapointLabel->setFont(fnt);
    ui->totalLabel->setFont(fnt);
    ui->f1MaxBox->setValue(ui->f1MaxBox->maximum());
    ui->f2MaxBox->setValue(ui->f2MaxBox->maximum());
    ui->f1minBox->setValue(ui->f1minBox->minimum());
    ui->f2MinBox->setValue(ui->f2MinBox->minimum());
    connect(ui->f1MaxBox, SIGNAL(valueChanged(double)), this, SLOT(updateCount()));
    connect(ui->f1minBox, SIGNAL(valueChanged(double)), this, SLOT(updateCount()));
    connect(ui->f2MinBox, SIGNAL(valueChanged(double)), this, SLOT(updateCount()));
    connect(ui->f2MaxBox, SIGNAL(valueChanged(double)), this, SLOT(updateCount()));
}

void datapointDialog::on_okButton_clicked()
{
    bool ok;
    int count(ui->totalLabel->text().toInt(&ok));
    if(ok && count <= 2e6 && count > 128)
    {
        sizeF1 = ui->f1DatapointLabel->text().toInt();
        sizeF2 = ui->f2DatapointLabel->text().toInt();
        if(ui->f1MaxBox->maximum()!=ui->f1MaxBox->value())
            firstF1 = ui->f1MaxBox->value()*obsF1;
        if(ui->f2MaxBox->maximum()!=ui->f2MaxBox->value())
            firstF2 = ui->f2MaxBox->value()*obsF2;

        if(ui->f1MaxBox->maximum()!=ui->f1MaxBox->value() ||
                ui->f1minBox->minimum()!=ui->f1minBox->value())
            swF1 = firstF1 - ui->f1minBox->value()*obsF1;
        if(ui->f2MaxBox->maximum()!=ui->f2MaxBox->value() ||
                ui->f2MinBox->minimum()!=ui->f2MinBox->value())
            swF2 = firstF2 - ui->f2MinBox->value()*obsF2;
        skipVal = ui->skipBox->currentText().toInt();
        accept();
    }
}

void datapointDialog::on_cancelButton_clicked()
{
    reject();
}

void datapointDialog::updateCount()
{
    ui->okButton->setEnabled(false);
    f1max = ui->f1MaxBox->value();
    f1min = ui->f1minBox->value();
    f2max = ui->f2MaxBox->value();
    f2min = ui->f2MinBox->value();
    skipVal = ui->skipBox->currentText().toInt();
    int f1(0), f2(0);
    if(f2max<f2min || f1max<f1min)
        return;
    if(f1max == ui->f1MaxBox->maximum() && f1min == ui->f1minBox->minimum())
        f1 = sizeF1;
    else
    {
        int u(0);
        double val(f1max*obsF1);
        if(f1max == ui->f1MaxBox->maximum())
            val = firstF1;
        while(firstF1+deltaF1*u>val)
            u+=skipVal;
        int v(0);
        while(firstF1+deltaF1*u+deltaF1*v>f1min*obsF1)
            v+=skipVal;
        f1=v;
        while(f1%skipVal!=0)
            f1--;
    }
        //
    if(f2max == ui->f2MaxBox->maximum() && f2min == ui->f2MinBox->minimum())
        f2 = sizeF2;
    else
    {
        double val2(f2max*obsF2);
        if(f2max == ui->f2MaxBox->maximum())
            val2 = firstF2;
        int u(0);
        while(firstF2+deltaF2*u>val2)
            u+=skipVal;
        int v(0);
        while(firstF2+deltaF2*u+deltaF2*v>f2min*obsF2)
            v+=skipVal;
        f2=v;
        while(f2%skipVal!=0)
            f2--;
    }
    f1/=skipVal;
    f2/=skipVal;
    ui->f1DatapointLabel->setText(QString::number(f1));
    ui->f2DatapointLabel->setText(QString::number(f2));
    ui->totalLabel->setText(QString::number(f1*f2));
    if(ui->totalLabel->text().toInt() <= 2e6 && ui->totalLabel->text().toInt() > 128)
        ui->okButton->setEnabled(true);
}

void datapointDialog::on_skipBox_currentIndexChanged(int index)
{
    Q_UNUSED(index)
    updateCount();
}
