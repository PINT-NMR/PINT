#include "nointworkerthread.h"
#include "cancelvar.h"
noIntWorkerThread::noIntWorkerThread(PeakListType argument, QObject* parent,
                                     VecString arg, OutputType arg2) :
    QObject(parent), peak((PeakListType) argument), error_msg((VecString) arg),
    output((OutputType) arg2)
{}

noIntWorkerThread::~noIntWorkerThread()
{}

void noIntWorkerThread::process()
{
    extern bool cancelVar;
    if(cancelVar)
    {
        emit finished();
        return;
    }
    Int i = output.printResult(peak, error_msg);
    if(cancelVar || i == 1)
    {
        emit finished();
        return;
    }
    output.printLists(peak, error_msg);
    emit finished();
}
