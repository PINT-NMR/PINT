#include "mainscreen.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    Q_INIT_RESOURCE(completer);
    QCoreApplication::addLibraryPath("./");
    //QLocale::setDefault(QLocale::c());
    QApplication a(argc, argv);
    MainScreen w;
    w.showMaximized();
    return a.exec();
}
