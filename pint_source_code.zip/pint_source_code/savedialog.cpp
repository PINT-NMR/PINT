#include "savedialog.h"
#include "ui_savedialog.h"
#include <QTimer>


saveDialog::saveDialog(QWidget *parent) :
    QDialog(parent), ui(new Ui::saveDialog), movie(new QMovie(":img/saving.gif", QByteArray(), this))
{
    ui->setupUi(this);
    movie->setParent(this);
    QSize size;
    size.setHeight(100);
    size.setWidth(100);
    movie->setScaledSize(size);
    ui->saveLabel->setMovie(movie);
    movie->start();
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(accept()));
    timer->start(1000);
}

saveDialog::~saveDialog()
{
    delete ui;
}
