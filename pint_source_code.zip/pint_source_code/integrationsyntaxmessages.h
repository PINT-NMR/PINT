#ifndef INTEGRATIONSYNTAXMESSAGES_H
#define INTEGRATIONSYNTAXMESSAGES_H
#include <QString>

class integrationSyntaxMessages
{
public:
    integrationSyntaxMessages();
    ~integrationSyntaxMessages();
    QString getMessage(int index);
};

#endif // INTEGRATIONSYNTAXMESSAGES_H
