#ifndef GENERATECONTOURPLOT_H
#define GENERATECONTOURPLOT_H
#include <qwt/qwt_plot.h>
#include <qwt/qwt_plot_spectrogram.h>
#include <qwt/qwt_plot_panner.h>
#include <cstdlib>
#include <QTimer>
#include "customzoomer.h"
#include "spectrumthemes.h"
#include "custommagnifier.h"
#include <QStringList>
#include "customplotpicker.h"
#include <QVector3D>
#include <QColor>
using namespace std;
class generateContourPlot: public QwtPlot
{
    Q_OBJECT

public:

    generateContourPlot( QWidget * = NULL );

public:
    ~generateContourPlot();
    int ctrlInt;
    int contourLevelsNumber;
    int contourLevelsNumberMin;
    double contourMin;
    double contourMinMin;
    double contourStep;
    double contourStepMin;
    int dragMode;
    bool ctrlPressed;
    QStringList selectedList;
    bool replotContour;
    bool moveModeEnabled;
    bool selectingFromRect;
    int modeSpec;
    QColor posContourColor;
    QColor negContourColor;
    bool loadedSpectrum;
    double f1Min;
    double f1Max;
    double f2Min;
    double f2Max;

public Q_SLOTS:
    void showContour( bool on );
    void showSpectrogram( bool on );
    void setColorMap( int );
    void setData(double firstF1, double firstF2, double stepYf1, double stepXf2, vector< vector<float> >yVec, double minX, double maxX, double minY, double maxY, double minZ, double maxZ);
    void setupWheelZooming(double minX,double maxX,double minY,double maxY);
    void updateCanvasScales();
    void updateContourLevels(int levels, double step, double min);
    void updateContourLevelsMin(int levels, double step, double min);
    void toggleSpectrogram();
    void changeTheme(spectrumThemes grad);
    void setTheme(spectrumThemes theme);
    void readPeaklist(QVector<QVector<QString> > peaklist, bool detAll);
    void updateContourPlotLabels(QVector<QString> vec);
    void deletePeak(QString peak);
    void detachAll();
    void updateZoom(float minF1, float maxF1, float minF2, float maxF2);
    void clearSelectedItems(QVector<QVector<QString> > peaklist);
    void highlightItems(QStringList list);
    void toggleMode(int mode);
    void exitMoveMode();
    void removeMarker();
    void toggleSpectrogramManual(int mode);
    void updateContourColors();
    void toggleLabels(bool labelsToggled);
    void ctrlDepressed(bool pressed);

private:
    QwtPlotSpectrogram *d_spectrogram;
    QwtPlotSpectrogram *neg_spectrogram;
    int d_mapType;
    bool moveForward;
    bool moveBackward;
    bool moveRight;
    bool moveLeft;
    bool moveYFlag;
    bool moveXFlag;
    QTimer *canvasTimer;
    int d_alpha;
    double iMin;
    double iMax;
    bool spectrogramBG;
    customZoomer *zoomer;
    spectrumThemes themeGradient;
    customMagnifier *zoom;
    QwtPlotPanner *panner;
    customPlotPicker *picker;
    customPlotPicker *pickerDrag;
    bool plotExist;
    bool validMove;
    QString movePoint;
    bool tempExist;
    QPointF moveToPoint;
    bool markerExist;
    bool labelsTogg;
    bool rendered;

private slots:
    bool eventFilter(QObject *obj, QEvent *event);
    void moveCanvasManual( double dx, double dy , int axis);
    void update3DZoom();
    void selectPoint(QPointF point);
    void selectRect(QRectF rect);
    void movePeakMode();

signals:
    void contourZoomed(float minF1, float maxF1, float minF2, float maxF2);
    void deselect();
    void highlight(QString peakidx);
    void ctrlPressedSync(bool pressed);
    void infoPeakMode(QString str, bool timerEnabled, int target);
    void defaultMoveModeFrame();
    void moveModeFrame();
    void updatePeakList(QString movePoint, QPointF moveToPoint);
    void createPeak(QVector3D vec,QString label);
    void contourPickPeaks(double minF1, double maxF1, double minF2, double maxF2);
};



#endif // GENERATECONTOURPLOT_H
