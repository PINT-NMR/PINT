#ifndef MAINSCREEN_H
#define MAINSCREEN_H

#include <QMainWindow>
#include "aboutwidget.h"
#include "mainwidget.h"
#include "loadprojectwidget.h"
#include "newprojectwidget.h"
#include "workspace.h"
#include "projecttemplate.h"
#include "widgetchangelog.h"


namespace Ui {
class MainScreen;
}

class MainScreen : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainScreen(QWidget *parent = 0);
    ~MainScreen();

private:
    aboutWidget *widget_about;
    widgetChangelog *widget_changelog;
    mainWidget *widget_main;
    loadProjectWidget *widget_load_project;
    newProjectWidget *widget_new_project;
    workspace *widget_workspace;
    bool newProject;
    QString templateFile;
    double scaleFactor;
    Ui::MainScreen *ui;

private slots:
    void renderMainWidget();
    void renderAbout();
    void renderChangelog();
    void renderLoadProject();
    void renderNewProject();
    void renderWorkspace(projectTemplate tmplate);
    void exitToMain();
    void exitToLoad();
    void quitApp();
    void openPlayer();
    void toggleBool(projectTemplate tmplate);
    void exitThenLoad();
    void exitThenMain();
};

#endif // MAINSCREEN_H
