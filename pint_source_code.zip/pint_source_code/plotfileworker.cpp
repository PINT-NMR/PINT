#include "plotfileworker.h"
#include <QTimer>
#include <iostream>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>

plotFileWorker::plotFileWorker(QObject* parent, QString arg1, int arg2, QString arg3)
    : QObject(parent), fname(arg1), rowNo(arg2), dir(arg3)
{}

plotFileWorker::~plotFileWorker()
{
}

void plotFileWorker::process()
{
    QString fit("N/A");
    fstream file;
    string fnam=dir.toStdString()+"/"+fname.toStdString();
    file.open(fnam.c_str(), ios::in);

    if(file.is_open())
    {
        int sampleCountX(0);
        int sampleCountZ(0);
        int tmpCount(0);
        string last("");
        vector<vector<float> >dataVec;
        string line;
        while(getline(file, line))
        {
            vector<float> tmpVec;
            if(line=="")
                continue;
            istringstream iss(line);
            string sub;
            int counter(1);
            while(iss>>sub)
            {
                if(counter==1)
                {
                    if(last!=sub)
                    {
                        sampleCountX++;
                        if(sampleCountZ<2)
                            sampleCountZ=tmpCount+1;
                    }
                    else
                        tmpCount++;
                    tmpVec.push_back(atof(sub.c_str()));
                    last=sub;
                }
                else if(counter==2)
                    tmpVec.push_back(atof(sub.c_str()));
                else if(counter==3)
                    tmpVec.push_back(atof(sub.c_str()));
                else if(counter==4)
                    tmpVec.push_back(atof(sub.c_str()));
                else
                    break;
                counter++;
            }
            dataVec.push_back(tmpVec);
        }
        file.close();
        if(dataVec.size()<16 || sampleCountX<4 || dataVec.size()/(sampleCountX+1)<4)
        {
            QStringList lst;
            lst << fit;
            lst << QString::number(rowNo);
            emit finished(lst);
        }
        else
        {
            float tmpMinZ(9e99), tmpMaxZ(-9e99);
            for(unsigned int i(0); i<dataVec.size(); i++)
            {
                if(dataVec[i][2]>tmpMaxZ)
                    tmpMaxZ=dataVec[i][2];
                if(dataVec[i][2]<tmpMinZ)
                    tmpMinZ=dataVec[i][2];
                if(dataVec[i][3]>tmpMaxZ)
                    tmpMaxZ=dataVec[i][3];
                if(dataVec[i][3]<tmpMinZ)
                    tmpMinZ=dataVec[i][3];
                if(dataVec[i][2]-dataVec[i][3]>tmpMaxZ)
                    tmpMaxZ=dataVec[i][2]-dataVec[i][3];
                if(dataVec[i][2]-dataVec[i][3]<tmpMinZ)
                    tmpMinZ=dataVec[i][2]-dataVec[i][3];
            }
            float sampleMaxY(tmpMaxZ);
            float sampleMinY(tmpMinZ);
            int noisePoints(0);
            double valSum(.0);
            for (int i = 0 ; i <sampleCountZ; i++)
            {
                for (unsigned int j = i; j <dataVec.size(); j+=sampleCountZ) {
                    double vMin(dataVec[j][3]);
                    double vMax(dataVec[j][2]);
                    if(vMax<vMin)
                    {
                        double tmp(vMax);
                        vMax=vMin;
                        vMin=tmp;
                    }
                    double val(fabs((vMax-vMin)/(sampleMaxY-sampleMinY)));
                    val*= (1.1 + fabs(dataVec[j][2])/(sampleMaxY-sampleMinY));
                    if((fabs(dataVec[j][2])/(sampleMaxY-sampleMinY)) < 0.04)
                        noisePoints++;
                    if(val>1.0)
                        val = 1.0;
                    valSum+=val;
                }
            }
            valSum/=(dataVec.size()-noisePoints+1);
            if(valSum<0.05)
                fit= "✪✪✪✪";
            else if(valSum<0.1)
                fit= "✪✪✪";
            else if (valSum<0.15)
                fit= "✪✪";
            else
                fit= "✪";
        }
    }
    QStringList lst;
    lst << fit;
    lst << QString::number(rowNo);
    emit finished(lst);
}
