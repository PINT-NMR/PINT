#ifndef AUTOMATICLABELFORMAT_H
#define AUTOMATICLABELFORMAT_H

#include <QDialog>
#include <QString>

namespace Ui {
class automaticLabelFormat;
}

class automaticLabelFormat : public QDialog
{
    Q_OBJECT

public:
    explicit automaticLabelFormat(QWidget *parent = 0, int arg = 1, int arg2 = 1, QString arg3 = "", QString arg4 = "");
    ~automaticLabelFormat();
    int autBase;
    int autIncrement;
    QString autPrefix;
    QString autSuffix;

private slots:
    void on_cancelButton_clicked();
    void on_okButton_clicked();
    bool errors();
    bool checkLegal(QString str, int type);
    void updateLabels();

private:
    Ui::automaticLabelFormat *ui;
    int character1;
    int character2;
    QString illegalChars;
};

#endif // AUTOMATICLABELFORMAT_H
