#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include "QGraphicsDropShadowEffect"
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>

namespace Ui {
class mainWidget;
}

class mainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit mainWidget(QWidget *parent = 0, double sF= 1.0);
    ~mainWidget();
    double scaleFactor;
    void scaleWidget();

private:
    Ui::mainWidget *ui;

signals:
    void openAbout();
    void openLoadProject();
    void closeApp();
    void openNewProject();
    void openPlayer();
    void openChange();

private slots:
    void setupCosmeticChanges();
    void checkUpdates();
    void replyFinished(QNetworkReply* reply);
    void on_aboutButton_clicked();
    void on_changelogButton_clicked();
    void on_exitButton_clicked();
    void on_updateButton_clicked();
    void on_loadButton_clicked();
    void on_newButton_clicked();
    QFont scaleFont(QFont fnt);
    void on_tutorialButton_clicked();
};

#endif // MAINWIDGET_H
