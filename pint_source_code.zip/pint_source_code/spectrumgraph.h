#ifndef SPECTRUMGRAPH_H
#define SPECTRUMGRAPH_H
#include <QtDataVisualization/Q3DSurface>
#include <QtDataVisualization/QSurface3DSeries>
#include <QtDataVisualization/QSurfaceDataProxy>
#include <QtWidgets/QSlider>
#include <cstdlib>
#include <QListWidgetItem>
#include <QtDataVisualization/QCustom3DLabel>
#include <QPropertyAnimation>
#include <QTimer>
#include <QTableWidget>
#include "customitemproperties.h"
#include "spectrumthemes.h"

using namespace QtDataVisualization;
using namespace std;

class SpectrumGraph : public QObject
{
    Q_OBJECT
public:
    explicit SpectrumGraph(QObject *parent, Q3DSurface *surface);
    ~SpectrumGraph();
    Q3DSurface *spectrum_graph;
    bool peakIsSelected;
    bool ctrlPressed;
    bool dragging;
    QPoint startDragPosition;
    QVector<customItemProperties* > selectionVector;
    bool lmbPressed;
    bool moveModeEnabled;
    spectrumThemes activeTheme;
    QSurfaceDataProxy *spectrum_renderPlotProxy;
    int toggledMode;
    QVector<QPointF> previousF1Scale;
    QVector<QPointF> previousF2Scale;
    int zoomCounter;
    double minF1;
    double maxF1;
    double minF2;
    double maxF2;
    double marginal;

private:
    QSurface3DSeries *spectrum_renderPlotSeries;
    QSurfaceDataRow *newRow;
    int ctrlInt;
    double minIntensity;
    double maxIntensity;
    QPropertyAnimation *m_animationCameraX;
    QVector3D target;
    bool moveForward;
    bool moveBackward;
    bool moveRight;
    bool moveLeft;
    bool moveYFlag;
    bool moveXFlag;
    QTimer *cameraTimer;
    QPropertyAnimation *m_selectionAnimation;
    QCustom3DItem *m_previouslyAnimatedItem;
    QCustom3DItem *m_previouslyAnimatedItem2;
    QCustom3DItem *m_selectionItem;
    QCustom3DLabel *selectedHighlightLabel;
    QVector3D m_previousScaling;
    QVector3D m_previousScaling2;
    QColor m_previousColor;
    QVector3D m_previousPosition;
    void selectionEffects(QCustom3DItem *item, QCustom3DItem *item2,QString label);
    void centerCamera(QCustom3DItem *item);
    QCustom3DItem *draggedItem;
    int deb;
    bool selectedSeries;
    bool disabled;
    double m_stepF1;
    double m_stepF2;
    bool gotDragStartPoint;
    bool getDragEndPoint;
    void undoZoom();
    bool moveModeLabel;
    QString moveLabelText;
    bool validMove;
    QString moveObjName;
    bool rendered;

public slots:
    void setAxisF1Range(float min, float max);
    void setAxisF2Range(float min, float max);
    void movePeakMode();
    void createUserPeak();
    void deleteUserPeak();
    void handleElementSelected(QAbstract3DGraph::ElementType type, QString label);
    void renderPlot(vector<double> f1, vector<double> f2, vector<double> y, int f1Size, int f2size);
    void setAxisIntensityRange(double min, double max);
    void adjustIntensityMin(double min);
    void setupVisuals();
    void overrideCamera();
    bool eventFilter(QObject *obj, QEvent *event);
    void customCamera();
    void clearPlots(bool newSpec);
    void addCustomLabel(QString label, QVector3D position, int globalID, bool folded);
    void removeCustomLabel(int globalID);
    void highlightSelection(QString obj, QString label, bool isCtrlPressed, bool viewActive);
    QVector3D normalize(float x, float y, float z);
    void handleDragging();
    void handleChange(QAbstract3DGraph::ElementType type);
    void changeTheme(spectrumThemes theme);
    void clearSelectedItems();
    bool clearSelectedItemsExcept(QString obj);
    void handleDeselection(QString obj);
    void deleteFromSelectionVector(QString obj);
    void exitMoveMode();
    void removeSelectionItem();

signals:
    QAbstract3DGraph::ElementType requestLabelTitle(QAbstract3DGraph::ElementType type);
    void deselectTable();
    void createPeak();
    void deletePeak();
    void createPeakConfirmed();
    void addToPeakTable(QVector3D position, QString label);
    void deleteFromPeakTable();
    void centerPeaks();
    void syncPeakTable(QString query, bool select);
    void selectAll();
    void infoPeakMode(QString str, bool timerEnabled, int target);
    void updatePeakPosition(QVector3D position, QString objName);
    void undoEvent();
    void redoEvent();
    void moveModeFrame();
    void defaultMoveModeFrame();
    void foldPeak();
    void selectPeaksWithinBorder(float x1,float x2,float z1,float z2);
    void pickPeaksWithinBorder(double x1,double x2,double z1,double z2);
    void pressCtrl(bool pressed);
    void zoomed();
};

#endif // SPECTRUMGRAPH_H
