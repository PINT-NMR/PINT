#ifndef CANCELVAR_H
#define CANCELVAR_H
extern bool cancelVar;
#endif // CANCELVAR_H
