#include "integrationsyntaxmessages.h"
#include <QFile>
integrationSyntaxMessages::integrationSyntaxMessages()
{}

integrationSyntaxMessages::~integrationSyntaxMessages()
{}

QString integrationSyntaxMessages::getMessage(int index)
{
    QFile file(":/syntax_help_lib.txt");
    if (!file.open(QFile::ReadOnly)) return "";
    int i(0);
    while (!file.atEnd())
    {
        QByteArray line = file.readLine();
        if (i==index)
        {
            file.close();
            return line.trimmed();
        }
        i++;
    }
    file.close();
    return "";
}
