#include "custommagnifier.h"
