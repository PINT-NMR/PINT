#ifndef THEMECLASS_H
#define THEMECLASS_H
#include <QVector>
#include "spectrumgraph.h"
#include <QString>

class themeClass
{
public:
    themeClass();
    ~themeClass();
    QVector<spectrumThemes> themeVector;

private slots:
    bool fileExists(QString path);
};

#endif // THEMECLASS_H
