/********************************************************************************
** Form generated from reading UI file 'overlaywidget.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OVERLAYWIDGET_H
#define UI_OVERLAYWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_overlayWidget
{
public:
    QGridLayout *gridLayout;
    QWidget *overlayWidget_2;
    QVBoxLayout *verticalLayout_24;
    QHBoxLayout *horizontalLayout_16;
    QLabel *navLabel1;
    QLabel *navLabel2;
    QHBoxLayout *horizontalLayout_17;
    QLabel *zoomLabel;
    QLabel *zoomLabel2;
    QHBoxLayout *horizontalLayout_18;
    QLabel *rotateLabel;
    QLabel *rotateLabel2;
    QHBoxLayout *horizontalLayout_19;
    QLabel *selectLabel;
    QLabel *selectLabel_2;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *overlayWidget)
    {
        if (overlayWidget->objectName().isEmpty())
            overlayWidget->setObjectName(QStringLiteral("overlayWidget"));
        overlayWidget->resize(476, 359);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(overlayWidget->sizePolicy().hasHeightForWidth());
        overlayWidget->setSizePolicy(sizePolicy);
        gridLayout = new QGridLayout(overlayWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        overlayWidget_2 = new QWidget(overlayWidget);
        overlayWidget_2->setObjectName(QStringLiteral("overlayWidget_2"));
        verticalLayout_24 = new QVBoxLayout(overlayWidget_2);
        verticalLayout_24->setObjectName(QStringLiteral("verticalLayout_24"));
        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        navLabel1 = new QLabel(overlayWidget_2);
        navLabel1->setObjectName(QStringLiteral("navLabel1"));
        navLabel1->setMaximumSize(QSize(60, 60));
        navLabel1->setPixmap(QPixmap(QString::fromUtf8(":/img/wasd.png")));
        navLabel1->setScaledContents(true);

        horizontalLayout_16->addWidget(navLabel1);

        navLabel2 = new QLabel(overlayWidget_2);
        navLabel2->setObjectName(QStringLiteral("navLabel2"));
        QFont font;
        font.setFamily(QStringLiteral("Myriad Pro"));
        font.setPointSize(12);
        font.setBold(false);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(50);
        navLabel2->setFont(font);

        horizontalLayout_16->addWidget(navLabel2);


        verticalLayout_24->addLayout(horizontalLayout_16);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        zoomLabel = new QLabel(overlayWidget_2);
        zoomLabel->setObjectName(QStringLiteral("zoomLabel"));
        zoomLabel->setMaximumSize(QSize(60, 60));
        zoomLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/mouse_scroll.png")));
        zoomLabel->setScaledContents(true);

        horizontalLayout_17->addWidget(zoomLabel);

        zoomLabel2 = new QLabel(overlayWidget_2);
        zoomLabel2->setObjectName(QStringLiteral("zoomLabel2"));
        zoomLabel2->setFont(font);

        horizontalLayout_17->addWidget(zoomLabel2);


        verticalLayout_24->addLayout(horizontalLayout_17);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        rotateLabel = new QLabel(overlayWidget_2);
        rotateLabel->setObjectName(QStringLiteral("rotateLabel"));
        rotateLabel->setMaximumSize(QSize(60, 60));
        rotateLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/mouse_r_click.png")));
        rotateLabel->setScaledContents(true);

        horizontalLayout_18->addWidget(rotateLabel);

        rotateLabel2 = new QLabel(overlayWidget_2);
        rotateLabel2->setObjectName(QStringLiteral("rotateLabel2"));
        rotateLabel2->setFont(font);

        horizontalLayout_18->addWidget(rotateLabel2);


        verticalLayout_24->addLayout(horizontalLayout_18);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        selectLabel = new QLabel(overlayWidget_2);
        selectLabel->setObjectName(QStringLiteral("selectLabel"));
        selectLabel->setMaximumSize(QSize(60, 60));
        selectLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/mouse_l_click.png")));
        selectLabel->setScaledContents(true);

        horizontalLayout_19->addWidget(selectLabel);

        selectLabel_2 = new QLabel(overlayWidget_2);
        selectLabel_2->setObjectName(QStringLiteral("selectLabel_2"));
        selectLabel_2->setFont(font);

        horizontalLayout_19->addWidget(selectLabel_2);


        verticalLayout_24->addLayout(horizontalLayout_19);


        gridLayout->addWidget(overlayWidget_2, 0, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 0, 1, 1);


        retranslateUi(overlayWidget);

        QMetaObject::connectSlotsByName(overlayWidget);
    } // setupUi

    void retranslateUi(QWidget *overlayWidget)
    {
        overlayWidget->setWindowTitle(QApplication::translate("overlayWidget", "Form", 0));
        navLabel1->setText(QString());
        navLabel2->setText(QApplication::translate("overlayWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Navigation</span></p></body></html>", 0));
        zoomLabel->setText(QString());
        zoomLabel2->setText(QApplication::translate("overlayWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Zoom</span></p></body></html>", 0));
        rotateLabel->setText(QString());
        rotateLabel2->setText(QApplication::translate("overlayWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Rotate</span></p></body></html>", 0));
        selectLabel->setText(QString());
        selectLabel_2->setText(QApplication::translate("overlayWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Select</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class overlayWidget: public Ui_overlayWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OVERLAYWIDGET_H
