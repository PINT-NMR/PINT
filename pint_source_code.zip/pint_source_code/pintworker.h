#ifndef PINTWORKER_H
#define PINTWORKER_H
#include <QString>
#include <QObject>
#include "integration/parser.h"
#include "integration/esd.h"
#include "integration/peakfit.h"
#include "integration/plot.h"
#include "integration/output.h"

class pintWorker : public QObject {
    Q_OBJECT

public:
    pintWorker(PeakFitType *argument, QObject* parent = 0, int ID=0);
    ~pintWorker();
    PeakFitType *p;
    int ID_no;
    PlotType *plot;

public slots:
    void process();

signals:
    void removeString(QString);
    void finished(QString);

private:
    string outfname;
};

#endif // PINTWORKER_H
