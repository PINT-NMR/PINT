#include "workspace.h"
#include "ui_workspace.h"
#include <QShortcut>
#include <QSignalMapper>
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <sstream>
#include "integration/pint.h"
#include <QDirIterator>
#include <QtMath>
#include "integration/peak.h"
#include "integration/spectrum.h"
#include "integration/peakfit.h"
#include "integration/esd.h"
#include "integration/parser.h"
#include "integration/output.h"
#include "integration/sort.h"
#include <QThread>
#include <QGroupBox>
#include "qcpdocumentobject.h"
#include <QCompleter>
#include "integrationsyntaxmessages.h"
#include "themeclass.h"
#include "integrationtemplatesclass.h"
#include "cancelvar.h"
#include "datapointdialog.h"
#include "folddialog.h"
#include "savedialog.h"
#include "automaticlabelformat.h"
#include "fileviewer.h"
#include "peaklistdialog.h"
#include "player.h"
#include "hintdialog.h"
#include "screendialog.h"


workspace::workspace(QWidget *parent, projectTemplate tmplate, bool newProject)
    :
      QWidget(parent), previousDir(QDir::currentPath()), ctrlInt(16777249), completer(0), paramEdit(0),
      iDialog(0), pintTemplate(projectTemplate()),
      spectrumView3D(0), plotView3D(0), cutoffSliderMax(1.0), cutoffSliderMin(0.0), minF1(0.0),
      minF2(0.0), maxF1(1.0), maxF2(1.0), errMsg(""), loadedSpectrum(""), peakId(0), selectedTableList(0), selectedTableList2(0),
      rubberBand(0), origin(0,0), msgTimer(0), stateVector(0),currentState(-1), statePeakId(0), ctrlPressed(false),
      themeVector(0), themeList(0), generateIntensities(false), threadsCount(0), threadsDone(0), colorFitGraph(0), colorExpGraph(0),
      fitInfoBrowser(0), plotColor(QColor(0,0,0)), themeListPlot(0),
      error_msg(0), plot("",0), workerThreads(0), noIntWorker(0), vecPFW(0), workerPlot(0), threadID(0), activeThreadID(0), integration(false), centeringPeak(false),
      toggledMode(1), centerPeakMode(false), autBase(999), autIncrement(1), autPrefix(""), autSuffix("N-HN"), quitIntegration(false),
      plot2DVec(0), plotStr(""), dataColor(Qt::black), errorColor(Qt::black), dataPenSize(1), errorPenSize(2), currentPlotIndex(0), titleQCustomPlotFit(0),
      titleQCustomPlotPlot(0), fitStyle(QCPScatterStyle::ssDisc), plotStyle(QCPScatterStyle::ssDisc), fitDataColor(QColor(0,0,0)), fitFitColor(QColor(0,0,0)), plotDataColor(QColor(0,0,0)),
      abortFitSave(false), nDim(0), contourPlot(0), errorIntegration(false), priorSelection(""), priorSelection2D(""), posContourColor(QColor(0,0,0)),
      negContourColor(QColor(0, 255, 0)), tmpltVec(0), parameterEditChanged(false), defaultTemplateCount(0), sdev(1.0), labelsToggled(true),
      dataPointCount(0), renderPlot(false), specmode(0), rendering(false), abortCP(false), restoringState(false), togglingStates(false),
      ui(new Ui::workspace), xMinZoom(0.0), xMaxZoom(1.0), yMinZoom(0.0), yMaxZoom(1.0), zMinZoom(0.0), zMaxZoom(1.0), zoomSaved(false),
      peaklistFormat(0), minY(0.0), minX(0.0), maxX(1.0), maxY(1.0), minYfit(0.0), minXfit(0.0), maxXfit(1.0), maxYfit(1.0), totalSec(0),
      movie(new QMovie(":img/warning.gif", QByteArray(), this)), movie2(new QMovie(":img/warning.gif", QByteArray(), this)), nPlane(0),
      plotSignalMapperType(0), plotSignalMapperType2(0), menuBar(0), rendering3Dplot(false), plotQueue(QQueue<int>())
{
    ui->setupUi(this);
    //    connect(ui->actionLoad_project, &QAction::triggered, this, &workspace::goToLoad);
    //return;
    qRegisterMetaType<pipeDataTemplate>("pipeDataTemplate");
#ifdef Q_OS_MAC
    ctrlInt = 16777250;
#endif
    initializePeaklistFormat();
    initializeAutomaticLabelFormat();
    if(QString::number(QThread::idealThreadCount())>0)
        ui->threadsBox->setValue(QThread::idealThreadCount());

    loadThemes();
    setupSpectrumWidget();
    setupPlotWidget();
    setup2DFitWidget();
    setup2DPlotWidget();
    setupContourPlotWidget();

    setupCompleter(true);
    loadIntegrationTemplates();
    setupCosmeticChanges();
    readFromTemplate(tmplate);
    changeActions(0);
    if(newProject)
    {
        importDefaultParameterEdit();
        saveProject();
    }
    if(tmplate.projectDirectory!="")
        previousDir = tmplate.projectDirectory;
#ifdef Q_OS_MAC
        displayInformation("Use the fn+F1-F7 keys to switch between tabs.", false, -1);
#else
        displayInformation("Use the F1-F7 keys to switch between tabs.", false, -1);
#endif
}

void allocateMyVectors(VecDoub &yopt, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, Int npar, Int sizecounter)
{
    yopt = VecDoub(npar);
    f1 = VecDoub(sizecounter);
    f2 = VecDoub(sizecounter);
    f3 = VecInt(sizecounter);
    y = VecDoub(sizecounter);
    sig = VecDoub(sizecounter);
}

void workspace::disconnectObjects()
{
    spectrumView3D->disconnect();
    themeList->disconnect();
    themeListPlot->disconnect();
    colorExpGraph->disconnect();
    colorFitGraph->disconnect();
    fitInfoBrowser->disconnect();
    plotView3D->disconnect();
    contourPlot->disconnect();
}

workspace::~workspace()
{
    if(rubberBand)
        rubberBand->deleteLater();
    delete ui;
}

void workspace::initStateVector()
{
    for(int i(0); i<stateVector.size(); i++)
    {
        stateVector.remove(i);
        statePeakId.remove(i);
    }
    currentState = -1;
}

void workspace::loadThemes()
{
    for(int i(0); i<themeVector.size(); i++)
        themeVector.remove(i);
    themeClass themes;
    themeVector = themes.themeVector;
}

bool workspace::fileExists(QString path)
{
    QFileInfo check_file(path);
    return (check_file.exists() && check_file.isFile());
}


int workspace::setActiveTheme()
{
    spectrumView3D->changeTheme(themeVector[0]);
    plotView3D->changeTheme(themeVector[1]);

    return 0;
}

void workspace::setupSpectrumWidget()
{
    //This widget displays 3D HSQC spectra
    QHBoxLayout *hLayout = new QHBoxLayout();
    QVBoxLayout *vLayout = new QVBoxLayout();
    QHBoxLayout *hLayout2 = new QHBoxLayout();
    Q3DSurface *spectrum3DSurface = new Q3DSurface();
    QWidget *container = QWidget::createWindowContainer(spectrum3DSurface);

    container->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    container->setMinimumSize(0,0);
    container->setFocusPolicy(Qt::StrongFocus);
    hLayout->addWidget(container, 1);
    hLayout->addLayout(vLayout);
    vLayout->setAlignment(Qt::AlignTop);
    ui->spectrum2DWidget->setLayout(hLayout);

    spectrumView3D = new SpectrumGraph(0, spectrum3DSurface);
    QApplication::processEvents();
    connect(spectrumView3D, SIGNAL(requestLabelTitle(QAbstract3DGraph::ElementType)), this, SLOT(sendLabelTitle(QAbstract3DGraph::ElementType)));

    //Setup combo box for selecting themes for spectra
    hLayout2->setAlignment(Qt::AlignRight);
    QLabel *themeLabel = new QLabel(QStringLiteral("<font color='black'>Theme</font>"));
    themeList = new QComboBox();
    themeLabel->setFont(QFont("Myriad Pro", 12));
    hLayout2->addWidget(themeLabel);
    for(int i(0); i<themeVector.size(); i++)
        themeList->addItem(themeVector[i].style);
    themeList->setStyleSheet("    color: white;\nbackground-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));"
                             "border-color: rgba(71,78,81,255);"
                             "border-width: 2px;"
                             "border-style: solid;"
                             "padding: 1px 0px 1px 3px;");
    themeList->setMinimumWidth(170);
    hLayout2->addWidget(themeList);
    ui->specLayout->addLayout(hLayout2);

    //Apply the active theme used in previous session
    QObject::connect(themeList, SIGNAL(currentIndexChanged(int)), this, SLOT(changeTheme(int)));
    ui->peaklistTable->horizontalHeader()->setSectionsClickable(false);

    ui->spectrum2DWidget->hide();
    ui->zMaxEdit->hide();
    ui->zMaxLabel->hide();
    ui->zMinEdit->hide();
    ui->zMinLabel->hide();
    ui->adjustZButton->hide();
    ui->flipZButton->hide();
    ui->intensityGroupBox->hide();
    ui->autoAdjustZButton->hide();
}

void workspace::changePlotTheme(int theme)
{
    plotView3D->changeTheme(themeVector[theme]);
}

void workspace::changeTheme(int theme)
{
    spectrumView3D->exitMoveMode();
    contourPlot->exitMoveMode();
    spectrumView3D->changeTheme(themeVector[theme]);
    contourPlot->changeTheme(themeVector[theme]);
    if(stateVector.size()>0)
        restoreStateFromVec();
}

void workspace::setupPlotWidget()
{
    //This widget displays 3D plots for integrated peaks
    QHBoxLayout *hLayout = new QHBoxLayout();
    QVBoxLayout *vLayout = new QVBoxLayout();
    QGroupBox *colorGroupBox = new QGroupBox(QStringLiteral("Plot colors"));
    QGridLayout *colorLayout= new QGridLayout();
    QVBoxLayout *expandLayout = new QVBoxLayout();
    Q3DSurface *plot3DSurface = new Q3DSurface();
    QWidget *container = QWidget::createWindowContainer(plot3DSurface);
    QVBoxLayout *gridLayout = new QVBoxLayout();

    container->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    container->setMinimumSize(0,0);
    container->setFocusPolicy(Qt::StrongFocus);

    hLayout->addWidget(container, 1);
    hLayout->addLayout(vLayout);
    vLayout->setAlignment(Qt::AlignTop);
    ui->plotWidget->setLayout(hLayout);

    //<Theme list>
    themeListPlot = new QComboBox();
    for(int i(0); i<themeVector.size(); i++)
        themeListPlot->addItem(themeVector[i].style);
    themeListPlot->setCurrentIndex(0);
    themeListPlot->setStyleSheet("    color: white;\nbackground-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));"
                                 "border-color: rgba(71,78,81,255);"
                                 "border-width: 2px;"
                                 "border-style: solid;"
                                 "padding: 1px 0px 1px 3px;");
    //</Theme list>
    colorGroupBox->setStyleSheet("QGroupBox{color:black;\nfont-size: 10pt;}");

    //<Color picker>
    QPixmap pm2(50, 50);
    pm2.fill(QColor(80,80,80));

    colorExpGraph = new QPushButton();
    colorExpGraph->setIcon(QIcon(pm2));
    colorExpGraph->setIconSize(QSize(50, 50));

    pm2.fill(QColor(240,240,240));
    colorFitGraph = new QPushButton();
    colorFitGraph->setIcon(QIcon(pm2));
    colorFitGraph->setIconSize(QSize(50, 50));
    colorLayout->addWidget(new QLabel(QStringLiteral("<html><head/><body><p><span style=\" font-size:10pt; color:#000000;\">Exp. data</span></p></body></html>")));
    colorLayout->addWidget(colorExpGraph);
    colorLayout->addWidget(new QLabel(QStringLiteral("<html><head/><body><p><span style=\" font-size:10pt; color:#000000;\">Fitted data</span></p></body></html>")));
    colorLayout->addWidget(colorFitGraph);
    colorGroupBox->setLayout(colorLayout);

    QSignalMapper* colorSignalMapper = new QSignalMapper (this);
    connect(colorExpGraph, SIGNAL(clicked()), colorSignalMapper, SLOT(map())) ;
    connect(colorFitGraph, SIGNAL(clicked()), colorSignalMapper, SLOT(map())) ;
    colorSignalMapper->setMapping(colorExpGraph, 0);
    colorSignalMapper->setMapping(colorFitGraph, 1);
    //</Color picker>

    //<Toggle buttons>
    QGroupBox *toggleGroupBox = new QGroupBox(QStringLiteral("Toggle surface"));
    toggleGroupBox->setStyleSheet("QGroupBox{color:black;\nfont-size: 10pt;}");
    QPushButton *toggleTitleButton = new QPushButton();
    toggleTitleButton->setText("Toggle labels");
    QPushButton *toggleDiffButton = new QPushButton();
    toggleDiffButton->setText("Toggle difference map");
    QPushButton *toggleGridButton = new QPushButton();
    toggleGridButton->setText("Exp. data");
    QPushButton *toggleFitGridButton = new QPushButton();
    toggleFitGridButton->setText("Fitted data");
    QPushButton *toggleMapGridButton = new QPushButton();
    toggleMapGridButton->setText("Difference map");
    gridLayout->addWidget(toggleGridButton);
    gridLayout->addWidget(toggleFitGridButton);
    gridLayout->addWidget(toggleMapGridButton);
    toggleGroupBox->setLayout(gridLayout);

    QSignalMapper* gridSignalMapper = new QSignalMapper (this);
    connect(toggleGridButton, SIGNAL(clicked()), gridSignalMapper, SLOT(map())) ;
    connect(toggleFitGridButton, SIGNAL(clicked()), gridSignalMapper, SLOT(map())) ;
    connect(toggleMapGridButton, SIGNAL(clicked()), gridSignalMapper, SLOT(map())) ;
    gridSignalMapper->setMapping(toggleGridButton, 0);
    gridSignalMapper->setMapping(toggleFitGridButton, 1);
    gridSignalMapper->setMapping(toggleMapGridButton, 2);

    QPushButton *viewInSpectrumButton = new QPushButton();
#ifdef Q_OS_MAC
    viewInSpectrumButton->setText("View in spectrum (fn+F4)");
#else
    viewInSpectrumButton->setText("View in spectrum (F4)");
#endif
    connect(viewInSpectrumButton, SIGNAL(clicked()), this, SLOT(viewRegionInSpectrum()));

    QPushButton *expandInfoButton= new QPushButton();
    expandInfoButton->setText("Toggle results of fit");
    fitInfoBrowser = new QTextBrowser();
    expandLayout->addWidget(expandInfoButton,0, Qt::AlignTop);
    expandLayout->addWidget(fitInfoBrowser);
    fitInfoBrowser->setVisible(false);
    connect(expandInfoButton, SIGNAL(clicked(bool)), this, SLOT(toggleInfoBrowser()));

    //</Toggle buttons>

    //<Adding widgets to layout>
    vLayout->addWidget(new QLabel(QStringLiteral("<html><head/><body><p><span style=\" font-size:10pt; color:#000000;\">Theme</span></p></body></html>")));
    vLayout->addWidget(themeListPlot);
    vLayout->addWidget(colorGroupBox);
    vLayout->addWidget(toggleTitleButton);
    vLayout->addWidget(toggleDiffButton);
    vLayout->addWidget(toggleGroupBox);
    vLayout->addWidget(viewInSpectrumButton);
    vLayout->addLayout(expandLayout);
    //</Adding widgets to layout>

    plotView3D = new plotGraph(0, plot3DSurface);
    QObject::connect(themeListPlot, SIGNAL(currentIndexChanged(int)), this, SLOT(changePlotTheme(int)));
    QObject::connect(toggleTitleButton, &QPushButton::pressed,
                     plotView3D, &plotGraph::toggleItems);
    QObject::connect(toggleDiffButton, &QPushButton::pressed,
                     plotView3D, &plotGraph::toggleDiffPlot);
    QObject::connect(gridSignalMapper, SIGNAL(mapped(int)),
                     plotView3D, SLOT(toggleGrid(int)));
    QObject::connect(colorSignalMapper, SIGNAL(mapped(int)),
                     this, SLOT(setColor(int)));
    plotView3D->plot_graph->scene()->activeCamera()->setXRotation(235);
    plotView3D->plot_graph->scene()->activeCamera()->setYRotation(15.0);
    plotView3D->plot_graph->scene()->activeCamera()->setZoomLevel(80.0);
    themeList->setCurrentIndex(setActiveTheme());
    themeListPlot->setCurrentIndex(setActiveTheme()+1);
}

void workspace::setupContourPlotWidget()
{
    contourPlot = new generateContourPlot(0);
    contourPlot->setAutoDelete(true);
    contourPlot->dragMode = toggledMode;
    ui->contourLayout->addWidget(contourPlot);
    contourPlot->show();
    contourPlot->setTheme(themeVector[0]);
    connect(contourPlot, SIGNAL(deselect()), this, SLOT(deselectContour()));
    connect(contourPlot, SIGNAL(ctrlPressedSync(bool)), this, SLOT(syncCtrl(bool)));
}

void workspace::setColor(int model)
{
    QColor color = QColorDialog::getColor(Qt::red, this);
    if(color.isValid())
    {
        plotColor = color;
        QPixmap pm(50, 50);
        pm.fill(plotColor);
        if(model==0)
            colorExpGraph->setIcon(pm);
        else
            colorFitGraph->setIcon(pm);
        plotView3D->setColor(plotColor,model);
    }
}

void workspace::readFromTemplate(projectTemplate tmplate)
{
    //Use tmplate to prepare the workspace accordingly
    pintTemplate = tmplate;
    ui->planeBox->setMinimum(1);
    ui->planeBox->setMaximum(pintTemplate.planeMax);
    if(pintTemplate.planeMax>1)
    {
        ui->planeBox->setEnabled(true);
        ui->allPlanesBox->setEnabled(true);
    }
    else
    {
        ui->planeBox->setEnabled(false);
        ui->allPlanesBox->setEnabled(false);
    }
    for(int i(0); i<pintTemplate.spectrumFiles.size(); i++)
    {
        ui->spectrumList->addItem(pintTemplate.spectrumFiles.at(i));
        ui->spectrumDefineBox->addItem(pintTemplate.spectrumFiles.at(i));
        ui->spectrumBox->addItem(pintTemplate.spectrumFiles.at(i));
    }
    for(int i(0); i<pintTemplate.peaklistFiles.size(); i++)
    {
        ui->peaklistList->addItem(pintTemplate.peaklistFiles.at(i));
        ui->peaklistBox->addItem(pintTemplate.peaklistFiles.at(i));
        ui->peaklistDefineBox->addItem(pintTemplate.peaklistFiles.at(i));
    }
    for(int i(0); i<pintTemplate.otherFiles.size(); i++)
    {
        ui->otherList->addItem(pintTemplate.otherFiles.at(i));
        ui->procparDefineBox->addItem(pintTemplate.otherFiles.at(i));
        if(ui->procparDefineBox->currentIndex()==0 && pintTemplate.otherFiles.at(i).contains("procpar", Qt::CaseInsensitive))
        {
            ui->procparDefineBox->setCurrentIndex(ui->procparDefineBox->count()-1);
            ui->procparRadioButton->setChecked(true);
            ui->vdlistRadioButton->setChecked(false);
        }
        else if(ui->procparDefineBox->currentIndex()==0 && pintTemplate.otherFiles.at(i).contains("vdlist", Qt::CaseInsensitive))
        {
            ui->procparDefineBox->setCurrentIndex(ui->procparDefineBox->count()-1);
            ui->procparRadioButton->setChecked(false);
            ui->vdlistRadioButton->setChecked(true);
        }
    }
    if(pintTemplate.currentPeakID!="")
    {
        bool ok;
        peakId = pintTemplate.currentPeakID.toInt(&ok);
        if(!ok)
            peakId=0;
    }
    if(pintTemplate.spD<ui->spectrumDefineBox->count())
        ui->spectrumDefineBox->setCurrentIndex(pintTemplate.spD);
    if(pintTemplate.peD<ui->peaklistDefineBox->count())
        ui->peaklistDefineBox->setCurrentIndex(pintTemplate.peD);
    if(pintTemplate.prD<ui->procparDefineBox->count())
        ui->procparDefineBox->setCurrentIndex(pintTemplate.prD);
    readParamFile();
    updatePlotFiles();
    update2DPlotFiles();
    updateParameterTable();
    if(ui->spectrumList->count()>0)
    {
        ui->workspaceTab->setTabEnabled(1,true);
        ui->workspaceTab->setTabEnabled(2,true);
    }
    else
    {
        ui->workspaceTab->setTabEnabled(1,false);
        ui->workspaceTab->setTabEnabled(2,false);
        ui->workspaceTab->setTabEnabled(3,false);
        ui->workspaceTab->setTabEnabled(4,false);
        ui->workspaceTab->setTabEnabled(5,false);
        ui->workspaceTab->setTabEnabled(6,false);
    }
    setupCompleter(false);
    if(pintTemplate.pipeData)
        ui->topspinLabel->hide();
    else
        ui->topspinLabel->show();
    makeConnections();
}

void workspace::setupCosmeticChanges()
{
#ifdef Q_OS_MAC //Ctrl key is Cmd key on Mac, but is still handled with Qt::Ctrl modifier
    ui->integrateLabel->setText("Integrate (Cmd+R)");
    ui->syntaxLabel->setText("<html><i>When typing, press Cmd+E to view auto-complete syntax.</i></html>");
    ui->view3DButton->setText("3D view (fn+F2 to toggle)");
#endif
    //Applies cosmetical changes to the GUI
    ui->infoLabel->hide();
    ui->infoLabelText->hide();
    msgTimer = new QTimer(this);
    msgTimer->setInterval(8000);
    msgTimer->setSingleShot(true);
    connect(msgTimer, SIGNAL(timeout()), this, SLOT(disableInformation()));
    ui->peaklistTable->setColumnCount(9);
    ui->peaklistTable->setColumnHidden(4,true);
    ui->peaklistTable->setColumnHidden(5,true);
    ui->peaklistTable->setColumnHidden(6,true);
    ui->peaklistTable->setColumnHidden(7,true);
    ui->peaklistTable->setColumnHidden(8,true);
    if(pintTemplate.pipeData)
        ui->topspinLabel->hide();
    for(int i(1); i<7;++i)
        ui->workspaceTab->setTabEnabled(i,false);
    ui->spectrumBox->setEditable(true);
    ui->spectrumBox->lineEdit()->setReadOnly(true);
    ui->spectrumBox->lineEdit()->setAlignment(Qt::AlignRight);
    ui->peaklistBox->setEditable(true);
    ui->peaklistBox->lineEdit()->setReadOnly(true);
    ui->peaklistBox->lineEdit()->setAlignment(Qt::AlignRight);
    ui->spectrumBox->lineEdit()->setStyleSheet("background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));");
    ui->peaklistBox->lineEdit()->setStyleSheet("background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));");
    ui->spectrumBox->view()->setStyleSheet("color:white;background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));");
    ui->peaklistBox->view()->setStyleSheet("color:white;background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));");
}

void workspace::makeConnections() //This function connects major signals and slots and creates shortcut commandos
{
    ui->peaklistTable->installEventFilter(this);
    ui->peaklistTable->viewport()->installEventFilter(this);
    ui->workspaceTab->installEventFilter(this);

    //This section setup the shortcuts F1-F7 for switching workspace tabs
    QSignalMapper* tabSignalMapper = new QSignalMapper (this) ;
    QShortcut *scFilesTab = new QShortcut(this);
    QShortcut *scSpectrumTab = new QShortcut(this);
    QShortcut *scIntegrationTab = new QShortcut(this);
    QShortcut *scPlotTab = new QShortcut(this);
    QShortcut *scDeletePeakListItem = new QShortcut(this);
    QShortcut *sc3Dplot = new QShortcut(this);
    QShortcut *sc2Dplot = new QShortcut(this);
    QShortcut *scManualplot = new QShortcut(this);
    scFilesTab->setKey(Qt::Key_F1);
    scSpectrumTab->setKey(Qt::Key_F2);
    scIntegrationTab->setKey(Qt::Key_F3);
    scPlotTab->setKey(Qt::Key_F4);
    sc3Dplot->setKey(Qt::Key_F5);
    sc2Dplot->setKey(Qt::Key_F6);
    scManualplot->setKey(Qt::Key_F7);

    connect (scFilesTab, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (scSpectrumTab, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (scIntegrationTab, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (scPlotTab, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (sc3Dplot, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (sc2Dplot, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (scManualplot, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    tabSignalMapper->setMapping (scFilesTab, 0) ;
    tabSignalMapper->setMapping (scSpectrumTab, 1) ;
    tabSignalMapper->setMapping (scIntegrationTab, 2) ;
    tabSignalMapper->setMapping (scPlotTab, 3) ;
    tabSignalMapper->setMapping (sc3Dplot, 4) ;
    tabSignalMapper->setMapping (sc2Dplot, 5) ;
    tabSignalMapper->setMapping (scManualplot, 6) ;
    connect (tabSignalMapper, SIGNAL(mapped(int)), this, SLOT(setTabFromShortcut(int))) ;
    connect(ui->workspaceTab, SIGNAL(currentChanged(int)), this, SLOT(tabChanged(int)));

    connect(ui->otherList, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(openFileViewer(QListWidgetItem*)));
    connect(ui->peaklistList, SIGNAL(itemDoubleClicked(QListWidgetItem*)), this, SLOT(openFileViewer(QListWidgetItem*)));

    //<PlotWidget>

    plotSignalMapperType = new QSignalMapper (this) ;
    connect(ui->fitPng, SIGNAL(toggled(bool)), plotSignalMapperType, SLOT(map()));
    connect(ui->fitPdf, SIGNAL(toggled(bool)), plotSignalMapperType, SLOT(map()));

    plotSignalMapperType->setMapping(ui->fitPng, 1);
    plotSignalMapperType->setMapping(ui->fitPdf, 0);
    connect (plotSignalMapperType, SIGNAL(mapped(int)), this, SLOT(handleSaveType(int))) ;


    plotSignalMapperType2 = new QSignalMapper (this) ;
    connect(ui->plotPng, SIGNAL(toggled(bool)), plotSignalMapperType2, SLOT(map()));
    connect(ui->plotPdf, SIGNAL(toggled(bool)), plotSignalMapperType2, SLOT(map()));

    plotSignalMapperType2->setMapping(ui->plotPng, 1);
    plotSignalMapperType2->setMapping(ui->plotPdf, 0);
    connect (plotSignalMapperType2, SIGNAL(mapped(int)), this, SLOT(handleSaveType2(int))) ;

    QShortcut *scCenter = new QShortcut(this);
    QShortcut *scDeletePeakListItem2 = new QShortcut(this);
    scDeletePeakListItem2->setKey(Qt::Key_Backspace);
    connect(scDeletePeakListItem2, SIGNAL(activated()), this, SLOT(deleteFromPeaklist()));
#ifdef Q_OS_MAC
    scCenter->setKey(Qt::META + Qt::Key_C);
#else
    scCenter->setKey(Qt::CTRL + Qt::Key_C);
#endif
    scDeletePeakListItem->setKey(Qt::Key_Delete);
    connect(scDeletePeakListItem, SIGNAL(activated()), this, SLOT(deleteFromPeaklist()));
    connect(scCenter, SIGNAL(activated()), this, SLOT(centerPeaks()));
    QShortcut *scUndo = new QShortcut(this);
#ifdef Q_OS_MAC
    scUndo->setKey(Qt::META + Qt::Key_Z);
#else
    scUndo->setKey(Qt::CTRL + Qt::Key_Z);
#endif
    connect(scUndo, SIGNAL(activated()), this, SLOT(undoEvent()));
    QShortcut *scRedo = new QShortcut(this);
#ifdef Q_OS_MAC
    scRedo->setKey(Qt::META + Qt::Key_Y);
#else
    scRedo->setKey(Qt::CTRL + Qt::Key_Y);
#endif
    connect(scRedo, SIGNAL(activated()), this, SLOT(redoEvent()));

    QShortcut *scOverlap = new QShortcut(this);
#ifdef Q_OS_MAC
    scOverlap->setKey(Qt::META + Qt::Key_O);
#else
    scOverlap->setKey(Qt::CTRL + Qt::Key_O);
#endif
    connect(scOverlap, SIGNAL(activated()), this, SLOT(defineOverlap()));
    QShortcut *scSave = new QShortcut(this);
#ifdef Q_OS_MAC
    scSave->setKey(QKeySequence::Save);
#else
    scSave->setKey(Qt::CTRL + Qt::Key_S);
#endif
    connect(scSave, SIGNAL(activated()), this, SLOT(saveProject()));

    QShortcut *scFold = new QShortcut(this);
#ifdef Q_OS_MAC
    scFold->setKey(Qt::META + Qt::Key_F);
#else
    scFold->setKey(Qt::CTRL + Qt::Key_F);
#endif
    connect(scFold, SIGNAL(activated()), this, SLOT(foldPeak()));

    QShortcut *scToggleLMBMode = new QShortcut(this);
    scToggleLMBMode->setKey(Qt::Key_Tab);
    connect(scToggleLMBMode, SIGNAL(activated()), this, SLOT(toggleLMBMode()));

    //This section setup the PageUp/Down browsing of plots used in both "3D fits" and "2D fits" tabs
    QSignalMapper* plotSignalMapper = new QSignalMapper (this) ;
    QShortcut *nextPlot = new QShortcut(this);
    nextPlot->setKey(Qt::Key_PageDown);
    QShortcut *previousPlot = new QShortcut(this);
    previousPlot->setKey(Qt::Key_PageUp);
    connect (nextPlot, SIGNAL(activated()), plotSignalMapper, SLOT(map())) ;
    connect (previousPlot, SIGNAL(activated()), plotSignalMapper, SLOT(map())) ;
    plotSignalMapper->setMapping(nextPlot, 1);
    plotSignalMapper->setMapping(previousPlot, -1);
    connect (plotSignalMapper, SIGNAL(mapped(int)), this, SLOT(setPlot(int))) ;

    QObject::connect(ui->plotList, SIGNAL(currentCellChanged(int,int,int,int)), this, SLOT(clickToPlot()));
    QObject::connect(ui->fit2DList, SIGNAL(itemSelectionChanged()), this, SLOT(clickToPlot2D()));

    QObject::connect(ui->selectionModeButton, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));
    QObject::connect(ui->scaleModeButton, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));
    QObject::connect(ui->pickPeakMode, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));

    connect(ui->planeBox, SIGNAL(valueChanged(int)), this, SLOT(updatePlotFiles()));
    connect(ui->view3DButton, SIGNAL(toggled(bool)), this, SLOT(togglePlotMode(bool)));
    connect(ui->flipZButton, SIGNAL(clicked(bool)), this, SLOT(flipZAxis()));
    connect(ui->adjustZButton, SIGNAL(clicked(bool)), this, SLOT(adjustZAxis()));
    connect(ui->autoAdjustZButton, SIGNAL(clicked(bool)), this, SLOT(autoAdjustZAxis()));
    connect(ui->zMinEdit, SIGNAL(returnPressed()), ui->adjustZButton, SLOT(click()));
    connect(ui->zMaxEdit, SIGNAL(returnPressed()), ui->adjustZButton, SLOT(click()));
    //</PlotWidget>


    //<Integration tab>
    connect(ui->threadsBox, SIGNAL(valueChanged(int)), this, SLOT(threadInfo()));
    QShortcut *scIntegrate = new QShortcut(this);
    scIntegrate->setKey(Qt::CTRL + Qt::Key_R);
    connect(scIntegrate, SIGNAL(activated()), this, SLOT(integrate()));
    //</Integration tab>

    //<Parameters tab>
    connect(ui->errorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters()));
    connect(ui->noErrorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters2()));
    connect(ui->selectionButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters3()));
    connect(ui->allButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters4()));
    //</Parameters tab>

    //<Plots>
    connect(ui->xaxisMinEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    connect(ui->xaxisMaxEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    connect(ui->yaxisMinEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    connect(ui->yaxisMaxEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    connect(ui->xaxisMinEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    connect(ui->xaxisMaxEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    connect(ui->yaxisMinEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    connect(ui->yaxisMaxEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    //</Plots>

    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));

    connect(spectrumView3D, SIGNAL(pressCtrl(bool)), this, SLOT(pressCtrl(bool)));
    connect(spectrumView3D, SIGNAL(deselectTable()), this, SLOT(deselectTable()));
    connect(spectrumView3D, SIGNAL(addToPeakTable(QVector3D, QString)), this, SLOT(createUserPeak(QVector3D, QString)));
    connect(spectrumView3D, SIGNAL(deleteFromPeakTable()), this, SLOT(deleteUserPeak()));
    connect(spectrumView3D, SIGNAL(syncPeakTable(QString, bool)), this, SLOT(syncPeakTable(QString, bool)));
    connect(spectrumView3D, SIGNAL(infoPeakMode(QString, bool, int)), this, SLOT(displayInformation(QString, bool, int)));
    connect(contourPlot, SIGNAL(infoPeakMode(QString, bool, int)), this, SLOT(displayInformation(QString, bool, int)));
    connect(contourPlot, SIGNAL(updatePeakList(QString,QPointF)), this, SLOT(updatePeakListFromContour(QString, QPointF)));
    connect(spectrumView3D, SIGNAL(moveModeFrame()), this, SLOT(moveModeFrame()));
    connect(contourPlot, SIGNAL(moveModeFrame()), this, SLOT(moveModeFrame()));
    connect(spectrumView3D, SIGNAL(selectPeaksWithinBorder(float,float,float,float)), this, SLOT(selectPeaksWithinBorder(float,float,float,float)));
    connect(spectrumView3D, SIGNAL(pickPeaksWithinBorder(double,double,double,double)), this, SLOT(pickPeaks(double,double,double,double)));
    connect(spectrumView3D, SIGNAL(defaultMoveModeFrame()), this, SLOT(defaultMoveModeFrame()));
    connect(contourPlot, SIGNAL(defaultMoveModeFrame()), this, SLOT(defaultMoveModeFrame()));
    connect(spectrumView3D, SIGNAL(updatePeakPosition(QVector3D,QString)) ,this, SLOT(updatePeakPosition(QVector3D,QString)));
    connect(ui->workspaceTab, SIGNAL(currentChanged(int)), this, SLOT(changeActions(int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    connect(ui->loadSpectrumButton, SIGNAL(clicked(bool)), this, SLOT(processSpectrumLoad()));

    //<Actions>
    menuBar = new QMenuBar(this);
    QMenu *fileMenu = new QMenu("File");
    QAction *actionMainMenu = new QAction("Main menu");
    QAction *actionLoadProject = new QAction("Load project");
    QAction *actionSaveProject= new QAction("Save project");
    QAction *actionQuit= new QAction("Quit");
    QAction *actionShowHints= new QAction("Show hints");
    QAction *actionAutomaticLabelFormat= new QAction("Automatic label format");
    QAction *actionUserManual= new QAction("User manual");
    QAction *actionVideoTutorials= new QAction("Video tutorials");

    fileMenu->addAction(actionMainMenu);
    fileMenu->addAction(actionLoadProject);
    fileMenu->addAction(actionSaveProject);
    fileMenu->addAction(actionQuit);
    QMenu *windowMenu = new QMenu("Window");
    windowMenu->addAction(actionShowHints);
    QMenu *settingsMenu = new QMenu("Settings");
    settingsMenu->addAction(actionAutomaticLabelFormat);
    QMenu *helpMenu = new QMenu("Help");
    helpMenu->addAction(actionUserManual);
    helpMenu->addAction(actionVideoTutorials);
    menuBar->addMenu(fileMenu);
    menuBar->addMenu(windowMenu);
    menuBar->addMenu(settingsMenu);
    menuBar->addMenu(helpMenu);
    this->layout()->setMenuBar(menuBar);

    connect(actionMainMenu, &QAction::triggered, this, &workspace::goToMain);
    connect(actionLoadProject, &QAction::triggered, this, &workspace::goToLoad);
    connect(actionSaveProject, &QAction::triggered, this, &workspace::saveProject);
    connect(actionQuit, &QAction::triggered, this, &workspace::quitApp);

    connect(actionShowHints, &QAction::triggered, this, &workspace::toggleHints);
    connect(actionAutomaticLabelFormat, &QAction::triggered, this, &workspace::editAutomaticLabelAppearance);
    connect(actionUserManual, &QAction::triggered, this, &workspace::helpTriggered);
    connect(actionVideoTutorials, &QAction::triggered, this, &workspace::tutorialTriggered);
#ifdef Q_OS_MAC
    QShortcut* scHint = new QShortcut(Qt::Key_F8,this);
#else
    QShortcut* scHint = new QShortcut(Qt::Key_F12,this);
#endif
    connect(scHint, SIGNAL(activated()), actionShowHints, SLOT(trigger()));
}

void workspace::selectPeaksWithinBorder(float x1, float x2, float z1, float z2)
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        if(ui->peaklistTable->item(i,5)->text()=="0" && ui->peaklistTable->item(i,5)->text()=="0" && ui->peaklistTable->item(i,1)->text().toFloat()>=z2 && ui->peaklistTable->item(i,1)->text().toFloat()<=z1
                && ui->peaklistTable->item(i,2)->text().toFloat()>=x2 && ui->peaklistTable->item(i,2)->text().toFloat()<=x1)
        {
            ui->peaklistTable->item(i,0)->setSelected(true);
            highlightPeak();
        }
        else if(ui->peaklistTable->item(i,5)->text()!="0" || ui->peaklistTable->item(i,6)->text()!="0")
        {
            if(ui->peaklistTable->item(i,5)->text()!="0")
            {
                if(ui->peaklistTable->item(i,7)->text().toFloat()<z2 || ui->peaklistTable->item(i,7)->text().toFloat()>z1)
                    continue;
            }
            else if(ui->peaklistTable->item(i,1)->text().toFloat()<z2 || ui->peaklistTable->item(i,1)->text().toFloat()>z1)
                continue;
            if(ui->peaklistTable->item(i,6)->text()!="0")
            {
                if(ui->peaklistTable->item(i,8)->text().toFloat()<x2 || ui->peaklistTable->item(i,8)->text().toFloat()>x1)
                    continue;
            }
            else if(ui->peaklistTable->item(i,2)->text().toFloat()<x2 || ui->peaklistTable->item(i,2)->text().toFloat()>x1)
                continue;
            ui->peaklistTable->item(i,0)->setSelected(true);
            highlightPeak();
        }
    }
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
}

void workspace::clickToPlot()
{
    viewPlot(ui->plotList->currentItem()->row());
    priorSelection =ui->plotList->item(ui->plotList->currentItem()->row(),0)->text();
    /*
    QString item(ui->plotList->item(ui->plotList->currentItem()->row(),0)->text());
    for(int i(0); i<ui->plotList->rowCount(); i++)
        if(item==ui->plotList->item(i,0)->text())
        {
            viewPlot(i);
            priorSelection =ui->plotList->item(i,0)->text();
            break;
        }
        */
}

void workspace::clickToPlot2D()
{
    QListWidgetItem *item(ui->fit2DList->currentItem());
    for(int i(0); i<ui->fit2DList->count(); i++)
        if(item->text()==ui->fit2DList->item(i)->text())
        {
            currentPlotIndex = i;
            priorSelection2D =ui->fit2DList->item(i)->text();
            viewPlot2D(i);
            break;
        }
}

void workspace::viewPlot2D(int index)
{
    ui->customPlotFit->clearGraphs();
    QString fname(pintTemplate.outDirectory+"/"+ui->fit2DList->item(index)->text());
    QFile file(fname);
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    disconnect(ui->xaxisMinEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    disconnect(ui->xaxisMaxEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    disconnect(ui->yaxisMinEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    disconnect(ui->yaxisMaxEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    QVector<QStringList> dataVec;
    QTextStream in(&file);
    QString line = in.readLine();
    while(!line.isNull())
    {
        if(line!="")
        {
            if(line[0]!='#')
            {
                istringstream iss(line.toStdString().c_str());
                string sub;
                QStringList list;
                while(iss >> sub)
                    list << QString::fromStdString(sub.c_str());
                dataVec.push_back(list);
            }
        }
        line = in.readLine();
    }
    file.close();
    displayInfoBrowserText(1,index);
    QString title("%1");
    titleQCustomPlotFit->setText(title.arg(ui->fit2DList->item(index)->text()));
    if(ui->titleSizeBoxFit->value()==0)
        titleQCustomPlotFit->setText("");
    else
        titleQCustomPlotFit->setFont(QFont("Myriad Pro", ui->titleSizeBoxFit->value(), QFont::Bold));
    QVector<double> x1(dataVec.size()), y1(dataVec.size()), y1err(dataVec.size()), yFit(dataVec.size());
    maxXfit=-9e99;
    maxYfit=-9e99;
    minXfit=9e99;
    minYfit=9e99;
    bool errorExist(false);
    if(dataVec.size()>0)
    {
        if(dataVec[0].size()>3)
        {
            errorExist = true;
            for(int i(0); i<dataVec.size(); i++)
            {
                if(dataVec.at(i).at(0).toDouble()<minXfit)
                    minXfit = dataVec.at(i).at(0).toDouble();
                if(dataVec.at(i).at(0).toDouble()>maxXfit)
                    maxXfit = dataVec.at(i).at(0).toDouble();
                if(dataVec.at(i).at(1).toDouble()-dataVec.at(i).at(2).toDouble()<minYfit)
                    minYfit = dataVec.at(i).at(1).toDouble()-dataVec.at(i).at(2).toDouble();
                if(dataVec.at(i).at(1).toDouble()+dataVec.at(i).at(2).toDouble()>maxYfit)
                    maxYfit = dataVec.at(i).at(1).toDouble()+dataVec.at(i).at(2).toDouble();
                if(dataVec.at(i).at(3).toDouble()<minYfit)
                    minYfit = dataVec.at(i).at(3).toDouble();
                if(dataVec.at(i).at(3).toDouble()>maxYfit)
                    maxYfit = dataVec.at(i).at(3).toDouble();
                x1[i] = dataVec.at(i).at(0).toDouble();
                y1[i] = dataVec.at(i).at(1).toDouble();
                y1err[i] = dataVec.at(i).at(2).toDouble();
                yFit[i] = dataVec.at(i).at(3).toDouble();
            }
        }
        else if(dataVec[0].size()==3)
        {
            for(int i(0); i<dataVec.size(); i++)
            {
                if(dataVec.at(i).at(0).toDouble()<minXfit)
                    minXfit = dataVec.at(i).at(0).toDouble();
                if(dataVec.at(i).at(0).toDouble()>maxXfit)
                    maxXfit = dataVec.at(i).at(0).toDouble();
                if(dataVec.at(i).at(1).toDouble()<minYfit)
                    minYfit = dataVec.at(i).at(1).toDouble();
                if(dataVec.at(i).at(1).toDouble()>maxYfit)
                    maxYfit = dataVec.at(i).at(1).toDouble();
                if(dataVec.at(i).at(2).toDouble()<minYfit)
                    minYfit = dataVec.at(i).at(2).toDouble();
                if(dataVec.at(i).at(2).toDouble()>maxYfit)
                    maxYfit = dataVec.at(i).at(2).toDouble();
                x1[i] = dataVec.at(i).at(0).toDouble();
                y1[i] = dataVec.at(i).at(1).toDouble();
                yFit[i] = dataVec.at(i).at(2).toDouble();
            }
        }
    }

    ui->customPlotFit->addGraph();
    ui->customPlotFit->addGraph();
    QPen dataPen;
    dataPen.setCapStyle(Qt::FlatCap);
    dataPen.setColor(fitDataColor);
    ui->customPlotFit->graph(1)->setPen(dataPen);
    ui->customPlotFit->graph(1)->setLineStyle(QCPGraph::lsNone);
    ui->customPlotFit->graph(1)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc, 15));
    ui->customPlotFit->graph(1)->setErrorType(QCPGraph::etValue);

    QPen errorPen;
    errorPen.setColor(fitDataColor);
    errorPen.setCapStyle(Qt::FlatCap);
    errorPen.setWidth(2);
    if(errorExist)
    {
        ui->customPlotFit->graph(1)->setErrorPen(errorPen);
        ui->customPlotFit->graph(1)->setErrorBarSkipSymbol(false);
        ui->customPlotFit->graph(1)->setName("Exp. data");
        ui->customPlotFit->graph(1)->setDataValueError(x1, y1, y1err);
    }
    else
    {
        ui->customPlotFit->graph(1)->setPen(errorPen);
        ui->customPlotFit->graph(1)->setName("Exp. data");
        ui->customPlotFit->graph(1)->setData(x1, y1);
    }

    errorPen.setColor(fitFitColor);
    errorPen.setWidth(2);
    ui->customPlotFit->graph(0)->setPen(errorPen);
    ui->customPlotFit->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->customPlotFit->graph(0)->setName("Fitted data");
    ui->customPlotFit->graph(0)->setData(x1, yFit);

    ui->customPlotFit->legend->setVisible(ui->fitLegendButton->isChecked());

    ui->customPlotFit->xAxis->setTickLengthIn(0);
    ui->customPlotFit->xAxis->setTickLengthOut(6);
    ui->customPlotFit->xAxis->setSubTickLengthIn(0);
    ui->customPlotFit->xAxis->setSubTickLengthOut(3);

    ui->customPlotFit->yAxis->setTickLengthIn(0);
    ui->customPlotFit->yAxis->setTickLengthOut(6);
    ui->customPlotFit->yAxis->setSubTickLengthIn(0);
    ui->customPlotFit->yAxis->setSubTickLengthOut(3);
    if(fname.length()>5)
    {
        QString ext(".cpmg");
        if(equal(ext.rbegin(), ext.rend(), fname.rbegin()))
            minXfit = 0;
    }
    if(minXfit!=0)
        minXfit -= qSqrt((maxXfit-minXfit)*(maxXfit-minXfit))*0.025;
    maxXfit += qSqrt((maxXfit-minXfit)*(maxXfit-minXfit))*0.025;
    minYfit -= qSqrt((maxYfit-minYfit)*(maxYfit-minYfit))*0.025;
    maxYfit += qSqrt((maxYfit-minYfit)*(maxYfit-minYfit))*0.025;
    if(!ui->lockFitRangeX->isChecked())
    {
        ui->customPlotFit->xAxis->setRange(minXfit, maxXfit);
        ui->customPlotFit->xAxis2->setRange(minXfit, maxXfit);
        ui->xaxisMaxEditFit->setText(QString::number(maxXfit));
        ui->xaxisMinEditFit->setText(QString::number(minXfit));
    }
    else
    {
        bool ok;
        minXfit = ui->xaxisMinEditFit->text().toDouble(&ok);
        if(!ok)
            minXfit=0;
        maxXfit = ui->xaxisMaxEditFit->text().toDouble(&ok);
        if(!ok)
            maxXfit=1;
    }
    if(!ui->lockFitRangeY->isChecked())
    {
        ui->customPlotFit->yAxis->setRange(minYfit, maxYfit);
        ui->customPlotFit->yAxis2->setRange(minYfit, maxYfit);
        ui->yaxisMaxEditFit->setText(QString::number(maxYfit));
        ui->yaxisMinEditFit->setText(QString::number(minYfit));
    }
    else
    {
        bool ok;
        minYfit = ui->yaxisMinEditFit->text().toDouble(&ok);
        if(!ok)
            minYfit=0;
        maxYfit = ui->yaxisMaxEditFit->text().toDouble(&ok);
        if(!ok)
            maxYfit=1;
    }
    if(ui->lockFitMinorX->isChecked())
    {
        ui->customPlotFit->xAxis->setAutoSubTicks(false);
        ui->customPlotFit->xAxis2->setAutoSubTicks(false);
        ui->customPlotFit->xAxis->setSubTickCount(ui->subTickXFit->value());
        ui->customPlotFit->xAxis2->setSubTickCount(ui->subTickXFit->value());
    }
    else
    {
        ui->customPlotFit->xAxis->setAutoSubTicks(true);
        ui->customPlotFit->xAxis2->setAutoSubTicks(true);
    }
    if(ui->lockFitMinorY->isChecked())
    {
        ui->customPlotFit->yAxis->setAutoSubTicks(false);
        ui->customPlotFit->yAxis2->setAutoSubTicks(false);
        ui->customPlotFit->yAxis->setSubTickCount(ui->subTickYFit->value());
        ui->customPlotFit->yAxis2->setSubTickCount(ui->subTickYFit->value());
    }
    else
    {
        ui->customPlotFit->yAxis->setAutoSubTicks(true);
        ui->customPlotFit->yAxis2->setAutoSubTicks(true);
    }

    if(ui->lockFitStepX->isChecked())
    {
        if((maxXfit-minXfit)/(ui->xtickBox_Fit->value()+1) > 100.0)
        {
            ui->customPlotFit->xAxis->setAutoTickStep(true);
            ui->customPlotFit->xAxis2->setAutoTickStep(true);
            ui->customPlotFit->xAxis->setAutoTickCount(9);
            ui->customPlotFit->xAxis2->setAutoTickCount(9);
        }
        else
        {
            ui->customPlotFit->xAxis->setAutoTickStep(false);
            ui->customPlotFit->xAxis2->setAutoTickStep(false);
            ui->customPlotFit->xAxis->setTickStep(ui->xtickBox_Fit->value());
            ui->customPlotFit->xAxis2->setTickStep(ui->xtickBox_Fit->value());
        }
    }
    else
    {
        ui->customPlotFit->xAxis->setAutoTickStep(true);
        ui->customPlotFit->xAxis2->setAutoTickStep(true);
        ui->customPlotFit->xAxis->setAutoTickCount(9);
        ui->customPlotFit->xAxis2->setAutoTickCount(9);
    }
    if(ui->lockFitStepY->isChecked())
    {
        if((maxYfit-minYfit)/(ui->ytickBox_Fit->value()+1) > 100.0)
        {
            ui->customPlotFit->yAxis->setAutoTickStep(true);
            ui->customPlotFit->yAxis2->setAutoTickStep(true);
            ui->customPlotFit->yAxis->setAutoTickCount(9);
            ui->customPlotFit->yAxis2->setAutoTickCount(9);
        }
        else
        {
            ui->customPlotFit->yAxis->setAutoTickStep(false);
            ui->customPlotFit->yAxis2->setAutoTickStep(false);
            ui->customPlotFit->yAxis->setTickStep(ui->ytickBox_Fit->value());
            ui->customPlotFit->yAxis2->setTickStep(ui->ytickBox_Fit->value());
        }
    }
    else
    {
        ui->customPlotFit->yAxis->setAutoTickStep(true);
        ui->customPlotFit->yAxis2->setAutoTickStep(true);
        ui->customPlotFit->yAxis->setAutoTickCount(9);
        ui->customPlotFit->yAxis2->setAutoTickCount(9);
    }
    ui->customPlotFit->axisRect()->setupFullAxesBox();
    ui->customPlotFit->xAxis->setLabelFont(QFont("Myriad Pro", ui->xaxisSizeBoxFit->value()));
    ui->customPlotFit->xAxis->setLabel(ui->xaxisTitleEditFit->text());
    ui->customPlotFit->yAxis->setLabelFont(QFont("Myriad Pro", ui->yaxisSizeBoxFit->value()));
    ui->customPlotFit->yAxis->setLabel(ui->yaxisTitleEditFit->text());
    ui->customPlotFit->replot();
    connect(ui->xaxisMinEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    connect(ui->xaxisMaxEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    connect(ui->yaxisMinEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
    connect(ui->yaxisMaxEditFit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRangesFit()));
}

void workspace::viewPlot(int index)
{
    if(index==-1)
        return;
    plotQueue.enqueue(index);
    if(rendering3Dplot)
        return;
    rendering3Dplot = true;
    while(!plotQueue.isEmpty())
    {
        plotView3D->index =plotQueue.dequeue();
        plotView3D->renderPlot(ui->plotList->item(plotView3D->index ,0), pintTemplate.plotDirectory.toStdString(), 2, pintTemplate.overlapVec, pintTemplate.outDirectory);
        displayInfoBrowserText(0,plotView3D->index);
        qApp->processEvents();
    }
    rendering3Dplot = false;
}

void workspace::displayInfoBrowserText(int target, int index)
{

    QString fname;
    int compVal(1);
    bool found(false);
    if(target ==0)
    {
        QString fname2 = pintTemplate.outDirectory+"/sortkey.txt";
        QFile file2(fname2);
        if(file2.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QTextStream in2(&file2);
            QString line2 = in2.readLine();
            while(!line2.isNull())
            {
                istringstream iss(line2.toStdString());
                string sub("");
                iss>>sub;
                if(sub==ui->plotList->item(index,0)->text().mid(0,ui->plotList->item(index,0)->text().length()-8).toStdString())
                {
                    bool ok;
                    int val(ui->plotList->item(index,0)->text().mid(ui->plotList->item(index,0)->text().length()-7,3).toInt(&ok));
                    while(iss>>sub)
                    {
                        if(sub==QString::number(val).toStdString())
                        {
                            found=true;
                            break;
                        }
                        ++compVal;
                    }
                    break;
                }
                line2=in2.readLine();
            }
            file2.close();
        }
        else
            return;
        fname = pintTemplate.outDirectory+"/"+ui->plotList->item(index,0)->text();
        fname = fname.mid(0,fname.length()-8);
        fname+=".out";
    }
    else
        fname = pintTemplate.outDirectory+"/"+ui->fit2DList->item(index)->text();
    QFile file(fname);
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QVector<QString> dataVec;
    QTextStream in(&file);
    QString line = in.readLine();
    bool intAndVol(false);
    int lineCC(1);
    while(!line.isNull())
    {
        if(line!="" && !intAndVol)
        {
            if(line[0]=='#')
            {
                if(line.length()>2)
                {
                    if(line[1]==' ')
                    {
                        dataVec.push_back(line.mid(2));
                    }
                    else if(line[1]=='#' && dataVec.size()>1)
                        intAndVol = true;
                }
            }
        }
        else if(target==0 && found)
        {
            //Read intensities and volumes
            if(line[0]!='#')
            {
                if(lineCC != compVal)
                {
                    lineCC++;
                    line = in.readLine();
                    continue;
                }
                lineCC++;
                dataVec.push_back("\n");
                stringstream iss(line.toStdString());
                string sub;
                int cc(0);
                QString app("Intensity:\t");
                while(iss>>sub)
                {
                    switch(cc)
                    {
                    case 1: //int
                    {
                        bool ok;
                        double d(QString::fromStdString(sub.c_str()).toDouble(&ok));
                        if(ok)
                        {
                            QString num = QString::number(d, 'e', 2 );
                            app+=num;
                        }
                        break;
                    }
                    case 2: //dint
                    {
                        bool ok;
                        double d(QString::fromStdString(sub.c_str()).toDouble(&ok));
                        if(ok)
                        {
                            QString num =" ± "+ QString::number(d, 'e', 2 ) + " ";
                            app+=num+"\n";
                            dataVec.push_back(app);
                            app="Volume:\t";
                        }
                        break;
                    }
                    case 3: //vol
                    {
                        bool ok;
                        double d(QString::fromStdString(sub.c_str()).toDouble(&ok));
                        if(ok)
                        {
                            QString num = QString::number(d, 'e', 2 );
                            app+=num;
                        }
                        break;
                    }
                    case 4: //dvol
                    {
                        bool ok;
                        double d(QString::fromStdString(sub.c_str()).toDouble(&ok));
                        if(ok)
                        {
                            QString num = " ± "+QString::number(d, 'e', 2 );
                            app+=num+"\n";
                            dataVec.push_back(app);
                        }
                        break;
                    }
                    default:
                        break;
                    }
                    ++cc;
                }
            }
        }
        line = in.readLine();
    }
    file.close();
    if(target==0)
    {
        fitInfoBrowser->clear();
        fitInfoBrowser->setFont(QFont("Myriad Pro", 12));
        for(int i(0); i<dataVec.size(); ++i)
            fitInfoBrowser->append(dataVec.at(i).trimmed());
    }
    else
    {
        ui->fitInfoBrowserDecay->clear();
        ui->fitInfoBrowserDecay->setFont(QFont("Myriad Pro", 12));
        for(int i(0); i<dataVec.size(); ++i)
            ui->fitInfoBrowserDecay->append(dataVec.at(i).trimmed());
    }
}

void workspace::setPlot(int increment)
{
    //Handle PGUP/PGDN shortcuts for browsing fitted plots
    if(ui->workspaceTab->currentIndex()==3)
    {
        if(ui->plotList->rowCount()<1)
            return;
        if(ui->plotList->currentIndex().row()+increment>-1 && ui->plotList->currentIndex().row()+increment<ui->plotList->rowCount())
            ui->plotList->setCurrentCell(ui->plotList->currentIndex().row()+increment,0);
        else if(ui->plotList->currentIndex().row()+increment==-1)
            ui->plotList->setCurrentCell(ui->plotList->rowCount()-1,0);
        else
            ui->plotList->setCurrentCell(0,0);
    }
    else if(ui->workspaceTab->currentIndex()==4)
    {
        if(ui->fit2DList->count()<1)
            return;
        if(ui->fit2DList->currentIndex().row()+increment>-1 && ui->fit2DList->currentIndex().row()+increment<ui->fit2DList->count())
            ui->fit2DList->setCurrentRow(ui->fit2DList->currentIndex().row()+increment);
        else if(ui->fit2DList->currentIndex().row()+increment==-1)
            ui->fit2DList->setCurrentRow(ui->fit2DList->count()-1);
        else
            ui->fit2DList->setCurrentRow(0);
    }
}

void workspace::undoEvent()
{
    if(restoringState) return;
    restoringState = true;
    currentState--;
    if(currentState<0)
    {
        currentState=0;
        displayInformation("Undo: No further history available", true, 0);
        restoringState = false;
    }
    else if(currentState==0 && stateVector.size()==1)
    {
        currentState=0;
        displayInformation("Undo: No further history available", true, 0);
        restoringState = false;
    }
    else
        restoreStateFromVec();
}

void workspace::redoEvent()
{
    if(restoringState) return;
    restoringState = true;
    currentState++;
    if(stateVector.size()<1)
    {
        currentState=0;
        displayInformation("Redo: No further history available", true, 0);
        restoringState = false;
    }
    else if(currentState>=stateVector.size())
    {
        currentState=stateVector.size()-1;
        displayInformation("Redo: No further history available", true, 0);
        restoringState = false;
    }
    else
        restoreStateFromVec();
}

void workspace::defaultMoveModeFrame()
{
    ui->spectrum2DWidget->setStyleSheet("QWidget #spectrum2DWidget{\nborder-style: solid;\nborder-width: 3px;\nborder-radius: 7px;\nborder-color: rgba(71,78,81,255);\n}");
    ui->spectrumContourWidget->setStyleSheet("QWidget #spectrumContourWidget{\nborder-style: solid;\nborder-width: 3px;\nborder-radius: 7px;\nborder-color: rgba(71,78,81,255);\n}");
}

void workspace::moveModeFrame()
{
    QString styleSheet;
    QString style = "rgb(%1, %2, %3)";
    styleSheet="QWidget %1{\nborder-style: solid;\nborder-width: 3px;\nborder-radius: 7px;\nborder-color: "
            + style.arg(spectrumView3D->activeTheme.moveBgColor.red()).arg(spectrumView3D->activeTheme.moveBgColor.green()).arg(spectrumView3D->activeTheme.moveBgColor.blue())
            + ";\n}";

    ui->spectrum2DWidget->setStyleSheet(styleSheet.arg("#spectrum2DWidget"));
    ui->spectrumContourWidget->setStyleSheet(styleSheet.arg("#spectrumContourWidget"));
}

void workspace::restoreStateFromVec()
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));

    spectrumView3D->spectrum_graph->removeCustomItems();
    spectrumView3D->spectrum_graph->clearSelection();
    ui->peaklistTable->clearSelection();
    ui->peaklistTable->clearContents();
    ui->peaklistTable->setRowCount(0);
    spectrumView3D->clearPlots(false);

    peakId=statePeakId[currentState];
    ui->peaklistTable->clearSelection();
    contourPlot->detachAll();
    QApplication::processEvents();
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));

    for(int i(0); i<stateVector[currentState].size(); i++)
    {
        ui->peaklistTable->insertRow(ui->peaklistTable->rowCount());
        for(int j(0); j<stateVector[currentState][i].size(); j++)
        {
            QTableWidgetItem *item = new QTableWidgetItem();
            item->setText(stateVector[currentState][i][j]);
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,j, item);
        }
    }
    ui->peaklistTable->horizontalHeader()->setStretchLastSection(true);

    if(ui->peaklistTable->rowCount()>0)
    {
        createPeakLabels(0);
        readContourPeaklist(0);
    }
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));

    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    spectrumView3D->exitMoveMode();
    contourPlot->exitMoveMode();
    restoringState = false;
}

void workspace::storeState()
{
    //Store the state of the peaklist. The stored properties are only used for redo/undo events.
    QVector< QVector<QString>> rowVector;
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        QVector<QString> colVector;
        for(int j(0); j<ui->peaklistTable->columnCount(); j++)
            colVector.push_back(ui->peaklistTable->item(i,j)->text());
        rowVector.push_back(colVector);
    }

    if(currentState == stateVector.size()-1 && stateVector.size()<20)
    {
        stateVector.push_back(rowVector);
        statePeakId.push_back(peakId);
        currentState++;
    }
    else if(currentState == stateVector.size())
    {
        for(int i(0); i<stateVector.size()-1; i++)
        {
            stateVector[i] = stateVector[i+1];
            statePeakId[i] = statePeakId[i+1];
        }
        stateVector[19] = rowVector;
        statePeakId[19] = peakId;
    }
    else if(currentState < stateVector.size())
    {
        for(int i(stateVector.size()-1); i>currentState; i--)
        {
            stateVector.remove(i);
            statePeakId.remove(i);
        }
        stateVector.push_back(rowVector);
        statePeakId.push_back(peakId);
        currentState++;
    }
}

void workspace::updatePeakPosition(QVector3D pos, QString objName)
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        if(ui->peaklistTable->item(i, 4)->text()==objName)
        {
            ui->peaklistTable->item(i, 1)->setText(QString::number(pos.z() + ui->peaklistTable->item(i, 5)->text().toDouble() * (maxF1-minF1) ));
            ui->peaklistTable->item(i, 2)->setText(QString::number(pos.x() + ui->peaklistTable->item(i, 6)->text().toDouble() * (maxF2-minF2)));
            ui->peaklistTable->item(i, 3)->setText(QString::number(pos.y()));
            updatePeakLabels(i,-1);
            break;
        }
    }
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
}

void workspace::removeThemeIdx(int idx)
{
    themeList->removeItem(idx);
    themeVector.remove(idx);
}

void workspace::selectAll()
{
    ui->peaklistTable->clearSelection();
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        ui->peaklistTable->item(i,0)->setSelected(true);
        highlightPeak();
    }
}

bool workspace::eventFilter(QObject *obj, QEvent *event)
{
    if(event->type() == QEvent::KeyPress && obj == ui->peaklistTable)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == 16777235) //upArrow
        {
            if(ui->peaklistTable->currentRow()==0)
            {
                ui->peaklistTable->setCurrentCell(ui->peaklistTable->rowCount()-1,ui->peaklistTable->currentColumn());
                return true;
            }
        }
        else if(keyEvent->key() == 16777237) //downArrow
        {
            if(ui->peaklistTable->currentRow()==ui->peaklistTable->rowCount()-1)
            {
                ui->peaklistTable->setCurrentCell(0,ui->peaklistTable->currentColumn());
                return true;
            }
        }
        else if(keyEvent->key() == 32) //Space
        {
            spectrumView3D->movePeakMode();
            return true;
        }
        else if(keyEvent->key() == ctrlInt)
        {
            ctrlPressed=true;
            spectrumView3D->ctrlPressed = true;
            contourPlot->ctrlPressed = true;
        }
        int key = keyEvent->key();
        Qt::KeyboardModifiers modifiers = keyEvent->modifiers();
        if(modifiers & Qt::ShiftModifier)
            key += Qt::SHIFT;
        if(modifiers & Qt::ControlModifier)
            key += Qt::CTRL;
        if(modifiers & Qt::AltModifier)
            key += Qt::ALT;
        if(modifiers & Qt::MetaModifier)
            key += Qt::META;
        if (QKeySequence(key) == QKeySequence(QKeySequence::SelectAll))
        {
            selectAll();
            return true;
        }
    }
    else if (event->type() == QEvent::MouseButtonPress || event->type() == QEvent::MouseMove || event->type() == QEvent::MouseButtonRelease)
    {
        Qt::KeyboardModifiers modifiers = QApplication::keyboardModifiers();
        if (modifiers & Qt::ShiftModifier)
        {
            return true;
        }
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        if(obj == spectrumView3D->spectrum_graph && event->type()==QEvent::MouseButtonPress)
        {
            QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
            if(Qt::LeftButton == mouseEvent->button())
            {
                origin = mouseEvent->globalPos();
                if(!rubberBand)
                    rubberBand = new QRubberBand(QRubberBand::Rectangle);
                rubberBand->setGeometry(QRect(mouseEvent->globalPos(), QSize()));
                rubberBand->show();
            }
        }
        if(obj == spectrumView3D->spectrum_graph && event->type()==QEvent::MouseMove && spectrumView3D->dragging)
        {
            if(mouseEvent->globalPos().x()>origin.x() && mouseEvent->globalPos().y() < origin.y())
                rubberBand->setGeometry(QRect(QPoint(origin.x(),mouseEvent->globalPos().y()), QPoint(mouseEvent->globalPos().x(), origin.y())));
            else if(mouseEvent->globalPos().x()<origin.x() && mouseEvent->globalPos().y() > origin.y())
                rubberBand->setGeometry(QRect(QPoint(mouseEvent->globalPos().x(),origin.y()), QPoint(origin.x(), mouseEvent->globalPos().y())));
            else if(mouseEvent->globalPos().x()<origin.x() && mouseEvent->globalPos().y() < origin.y())
                rubberBand->setGeometry(QRect(mouseEvent->globalPos(), origin));
            else
                rubberBand->setGeometry(QRect(origin, mouseEvent->globalPos()));
        }
        if(obj == spectrumView3D->spectrum_graph && event->type()==QEvent::MouseButtonRelease)
        {
            QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
            if(Qt::LeftButton == mouseEvent->button())
            {
                rubberBand->hide();
            }
        }
    }
    else if(event->type() == QEvent::KeyRelease)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == ctrlInt)
        {
            ctrlPressed=false;
            spectrumView3D->ctrlPressed = false;
            contourPlot->ctrlPressed = false;
        }
        //else if(keyEvent->key() == 90 && ctrlPressed)//Z, Undo
        //   undoEvent();
        //else if(keyEvent->key() == 89 && ctrlPressed)//Y, Redo
        //   redoEvent();
        //else if(keyEvent->key() == 67 && ctrlPressed) //C, centerPeaks
        //  centerPeaks();
        else if(keyEvent->key() == 16777216)//Escape
        {
            spectrumView3D->exitMoveMode();
            contourPlot->exitMoveMode();
        }
    }
    return false;
}

void workspace::toggleLMBMode()
{
    if(ui->workspaceTab->currentIndex()!=1)
        return;
    if(ui->zMinEdit->hasFocus())
    {
        ui->zMaxEdit->setFocus();
        ui->zMaxEdit->selectAll();
        return;
    }
    disconnect(ui->pickPeakMode, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));
    disconnect(ui->selectionModeButton, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));
    disconnect(ui->scaleModeButton, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));
    toggledMode++;
    if(toggledMode == 3)
        toggledMode = 0;
    spectrumView3D->toggledMode = toggledMode;
    contourPlot->toggleMode(toggledMode);
    switch (toggledMode) {
    case 0:
        ui->selectionModeButton->toggle();
        displayInformation("LMB + mouse dragging is now selecting peaks.", true, 0);
        spectrumView3D->spectrum_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetDirectlyAbove);
        break;
    case 1:
        ui->scaleModeButton->toggle();
        displayInformation("LMB + mouse dragging is now scaling the spectrum.", true, 0);
        break;
    case 2:
        ui->pickPeakMode->toggle();
        displayInformation("LMB + mouse dragging is now picking peaks.\nAlter the contour levels of the contour plot to adjust the peak picking tolerance.", true, 0);
        spectrumView3D->spectrum_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetDirectlyAbove);
        break;
    default:
        break;
    }
    QObject::connect(ui->pickPeakMode, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));
    QObject::connect(ui->selectionModeButton, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));
    QObject::connect(ui->scaleModeButton, SIGNAL(clicked(bool)), this, SLOT(manualLMBToggle()));
}

void workspace::manualLMBToggle()
{
    if(ui->selectionModeButton->isChecked())
    {
        toggledMode = 0;
        spectrumView3D->spectrum_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetDirectlyAbove);
        displayInformation("LMB + mouse dragging is now selecting peaks.", true, 0);
    }
    else if(ui->scaleModeButton->isChecked())
    {
        toggledMode = 1;
        displayInformation("LMB + mouse dragging is now scaling the spectrum.", true, 0);
    }
    else if(ui->pickPeakMode->isChecked())
    {
        toggledMode = 2;
        displayInformation("LMB + mouse dragging is now picking peaks.\nAlter the contour levels of the contour plot to adjust the peak picking tolerance.", true, 0);
    }
    spectrumView3D->toggledMode = toggledMode;
    contourPlot->toggleMode(toggledMode);
}

void workspace::syncPeakTable(QString query, bool select)
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        if(query==ui->peaklistTable->item(i,4)->text())
        {
            ui->peaklistTable->item(i,0)->setSelected(select);
            ui->peaklistTable->item(i,1)->setSelected(select);
            ui->peaklistTable->item(i,2)->setSelected(select);
            ui->peaklistTable->item(i,3)->setSelected(select);
            if(select)
            {
                selectedTableList << ui->peaklistTable->item(i,4)->text();
                selectedTableList2 << ui->peaklistTable->item(i,0)->text();
            }
            else
            {
                selectedTableList.clear();
                selectedTableList2.clear();
                for(int j(0); j<ui->peaklistTable->rowCount(); j++)
                {
                    if(ui->peaklistTable->item(j,0)->isSelected())
                    {
                        selectedTableList << ui->peaklistTable->item(j,4)->text();
                        selectedTableList2 << ui->peaklistTable->item(j,0)->text();
                    }
                }
            }
            break;
        }
    }
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
}

void workspace::changeActions(int activeTab)
{
    //Edit menubar actions so that they are topical to the current tab
    switch(activeTab)
    {
    case 1: //Spectrum tab
    {
        menuBar->actions().at(1)->setVisible(true);
        menuBar->actions().at(2)->setVisible(true);
        break;
    }
    default:
    {
        menuBar->actions().at(1)->setVisible(false);
        menuBar->actions().at(2)->setVisible(false);
        break;
    }
    }
}

void workspace::setTabFromShortcut(int tabNo)
{
    if(tabNo == 1 && ui->workspaceTab->currentIndex() == 1 && ui->view3DButton->isEnabled())
    {
        ui->view3DButton->toggle();
        ui->contourButton->toggle();
    }
    if(tabNo == 3 && ui->workspaceTab->currentIndex() == 3)
        viewRegionInSpectrum();
    else if(ui->workspaceTab->isTabEnabled(tabNo))
        ui->workspaceTab->setCurrentIndex(tabNo);
}

void workspace::tabChanged(int tabNo)
{
    disableInformation();
    if(tabNo==0)//import files
    {
#ifdef Q_OS_MAC
        displayInformation("Use the fn+F1-F7 keys to switch between tabs.", false, -1);
#else
        displayInformation("Use the F1-F7 keys to switch between tabs.", false, -1);
#endif
    }
    if(tabNo==1)
    {
#ifdef Q_OS_MAC
        displayInformation("Press fn+F8 to toggle hints", false, 0);
#else
        displayInformation("Press F12 to toggle hints", false, 0);
#endif
    }
    if(tabNo==2)//integrate msg
    {
        displayInformation(randomTip(), false, 1);
        setupCompleter(false);
    }
    else if(tabNo==3)
    {
        displayInformation("Use Page Up/Down to browse plots.\nW, A, S and D keys can be used to move around in the spectrum.", false, 2);
        ui->workspaceTab->setTabIcon(3,QIcon(":img/3dFits.png"));
    }
    else if(tabNo==4)
    {
        displayInformation("Use Page Up/Down to browse plots.", false, 3);
        ui->workspaceTab->setTabIcon(4,QIcon(":img/2dFits.png"));
    }
    else if(tabNo==5)
    {
        displayInformation("To plot a subset of residues highlight items in the \"Residue number\" column and tick the \"Selected\" box.", false, 4);
        ui->workspaceTab->setTabIcon(5,QIcon(":img/parameters.png"));
    }
}

void workspace::on_spectrumButton_clicked()
{
    QStringList files;
    if(pintTemplate.pipeData)
        files=addFiles("Add spectra to the project");
    else
        files << addTopspinDirs("Add spectra to the project");
    if(!files.isEmpty())
    {
        bool add(true);
        for(int i(0); i<files.size(); i++)
        {
            add=true;
            for(int j(0); j<ui->spectrumList->count(); j++)
            {
                if(files[i] == ui->spectrumList->item(j)->text())
                {
                    add=false;
                    break;
                }
            }
            if(add)
            {
                ui->spectrumList->addItem(files[i]);
                ui->spectrumBox->addItem(files[i]);
                ui->spectrumDefineBox->addItem(files[i]);
                pintTemplate.spectrumFiles.push_back(files[i]);
                peaklistClass newClass;
                newClass.spectrum = files[i];
                pintTemplate.pintPeaklists.push_back(newClass);
            }
        }
        setupCompleter(false);
    }
    if(ui->spectrumList->count()>0)
    {
        ui->workspaceTab->setTabEnabled(1,true);
        ui->workspaceTab->setTabEnabled(2,true);
    }
}

void workspace::on_peaklistButton_clicked()
{
    QStringList files(addFiles("Add peaklists to the project"));
    if(!files.isEmpty())
    {
        bool add(true);
        for(int i(0); i<files.size(); i++)
        {
            add=true;
            for(int j(0); j<ui->peaklistList->count(); j++)
            {
                if(files[i] == ui->peaklistList->item(j)->text())
                {
                    add=false;
                    break;
                }
            }
            if(add)
            {
                ui->peaklistList->addItem(files[i]);
                ui->peaklistBox->addItem(files[i]);
                ui->peaklistDefineBox->addItem(files[i]);
                pintTemplate.peaklistFiles.push_back(files[i]);
            }
        }
        setupCompleter(false);
    }
}

void workspace::on_otherButton_clicked()
{
    QStringList files(addFiles("Add files to the project"));
    if(!files.isEmpty())
    {
        bool add(true);
        for(int i(0); i<files.size(); i++)
        {
            add=true;
            for(int j(0); j<ui->otherList->count(); j++)
            {
                if(files[i] == ui->otherList->item(j)->text())
                {
                    add=false;
                    break;
                }
            }
            if(add)
            {
                ui->otherList->addItem(files[i]);
                pintTemplate.otherFiles.push_back(files[i]);
                ui->procparDefineBox->addItem(files[i]);
                if(ui->procparDefineBox->currentIndex()==0)
                {
                    if(files[i].contains("procpar", Qt::CaseInsensitive))
                    {
                        ui->procparDefineBox->setCurrentIndex(ui->procparDefineBox->count()-1);
                        ui->procparRadioButton->setChecked(true);
                        ui->vdlistRadioButton->setChecked(false);
                    }
                    else if(files[i].contains("vdlist", Qt::CaseInsensitive))
                    {
                        ui->procparDefineBox->setCurrentIndex(ui->procparDefineBox->count()-1);
                        ui->procparRadioButton->setChecked(false);
                        ui->vdlistRadioButton->setChecked(true);
                    }
                }
            }
        }
        setupCompleter(false);
    }
}

void workspace::removeFiles(int source)
{
    switch(source)
    {
    case 0:
    {
        for(int j(0); j<ui->spectrumList->selectedItems().count(); j++)
        {
            for(int i(0); i<ui->spectrumBox->count(); i++)
            {
                if(ui->spectrumBox->itemText(i)==ui->spectrumList->selectedItems().at(j)->text())
                    ui->spectrumBox->removeItem(i);
                if(pintTemplate.spectrumFiles.at(i)==ui->spectrumList->selectedItems().at(j)->text())
                {
                    pintTemplate.spectrumFiles.removeAt(i);
                    for(int k(0); k<pintTemplate.pintPeaklists.count(); ++k)
                    {
                        if(pintTemplate.pintPeaklists.at(k).spectrum == ui->spectrumList->selectedItems().at(j)->text())
                        {
                            pintTemplate.pintPeaklists.removeAt(k);
                            --k;
                        }
                    }
                }
            }
            for(int i(2); i<ui->spectrumDefineBox->count(); i++)
            {
                if(ui->spectrumDefineBox->itemText(i)==ui->spectrumList->selectedItems().at(j)->text())
                    ui->spectrumDefineBox->removeItem(i);
            }
            if(loadedSpectrum==ui->spectrumList->selectedItems().at(j)->text())
            {
                spectrumView3D->clearPlots(true);
                loadedSpectrum = "";
            }
        }
        qDeleteAll(ui->spectrumList->selectedItems());
        break;
    }
    case 1:
    {
        for(int j(0); j<ui->peaklistList->selectedItems().count(); j++)
        {
            for(int i(0); i<ui->peaklistBox->count(); i++)
            {
                if(ui->peaklistBox->itemText(i)==ui->peaklistList->selectedItems().at(j)->text())
                    ui->peaklistBox->removeItem(i);
                if(pintTemplate.peaklistFiles.at(i)==ui->peaklistList->selectedItems().at(j)->text())
                    pintTemplate.peaklistFiles.removeAt(i);
            }
            for(int i(2); i<ui->peaklistDefineBox->count(); i++)
            {
                if(ui->peaklistDefineBox->itemText(i)==ui->peaklistList->selectedItems().at(j)->text())
                    ui->peaklistDefineBox->removeItem(i);
            }
        }
        qDeleteAll(ui->peaklistList->selectedItems());
        break;
    }
    case 2:
    {
        for(int j(0); j<ui->otherList->selectedItems().count(); j++)
        {
            for(int i(0); i<pintTemplate.otherFiles.size(); i++)
            {
                if(pintTemplate.otherFiles.at(i)==ui->otherList->selectedItems().at(j)->text())
                    pintTemplate.otherFiles.removeAt(i);
            }
            for(int k(1); k<ui->procparDefineBox->count(); k++)
            {
                if(ui->procparDefineBox->itemText(k)==ui->otherList->selectedItems().at(j)->text())
                    ui->procparDefineBox->removeItem(k);
            }
        }
        qDeleteAll(ui->otherList->selectedItems());
        break;
    }
    }
    if(ui->spectrumList->count()==0)
    {
        for(int i(1); i<7; ++i)
            ui->workspaceTab->setTabEnabled(i,false);
    }
    setupCompleter(false);
}

void workspace::on_removeSelectedButton_clicked()
{
    removeFiles(0);
}

void workspace::on_removeSelectedButton_2_clicked()
{
    removeFiles(1);
}

void workspace::on_removeSelectedButton_3_clicked()
{
    removeFiles(2);
}

void workspace::integrate()
{
    //Integrate using mtPINT source files.
    //Important note, do not alter called files so changes to cmd version
    //can be easily imported
    //All mtPINT files are put in the integration directory
    //
    //Everytime files are updated, the following have to be made
    //1. Create a header file for mtpint.cpp
    //2. Rename main in mtpint toPint
    if(!ui->integrateButton->isEnabled())
        return;
    if(activeThreadID!=0)
    {
        QString str("Cleaning up the aborted integration. %1 active thread(s) remaining.");
        ui->integrationBrowser->append(str.arg(QString::number(activeThreadID)));
        return;
    }
    extern bool cancelVar;
    cancelVar = false;
    if(ui->workspaceTab->currentIndex()!=2)
        return;
    saveProject();
    disconnect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
    quitIntegration=false;
    iDialog = new integrationStatusDialog();
    //iDialog->setWindowModality(Qt::ApplicationModal);
    //ui->paramLayout->addWidget(iDialog,0,1,Qt::AlignRight);
    ui->paramLayout->addWidget(iDialog);
    disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegrationPrep()));
    connect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegrationPrep()));
    disconnect(iDialog, SIGNAL(rejected()), iDialog, SLOT(deleteLater()));
    connect(iDialog, SIGNAL(rejected()), iDialog, SLOT(deleteLater()));
    iDialog->updateLabels();
    iDialog->show();
    QString str("Preparing for analysis...");
    iDialog->updateLabel(str);
    iDialog->updateProgress(0);
    ui->warningIntegrationLabel->clear();
    QSize size;
    size.setHeight(20);
    size.setWidth(20);
    movie2->setScaledSize(size);

    QFile param(pintTemplate.paramFile);
    if (!param.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        iDialog->reject();
        connect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
        return;
    }
    QTextStream out(&param);
    out << paramEdit->toPlainText();
    param.close();
    QTextCursor cursor = paramEdit->textCursor();
    cursor.movePosition(QTextCursor::End);
    paramEdit->setTextCursor(cursor);
    if(quitIntegration)
    {
        connect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
        iDialog->reject();
        return;
    }
    if(errorCheckParamFile())
    {
        connect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
        disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegrationPrep()));
        iDialog->reject();
        return;
    }
    writeIntegratePeaklist();
    if(quitIntegration)
    {
        connect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
        iDialog->reject();
        return;
    }
    QDir dir;
    dir = pintTemplate.outDirectory;
    if(!dir.exists())
        dir.mkpath(pintTemplate.outDirectory); //Create projectDirectory and parent dirs
    dir = pintTemplate.plotDirectory;
    if(!dir.exists())
        dir.mkpath(pintTemplate.plotDirectory); //Create projectDirectory and parent dirs
    //clearDir(pintTemplate.outDirectory);
    //clearDir(pintTemplate.plotDirectory);
    ui->workspaceTab->setTabIcon(3,QIcon(":img/3dFits.png"));
    ui->workspaceTab->setTabIcon(4,QIcon(":img/2dFits.png"));
    ui->workspaceTab->setTabIcon(5,QIcon(":img/parameters.png"));
    ui->workspaceTab->setTabEnabled(3, false);
    ui->workspaceTab->setTabEnabled(4, false);
    ui->workspaceTab->setTabEnabled(5, false);
    ui->workspaceTab->setTabEnabled(6, false);
    lockUI(false);
    runPint(pintTemplate.paramFile.toStdString()+".tmp", pintTemplate.outDirectory.toStdString(), pintTemplate.plotDirectory.toStdString(), true);
    connect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
}

void workspace::lockUI(bool lock)
{
    ui->workspaceTab->setTabEnabled(0, lock);
    ui->workspaceTab->setTabEnabled(1, lock);
    ui->integrateButton->setEnabled(lock);
    ui->removeTemplateButton->setEnabled(lock);
    ui->saveTemplateButton->setEnabled(lock);
    ui->peaklistFormatButton2->setEnabled(lock);
    menuBar->setEnabled(lock);
}

void workspace::clearDir(const QString path)
{
    QDir dir(path);
    dir.setFilter( QDir::NoDotAndDotDot | QDir::Files );
    foreach( QString dirItem, dir.entryList() )
        dir.remove( dirItem );
    dir.setFilter( QDir::NoDotAndDotDot | QDir::Dirs );
    foreach( QString dirItem, dir.entryList() )
    {
        QDir subDir( dir.absoluteFilePath( dirItem ) );
        subDir.removeRecursively();
    }
}

QStringList workspace::addFiles(QString str)
{
    QStringList files = QFileDialog::getOpenFileNames(this, str, previousDir);
    if(!files.empty())
        previousDir = QDir(files[files.size()-1]).absolutePath();
    return files;
}

QString workspace::addTopspinDirs(QString str)
{
    QString files = QFileDialog::getExistingDirectory(this,str, previousDir);
    if(files!="")
        previousDir = files;
    return files;
}

void workspace::pressCtrl(bool pressed)
{
    ctrlPressed = pressed;
    contourPlot->ctrlPressed = pressed;
}
void workspace::processSpectrumLoad()
{
    if(rendering)
        return;
    disconnect(ui->loadSpectrumButton, SIGNAL(clicked(bool)), this, SLOT(processSpectrumLoad()));
    disconnect(ui->spectrumPlaneBox, SIGNAL(editingFinished()), this, SLOT(processSpectrumLoad()));
    disconnect(ui->spectrumPlaneBox, SIGNAL(editingFinished()), this, SLOT(handleSpinBox()));
    qApp->processEvents();
    rendering = true;
    if(ui->spectrumBox->count()>0)
    {
        spectrumView3D->exitMoveMode();
        contourPlot->exitMoveMode();
        if(loadedSpectrum!="")
            writeConnectedPeaklist();
        spectrumView3D->disconnect();
        ui->peaklistTable->disconnect();
        contourPlot->disconnect();
        if(!read3DSpectrum(ui->adjustButton->isChecked()))
        {
            if(spectrumView3D->spectrum_graph->seriesList().count()>0)
            {
                connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
                connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
                connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
                connect(spectrumView3D, SIGNAL(zoomed()), this, SLOT(updateContourZoom()));
                connect(contourPlot, SIGNAL(deselect()), this, SLOT(deselectContour()));
                connect(contourPlot, SIGNAL(createPeak(QVector3D,QString)), this, SLOT(createUserPeak(QVector3D,QString)));
                connect(contourPlot, SIGNAL(updatePeakList(QString,QPointF)), this, SLOT(updatePeakListFromContour(QString, QPointF)));
                connect(contourPlot, SIGNAL(ctrlPressedSync(bool)), this, SLOT(syncCtrl(bool)));
                connect(contourPlot, SIGNAL(contourZoomed(float,float,float,float)), this, SLOT(update3DZoom(float,float,float,float)));
                connect(contourPlot, SIGNAL(highlight(QString)), this, SLOT(highlightContourFromIdx(QString)));
                connect(contourPlot, SIGNAL(contourPickPeaks(double,double,double,double)), this, SLOT(pickPeaks(double,double,double,double)));
                connect(spectrumView3D, SIGNAL(pressCtrl(bool)), this, SLOT(pressCtrl(bool)));

                connect(spectrumView3D, SIGNAL(selectPeaksWithinBorder(float,float,float,float)), this, SLOT(selectPeaksWithinBorder(float,float,float,float)));
                connect(spectrumView3D, SIGNAL(pickPeaksWithinBorder(double,double,double,double)), this, SLOT(pickPeaks(double,double,double,double)));
                //connect(spectrumView3D, SIGNAL(undoEvent()), this, SLOT(undoEvent()));
                //connect(spectrumView3D, SIGNAL(redoEvent()), this, SLOT(redoEvent()));
                connect(spectrumView3D, SIGNAL(requestLabelTitle(QAbstract3DGraph::ElementType)), this, SLOT(sendLabelTitle(QAbstract3DGraph::ElementType)));
                connect(spectrumView3D, SIGNAL(deselectTable()), this, SLOT(deselectTable()));
                connect(spectrumView3D, SIGNAL(addToPeakTable(QVector3D, QString)), this, SLOT(createUserPeak(QVector3D, QString)));
                connect(spectrumView3D, SIGNAL(deleteFromPeakTable()), this, SLOT(deleteUserPeak()));
                connect(spectrumView3D, SIGNAL(syncPeakTable(QString, bool)), this, SLOT(syncPeakTable(QString, bool)));
                connect(spectrumView3D, SIGNAL(selectAll()), this, SLOT(selectAll()));
                connect(contourPlot, SIGNAL(infoPeakMode(QString, bool, int)), this, SLOT(displayInformation(QString, bool, int)));
                connect(spectrumView3D, SIGNAL(infoPeakMode(QString, bool, int)), this, SLOT(displayInformation(QString, bool, int)));
                connect(spectrumView3D, SIGNAL(moveModeFrame()), this, SLOT(moveModeFrame()));
                connect(contourPlot, SIGNAL(moveModeFrame()), this, SLOT(moveModeFrame()));
                connect(spectrumView3D, SIGNAL(defaultMoveModeFrame()), this, SLOT(defaultMoveModeFrame()));
                connect(contourPlot, SIGNAL(defaultMoveModeFrame()), this, SLOT(defaultMoveModeFrame()));
                connect(spectrumView3D, SIGNAL(updatePeakPosition(QVector3D,QString)) ,this, SLOT(updatePeakPosition(QVector3D,QString)));
            }
        }
        else
            rendering = false;
    }
    else
        rendering = false;
    connect(ui->spectrumPlaneBox, SIGNAL(editingFinished()), this, SLOT(handleSpinBox()));
    connect(ui->loadSpectrumButton, SIGNAL(clicked(bool)), this, SLOT(processSpectrumLoad()));
    connect(ui->spectrumPlaneBox, SIGNAL(editingFinished()), this, SLOT(processSpectrumLoad()));
}

void workspace::handleSpinBox()
{
    ui->spectrumPlaneBox->clearFocus();
}

void workspace::readThreadedSpectrum(pipeDataTemplate tmpPipe, pipeDataTemplate moddedPipe, int skip)
{
    // Call worker, connect signals
    bool enbled (ui->spectrumPlaneBox->isEnabled());
    int val(1);
    if(enbled)
        val = ui->spectrumPlaneBox->value();
    readSpectrumWorker* worker = new readSpectrumWorker(tmpPipe, moddedPipe, 0, skip, ui->spectrumBox->currentText(), pintTemplate.pipeData, enbled, val, nDim);
    QThread* thread = new QThread();
    worker->moveToThread(thread);
    disconnect(thread);
    disconnect(worker);
    connect(thread, SIGNAL(started()), worker, SLOT(process()));
    connect(worker, SIGNAL(finished(pipeDataTemplate,float,float,float,float,float,float)), thread, SLOT(quit()));
    connect(worker, SIGNAL(finished(pipeDataTemplate,float,float,float,float,float,float)), this, SLOT(processReadThreadedSpectrum(pipeDataTemplate,float,float,float,float,float,float)));
    connect(worker, SIGNAL(finished(pipeDataTemplate,float,float,float,float,float,float)), thread, SLOT(deleteLater()));
    connect(worker, SIGNAL(finished(pipeDataTemplate,float,float,float,float,float,float)), worker, SLOT(deleteLater()));
    //connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
    //connect(thread, SIGNAL(finished()), worker, SLOT(deleteLater()));
    thread->start();
}

void workspace::processReadThreadedSpectrum(pipeDataTemplate pipe, float minf1, float maxf1, float minf2, float maxf2, float cutoffslidermin, float cutoffslidermax)
{
    minF1 = minf1;
    maxF1 = maxf1;
    minF2 = minf2;
    maxF2 = maxf2;
    cutoffSliderMax = cutoffslidermax;
    cutoffSliderMin = cutoffslidermin;
    spectrumView3D->spectrum_graph->removeCustomItems();
    spectrumView3D->spectrum_graph->clearSelection();
    qApp->processEvents();
    ui->peaklistTable->clearSelection();
    ui->peaklistTable->clearContents();
    ui->peaklistTable->setRowCount(0);
    spectrumView3D->clearPlots(true);
    spectrumView3D->renderPlot(pipe.f1,pipe.f2,pipe.y,pipe.sizeF1,pipe.sizeF2);
    ui->zMinEdit->setText(QString::number(cutoffSliderMin));
    ui->zMaxEdit->setText(QString::number(cutoffSliderMax+spectrumView3D->marginal));
    ui->view3DButton->setEnabled(true);
    spectrumBox_update();
    if(zoomSaved)
    {
        if(spectrumView3D->spectrum_graph->axisX()->min()<xMinZoom && spectrumView3D->spectrum_graph->axisX()->max()>xMinZoom)
            spectrumView3D->spectrum_graph->axisX()->setMin(xMinZoom);
        if(spectrumView3D->spectrum_graph->axisY()->min()<yMinZoom && spectrumView3D->spectrum_graph->axisY()->max()>yMinZoom)
            spectrumView3D->spectrum_graph->axisY()->setMin(yMinZoom);
        if(spectrumView3D->spectrum_graph->axisZ()->min()<zMinZoom && spectrumView3D->spectrum_graph->axisZ()->max()>zMinZoom)
            spectrumView3D->spectrum_graph->axisZ()->setMin(zMinZoom);
        if(spectrumView3D->spectrum_graph->axisX()->min()<xMaxZoom && spectrumView3D->spectrum_graph->axisX()->max()>xMaxZoom)
            spectrumView3D->spectrum_graph->axisX()->setMax(xMaxZoom);
        if(spectrumView3D->spectrum_graph->axisY()->min()<yMaxZoom && spectrumView3D->spectrum_graph->axisY()->max()>yMaxZoom)
            spectrumView3D->spectrum_graph->axisY()->setMax(yMaxZoom);
        if(spectrumView3D->spectrum_graph->axisZ()->min()<zMaxZoom && spectrumView3D->spectrum_graph->axisZ()->max()>zMaxZoom)
            spectrumView3D->spectrum_graph->axisZ()->setMax(zMaxZoom);

        spectrumView3D->previousF1Scale[1] = QPointF(spectrumView3D->spectrum_graph->axisX()->min(), spectrumView3D->spectrum_graph->axisX()->max());
        spectrumView3D->previousF2Scale[1] = QPointF(spectrumView3D->spectrum_graph->axisZ()->min(), spectrumView3D->spectrum_graph->axisZ()->max());
        spectrumView3D->zoomCounter = 1;
    }
    setupContourWidget(pipe);
    if(zoomSaved)
        updateContourZoomManual(xMinZoom, xMaxZoom, zMinZoom, zMaxZoom);
    addSpectrumToParamBrowser();
    initStateVector();
    for(int i(0); i<pintTemplate.pintPeaklists.count(); i++)
        if(pintTemplate.pintPeaklists.at(i).spectrum==loadedSpectrum && pintTemplate.pintPeaklists.at(i).peaklist.size()>0)
            readConnectedPeaklist(i);
    readContourPeaklist(0);
    contourPlot->toggleLabels(labelsToggled);
    storeState();
    contourPlot->posContourColor = posContourColor;
    contourPlot->negContourColor = negContourColor;
    contourPlot->updateContourColors();
    spectrumView3D->spectrum_graph->installEventFilter(this);
    contourPlot->dragMode = -1;
    contourPlot->toggleMode(toggledMode);
    emit closeScreenDialog();

    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));

    connect(spectrumView3D, SIGNAL(zoomed()), this, SLOT(updateContourZoom()));
    connect(contourPlot, SIGNAL(deselect()), this, SLOT(deselectContour()));
    connect(contourPlot, SIGNAL(createPeak(QVector3D,QString)), this, SLOT(createUserPeak(QVector3D,QString)));
    disconnect(contourPlot, SIGNAL(updatePeakList(QString,QPointF)), this, SLOT(updatePeakListFromContour(QString, QPointF)));
    connect(contourPlot, SIGNAL(updatePeakList(QString,QPointF)), this, SLOT(updatePeakListFromContour(QString, QPointF)));
    connect(contourPlot, SIGNAL(ctrlPressedSync(bool)), this, SLOT(syncCtrl(bool)));
    connect(contourPlot, SIGNAL(contourZoomed(float,float,float,float)), this, SLOT(update3DZoom(float,float,float,float)));
    connect(contourPlot, SIGNAL(highlight(QString)), this, SLOT(highlightContourFromIdx(QString)));
    connect(contourPlot, SIGNAL(contourPickPeaks(double,double,double,double)), this, SLOT(pickPeaks(double,double,double,double)));
    connect(spectrumView3D, SIGNAL(pressCtrl(bool)), this, SLOT(pressCtrl(bool)));
    connect(spectrumView3D, SIGNAL(selectPeaksWithinBorder(float,float,float,float)), this, SLOT(selectPeaksWithinBorder(float,float,float,float)));
    connect(spectrumView3D, SIGNAL(pickPeaksWithinBorder(double,double,double,double)), this, SLOT(pickPeaks(double,double,double,double)));
    //connect(spectrumView3D, SIGNAL(undoEvent()), this, SLOT(undoEvent()));
    //connect(spectrumView3D, SIGNAL(redoEvent()), this, SLOT(redoEvent()));
    connect(spectrumView3D, SIGNAL(requestLabelTitle(QAbstract3DGraph::ElementType)), this, SLOT(sendLabelTitle(QAbstract3DGraph::ElementType)));
    connect(spectrumView3D, SIGNAL(deselectTable()), this, SLOT(deselectTable()));
    connect(spectrumView3D, SIGNAL(addToPeakTable(QVector3D, QString)), this, SLOT(createUserPeak(QVector3D, QString)));
    connect(spectrumView3D, SIGNAL(deleteFromPeakTable()), this, SLOT(deleteUserPeak()));
    connect(spectrumView3D, SIGNAL(syncPeakTable(QString, bool)), this, SLOT(syncPeakTable(QString, bool)));
    connect(spectrumView3D, SIGNAL(selectAll()), this, SLOT(selectAll()));
    connect(contourPlot, SIGNAL(infoPeakMode(QString, bool, int)), this, SLOT(displayInformation(QString, bool, int)));
    connect(spectrumView3D, SIGNAL(infoPeakMode(QString, bool, int)), this, SLOT(displayInformation(QString, bool, int)));
    connect(spectrumView3D, SIGNAL(moveModeFrame()), this, SLOT(moveModeFrame()));
    connect(contourPlot, SIGNAL(moveModeFrame()), this, SLOT(moveModeFrame()));
    connect(spectrumView3D, SIGNAL(defaultMoveModeFrame()), this, SLOT(defaultMoveModeFrame()));
    connect(contourPlot, SIGNAL(defaultMoveModeFrame()), this, SLOT(defaultMoveModeFrame()));
    connect(spectrumView3D, SIGNAL(updatePeakPosition(QVector3D,QString)) ,this, SLOT(updatePeakPosition(QVector3D,QString)));
    rendering = false;
}

void workspace::threadInfo()
{
    if(QThread::idealThreadCount()>0)
    {
        QString str = "Changing the thread count will affect the integration performance.\nThe ideal thread count for your system is: " + QString::number(QThread::idealThreadCount());
        displayInformation(str, true, 1);
    }
    else
    {
        QString str = "Changing the thread count will affect the integration performance.";
        displayInformation(str, true, 1);
    }
}

void workspace::displayInformation(QString msg, bool timerEnabled, int target)
{
    if(msg=="")
    {
        disableInformation();
        return;
    }
    if(target!=ui->workspaceTab->currentIndex()-1)
        return;
    ui->infoLabel->setPixmap(QPixmap(":img/info.png"));
    ui->infoLabel->setStyleSheet("QLabel#infoLabel {\nbackground-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n border-style: outset;\nborder-radius: 15px;\nborder-width: 1px;\nborder-color: gray;\n}");
    ui->infoLabel->setMaximumSize(30,30);
    ui->infoLabelText->setFont(QFont("Myriad Pro", 12));
    if(target==0) // spectrumTab infotext
    {
        msgTimer->stop();
        if(msg=="LMB + mouse dragging is now scaling the spectrum.")
        {
            ui->infoLabel->setPixmap(QPixmap(":img/zoomTool.png"));
            ui->infoLabel->setStyleSheet("");
            ui->infoLabel->setMaximumSize(40,40);
        }
        else if(msg=="LMB + mouse dragging is now selecting peaks.")
        {
            ui->infoLabel->setPixmap(QPixmap(":img/selectTool.png"));
            ui->infoLabel->setStyleSheet("");
            ui->infoLabel->setMaximumSize(40,40);
        }
        else if(msg=="LMB + mouse dragging is now picking peaks.\nAlter the contour levels of the contour plot to adjust the peak picking tolerance.")
        {
            ui->infoLabel->setPixmap(QPixmap(":img/selectTool.png"));
            ui->infoLabel->setStyleSheet("");
            ui->infoLabel->setMaximumSize(40,40);
        }
        ui->infoLabelText->setText(msg);
        ui->infoLabel->show();
        ui->infoLabelText->show();
        if(timerEnabled)
            msgTimer->start();
    }
    else if (target>0 || target ==-1)
    {
        msgTimer->stop();
        ui->infoLabelText->setText(msg);
        ui->infoLabel->show();
        ui->infoLabelText->show();
        if(timerEnabled)
            msgTimer->start();
    }
}

void workspace::disableInformation()
{
    ui->infoLabelText->hide();
    ui->infoLabel->hide();
}

int workspace::read3DSpectrum(bool adjustSW)
{
    zoomSaved = false;
    int skip(1);
    if(loadedSpectrum == ui->spectrumBox->currentText())
    {
        xMinZoom = spectrumView3D->spectrum_graph->axisX()->min();
        xMaxZoom = spectrumView3D->spectrum_graph->axisX()->max();
        yMinZoom = spectrumView3D->spectrum_graph->axisY()->min();
        yMaxZoom = spectrumView3D->spectrum_graph->axisY()->max();
        zMinZoom = spectrumView3D->spectrum_graph->axisZ()->min();
        zMaxZoom = spectrumView3D->spectrum_graph->axisZ()->max();
        zoomSaved = true;
    }
    else
    {
        ui->spectrumPlaneBox->setDisabled(true);
        ui->spectrumPlaneBox->setValue(1);
    }
    QString tmpLoaded(loadedSpectrum);
    if(pintTemplate.pipeData)
    {
        pipeDataTemplate tmpPipe, moddedPipe;
        //Read and display a 3D spectrum for NMRpipe
        tmpPipe = readPipeHeader();
        moddedPipe = tmpPipe;
        if(errMsg!="")
        {
            displayError();
            rendering = false;
            return 0;
        }
        dataPointCount = tmpPipe.sizeF1* tmpPipe.sizeF2;
        if(nDim==3)
            dataPointCount/= tmpPipe.nPlane; //No submatrix system for nmrPipe 3D data
        renderPlot = true;
        loadedSpectrum = ui->spectrumBox->currentText();

        if(dataPointCount>2000000 || adjustSW)
        {
            zoomSaved = false;
            datapointDialog *ddlg = new datapointDialog();
            ddlg->setWindowFlags(Qt::WindowTitleHint | Qt::WindowCloseButtonHint);
            ddlg->sizeF1 = tmpPipe.sizeF1;
            ddlg->sizeF2 = tmpPipe.sizeF2;
            ddlg->firstF1 = tmpPipe.firstF1;
            ddlg->firstF2 = tmpPipe.firstF2;
            ddlg->obsF1 = tmpPipe.obsF1;
            ddlg->obsF2 = tmpPipe.obsF2;
            ddlg->deltaF1 = tmpPipe.deltaF1;
            ddlg->deltaF2 = tmpPipe.deltaF2;
            ddlg->swF1 = tmpPipe.swF1;
            ddlg->swF2 = tmpPipe.swF2;
            ddlg->setupLimits();
            ddlg->setWindowModality(Qt::ApplicationModal);
            if(ddlg->exec())
            {
                moddedPipe.sizeF1 = ddlg->sizeF1;
                moddedPipe.sizeF2 = ddlg->sizeF2;
                moddedPipe.firstF1 = ddlg->firstF1;
                moddedPipe.firstF2 = ddlg->firstF2;
                moddedPipe.swF1 = ddlg->swF1;
                moddedPipe.swF2 = ddlg->swF2;
                skip = ddlg->skipVal;
            }
            else
            {
                ddlg->deleteLater();
                renderPlot = false;
                rendering = false;
                loadedSpectrum = tmpLoaded;
                return 0;
            }
            ddlg->deleteLater();
        }
        screenDialog *sDialog = new screenDialog();
        sDialog->setAttribute(Qt::WA_DeleteOnClose);
        disconnect(sDialog, SIGNAL(ctrl(bool)), this, SLOT(syncCtrl(bool)));
        connect(sDialog, SIGNAL(ctrl(bool)), this, SLOT(syncCtrl(bool)));
        disconnect(this, SIGNAL(closeScreenDialog()), sDialog, SLOT(reject()));
        connect(this, SIGNAL(closeScreenDialog()), sDialog, SLOT(reject()));
        sDialog->setWindowModality(Qt::ApplicationModal);
        sDialog->setStyleSheet("background:transparent;");
        sDialog->setAttribute(Qt::WA_TranslucentBackground);
        sDialog->setWindowFlags(Qt::FramelessWindowHint);
        sDialog->show();
        QApplication::processEvents();
        readThreadedSpectrum(tmpPipe, moddedPipe, skip);
    }
    else
    {
        //Read and display a 3D spectrum for topspin
        pipeDataTemplate tmpPipe, moddedPipe;
        tmpPipe = readTopspinHeader();
        moddedPipe = tmpPipe;
        if(errMsg!="")
        {
            displayError();
            rendering = false;
            return 0;
        }
        dataPointCount = tmpPipe.sizeF1 * tmpPipe.sizeF2; // Due to submatrix system for 3rrr
        renderPlot = true;
        loadedSpectrum = ui->spectrumBox->currentText();
        if(dataPointCount>2000000 || adjustSW)
        {
            zoomSaved = false;
            datapointDialog *ddlg = new datapointDialog();
            ddlg->setWindowFlags(Qt::WindowTitleHint | Qt::WindowCloseButtonHint);
            ddlg->sizeF1 = tmpPipe.sizeF1;
            ddlg->sizeF2 = tmpPipe.sizeF2;
            ddlg->firstF1 = tmpPipe.firstF1;
            ddlg->firstF2 = tmpPipe.firstF2;
            ddlg->obsF1 = tmpPipe.obsF1;
            ddlg->obsF2 = tmpPipe.obsF2;
            ddlg->deltaF1 = tmpPipe.deltaF1;
            ddlg->deltaF2 = tmpPipe.deltaF2;
            ddlg->swF1 = tmpPipe.swF1;
            ddlg->swF2 = tmpPipe.swF2;
            ddlg->setupLimits();
            ddlg->setWindowModality(Qt::ApplicationModal);
            if(ddlg->exec())
            {
                moddedPipe.sizeF1 = ddlg->sizeF1;
                moddedPipe.sizeF2 = ddlg->sizeF2;
                moddedPipe.firstF1 = ddlg->firstF1;
                moddedPipe.firstF2 = ddlg->firstF2;
                moddedPipe.swF1 = ddlg->swF1;
                moddedPipe.swF2 = ddlg->swF2;
                skip = ddlg->skipVal;
            }
            else
            {
                ddlg->deleteLater();
                renderPlot = false;
                rendering = false;
                loadedSpectrum = tmpLoaded;
                return 0;
            }
            ddlg->deleteLater();
        }
        screenDialog *sDialog = new screenDialog();
        sDialog->setAttribute(Qt::WA_DeleteOnClose);
        disconnect(sDialog, SIGNAL(ctrl(bool)), this, SLOT(syncCtrl(bool)));
        connect(sDialog, SIGNAL(ctrl(bool)), this, SLOT(syncCtrl(bool)));
        disconnect(this, SIGNAL(closeScreenDialog()), sDialog, SLOT(reject()));
        connect(this, SIGNAL(closeScreenDialog()), sDialog, SLOT(reject()));
        sDialog->setWindowModality(Qt::ApplicationModal);
        sDialog->setStyleSheet("background:transparent;");
        sDialog->setAttribute(Qt::WA_TranslucentBackground);
        sDialog->setWindowFlags(Qt::FramelessWindowHint);
        sDialog->show();
        QApplication::processEvents();
        readThreadedSpectrum(tmpPipe, moddedPipe, skip);
    }
    ui->spectrumDefineBox->setCurrentIndex(0);
    ui->peaklistDefineBox->setCurrentIndex(0);
    qApp->processEvents();
    return 1;
}

void workspace::displayError()
{
    //Error occurred and is stored in errMsg
    QMessageBox::StandardButton dlg;
    dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
    if(dlg==QMessageBox::Ok)
    {
        errMsg=""; //We never have to worry about random errors when reseting the property before returning.
        return;
    }
}

Int workspace::setNoDim()
{
    // determines dimensionality of spectrum from header
    FILE *fp;
    if(!(fp = fopen(ui->spectrumBox->currentText().toStdString().c_str(), "rb")))
        return 1;
    float temp; // N.B. must be a 4 byte float
    fseek(fp, NDIM*4, SEEK_SET);
    fread(&temp, 4, 1, fp);
    nDim = (Int)(temp+0.5);
    fclose(fp);
    if (nDim < 2 || nDim > 3)
        return 1;
    return 0;
}

Int workspace::setNoDim_Topspin()
{
    // determines dimensionality of spectrum TOPSPIN
    FILE *fp;
    bool ok(true);
    if(!(fp = fopen((ui->spectrumBox->currentText().toStdString()+"/2rr").c_str(), "rb")))
        ok = false;
    else
    {
        nDim = 2;
        fclose(fp);
    }
    if(!(fp = fopen((ui->spectrumBox->currentText().toStdString()+"/3rrr").c_str(), "rb")))
    {
        if(!ok)
            return 1;
    }
    else
    {
        nDim = 3;
        fclose(fp);
    }
    return 0;
}

pipeDataTemplate workspace::readTopspinHeader()
{
    pipeDataTemplate pipe;
    if (setNoDim_Topspin())
    {
        errMsg = "Could not read spectrum.\nOnly 2D or 3D spectra are allowed";
        return pipe;
    }
    //Read header
    if(nDim==2 || nDim ==3)
    {
        QFile file(ui->spectrumBox->currentText()+"/procs");
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            errMsg="Could not open "+ui->spectrumBox->currentText()+"/procs";
            return pipe;
        }
        QTextStream in(&file);
        QString line = in.readLine();
        while(!line.isNull())
        {
            istringstream iss(line.toStdString().c_str());
            string sub;
            int col(0);
            int type(-1);
            while(iss >> sub)
            {
                if(col==0 && sub =="##$SI=")
                    type = 1;
                else if(col==0 && sub =="##$SW_p=")
                    type = 2;
                else if(col==0 && sub =="##$SF=")
                    type = 3;
                else if(col==0 && sub =="##$OFFSET=")
                    type = 4;
                else if(col==0 && sub =="##$XDIM=")
                    type = 5;
                else if(col==0 && sub =="##$NC_proc=")
                    type = 6;

                if(col==1)
                {
                    switch(type)
                    {
                    case 1:
                    {
                        pipe.sizeF2 = atoi(sub.c_str());
                        break;
                    }
                    case 2:
                    {
                        pipe.swF2 = atof(sub.c_str());
                        break;
                    }
                    case 3:
                    {
                        pipe.obsF2 = atof(sub.c_str());
                        break;
                    }
                    case 4:
                    {
                        pipe.origF2 = atof(sub.c_str());
                        break;
                    }
                    case 5:
                    {
                        pipe.xDimF2 = atof(sub.c_str());
                        break;
                    }
                    case 6:
                    {
                        pipe.nc_proc = atoi(sub.c_str());
                        break;
                    }
                    default:
                        break;
                    }
                }
                col++;
            }
            line = in.readLine();
        }
        file.close();
        QFile file2(ui->spectrumBox->currentText()+"/proc2s");
        if(!file2.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            errMsg="Could not open "+ui->spectrumBox->currentText()+"/proc2s";
            return pipe;
        }
        QTextStream in2(&file2);
        line = in2.readLine();
        while(!line.isNull())
        {
            istringstream iss(line.toStdString().c_str());
            string sub;
            int col(0);
            int type(-1);
            while(iss >> sub)
            {
                if(col==0 && sub =="##$SI=")
                    type = 1;
                else if(col==0 && sub =="##$SW_p=")
                    type = 2;
                else if(col==0 && sub =="##$SF=")
                    type = 3;
                else if(col==0 && sub =="##$OFFSET=")
                    type = 4;
                else if(col==0 && sub =="##$XDIM=")
                    type = 5;
                else if(col==0 && sub =="##$NC_proc=")
                    type = 6;


                if(col==1)
                {
                    switch(type)
                    {
                    case 1:
                    {
                        pipe.sizeF1 = atoi(sub.c_str());
                        break;
                    }
                    case 2:
                    {
                        pipe.swF1 = atof(sub.c_str());
                        break;
                    }
                    case 3:
                    {
                        pipe.obsF1 = atof(sub.c_str());
                        break;
                    }
                    case 4:
                    {
                        pipe.origF1 = atof(sub.c_str());
                        break;
                    }
                    case 5:
                    {
                        pipe.xDimF1 = atof(sub.c_str());
                        break;
                    }
                    case 6:
                    {
                        pipe.nc_proc = atoi(sub.c_str());
                        break;
                    }
                    default:
                        break;
                    }
                }
                col++;
            }
            line = in2.readLine();
        }
        file2.close();

        pipe.origF1 = pipe.origF1*pipe.obsF1-pipe.swF1;
        pipe.origF2 = pipe.origF2*pipe.obsF2-pipe.swF2;
        pipe.deltaF1 = -pipe.swF1/(double)pipe.sizeF1;
        pipe.deltaF2 = -pipe.swF2/(double)pipe.sizeF2;
        pipe.firstF1 = pipe.origF1 - pipe.deltaF1*((double)pipe.sizeF1-1.);
        pipe.firstF2 = pipe.origF2 - pipe.deltaF2*((double)pipe.sizeF2-1.);
        pipe.xDimF3=1;
    }
    if(nDim==3)
    {//3D spectra
        QFile file3(ui->spectrumBox->currentText()+"/proc3s");
        if(!file3.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            errMsg="Could not open "+ui->spectrumBox->currentText()+"/proc3s";
            return pipe;
        }
        QTextStream in3(&file3);
        QString line = in3.readLine();
        while(!line.isNull())
        {
            istringstream iss(line.toStdString().c_str());
            string sub;
            int col(0);
            int type(-1);
            while(iss >> sub)
            {
                if(col==0 && sub =="##$SI=")
                    type = 1;
                else if(col==0 && sub =="##$XDIM=")
                    type = 2;

                if(col==1)
                {
                    switch(type)
                    {
                    case 1:
                    {
                        pipe.nPlane = atoi(sub.c_str());
                        nPlane = atoi(sub.c_str());
                        break;
                    }
                    case 2:
                    {
                        pipe.xDimF3 = atof(sub.c_str());
                        break;
                    }
                    default:
                        break;
                    }
                }
                col++;
            }
            line = in3.readLine();
        }
        file3.close();
    }

    return pipe;
}

pipeDataTemplate workspace::readPipeHeader()
{
    pipeDataTemplate pipe;
    if (setNoDim())
    {
        errMsg = "Invalid dimension of loaded spectrum. Aborting.";
        return pipe;
    }
    //Read header
    FILE *fp;
    float temp;
    if(!(fp = fopen(ui->spectrumBox->currentText().toStdString().c_str(), "rb")))
    {
        errMsg="Cannot open " + ui->spectrumBox->currentText();
        return pipe;
    }
    fseek(fp, 9*4, 0);
    fread(&temp, 4, 1, fp);
    fclose(fp);
    int nDim = (int)(temp+0.5);
    if (nDim < 2 || nDim > 3)
    {
        errMsg = "Only 2D or 3D spectra are allowed";
        return pipe;
    }
    fp = fopen(ui->spectrumBox->currentText().toStdString().c_str(), "rb");
    fread(pipe.header, 4, 512, fp);
    fclose(fp);
    pipe.sizeF2 = pipe.header[99];
    pipe.swF2 = pipe.header[100];
    pipe.obsF2 = pipe.header[119];
    pipe.origF2 = pipe.header[101];

    if (nDim == 2) {
        pipe.sizeF1 = pipe.header[F1SIZE];
        pipe.swF1 = pipe.header[F1SW];
        pipe.obsF1 = pipe.header[F1OBS];
        pipe.origF1 = pipe.header[F1ORIG];
    }
    else if (nDim == 3) {
        pipe.sizeF1 = pipe.header[F1SIZE_3D];
        pipe.swF1 = pipe.header[F1SW_3D];
        pipe.obsF1 = pipe.header[F1OBS_3D];
        pipe.origF1 = pipe.header[F1ORIG_3D];
        pipe.nPlane = pipe.header[NPLANE];
    }
    pipe.deltaF1 = -pipe.swF1/(double)pipe.sizeF1;
    pipe.deltaF2 = -pipe.swF2/(double)pipe.sizeF2;
    pipe.firstF1 = pipe.origF1 - pipe.deltaF1*((double)pipe.sizeF1-1.);
    pipe.firstF2 = pipe.origF2 - pipe.deltaF2*((double)pipe.sizeF2-1.);

    return pipe;
}

void workspace::toggleHints()
{
    if(ui->workspaceTab->currentIndex()!=1)
        return;
    hintDialog hdlg;
    hdlg.setWindowModality(Qt::ApplicationModal);
    if(hdlg.exec())
    {
#ifdef Q_OS_MAC
        if("Press fn+F8 to toggle hints" == ui->infoLabelText->text())
            disableInformation();
#else
        if("Press F12 to toggle hints" == ui->infoLabelText->text())
            disableInformation();
#endif
    }
}

void workspace::on_loadPeaklistButton_clicked()
{
    if(ui->peaklistBox->count()>0 && spectrumView3D->spectrum_graph->seriesList().count()!=0)
    {
        int rowNo(0);
        if(ui->peaklistTable->rowCount()!=0)
        {
            QMessageBox dlg;
            dlg.setText("Do you want to add peaks to the current peaklist or replace them?");
            dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
            dlg.setDefaultButton(QMessageBox::Yes);
            dlg.setButtonText(QMessageBox::Yes, tr("Add"));
            dlg.setButtonText(QMessageBox::No, tr("Replace"));
            dlg.setWindowTitle("PINT");
            int ret = dlg.exec();
            switch (ret)
            {
            case QMessageBox::No:
            {
                disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
                disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
                disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
                disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
                disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
                spectrumView3D->clearSelectedItems();
                spectrumView3D->selectionVector.clear();
                ui->peaklistTable->clearSelection();
                for(int i(0); i<ui->peaklistTable->rowCount(); i++)
                {
                    spectrumView3D->deleteFromSelectionVector("peak" + ui->peaklistTable->item(i,4)->text());
                    spectrumView3D->removeCustomLabel(ui->peaklistTable->item(i,4)->text().toInt());
                    ui->peaklistTable->removeRow(i);
                    i--;
                }
                peakId=0;
                ui->peaklistTable->clearSelection();
                contourPlot->detachAll();
                QApplication::processEvents();
                storeState();
                QApplication::processEvents();
                connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
                connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
                connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
                connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
                connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
                break;
            }
            case QMessageBox::Cancel:
                return;
            default:
            {
                rowNo = ui->peaklistTable->rowCount();
                break;
            }
            }
        }
        disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
        disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
        disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
        QString fname= ui->peaklistBox->currentText();
        QFile file(fname);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            errMsg="Could not open the peaklist";
            storeState();
            displayError();
            connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
            connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
            connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
            return;
        }
        QTextStream in(&file);
        generateIntensities = false;
        int hCount(0);
        QString line("not_null");
        bool readAgain(true);
        errMsg="";
        while(hCount < peaklistFormat.at(0))
        {
            line = in.readLine();
            hCount++;
            if(line.isNull())
                break;
        }
        int errCount(0);
        while(!line.isNull())
        {
            if(readAgain)
            {
                line = in.readLine();
                readAgain=false;
                continue;
            }
            istringstream iss(line.toStdString().c_str());
            string sub;
            int col(1);
            bool importOk(false);
            QString ass(""), f1(""), f2("");
            while(iss >> sub)
            {
                if(peaklistFormat.at(1) == col) //assignment
                    ass = QString::fromStdString(sub.c_str());
                else if(peaklistFormat.at(2) == col) //f1
                    f1 = QString::fromStdString(sub.c_str());
                else if(peaklistFormat.at(3) == col) //f2
                    f2 = QString::fromStdString(sub.c_str());
                if(ass!="" && f1!="" && f2!="")
                {
                    bool convOk;
                    f1.toDouble(&convOk);
                    if(!convOk)
                        break;
                    f2.toDouble(&convOk);
                    if(!convOk)
                        break;
                    importOk = true;
                    ui->peaklistTable->insertRow(ui->peaklistTable->rowCount());
                    for(int i(0); i<3; i++)
                    {
                        QTableWidgetItem *item = new QTableWidgetItem;
                        switch(i)
                        {
                        case 0:
                        {
                            item->setText(ass);
                            break;
                        }
                        case 1:
                        {
                            item->setText(f1);
                            break;
                        }
                        case 2:
                        {
                            item->setText(f2);
                            break;
                        }
                        default: break;
                        }
                        ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,i,item);
                    }
                    break;
                }
                col++;
            }
            if(!importOk)
            {
                errCount++;
                if(errCount<6)
                    errMsg+= line + "\n";
                line = in.readLine();
            }
            else
            {
                generateIntensities = true;
                QTableWidgetItem *item0 = new QTableWidgetItem;
                item0->setText("0");
                ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,3,item0);
                QTableWidgetItem *item = new QTableWidgetItem;
                item->setText(QString::number(peakId++));
                ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 4, item);
                QTableWidgetItem *item2 = new QTableWidgetItem;
                foldedClass fold(isPeakFolded(ui->peaklistTable->item(ui->peaklistTable->rowCount()-1,1)->text(),ui->peaklistTable->item(ui->peaklistTable->rowCount()-1,2)->text()));
                item2->setText(QString::number(fold.foldedF1));
                ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 5, item2);
                QTableWidgetItem *item5 = new QTableWidgetItem;
                item5->setText(QString::number(fold.foldedF2));
                ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 6, item5);
                QTableWidgetItem *item3 = new QTableWidgetItem;
                item3->setText(QString::number(fold.foldedF1val));
                ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 7, item3);
                QTableWidgetItem *item4 = new QTableWidgetItem;
                item4->setText(QString::number(fold.foldedF2val));
                ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 8, item4);
                line = in.readLine();
            }
        }
        file.close();

        if(errCount>0)
        {
            errMsg = "Could not read data from "+QString::number(errCount)+" number of lines, including:\n" + errMsg
                    + "...\nPlease check your peaklist format settings by clicking \"Edit format\".\n"
                    + "The current peaklist format is:\nHeader rows: "+QString::number(peaklistFormat.at(0))
                    +"\nAssignment column: "+QString::number(peaklistFormat.at(1))+"\nF1 column: "
                    +QString::number(peaklistFormat.at(2))+"\nF2 column: "+QString::number(peaklistFormat.at(3));
            displayError();
        }
        ui->peaklistTable->horizontalHeader()->setStretchLastSection(true);

        if(ui->peaklistTable->rowCount()>0)
        {
            createPeakLabels(rowNo);
            readContourPeaklist(rowNo);
            storeState();
        }
        else if(errCount == 0 && ui->peaklistTable->rowCount()==0)
        {
            errMsg = "No data to read.\nPlease check your peaklist format settings by clicking \"Edit format\".\n"
                     "The current peaklist format is:\nHeader rows: "+QString::number(peaklistFormat.at(0))
                    +"\nAssignment column: "+QString::number(peaklistFormat.at(1))+"\nF1 column: "
                    +QString::number(peaklistFormat.at(2))+"\nF2 column: "+QString::number(peaklistFormat.at(3));
            displayError();
        }

        disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
        disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
        disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
        connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
        connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
        connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
        disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
        connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
        disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
        connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
        spectrumView3D->exitMoveMode();
        contourPlot->exitMoveMode();
    }
}

void workspace::createPeakLabels(int start)
{
    for(int i(start); i<ui->peaklistTable->rowCount(); i++)
    {
        bool folded(false);
        double f1(ui->peaklistTable->item(i,1)->text().toDouble());
        double f2(ui->peaklistTable->item(i,2)->text().toDouble());
        if(ui->peaklistTable->item(i,5)->text().toInt()!=0)
        {
            f1 = ui->peaklistTable->item(i,7)->text().toDouble();
            folded = true;
        }
        if(ui->peaklistTable->item(i,6)->text().toInt()!=0)
        {
            f2 = ui->peaklistTable->item(i,8)->text().toDouble();
            folded = true;
        }
        QString peakName("");
        for(int j(0); j< ui->peaklistTable->item(i,0)->text().size(); j++)
        {
            if(ui->peaklistTable->item(i,0)->text()[j]!=' ')
                peakName+=ui->peaklistTable->item(i,0)->text()[j];
        }
        if(peakName=="")
            ui->peaklistTable->item(i,0)->setText("?");
        else
            ui->peaklistTable->item(i,0)->setText(peakName);
        if(generateIntensities)
        {
            // x==1H, z==15N
            float diff(9.9e99);
            QPoint closestPoint(0,0);
            for(int k(0); k<spectrumView3D->spectrum_renderPlotProxy->rowCount(); k++)
                for(int j(0); j<spectrumView3D->spectrum_renderPlotProxy->columnCount(); j++)
                {
                    float val(qSqrt(qPow(f2-spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x(),2) + qPow(f1 - spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().z(),2)));
                    if(diff > val)
                    {
                        diff = val;
                        closestPoint = QPoint(k,j);
                    }
                }
            ui->peaklistTable->item(i,3)->setText(QString::number(spectrumView3D->spectrum_renderPlotProxy->itemAt(closestPoint)->y()));
        }
        spectrumView3D->addCustomLabel(ui->peaklistTable->item(i,0)->text(),QVector3D(f2,ui->peaklistTable->item(i,3)->text().toDouble(),f1), ui->peaklistTable->item(i,4)->text().toDouble(), folded);
    }
}

void workspace::updatePeakLabels(int row, int col)
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    if(col==0)
    {
        QChar chr(checkLegalFileName(ui->peaklistTable->item(row,col)->text()));
        if(chr!='1')
        {
            ui->peaklistTable->item(row,col)->setText(getNextLabelName(0));
            QString msg="The edited peak name contains an illegal character ('" +(QString)chr+"').\nGenerated a label automatically.";
            displayInformation(msg, true, 0);
        }
    }
    spectrumView3D->clearSelectedItems();
    spectrumView3D->selectionVector.clear();
    spectrumView3D->deleteFromSelectionVector("peak" + ui->peaklistTable->item(row,4)->text());
    spectrumView3D->removeCustomLabel(ui->peaklistTable->item(row,4)->text().toInt());
    if(col!=-1)
        ui->peaklistTable->item(row,col)->setSelected(true);
    foldedClass fold(isPeakFolded(ui->peaklistTable->item(row,1)->text(),ui->peaklistTable->item(row,2)->text()));
    ui->peaklistTable->item(row,5)->setText(QString::number(fold.foldedF1));
    ui->peaklistTable->item(row,6)->setText(QString::number(fold.foldedF2));
    ui->peaklistTable->item(row,7)->setText(QString::number(fold.foldedF1val));
    ui->peaklistTable->item(row,8)->setText(QString::number(fold.foldedF2val));
    QApplication::processEvents();
    bool folded(false);
    double f1(ui->peaklistTable->item(row,1)->text().toDouble());
    double f2(ui->peaklistTable->item(row,2)->text().toDouble());
    if(ui->peaklistTable->item(row,5)->text().toInt()!=0)
    {
        f1 = ui->peaklistTable->item(row,7)->text().toDouble();
        folded = true;
    }
    if(ui->peaklistTable->item(row,6)->text().toInt()!=0)
    {
        f2 = ui->peaklistTable->item(row,8)->text().toDouble();
        folded = true;
    }
    QString peakName("");
    for(int j(0); j< ui->peaklistTable->item(row,0)->text().size(); j++)
    {
        if(ui->peaklistTable->item(row,0)->text()[j]!=' ')
            peakName+=ui->peaklistTable->item(row,0)->text()[j];
    }
    if(peakName=="")
        ui->peaklistTable->item(row,0)->setText("?");
    else
        ui->peaklistTable->item(row,0)->setText(peakName);
    spectrumView3D->addCustomLabel(ui->peaklistTable->item(row,0)->text(),QVector3D(f2,ui->peaklistTable->item(row,3)->text().toDouble(),f1), ui->peaklistTable->item(row,4)->text().toDouble(), folded);
    if(!centeringPeak && contourPlot->replotContour == true)
        storeState();
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    QApplication::processEvents();
    if(col != -1)
        spectrumView3D->highlightSelection(ui->peaklistTable->item(row,4)->text(), ui->peaklistTable->item(row,0)->text(),false, ui->view3DButton->isChecked());
}

void workspace::sendLabelTitle(QAbstract3DGraph::ElementType type)
{
    if(type == QAbstract3DGraph::ElementCustomItem)
    {
        if(spectrumView3D->spectrum_graph->selectedCustomItem()->objectName().isEmpty())
            return;
        QString label("");
        QString str(spectrumView3D->spectrum_graph->selectedCustomItem()->objectName());
        if(str[0]=='d') //Dummy label selected, check if ctrl-click else do nothing
        {
            if(spectrumView3D->ctrlPressed)
                spectrumView3D->handleDeselection("");
            return;
        }
        else if(str[0]=='p')
            str=str.mid(4);
        else
            str=str.mid(5);
        for(int i(0); i<ui->peaklistTable->rowCount(); i++)
        {
            if(ui->peaklistTable->item(i,4)->text()==str)
            {
                label = ui->peaklistTable->item(i,0)->text();
                disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
                ui->peaklistTable->selectRow(i);
                connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
                break;
            }
        }
        spectrumView3D->handleElementSelected(type, label);
    }
    else if (type == QAbstract3DGraph::ElementSeries)
        spectrumView3D->handleElementSelected(type, "");
    else
        spectrumView3D->handleElementSelected(type, "");
}

void workspace::highlightPeak()
{
    if(spectrumView3D->moveModeEnabled)
    {
        spectrumView3D->exitMoveMode();
        contourPlot->exitMoveMode();
    }
    int count(0);
    for(int i(0); i<ui->peaklistTable->selectedItems().count(); i++)
    {
        if(ui->peaklistTable->selectedItems().at(i)->column()==0)
            count++;
        if(count>1)
            break;
    }
    if(count==0) //deselect
    {
        spectrumView3D->clearSelectedItems();
        spectrumView3D->selectionVector.clear();
        selectedTableList.clear();
        selectedTableList2.clear();
    }
    else if(count==1)
    {
        for(int i(0); i<ui->peaklistTable->selectedItems().count(); i++)
        {
            if(ui->peaklistTable->selectedItems().at(i)->column()==0)
            {
                selectedTableList.clear();
                selectedTableList2.clear();
                selectedTableList << ui->peaklistTable->item(ui->peaklistTable->selectedItems().at(i)->row(),4)->text();
                selectedTableList2 << ui->peaklistTable->item(ui->peaklistTable->selectedItems().at(i)->row(),0)->text();
                spectrumView3D->highlightSelection(ui->peaklistTable->item(ui->peaklistTable->selectedItems().at(i)->row(),4)->text(), ui->peaklistTable->item(ui->peaklistTable->selectedItems().at(i)->row(),0)->text(),false, ui->view3DButton->isChecked());
                break;
            }
        }
    }
    else
    {
        QStringList strList, strList2;
        for(int i(0); i<ui->peaklistTable->selectedItems().count(); i++)
        {
            if(ui->peaklistTable->selectedItems().at(i)->column()==0)
            {
                strList << ui->peaklistTable->item(ui->peaklistTable->selectedItems().at(i)->row(),4)->text();
                strList2 << ui->peaklistTable->item(ui->peaklistTable->selectedItems().at(i)->row(),0)->text();
            }
        }
        //strList are items selected in peaklist to be synced with the graph
        QString obj(""), label("");
        if(strList.count() < selectedTableList.count()) //Deselection
        {
            for(int j(0); j<selectedTableList.count(); j++)
            {
                for(int i(0); i<strList.count(); i++)
                {
                    if(strList.at(i)==selectedTableList.at(j))
                        break;
                    else if (i==strList.count()-1)
                    {
                        obj = selectedTableList.at(j);
                        label = selectedTableList2.at(j);
                        selectedTableList=strList;
                        selectedTableList2=strList2;
                        spectrumView3D->highlightSelection(obj, label,true, ui->view3DButton->isChecked());
                        return;
                    }
                }
            }
        }
        else //New selection
        {
            for(int i(0); i<strList.count(); i++)
            {
                for(int j(0); j<selectedTableList.count(); j++)
                {
                    if(strList.at(i)==selectedTableList.at(j))
                        break;
                    else if (j==selectedTableList.count()-1)
                    {
                        obj = strList.at(i);
                        label = strList2.at(i);
                        spectrumView3D->highlightSelection(obj, label,true, ui->view3DButton->isChecked());
                        selectedTableList=strList;
                        selectedTableList2=strList2;
                        return;
                    }
                }
            }
        }
    }
}

void workspace::deselectTable()
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    ui->peaklistTable->clearSelection();
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
}

void workspace::createUserPeak(QVector3D position, QString label)
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    storeState();
    ui->peaklistTable->insertRow(ui->peaklistTable->rowCount());
    if(label=="?" || label=="??")
        label=getNextLabelName(1);

    QTableWidgetItem *item0 = new QTableWidgetItem;
    item0->setText(label);
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 0, item0);
    QTableWidgetItem *item = new QTableWidgetItem;
    item->setText(QString::number(position.z()));
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 1, item);
    QTableWidgetItem *item1 = new QTableWidgetItem;
    item1->setText(QString::number(position.x()));
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 2, item1);
    QTableWidgetItem *item2 = new QTableWidgetItem;
    if(label!="??")
        item2->setText(QString::number(position.y()));
    else
    {
        // x==1H, z==15N
        float diff(9.9e99);
        QPoint closestPoint(0,0);
        for(int k(0); k<spectrumView3D->spectrum_renderPlotProxy->rowCount(); k++)
            for(int j(0); j<spectrumView3D->spectrum_renderPlotProxy->columnCount(); j++)
            {
                float val(qSqrt(qPow(position.x()-spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x(),2) + qPow(position.z() - spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().z(),2)));
                if(diff > val)
                {
                    diff = val;
                    closestPoint = QPoint(k,j);
                }
            }
        item2->setText(QString::number(spectrumView3D->spectrum_renderPlotProxy->itemAt(closestPoint)->y()));
    }
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 3, item2);
    QTableWidgetItem *item3 = new QTableWidgetItem;
    item3->setText(QString::number(peakId++));
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 4, item3);
    QTableWidgetItem *item4 = new QTableWidgetItem;
    item4->setText("0");
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 5, item4);
    QTableWidgetItem *item5 = new QTableWidgetItem;
    item5->setText("0");
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 6, item5);
    QTableWidgetItem *item6 = new QTableWidgetItem;
    item6->setText("0");
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 7, item6);
    QTableWidgetItem *item7 = new QTableWidgetItem;
    item7->setText("0");
    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 8, item7);
    contourPlot->removeMarker();
    ui->peaklistTable->scrollToBottom();
    createPeakLabels(ui->peaklistTable->rowCount()-1);
    readContourPeaklist(ui->peaklistTable->rowCount()-1);
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    QApplication::processEvents();
    ui->peaklistTable->item(ui->peaklistTable->rowCount()-1, 0)->setSelected(true);
}
void workspace::deleteUserPeak()
{
    if(spectrumView3D->moveModeEnabled)
        return;
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    spectrumView3D->clearSelectedItems();
    spectrumView3D->selectionVector.clear();
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        if(ui->peaklistTable->item(i,0)->isSelected() || ui->peaklistTable->item(i,1)->isSelected() || ui->peaklistTable->item(i,2)->isSelected() || ui->peaklistTable->item(i,3)->isSelected())
        {
            spectrumView3D->deleteFromSelectionVector("peak" + ui->peaklistTable->item(i,4)->text());
            spectrumView3D->removeCustomLabel(ui->peaklistTable->item(i,4)->text().toInt());
            contourPlot->deletePeak(ui->peaklistTable->item(i,4)->text());
            ui->peaklistTable->removeRow(i);
            i--;
        }
    }
    ui->peaklistTable->clearSelection();
    storeState();
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
}

void workspace::deleteFromPeaklist()
{
    //Check if QTableItem is selected
    //delete button has been pressed
    if(ui->workspaceTab->currentIndex()==1 && ui->peaklistTable->selectedItems().count()>0 && spectrumView3D->peakIsSelected)
    {
        spectrumView3D->deleteUserPeak();
        readContourPeaklist(0);
    }
}

foldedClass workspace::isPeakFolded(QString f1, QString f2)
{
    foldedClass fold;
    fold.foldedF1=0;
    fold.foldedF2=0;
    fold.foldedF1val=0.0;
    fold.foldedF2val=0.0;
    bool ok;
    bool loop(true);
    float _f1(f1.toFloat(&ok));
    if(!ok)
        return fold;
    float _f2(f2.toFloat(&ok));
    if(!ok)
        return fold;
    while(loop)
    {
        loop = false;
        if(_f1 < minF1)
        {
            loop = true;
            fold.foldedF1--;
            fold.foldedF1val = maxF1-minF1+_f1;
            _f1 = fold.foldedF1val;
        }
        else if(_f1 > maxF1)
        {
            loop = true;
            fold.foldedF1++;
            fold.foldedF1val = _f1-maxF1+minF1;
            _f1 = fold.foldedF1val;
        }
        if(_f2 < minF2)
        {
            loop = true;
            fold.foldedF2--;
            fold.foldedF2val = maxF2-minF2+_f2;
            _f2 = fold.foldedF2val;
        }
        else if(_f2 > maxF2)
        {
            loop = true;
            fold.foldedF2++;
            fold.foldedF2val = _f2-maxF2+minF2;
            _f2 = fold.foldedF2val;
        }
    }
    return fold;
}

void workspace::foldPeak()
{
    if(ui->workspaceTab->currentIndex()!=1)
        return;
    if(spectrumView3D->moveModeEnabled || contourPlot->moveModeEnabled)
    {
        spectrumView3D->exitMoveMode();
        contourPlot->exitMoveMode();
    }
    if(spectrumView3D->spectrum_graph->seriesList().count()>0 && spectrumView3D->peakIsSelected && !spectrumView3D->moveModeEnabled)
    {
        foldDialog fDialog;
        fDialog.setWindowModality(Qt::ApplicationModal);
        if(fDialog.exec() && (fDialog.foldF1!=0 || fDialog.foldF2!=0))
        {
            QVector<int> selVec;
            for(int i(0); i<ui->peaklistTable->rowCount(); i++)
            {
                if(ui->peaklistTable->item(i,0)->isSelected() || ui->peaklistTable->item(i,1)->isSelected() || ui->peaklistTable->item(i,2)->isSelected() || ui->peaklistTable->item(i,3)->isSelected())
                    selVec.push_back(i);
            }
            disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
            disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
            disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
            spectrumView3D->clearSelectedItems();
            spectrumView3D->selectionVector.clear();
            ui->peaklistTable->clearSelection();
            for(int i(0); i<selVec.size(); i++)
            {
                spectrumView3D->deleteFromSelectionVector("peak" + ui->peaklistTable->item(selVec[i],4)->text());
                spectrumView3D->removeCustomLabel(ui->peaklistTable->item(selVec[i],4)->text().toInt());
                ui->peaklistTable->item(selVec[i],1)->setText(QString::number(ui->peaklistTable->item(selVec[i],1)->text().toDouble()+fDialog.foldF1*(maxF1-minF1)));
                ui->peaklistTable->item(selVec[i],2)->setText(QString::number(ui->peaklistTable->item(selVec[i],2)->text().toDouble()+fDialog.foldF2*(maxF2-minF2)));

                foldedClass fold(isPeakFolded(ui->peaklistTable->item(selVec[i],1)->text(),ui->peaklistTable->item(selVec[i],2)->text()));
                ui->peaklistTable->item(selVec[i],5)->setText(QString::number(fold.foldedF1));
                ui->peaklistTable->item(selVec[i],6)->setText(QString::number(fold.foldedF2));
                ui->peaklistTable->item(selVec[i],7)->setText(QString::number(fold.foldedF1val));
                ui->peaklistTable->item(selVec[i],8)->setText(QString::number(fold.foldedF2val));
                QApplication::processEvents();
                bool folded(false);
                double f1(ui->peaklistTable->item(selVec[i],1)->text().toDouble());
                double f2(ui->peaklistTable->item(selVec[i],2)->text().toDouble());
                if(ui->peaklistTable->item(selVec[i],5)->text().toInt()!=0)
                {
                    f1 = ui->peaklistTable->item(selVec[i],7)->text().toDouble();
                    folded = true;
                }
                if(ui->peaklistTable->item(selVec[i],6)->text().toInt()!=0)
                {
                    f2 = ui->peaklistTable->item(selVec[i],8)->text().toDouble();
                    folded = true;
                }
                spectrumView3D->addCustomLabel(ui->peaklistTable->item(selVec[i],0)->text(),QVector3D(f2,ui->peaklistTable->item(selVec[i],3)->text().toDouble(),f1), ui->peaklistTable->item(selVec[i],4)->text().toDouble(), folded);
            }
            storeState();
            connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
            connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
            connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
        }
        spectrumView3D->ctrlPressed = false;
        syncCtrl(false);
        contourPlot->ctrlDepressed(false);
    }
}

QVector<QString> workspace::moveToLocalMax(QVector3D shifts)
{
    QVector<QString> retVec(2,"none");
    double thresholdF1(0.05*(spectrumView3D->maxF1 - spectrumView3D->minF1));
    double thresholdF2(0.05*(spectrumView3D->maxF2 - spectrumView3D->minF2));
    QVector<QVector<QVector3D> >vec;
    for(int k(0); k<spectrumView3D->spectrum_renderPlotProxy->rowCount(); k++)
    {
        QVector<QVector3D> row;
        for(int j(0); j<spectrumView3D->spectrum_renderPlotProxy->columnCount(); j++)
        {
            if(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x()<shifts.y()+thresholdF1 && spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x()>shifts.y()-thresholdF1
                    && spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().z()<shifts.x()+thresholdF2 && spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().z()>shifts.x()-thresholdF2) //z
                row.push_back(QVector3D(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().z(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()));
        }
        if(row.size()>0)
            vec.push_back(row);
    }
    if(vec.size()==0)
        return retVec;

    QVector<QVector<float> > fVec(vec.size(), QVector<float>(vec.at(0).size(),0.0));
    for(int i(0); i<vec.size(); i++)
    {
        for(int j(0); j<vec.at(i).size(); j++)
        {
            if(j>0) //Above data point
            {
                if(qSqrt(qPow(vec.at(i).at(j).z(),2))<qSqrt(qPow(vec.at(i).at(j-1).z(),2)))
                    continue;
                if(i>0) //left of datapoint
                {
                    if(qSqrt(qPow(vec.at(i).at(j).z(),2))<qSqrt(qPow(vec.at(i-1).at(j-1).z(),2)))
                        continue;
                }
                if(i<vec.size()-1) //right of datapoint
                {
                    if(qSqrt(qPow(vec.at(i).at(j).z(),2))<qSqrt(qPow(vec.at(i+1).at(j-1).z(),2)))
                        continue;
                }
            }
            if(j<vec.at(i).size()) //Below data point
            {
                if(qSqrt(qPow(vec.at(i).at(j).z(),2))<qSqrt(qPow(vec.at(i).at(j+1).z(),2)))
                    continue;
                if(i>0) //left of datapoint
                {
                    if(qSqrt(qPow(vec.at(i).at(j).z(),2))<qSqrt(qPow(vec.at(i-1).at(j+1).z(),2)))
                        continue;
                }
                if(i<vec.size()-1) //right of datapoint
                {
                    if(qSqrt(qPow(vec.at(i).at(j).z(),2))<qSqrt(qPow(vec.at(i+1).at(j+1).z(),2)))
                        continue;
                }
            }
            if(i>0) //left of datapoint
            {
                if(qSqrt(qPow(vec.at(i).at(j).z(),2))<qSqrt(qPow(vec.at(i-1).at(j).z(),2)))
                    continue;
            }
            if(i<vec.size()-1) //right of datapoint
            {
                if(qSqrt(qPow(vec.at(i).at(j).z(),2))<qSqrt(qPow(vec.at(i+1).at(j).z(),2)))
                    continue;
            }
            fVec[i][j] = 1.0;
        }
    }
    QPoint closestPoint(0,0);
    QPoint closestPoint2(-10000,-10000);
    double diff2(9.9e99);
    double redThresholdF1(thresholdF1/10.0);
    double redThresholdF2(thresholdF2/10.0);
    bool added(false);
    for(int i(0); i<fVec.size();i++)
    {
        for(int j(0); j<fVec.at(i).size();j++)
        {
            if(fVec.at(i).at(j)==1.0)
            {
                double val2(qSqrt(qPow((shifts.x()-vec.at(i).at(j).x())*redThresholdF1/(redThresholdF1+redThresholdF2),2) + qPow((shifts.y() - vec.at(i).at(j).y())*redThresholdF2/(redThresholdF1+redThresholdF2),2)));
                if(diff2 > val2 && (2*sdev < vec.at(i).at(j).z() || -2*sdev > vec.at(i).at(j).z()))
                {
                    diff2 = val2;
                    closestPoint2 = QPoint(i,j);
                }
            }
        }
    }
    if(added)
    {
        retVec[0] = QString::number(vec.at(closestPoint.x()).at(closestPoint.y()).x());
        retVec[1] = QString::number(vec.at(closestPoint.x()).at(closestPoint.y()).y());
    }
    else if(QPoint(-10000,-10000)!=closestPoint2)
    {
        retVec[0] = QString::number(vec.at(closestPoint2.x()).at(closestPoint2.y()).x());
        retVec[1] = QString::number(vec.at(closestPoint2.x()).at(closestPoint2.y()).y());
    }
    else
    {
        retVec[0] = "none";
        retVec[1] = "none";
        return retVec;
    }
    return retVec;
}

void workspace::centerPeaks()
{
    if(centerPeakMode || contourPlot->moveModeEnabled || spectrumView3D->moveModeEnabled)
        return;
    storeState();
    centerPeakMode = true;
    abortCP = false;
    extern bool cancelVar;
    cancelVar = false;
    if(spectrumView3D->spectrum_graph->seriesList().count()>0 && spectrumView3D->peakIsSelected && !spectrumView3D->moveModeEnabled)
    {
        QFileInfo check_file(pintTemplate.projectDirectory);
        if(!check_file.exists())
        {
            QDir dir;
            dir = pintTemplate.projectDirectory;
            if(!dir.exists())
                dir.mkpath(pintTemplate.projectDirectory); //Create projectDirectory and parent dirs
        }
        QFile peaklist(pintTemplate.centerPeakList);
        if(!peaklist.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QMessageBox::StandardButton dlg;
            dlg = QMessageBox::warning(this, "PINT", "PINT cannot write to the specified project directory. Ensure that the directory is not write protected and restart PINT.", QMessageBox::Ok);
            Q_UNUSED(dlg)
            centerPeakMode = false;
            return;
        }
        int peakCounter(0);
        QTextStream out2(&peaklist);
        for(int i(0); i<ui->peaklistTable->rowCount(); i++)
        {
            if(ui->peaklistTable->item(i,0)->isSelected() || ui->peaklistTable->item(i,1)->isSelected() || ui->peaklistTable->item(i,2)->isSelected() || ui->peaklistTable->item(i,3)->isSelected() || ui->peaklistTable->item(i,4)->isSelected())
            {
                if(ui->centerPeakModeBox->currentIndex()==0)
                {
                    float f1, f2;
                    bool ok(true);

                    if(ui->peaklistTable->item(i,7)->text()!="0")
                        f2 = ui->peaklistTable->item(i,7)->text().toFloat(&ok);
                    else
                        f2 = ui->peaklistTable->item(i,1)->text().toFloat(&ok);
                    if(!ok) continue;
                    if(ui->peaklistTable->item(i,8)->text()!="0")
                        f1 = ui->peaklistTable->item(i,8)->text().toFloat(&ok);
                    else
                        f1 = ui->peaklistTable->item(i,2)->text().toFloat(&ok);
                    if(!ok) continue;

                    QVector<QVector3D> maxVec;

                    for(int k(1); k<spectrumView3D->spectrum_renderPlotProxy->rowCount()-1; ++k)
                    {
                        for(int j(1); j<spectrumView3D->spectrum_renderPlotProxy->columnCount()-1; ++j)
                        {
                            if(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y() > sdev*4 &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j+1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j-1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j+1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j-1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j-1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j+1)->position().y())
                                maxVec.push_back(QVector3D(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->x(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->y(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->z()));
                            else if(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y() < -sdev*4 &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j+1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j-1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j+1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j-1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j-1)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j)->position().y() &&
                                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j+1)->position().y())
                                maxVec.push_back(QVector3D(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->x(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->y(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->z()));
                        }
                    }
                    QVector<QVector<double>> closestPoint(10,QVector<double>(3));
                    for(int i(0); i<10; ++i)
                    {
                        closestPoint[i][0]=-1;
                        closestPoint[i][1]=9999;
                        closestPoint[i][2]=0.0;
                    }

                    for(int i(0); i<maxVec.size(); ++i)
                    {
                        float val(qSqrt(qPow(((float)maxVec.at(i).x()-f1)/(contourPlot->f2Max-contourPlot->f2Min),2) + qPow(((float)maxVec.at(i).z() - f2)/(contourPlot->f1Max-contourPlot->f1Min),2)));
                        for(int k(0); k<10; ++k)
                        {
                            if(val< (float)closestPoint[k][1])
                            {
                                for(int j(9); j>k; --j)
                                {
                                    closestPoint[j][0]=closestPoint[j-1][0];
                                    closestPoint[j][1]=closestPoint[j-1][1];
                                    closestPoint[j][2]=closestPoint[j-1][2];
                                }
                                closestPoint[k][0]=i;
                                closestPoint[k][1]=(double) val;
                                closestPoint[k][2]=fabs(maxVec.at(i).y());
                                break;
                            }
                        }
                    }
                    int closestPointInt(-1);
                    double optVal(9999);
                    for(int i(0); i<10; ++i)
                        if(closestPoint[i][0]!=-1)
                        {
                            if(closestPoint[i][1]/closestPoint[i][2]<optVal)
                            {
                                optVal = closestPoint[i][1]/closestPoint[i][2];
                                closestPointInt = closestPoint[i][0];
                            }
                        }
                    if(closestPointInt>=0)
                        out2<<"\n"<<ui->peaklistTable->item(i,0)->text()<<" "<<QString::number(maxVec.at(closestPointInt).z())<<" "<<QString::number(maxVec.at(closestPointInt).x());
                    else
                        out2<<"\n"<<ui->peaklistTable->item(i,0)->text()<<" "<<QString::number(f2)<<" "<<QString::number(f1);
                }
                else
                {

                    if(ui->peaklistTable->item(i,3)->text().toDouble() > sdev*2 || ui->peaklistTable->item(i,3)->text().toDouble() < sdev*2)
                    {
                        bool ok,ok2;
                        double f1(ui->peaklistTable->item(i,1)->text().toDouble(&ok));
                        double f2(ui->peaklistTable->item(i,2)->text().toDouble(&ok2));
                        if(!ok || !ok2)
                        {
                            centerPeakMode = false;
                            return;
                        }
                        if(ui->peaklistTable->item(i,5)->text().toInt()!=0)
                            f1 = ui->peaklistTable->item(i,7)->text().toDouble();
                        if(ui->peaklistTable->item(i,6)->text().toInt()!=0)
                            f2 = ui->peaklistTable->item(i,8)->text().toDouble();
                        out2<<"\n"<<ui->peaklistTable->item(i,0)->text()<<" "<<QString::number(f1)<<" "<<QString::number(f2);
                    }
                    else
                    {
                        bool ok,ok2;
                        double f1(ui->peaklistTable->item(i,1)->text().toDouble(&ok));
                        double f2(ui->peaklistTable->item(i,2)->text().toDouble(&ok2));
                        if(!ok || !ok2)
                        {
                            centerPeakMode = false;
                            return;
                        }
                        if(ui->peaklistTable->item(i,5)->text().toInt()!=0)
                            f1 = ui->peaklistTable->item(i,7)->text().toDouble();
                        if(ui->peaklistTable->item(i,6)->text().toInt()!=0)
                            f2 = ui->peaklistTable->item(i,8)->text().toDouble();
                        QVector<QString> shifts(moveToLocalMax(QVector3D(f1, f2, ui->peaklistTable->item(i,3)->text().toDouble())));
                        if(shifts.at(0)!= "none" && shifts.at(1)!="none")
                            out2<<"\n"<<ui->peaklistTable->item(i,0)->text()<<" "<<shifts.at(0)<<" "<<shifts.at(1);
                        else
                        {
                            displayInformation("Peak centering failed. Could not find a local maximum/minimum above/below noise level", true, 0);
                            centerPeakMode = false;
                            return;
                        }
                    }
                }
                peakCounter++;
            }
        }
        peaklist.close();
        if(peakCounter==0)
        {
            centerPeakMode = false;
            return;
        }

        QString fname(pintTemplate.peakCenterParamFile);
        QFile file(fname);
        if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QMessageBox::StandardButton dlg;
            dlg = QMessageBox::warning(this, "PINT", "PINT cannot write to the specified project directory. Ensure that the directory is not write protected and restart PINT.", QMessageBox::Ok);
            Q_UNUSED(dlg)
            centerPeakMode = false;
            return;
        }
        QTextStream out(&file);
        out<<"-spectrum ";
        out<<loadedSpectrum;
        out<<"\n-peaklist ";
        out<<pintTemplate.centerPeakList;
        out<<"\n-skipLines 1";
        out<<"\n-overlap auto";
        out<<"\n-maxMovement "<<0.1*(spectrumView3D->maxF1-spectrumView3D->minF1)<<" "<<0.10*(spectrumView3D->maxF2-spectrumView3D->minF2);
        if(ui->spectrumPlaneBox->isEnabled())
        {
            out<<"\n-excludePlanes";
            for(int i(0); i<ui->spectrumPlaneBox->maximum(); ++i)
                if(i+1!=ui->spectrumPlaneBox->value())
                    out<<" "<<i+1;
            if(ui->spectrumPlaneBox->value()>1)
                out<<"\n-plane2FitFirst 2";
        }
        file.close();
        QDir dir;
        dir = pintTemplate.tmpOutDirectory;
        if(!dir.exists())
            dir.mkpath(pintTemplate.tmpOutDirectory); //Create projectDirectory and parent dirs
        dir = pintTemplate.tmpPlotDirectory;
        if(!dir.exists())
            dir.mkpath(pintTemplate.tmpPlotDirectory); //Create projectDirectory and parent dirs
        displayInformation("Centering peaks. Press Esc to cancel.", false, 0);

        screenDialog *sDialog = new screenDialog();
        sDialog->setAttribute(Qt::WA_DeleteOnClose);
        disconnect(sDialog, SIGNAL(ctrl(bool)), this, SLOT(syncCtrl(bool)));
        connect(sDialog, SIGNAL(ctrl(bool)), this, SLOT(syncCtrl(bool)));
        disconnect(sDialog, SIGNAL(rejected()), this, SLOT(abortCenterPeaks()));
        connect(sDialog, SIGNAL(rejected()), this, SLOT(abortCenterPeaks()));
        disconnect(this, SIGNAL(closeScreenDialog()), sDialog, SLOT(accept()));
        connect(this, SIGNAL(closeScreenDialog()), sDialog, SLOT(accept()));
        sDialog->setWindowModality(Qt::ApplicationModal);
        sDialog->setStyleSheet("background:transparent;");
        sDialog->setAttribute(Qt::WA_TranslucentBackground);
        sDialog->setWindowFlags(Qt::FramelessWindowHint);
        sDialog->show();
        quitIntegration = false;
        int a = runPint(pintTemplate.peakCenterParamFile.toStdString(), pintTemplate.tmpOutDirectory.toStdString(), pintTemplate.tmpPlotDirectory.toStdString(), false);
        if(a == 1) //Error
        {
            emit closeScreenDialog();
            contourPlot->ctrlDepressed(false);
            centerPeakMode = false;
            removeDir(pintTemplate.tmpOutDirectory);
            removeDir(pintTemplate.tmpPlotDirectory);
        }
        if(fileExists(pintTemplate.centerPeakList))
            QFile::remove(pintTemplate.centerPeakList);
        if(fileExists(pintTemplate.peakCenterParamFile))
            QFile::remove(pintTemplate.peakCenterParamFile);

    }
    else
        centerPeakMode=false;
}

void workspace::abortCenterPeaks()
{
    abortCP = true;
    extern bool cancelVar;
    cancelVar = true;
}

void workspace::centerPeakEvaluate()
{
    if(abortCP){centerPeakMode=false; contourPlot->ctrlDepressed(false); displayInformation("Aborted peak centering.",true,0); return;}
    disableInformation();
    QString fname=pintTemplate.tmpOutDirectory + "/peaklist.txt";
    QFile file(fname);
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        fname=pintTemplate.tmpOutDirectory + "/error.txt";
        QFile file2(fname);
        if(file2.exists())
            displayInformation("Peak centering did not converge.",true,0);
        removeDir(pintTemplate.tmpOutDirectory);
        removeDir(pintTemplate.tmpPlotDirectory);
        centerPeakMode = false;
        if(!abortCP)
        {
            emit closeScreenDialog();
        }
        contourPlot->ctrlDepressed(false);
        return;
    }
    QTextStream in(&file);
    QString line = in.readLine();
    line = in.readLine();
    while(!line.isNull())
    {
        istringstream iss(line.toStdString().c_str());
        string sub;
        QString peakName, F1, F2;
        iss >> sub;
        peakName = QString::fromStdString(sub.c_str());
        iss >> sub;
        F1 = QString::number(QString::fromStdString(sub.c_str()).toDouble());
        iss >> sub;
        F2 = QString::number(QString::fromStdString(sub.c_str()).toDouble());
        for(int i(0); i<ui->peaklistTable->rowCount(); i++)
        {
            if(ui->peaklistTable->item(i,0)->text()==peakName)
            {
                disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
                disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
                disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
                centeringPeak=true;
                if(ui->peaklistTable->item(i,5)->text().toInt()!=0)
                {
                    ui->peaklistTable->item(i,7)->setText(F1);
                    F1 = QString::number((maxF1-minF1)*ui->peaklistTable->item(i,5)->text().toInt() + F1.toDouble());
                }
                if(ui->peaklistTable->item(i,6)->text().toInt()!=0)
                {
                    ui->peaklistTable->item(i,8)->setText(F2);
                    F2 = QString::number((maxF2-minF2)*ui->peaklistTable->item(i,6)->text().toInt() + F2.toDouble());
                }
                ui->peaklistTable->item(i,1)->setText(F1);
                ui->peaklistTable->item(i,2)->setText(F2);
                float diff(9.9e99);
                QPoint closestPoint(0,0);
                for(int k(0); k<spectrumView3D->spectrum_renderPlotProxy->rowCount(); k++)
                    for(int j(0); j<spectrumView3D->spectrum_renderPlotProxy->columnCount(); j++)
                    {
                        float val(qSqrt(qPow(F2.toDouble()-spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x(),2) + qPow(F1.toDouble() - spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().z(),2)));
                        if(diff > val)
                        {
                            diff = val;
                            closestPoint = QPoint(k,j);
                        }
                    }
                ui->peaklistTable->item(i,3)->setText(QString::number(spectrumView3D->spectrum_renderPlotProxy->itemAt(closestPoint)->y()));

                updatePeakLabels(i,-1);
                centeringPeak=false;
            }
        }
        line = in.readLine();
    }
    file.close();
    storeState();
    ui->peaklistTable->clearSelection();
    spectrumView3D->peakIsSelected=false;
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    removeDir(pintTemplate.tmpOutDirectory);
    removeDir(pintTemplate.tmpPlotDirectory);
    centerPeakMode = false;
    if(!abortCP)
    {
        emit closeScreenDialog();
    }
    contourPlot->ctrlDepressed(false);
}

bool workspace::removeDir(const QString & dirName)
{
    bool result = true;
    QDir dir(dirName);

    if (dir.exists(dirName))
    {
        Q_FOREACH(QFileInfo info, dir.entryInfoList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden  | QDir::AllDirs | QDir::Files, QDir::DirsFirst))
        {
            if (info.isDir())
                result = removeDir(info.absoluteFilePath());
            else
                result = QFile::remove(info.absoluteFilePath());
            if (!result)
                return result;
        }
        result = dir.rmdir(dirName);
    }
    return result;
}

void workspace::readAutoOverlaps()
{
    QFile file(pintTemplate.outDirectory+"/overlap.txt");
    if(!file.exists())
        return;
    if(file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QString currentText(paramEdit->toPlainText());
        QStringList lines = currentText.split("\n");
        paramEdit->clear();
        for(int i(0); i<lines.count(); i++)
        {
            string str(lines.at(i).toStdString());
            istringstream iss(str);
            string sub;
            bool add(true);
            while(iss >> sub)
            {
                toUpper(sub);
                if(sub=="OVERLAP" || sub=="-OVERLAP")
                {
                    add = false;
                    break;
                }
            }
            if(add)
                paramEdit->append(lines.at(i));
        }
        QTextStream in(&file);
        paramEdit->append(in.readAll());
        file.close();
    }
}

//mtpint.cpp code integrated into GUI version below
int workspace::runPint(string paramFile, string outDir, string plotDir, bool integrationMode)
{
    ui->integrationBrowser->clear();
    integration = integrationMode;
    //verb =Verbose();
    error_msg = VecString();
    VecString info_msg;
    peak = PeakListType();
    static string progname = (string)"MTPINT (Multithreaded Peak INTegration) v. " + (string)PINT_VERSION;
    parser = ParserType(paramFile, outDir, progname);
    parser.pipeData = pintTemplate.pipeData;
    parser.parse(error_msg);
    if(ui->peaklistDefineBox->currentIndex()!=0 && !centerPeakMode)
    {
        parser.skipLines = peaklistFormat.at(0);
        parser.assiCol = peaklistFormat.at(1)-1;
        parser.F1Col = peaklistFormat.at(2)-1;
        parser.F2Col = peaklistFormat.at(3)-1;
    }
    //parser.indError = true;
    if(quitIntegration && integrationMode)
    {
        iDialog->reject();
        if(integrationMode)
        {
            ui->warningIntegrationLabel->setMovie(movie2);
            movie2->start();
        }
        lockUI(true);
        return 1;
    }
    else if(abortCP){centerPeakMode=false; contourPlot->ctrlDepressed(false); displayInformation("Aborted peak centering.",true,0); return 0;}
    spec = SpectrumType(parser.specName, (Doub) sdev);
    spec.getCalib(error_msg, pintTemplate.pipeData);
    esd = EsdType(outDir);
    output = OutputType(outDir, parser, spec);
    if(quitIntegration && integrationMode)
    {
        iDialog->reject();
        if(integrationMode)
        {
            ui->warningIntegrationLabel->setMovie(movie2);
            movie2->start();
        }
        lockUI(true);
        return 1;
    }
    else if(abortCP){centerPeakMode=false; contourPlot->ctrlDepressed(false); displayInformation("Aborted peak centering.",true,0); return 0;}

    // Read peaks from peak lists and intensities from spectrum/spectra
    // ----------------------------------------------------------------
    peakFit.clear();
    plot = PlotType(plotDir, parser.plotMode);
    if (!parser.noIntegration)
    {
        bool lshape_ePlane_OK = true; // no conflicts for lineshapes and excluded planes in overlapped groups if true
        Uint nerror = error_msg.size();
        readPeaks(peak, parser, spec, error_msg);
        if (peak.size() == 0)
            error_msg.push_back("ERROR: Empty peak list!");
        if (parser.peak.fitR1rho)
            readR1List(parser.r1List, peak, error_msg);
        if (parser.autoOverLap)
        {
            bool overload = false;
            autoOverLapPeaks(peak, parser.group, outDir, error_msg, overload);
            if(integrationMode)
                readAutoOverlaps();
            if(overload && !centerPeakMode)
            {
                if (error_msg.size() > 0) {
                    sort(error_msg.begin(), error_msg.end());
                    error_msg.erase( unique( error_msg.begin(), error_msg.end() ), error_msg.end() );
                    for (Uint i=0; i<error_msg.size(); i++)
                    {
                        QString qMsg(QString::fromStdString(error_msg[i].c_str())+"\n");
                        if(ui->workspaceTab->currentIndex()==2)
                            ui->integrationBrowser->append(qMsg);
                        else if(ui->workspaceTab->currentIndex()==1)
                            displayInformation(qMsg.trimmed(), true, 0);
                    }
                    if(integrationMode)
                    {
                        disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegrationPrep()));
                        iDialog->reject();
                        ui->warningIntegrationLabel->setMovie(movie2);
                        movie2->start();
                    }
                    lockUI(true);
                    return 1;
                }
            }
        }
        else {
            checkPeaks(peak, parser.group, error_msg);
            fillInGroups(peak, parser.group, error_msg);
        }

        if(quitIntegration && integrationMode)
        {
            iDialog->reject();
            ui->warningIntegrationLabel->setMovie(movie2);
            movie2->start();
            lockUI(true);
            return 1;
        }
        else if(abortCP){centerPeakMode=false; contourPlot->ctrlDepressed(false); displayInformation("Aborted peak centering.",true,0); return 0;}
        lshape_ePlane_OK = (lshape_ePlane_OK && (nerror == error_msg.size())); // no conflicts for lineshapes and excluded planes in overlapped groups if true
        spec.checkSpecData(peak, error_msg);

        bool maxDataOK = lshape_ePlane_OK;

        if(spec.calib_OK && peak.size()>0)
        {
            for(auto &_peak : peak)
            {
                if(!_peak.readFlag)
                {
                    PeakListType peakToFit;
                    getPeaksToFit(_peak, parser.group, peakToFit);
                    maxDataOK = maxDataOK && !spec.checkMaxData(peakToFit, parser.maxdata, error_msg);
                }
            }
        }

        if(!maxDataOK && centerPeakMode)
        {
            displayInformation("Peak centering failed. Could not find a local maximum/minimum above/below noise level", true, 0);
            centerPeakMode = false;
            contourPlot->ctrlDepressed(false);
            return 0;
        }

        if (spec.calib_OK && peak.size()>0 && maxDataOK && !error_msg.size())
        {
            /* WORKING ORIGINAL CODE
            for (Uint i=0; i<peak.size() && spec.calib_OK; i++)
            {
                if(integrationMode)
                    iDialog->updateProgress((int)(100*i/peak.size()));
                if(quitIntegration && integrationMode)
                {
                    iDialog->reject();
                    if(integrationMode)
                    {
                        ui->warningIntegrationLabel->setMovie(movie2);
                        movie2->start();
                    }
                    lockUI(true);
                    return 1;
                }
                else if(abortCP){centerPeakMode=false; contourPlot->ctrlDepressed(false); displayInformation("Aborted peak centering.",true,0); return 0;}
                QApplication::processEvents();
                if (!peak[i].readFlag) {

                    PeakListType peakToFit;
                    Int BJ=0;
                    VecDoub f1,f2, y, sig, yopt;
                    VecInt f3;
                    getPeaksToFit(peak[i], parser.group, peakToFit);
                    spec.readData(peakToFit, f1, f2, f3, y, sig, yopt, BJ, parser.maxdata, error_msg, pintTemplate.pipeData);

                    PeakFitType pf(peakToFit, f1, f2, f3, y, sig, yopt, BJ, outDir, plotDir, \
                                   spec, parser, error_msg);
                    if(f1.size()==0 || f2.size() ==0)
                    {
                        string str;
                        for (Uint i=0; i<pf.peak.size(); i++)
                            str+=pf.peak[i].assi + " ";
                        stringstream conv;
                        conv << pf.peak.size();
                        str+="(" + conv.str() + ")\t";
                        str+= "FAIL! Radius is too small. No datapoints could be imported.";
                        error_msg.push_back(str);
                    }
                    pf.initFitPar(yopt);

                    // Only add relevant groups
                    if (std::find_if(peakFit.begin(), peakFit.end(), [&](PeakFitType &pfit){return pfit.peak[0].assi==pf.peak[0].assi;}) == peakFit.end())
                        peakFit.push_back(pf);
                    // mark peaks in peaklist as read if they are present in peakToFit in order not to fit them twice
                    for (auto &_pk : peak)
                        _pk.readFlag = (std::find_if(peakToFit.begin(), peakToFit.end(), [&](PeakType &p){return p.assi==_pk.assi;}) != peakToFit.end());
                }
            }
            //OLD CODE
            */

            // NEW CODE
            vector<PeakListType> peakToFit;
            vector<PeakFitType> peakFit2;
            vector<Int> sz;
            VecInt imin, jmin, imax, jmax;
            vector<VecInt> iopt, jopt;
            vector<Int> sizecounter;
            vector<Int> nArrReal;
            bool tooLarge = false;
            VecInt realCnt;
            bool stopProcessing(false);
            for (Uint i=0; i<peak.size() && spec.calib_OK; ++i)
            {
                if (!peak[i].readFlag) {
                    peakToFit.push_back(PeakListType());
                    getPeaksToFit(peak[i], parser.group, peakToFit[i]);
                    Int BJ=0;
                    VecDoub f1,f2, y, sig, yopt;
                    VecInt f3;
                    PeakFitType pf(peakToFit[i], f1, f2, f3, y, sig, yopt, BJ, outDir, plotDir,spec, parser, error_msg);
                    peakFit2.push_back(pf);
                    sz.push_back(0);
                    imin.push_back(0);
                    jmin.push_back(0);
                    imax.push_back(0);
                    jmax.push_back(0);
                    iopt.push_back(VecInt(pf.peak.size()));
                    jopt.push_back(VecInt(pf.peak.size()));
                    realCnt.push_back(0);
                    nArrReal.push_back((Int)(pf.peak[0].arr.size() - pf.peak[0].excludePlane.size()));
                    spec.getRegionOL(peakFit2.back().peak, imin.back(), imax.back(), jmin.back(), jmax.back(), iopt.back(), jopt.back());
                    sizecounter.push_back(spec.getDataSize(peakFit2.back().peak, imin.back(), imax.back(), jmin.back(), jmax.back(), nArrReal.back()));
                    if (spec.checkDataSize(peakFit2.back().peak, sizecounter.back(), parser.maxdata, error_msg))
                        tooLarge = true; // must return if datasize too big
                    else
                    {
                        allocateMyVectors(peakFit2.back().yopt, peakFit2.back().f1, peakFit2.back().f2,
                                          peakFit2.back().f3, peakFit2.back().y, peakFit2.back().sig,
                                          peakFit2.back().peak.size()*nArrReal.back(), sizecounter.back());
                        sizecounter.back() = 0;
                    }
                }
            }
            bool isBigEndian(true);
            union
            {
                uint32_t i;
                char c[4];
            } bigint = {0x01020304};

            if(bigint.c[0] != 1)
                isBigEndian=false;
            int endian(-1);
            int endianStart(3);
            if(isBigEndian) // Big endian byte ordering
            {
                endian = 1;
                endianStart = 0;
            }
            for(Uint i(0); i<spec.specName.size(); ++i)
            {
                if(stopProcessing) break;
                if(tooLarge) break;
                int val(1);
                if(spec.nDim==3)
                    val = spec.nPlane;

                for(int i2(0); i2<val; ++i2)
                {
                    if(spec.nDim==2 ||spec.nDim==3)
                    {
                        VecDoub _y = VecDoub(spec.sizeF1*spec.sizeF2,0);
                        VecDoub _F1= VecDoub(spec.sizeF1*spec.sizeF2,0);
                        VecDoub _F2= VecDoub(spec.sizeF1*spec.sizeF2,0);
                        Doub noise(1.0);
                        if(pintTemplate.pipeData) //NMRPipe
                        {
                            Doub mean, ndata=0., sum=0., sqSum=0., ndataPrev = spec.sizeF1*spec.sizeF2;
                            QFile fp(QString::fromStdString(spec.specName[i].c_str()));
                            if(!fp.open(QIODevice::ReadOnly))
                            {
                                stopProcessing = true;
                                break;
                            }
                            const int page_size = spec.sizeF1*spec.sizeF2*sizeof(float);
                            long off(0);
                            off=2048; //skip header
                            off+=i2*spec.sizeF1*spec.sizeF2*sizeof(float); //skip plane
                            int cc(0);
                            bool calcNoise(true);
                            uchar *memory = fp.map(off,page_size);
                            if(memory)
                            {
                                for (int ii(0); ii<spec.sizeF1; ii++)
                                {
                                    for (int jj(0); jj<spec.sizeF2; jj++)
                                    {
                                        int u(ii*spec.sizeF2*sizeof(float)+jj*sizeof(float));
                                        union test
                                        {
                                            unsigned char buf[4];
                                            float number;
                                        }tt;
                                        tt.buf[endianStart]= memory[u+3];
                                        tt.buf[endianStart+endian]= memory[u+2];
                                        tt.buf[endianStart+2*endian]= memory[u+1];
                                        tt.buf[endianStart+3*endian]= memory[u];
                                        _y[cc] = (Doub) tt.number;
                                        _F1[cc] = (Doub)(spec.firstF1 + (ii)*spec.deltaF1)/spec.obsF1;
                                        _F2[cc] = (Doub)(spec.firstF2 + (jj)*spec.deltaF2)/spec.obsF2;
                                        ++cc;
                                        if(calcNoise)
                                        {
                                            sum+= (Doub) tt.number;
                                            sqSum+= (Doub)(tt.number*tt.number);
                                            ++ndata;
                                        }
                                    }
                                }
                                if(calcNoise)
                                {
                                    mean = sum/ndata;
                                    noise =  sqrt(1.0/(ndata-1.0)*(sqSum-sum*sum/ndata));
                                    for(;;)
                                    {
                                        ndata=0.; sum=0.; sqSum=0.;
                                        for (Int ii=0; ii<spec.sizeF1*spec.sizeF2; ++ii)
                                            if (fabs(_y[ii]) < mean + 3.0*noise)
                                            {
                                                sum+= _y[ii];
                                                sqSum+= _y[ii]*_y[ii];
                                                ++ndata;
                                            }
                                        mean = sum/ndata;
                                        noise =  sqrt(1.0/(ndata-1.0)*(sqSum-sum*sum/ndata));

                                        if (ndata == ndataPrev)
                                            break;
                                        ndataPrev = ndata;
                                    }
                                    calcNoise = false;
                                }
                                fp.unmap(memory);
                            }

                            fp.close();
                        }
                        else // TopSpin
                        {
                            Doub mean, ndata=0., sum=0., sqSum=0., ndataPrev = spec.sizeF1*spec.sizeF2;
                            QString ext("/2rr");
                            if(nDim==3)
                                ext="/3rrr";
                            QFile fp(QString::fromStdString(spec.specName[i].c_str())+ext);
                            if(!fp.open(QIODevice::ReadOnly))
                            {
                                stopProcessing = true;
                                break;
                            }

                            int a;
                            int submatrixF1 = spec.sizeF1/spec.xDimF1;
                            int submatrixF2 = spec.sizeF2/spec.xDimF2;

                            const int page_size = spec.xDimF1*spec.xDimF2*spec.xDimF3*sizeof(int);
                            long off(0);
                            off= page_size*submatrixF2*submatrixF1 *(int)(floor)((i2-1)/spec.xDimF3); //Skip submatrix in F3 if needed
                            off+=sizeof(int)*spec.xDimF2*spec.xDimF1*(i2-1-spec.xDimF3*(int)(floor)((i2-1)/spec.xDimF3)); //Skip planes in submatrix if needed
                            vector<double> tmp_y = vector<double>(spec.sizeF1*spec.sizeF2);
                            int cc(0);
                            while(off<fp.size())
                            {
                                uchar *memory = fp.map(off,page_size);
                                if(memory)
                                {
                                    for(ulong ii(endianStart); ii<spec.xDimF1*spec.xDimF2*sizeof(int);ii+=4)
                                    {
                                        a = memory[ii];
                                        a = a*256 + memory[ii+endian];
                                        a = a*256 + memory[ii+2*endian];
                                        a = a*256 + memory[ii+3*endian];
                                        a = (int)((double) a * (double)pow(2,spec.nc_proc)+0.5f); //Compensate for the 2^N Bruker scaling factor
                                        tmp_y[cc++] = a;
                                    }
                                    fp.unmap(memory);
                                }
                                off+=page_size;
                                if(cc==(int)tmp_y.size())
                                    break;
                            }
                            fp.close();
                            int countingF2(0);
                            cc=0;
                            for(ulong ii(0); ii<tmp_y.size(); ++ii)
                            {
                                int v = ii + (spec.xDimF2*spec.xDimF1-spec.xDimF2)*(int)((floor)((double)((double)ii/(double)spec.xDimF2)))
                                        + (spec.xDimF2-submatrixF2*spec.xDimF1*spec.xDimF2)*(int)((floor)((double)((double)ii/(double)spec.sizeF2)))
                                        + ((submatrixF2-1)*spec.xDimF1*spec.xDimF2)*(int)((floor)((double)((double)ii/(double)(spec.sizeF2*spec.xDimF1))));

                                _y[cc] = (Doub) tmp_y[v];
                                _F1[cc] = (spec.firstF1 + ((int)(floor)(ii/spec.sizeF2))*spec.deltaF1)/spec.obsF1;
                                _F2[cc] = (spec.firstF2 + (ii-spec.sizeF2*(int)(floor)(ii/spec.sizeF2))*spec.deltaF2)/spec.obsF2;
                                ++countingF2;
                                ++cc;
                                if(countingF2==spec.sizeF2)
                                {
                                    i+=spec.sizeF2-countingF2;
                                    countingF2=0;
                                }
                            }
                            for(int ii(0); ii<spec.sizeF1*spec.sizeF2;++ii)
                            {
                                sum+= _y[ii];
                                sqSum+= (Doub)(_y[ii]*_y[ii]);
                                ++ndata;
                            }
                            mean = sum/ndata;
                            noise =  sqrt(1.0/(ndata-1.0)*(sqSum-sum*sum/ndata));
                            for(;;)
                            {
                                ndata=0.; sum=0.; sqSum=0.;
                                for (Int ii=0; ii<spec.sizeF1*spec.sizeF2; ++ii)
                                    if (fabs(_y[ii]) < mean + 3.0*noise)
                                    {
                                        sum+= _y[ii];
                                        sqSum+= _y[ii]*_y[ii];
                                        ++ndata;
                                    }
                                mean = sum/ndata;
                                noise =  sqrt(1.0/(ndata-1.0)*(sqSum-sum*sum/ndata));

                                if (ndata == ndataPrev)
                                    break;
                                ndataPrev = ndata;
                            }
                        }
                        if(!tooLarge)
                        {
                            for(Uint j(0); j<peakFit2.size(); ++j)
                            {
                                ++realCnt[j];
                                Bool flag = false;
                                for (Uint k=0; k<peakFit2[j].peak[0].excludePlane.size(); ++k)
                                {
                                    if (i2+i+1 == (Uint)peakFit2[j].peak[0].excludePlane[k])
                                    {
                                        --realCnt[j];
                                        flag = true;
                                        break;
                                    }
                                }
                                if (flag)
                                    continue;
                                //READ DATA

                                for (Int ii=imin[j]; ii<imax[j]; ++ii)
                                {
                                    for (Int jj=jmin[j]; jj<jmax[j]; ++jj)
                                    {
                                        int u(ii*spec.sizeF2 + jj);
                                        for (Uint kk=0; kk<peakFit2[j].peak.size(); ++kk)
                                            if (ii == iopt[j][kk] && jj == jopt[j][kk])
                                                peakFit2[j].yopt[kk*nArrReal[j]+realCnt[j]-1] = _y[u];
                                        for (Uint kk=0; kk<peakFit2[j].peak.size(); ++kk)
                                        {
                                            Doub radius = sqrt(SQR((_F1[u]-peakFit2[j].peak[kk].appF1)/peakToFit[j][kk].radF1) + SQR((_F2[u]-peakFit2[j].peak[kk].appF2)/peakFit2[j].peak[kk].radF2));
                                            if (radius <= 1.0)
                                            {
                                                peakFit2[j].f1[sz[j]] = _F1[u];
                                                peakFit2[j].f2[sz[j]] = _F2[u];
                                                peakFit2[j].f3[sz[j]] = realCnt[j];
                                                peakFit2[j].y[sz[j]] = _y[u];
                                                peakFit2[j].sig[sz[j]] = ((peakFit2[j].peak[kk].centerWt - 1.)*radius + 1.)*noise;
                                                ++sz[j];
                                                break;
                                            }
                                        }
                                    }
                                }
                                if(peakFit2[j].f1.size()==0 || peakFit2[j].f2.size()==0)
                                {
                                    string str;
                                    for (Uint j2=0; j2<peakFit2[j].peak.size(); ++j2)
                                        str+=peakFit2[j].peak[j2].assi + " ";
                                    stringstream conv;
                                    conv << peakFit2[j].peak.size();
                                    str+="(" + conv.str() + ")\t";
                                    str+= "FAIL! Radius is too small. No datapoints could be imported.";
                                    error_msg.push_back(str);
                                }
                                peakFit2[j].BigJ = jmax[j] - jmin[j] + 1;
                                if(integrationMode)
                                {
                                    double val2((double)((double)(j+1)/((double)val*(double)peakFit2.size()*(double)spec.specName.size())));
                                    iDialog->updateProgress((int)100*(val2+((double)i2+(double)i)/((double)val*(double)spec.specName.size())));
                                }
                                if(quitIntegration && integrationMode)
                                {
                                    iDialog->reject();
                                    if(integrationMode)
                                    {
                                        ui->warningIntegrationLabel->setMovie(movie2);
                                        movie2->start();
                                    }
                                    lockUI(true);
                                    return 1;
                                }
                                else if(abortCP){centerPeakMode=false; contourPlot->ctrlDepressed(false); displayInformation("Aborted peak centering.",true,0); return 0;}
                                QApplication::processEvents();
                            }
                        }
                        else
                            break;
                        if(integrationMode)
                            iDialog->updateProgress((int)100*(((double)i2+(double)i+1.0)/((double)val*(double)spec.specName.size())));
                    }
                }
            }
            for(Uint i3(0); i3<peakFit2.size(); ++i3)
            {
                peakFit2[i3].initFitPar(peakFit2[i3].yopt);
                if (std::find_if(peakFit.begin(), peakFit.end(), [&](PeakFitType &pfit){return pfit.peak[0].assi==peakFit2[i3].peak[0].assi;}) == peakFit.end())
                    peakFit.push_back(peakFit2[i3]);
                for (auto &_pk : peak)
                    _pk.readFlag = (std::find_if(peakFit2[i3].peak.begin(), peakFit2[i3].peak.end(), [&](PeakType &p){return p.assi==_pk.assi;}) != peakFit2[i3].peak.end());
            }
        }
    }
    if(integrationMode)
        iDialog->updateProgress(100);
    // report info messages and errors. quit if errors
    // ----------------------------------------------
    if (info_msg.size() > 0) {
        sort(info_msg.begin(), info_msg.end());
        info_msg.erase( unique( info_msg.begin(), info_msg.end() ), info_msg.end() );
        for (Uint i=0; i<info_msg.size(); i++)
        {
            QString qMsg(QString::fromStdString(info_msg[i].c_str())+"\n");
            ui->integrationBrowser->append(qMsg);
        }
    }
    if (error_msg.size() > 0) {
        sort(error_msg.begin(), error_msg.end());
        error_msg.erase( unique( error_msg.begin(), error_msg.end() ), error_msg.end() );
        for (Uint i=0; i<error_msg.size(); i++)
        {
            QString qMsg(QString::fromStdString(error_msg[i].c_str())+"\n");
            if(ui->workspaceTab->currentIndex()==2)
                ui->integrationBrowser->append(qMsg);
            else if(ui->workspaceTab->currentIndex()==1)
                displayInformation(qMsg.trimmed(), true, 0);
        }
        if(integrationMode)
        {
            disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegrationPrep()));
            iDialog->reject();
            ui->warningIntegrationLabel->setMovie(movie2);
            movie2->start();
        }
        lockUI(true);
        return 1;
    }

    if (!parser.noIntegration) {
        clearDir(pintTemplate.outDirectory);
        clearDir(pintTemplate.plotDirectory);
        //QtThreads
        if(integrationMode)
        {
            iDialog->updateTimer->stop();
            int sec(iDialog->progressTimer.elapsed()/1000);
            totalSec = sec;
            int min(0);
            while(sec>59)
            {
                min++;
                sec-=60;
            }
            QString msg("Preparation has completed successfully.\tElapsed time: %1 min, %2 sec");
            ui->integrationBrowser->append(msg.arg(QString::number(min)).arg(QString::number(sec)));
            disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegrationPrep()));
            iDialog->reject();
            iDialog = new integrationStatusDialog();
            //ui->paramLayout->addWidget(iDialog,0,1,Qt::AlignRight);
            ui->paramLayout->addWidget(iDialog);
            //iDialog->setWindowModality(Qt::ApplicationModal);
            disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegration()));
            connect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegration()));
            disconnect(iDialog, SIGNAL(rejected()), iDialog, SLOT(deleteLater()));
            connect(iDialog, SIGNAL(rejected()), iDialog, SLOT(deleteLater()));
            iDialog->show();
            QString str("Integrating 0/");
            str+=QString::number(peakFit.size());
            iDialog->updateLabel(str);
            iDialog->updateProgress(0);
        }
        threadsCount = peakFit.size();
        threadsDone = 0;

        workerThreads = QVector<pintWorker*>();
        threadID=0;
        activeThreadID=0;
        for (Uint i=0; i<peakFit.size(); i++)
            workerThreads.push_back(new pintWorker(&peakFit[i],0,i));
        qApp->processEvents();
        if(integrationMode)
        {
            disconnect(ui->planeBox, SIGNAL(valueChanged(int)), this, SLOT(updatePlotFiles()));
            ui->planeBox->setValue(1);
        }
        for(int i(0); i<ui->threadsBox->value(); i++)
        {
            if(i<threadsCount)
                handleThreading();
        }
        //if(spec.nDim==3)
        if(integrationMode)
        {
            ui->planeBox->setMinimum(1);
            ui->planeBox->setMaximum(spec.nPlane);
            if(ui->planeBox->maximum()>1)
            {
                ui->planeBox->setEnabled(true);
                ui->allPlanesBox->setEnabled(true);
            }
            else
            {
                ui->allPlanesBox->setEnabled(false);
                ui->planeBox->setEnabled(false);
            }
            connect(ui->planeBox, SIGNAL(valueChanged(int)), this, SLOT(updatePlotFiles()));
        }
    }
    // no integration, only downstream fitting
    // ---------------------------------------
    else {

        listPeaks(peak, outDir, error_msg);

        for (Uint i=0; i<peak.size(); i++)
            peak[i].setFromParser(parser.peak, parser.OR, error_msg);

        if (parser.peak.fitR1rho)
            readR1List(parser.r1List, peak, error_msg);

        noIntWorker= new noIntWorkerThread(peak, 0, error_msg, output);
        iDialog->updateLabel("Fitting data.");
        iDialog->hideProgressBar();
        activeThreadID = 1;
        QThread* thread = new QThread();
        noIntWorker->moveToThread(thread);
        disconnect(thread);
        disconnect(noIntWorker);
        disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegrationPrep()));
        disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegration()));
        connect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegration()));
        connect(thread, SIGNAL(started()), noIntWorker, SLOT(process()));
        connect(noIntWorker, SIGNAL(finished()), this, SLOT(noIntegrationEvaluate()));
        connect(noIntWorker, SIGNAL(finished()), thread, SLOT(quit()));
        connect(noIntWorker, SIGNAL(finished()), this, SLOT(cleanUpThreadsCount()));
        connect(noIntWorker, SIGNAL(finished()), noIntWorker, SLOT(deleteLater()));
        connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
        thread->start();
        //output.printResult(peak, error_msg);
        //output.printLists(peak, error_msg);

    }
    return 0;
}
//mtpint.cpp code integrated into GUI version above

void workspace::noIntegrationEvaluate()
{
    if(quitIntegration)
    {
        lockUI(true);
        return;
    }

    defineOverlapForPlots();
    bool enableTab = updatePlotFiles();
    update2DPlotFiles();
    updateParameterTable();
    if(enableTab)
    {
        if(!errorIntegration)
            ui->workspaceTab->setTabIcon(3,QIcon(":img/3dFits_upd.png"));
        else
            ui->workspaceTab->setTabIcon(3,QIcon(":img/3dFits_upd_err.png"));
    }
    if(ui->fit2DList->count()>0)
        ui->workspaceTab->setTabIcon(4,QIcon(":img/2dFits_upd.png"));
    if(ui->parametersTable->rowCount()>0)
        ui->workspaceTab->setTabIcon(5,QIcon(":img/parameters_upd.png"));
    disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegration()));
    disconnect(iDialog, SIGNAL(rejected()), this, SLOT(abortIntegrationPrep()));
    iDialog->reject();
    saveProject();
    lockUI(true);
    QString fnam(pintTemplate.paramFile+".tmp");
    if (QFile::exists(fnam))
        QFile::remove(fnam);
}

void workspace::updateIntBrowser(QString str)
{
    if(quitIntegration)
    {
        lockUI(true);
        return;
    }
    else if(abortCP){centerPeakMode=false; contourPlot->ctrlDepressed(false); displayInformation("Aborted peak centering.",true,0); return;}
    qApp->processEvents();
    threadsDone++;
    handleThreading();
    if(integration)
    {
        if(str!="")
            ui->integrationBrowser->append(str);
        if(threadsDone!=threadsCount)
        {
            QString str2("Integrating: ");
            str2+=QString::number(threadsDone)+"/"+QString::number(threadsCount);
            iDialog->updateLabel(str2);
            iDialog->updateProgress((int)(100.0*(float)threadsDone/(float)threadsCount));
        }
        else
        {
            iDialog->updateProgress((int)(100.0*(float)threadsDone/(float)threadsCount));
            iDialog->updateLabel("Integration is done");
            iDialog->updateTimer->stop();
            int sec(iDialog->progressTimer.elapsed()/1000);
            sec+=totalSec;
            int min(0);
            while(sec>59)
            {
                min++;
                sec-=60;
            }
            QString msg("Integration has completed successfully.\tElapsed time: %1 min, %2 sec\n\nInput data for plotted decays can be found in the \"%3/\" directory.\nThe table values shown in the parameter tab can be found in \"%4/parameters.txt\".\nUpdated integration based chemical shifts can be found in \"%4/peaklist.txt\"");
            ui->integrationBrowser->append(msg.arg(QString::number(min)).arg(QString::number(sec)).arg(pintTemplate.outDirectory).arg(pintTemplate.outDirectory));
            if(quitIntegration)
            {
                lockUI(true);
                return;
            }
            //output.printResult(peak, error_msg);

            copyPeakFitListToPeakList(peak, peakFit);
            if(quitIntegration)
            {
                lockUI(true);
                return;
            }
            output.printLists(peak, error_msg);

            if(quitIntegration)
            {
                lockUI(true);
                return;
            }
            plot.writePlotSummary(peak, peakFit, parser.planeToPlot, error_msg);
            plot.writeIndividualPlotSummary(peak, peakFit, parser.planeToPlot, error_msg);
            defineOverlapForPlots();
            bool enableTab = updatePlotFiles();
            update2DPlotFiles();
            updateParameterTable();
            //if(ui->plotList->rowCount()>0)
            if(enableTab)
            {
                if(!errorIntegration)
                    ui->workspaceTab->setTabIcon(3,QIcon(":img/3dFits_upd.png"));
                //else
                //  ui->workspaceTab->setTabIcon(3,QIcon(":img/3dFits_upd_err.png"));
            }
            if(ui->fit2DList->count()>0)
                ui->workspaceTab->setTabIcon(4,QIcon(":img/2dFits_upd.png"));
            if(ui->parametersTable->rowCount()>0)
                ui->workspaceTab->setTabIcon(5,QIcon(":img/parameters_upd.png"));
            iDialog->accept();
            iDialog->deleteLater();
            saveProject();
            lockUI(true);
            QString fnam(pintTemplate.paramFile+".tmp");
            if (QFile::exists(fnam))
                QFile::remove(fnam);
        }
    }
    else if(threadsDone==threadsCount)
    {
        //Center peak mode
        /*
        if (!parser.indError) {
            for (Uint i=0; i<peakFit.size(); i++) {
                peakFit[i].makeFinalParam(peak);
                //peakFit[i].makeFinalParam(peakFit[i].convFlag, spec, peak, peakFit[i].f1.size(), peakFit[i].a);
            }
            esd.calcEsd(peak);
        }
        // generate summaries for the case of -indError
        else {
        */
        copyPeakFitListToPeakList(peak, peakFit);
        //}
        output.printLists(peak, error_msg);

        // write gnuplot files
        //verb.PlotESDPre();
        plot.writePlotSummary(peak, peakFit, parser.planeToPlot,error_msg);
        plot.writeIndividualPlotSummary(peak, peakFit, parser.planeToPlot,error_msg);
        //verb.PlotESDPost();
        centerPeakEvaluate();
        QString fnam(pintTemplate.paramFile+".tmp");
        if (QFile::exists(fnam))
            QFile::remove(fnam);
    }
}

void workspace::handleThreadingPlotFile()
{
    if(threadID<vecPFW.size())
    {
        QThread* thread = new QThread();
        vecPFW[threadID]->moveToThread(thread);
        disconnect(thread);
        disconnect(vecPFW[threadID]);
        connect(thread, SIGNAL(started()), vecPFW[threadID], SLOT(process()));
        connect(vecPFW[threadID], SIGNAL(finished(QStringList)), this, SLOT(updatePlotFilesEval(QStringList)));
        connect(vecPFW[threadID], SIGNAL(finished(QStringList)), thread, SLOT(quit()));
        connect(vecPFW[threadID], SIGNAL(finished(QStringList)), vecPFW[threadID], SLOT(deleteLater()));
        connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
        thread->start();
        threadID++;
    }
}

void workspace::handleThreading()
{
    if(threadID<workerThreads.size())
    {
        if(quitIntegration)
        {
            ui->workspaceTab->setTabEnabled(0, true);
            ui->workspaceTab->setTabEnabled(1, true);
            ui->integrateButton->setEnabled(true);
            return;
        }
        else if(abortCP){centerPeakMode=false; contourPlot->ctrlDepressed(false); displayInformation("Aborted peak centering.",true,0); return;}
        if(!centerPeakMode)
        {
            QString msg("");
            for(ulong i(0); i<workerThreads[threadID]->p->peak.size(); ++i)
                msg+=QString::fromStdString(workerThreads[threadID]->p->peak.at(i).assi.c_str()) + " ";
            iDialog->updateProgressString(msg);
        }
        QThread* thread = new QThread();
        workerThreads[threadID]->moveToThread(thread);
        disconnect(thread);
        disconnect(workerThreads[threadID]);
        //qRegisterMetaType<PeakFitType>("PeakFitType");
        connect(thread, SIGNAL(started()), workerThreads[threadID], SLOT(process()));
        if(!centerPeakMode)
            connect(workerThreads[threadID], SIGNAL(removeString(QString)), iDialog, SLOT(removeProgressString(QString)));
        connect(workerThreads[threadID], SIGNAL(finished(QString)), this, SLOT(cleanUpThreadsCount()));
        connect(workerThreads[threadID], SIGNAL(finished(QString)), this, SLOT(updateIntBrowser(QString)));

        connect(workerThreads[threadID], SIGNAL(finished(QString)), thread, SLOT(quit()));
        connect(workerThreads[threadID], SIGNAL(finished(QString)), workerThreads[threadID], SLOT(deleteLater()));
        connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
        thread->start();
        threadID++;
        activeThreadID++;
    }
}

void workspace::cleanUpThreadsCount()
{
    activeThreadID--;
    if(activeThreadID==0 && quitIntegration)
        ui->integrationBrowser->append("Clean-up complete. A new integration may be performed now.");
}

bool workspace::updatePlotFiles()
{
    disconnect(ui->planeBox, SIGNAL(valueChanged(int)), this, SLOT(updatePlotFiles()));
    if(ui->planeToPlotBox->isChecked())
        connect(ui->planeBox, SIGNAL(valueChanged(int)), this, SLOT(updatePlotFiles()));
    screenDialog *sDialog = new screenDialog();
    sDialog->setAttribute(Qt::WA_DeleteOnClose);
    disconnect(sDialog, SIGNAL(ctrl(bool)), this, SLOT(syncCtrl(bool)));
    connect(sDialog, SIGNAL(ctrl(bool)), this, SLOT(syncCtrl(bool)));
    disconnect(this, SIGNAL(closeScreenDialog()), sDialog, SLOT(reject()));
    connect(this, SIGNAL(closeScreenDialog()), sDialog, SLOT(reject()));
    sDialog->setWindowModality(Qt::ApplicationModal);
    sDialog->setStyleSheet("background:transparent;");
    sDialog->setAttribute(Qt::WA_TranslucentBackground);
    sDialog->setWindowFlags(Qt::FramelessWindowHint);
    sDialog->show();
    qApp->processEvents();
    ui->plotList->disconnect();
    ui->plotList->clearSelection();
    ui->plotList->clearContents();
    ui->plotList->setRowCount(0);
    errorIntegration = false;
    QDir recordedDir(pintTemplate.plotDirectory);
    QStringList tmp= recordedDir.entryList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden  | QDir::AllDirs | QDir::Files, QDir::DirsFirst);
    QStringList files;
    for(int u(0); u<tmp.count(); u++)
    {
        bool add(false);
        if(tmp.at(u).length()>4)
        {
            for(int s(0); s<tmp.at(u).length()-2;s++)
            {
                if(tmp.at(u)[s]=='i' && tmp.at(u)[s+1]=='n' && tmp.at(u)[s+2]=='d')
                    break;
                else if(tmp.at(u)[s]=='g' && tmp.at(u)[s+1]=='n' && tmp.at(u)[s+2]=='u')
                    break;
                else if(s==tmp.at(u).length()-3)
                    add=true;
            }
        }
        if(add)
        {
            if(ui->planeToPlotBox->isChecked())
            {
                QString plane(QString::number(ui->planeBox->value()));
                if(!ui->planeBox->isEnabled())
                    plane ="1";
                QString number("_");
                if(ui->planeBox->value()<10)
                    number+="00"+plane;
                else if(ui->planeBox->value()<100)
                    number+="0"+plane;
                else
                    number+=plane;
                number+=".dat";
                QString name(tmp.at(u));
                if(name.length()>number.length())
                {
                    if(equal(number.rbegin(), number.rend(), name.rbegin()))
                        files<<tmp.at(u);
                }
            }
            else
            {
                QString ext(".dat");
                QString name(tmp.at(u));
                if(name.length()>ext.length())
                {
                    if(equal(ext.rbegin(), ext.rend(), name.rbegin()))
                        files<<tmp.at(u);
                }
            }
        }
    }
    files=sortList(files);

    ui->plotList->setRowCount(files.count());
    if(files.count()>0)
    {
        threadsCount = files.count();
        vecPFW = QVector<plotFileWorker*>();
        activeThreadID=0;
        threadID=0;
        threadsDone = 0;
        for(int i(0); i<files.count(); ++i)
        {
            QTableWidgetItem *item = new QTableWidgetItem(files.at(i));
            item->setFlags(item->flags() ^ Qt::ItemIsEditable);
            ui->plotList->setItem(i,0,item);

            workerPlot = new plotFileWorker(0, files.at(i), i, pintTemplate.plotDirectory);
            vecPFW.push_back(workerPlot);
        }
        for(int i(0); i<ui->threadsBox->value(); i++)
        {
            if(i<threadsCount)
                handleThreadingPlotFile();
        }
        return true;
    }
    else
    {
        ui->plotList->setHorizontalHeaderItem(0, new QTableWidgetItem("Peaks"));
        ui->plotList->setHorizontalHeaderItem(1, new QTableWidgetItem("Quality"));
        ui->plotList->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        ui->plotList->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Interactive);
        ui->plotList->setColumnWidth(1,60);
        if(priorSelection!="" && ui->plotList->rowCount()>0)
        {
            ui->workspaceTab->setTabEnabled(3,true);
            bool ok(false);
            for(int j(0); j<ui->plotList->rowCount(); j++)
            {
                if(priorSelection==ui->plotList->item(j,0)->text())
                {
                    ui->plotList->setCurrentCell(j,0);
                    viewPlot(j);
                    ok=true;
                    break;
                }
            }
            if(!ok)
            {
                ui->plotList->setCurrentCell(0,0);
                viewPlot(0);
            }
        }
        else if(ui->plotList->rowCount()>0)
        {
            ui->plotList->setCurrentCell(0,0);
            ui->workspaceTab->setTabEnabled(3,true);
            viewPlot(0);
        }
        else if(ui->plotList->rowCount()==0 && ui->planeBox->maximum()==1)
            ui->workspaceTab->setTabEnabled(3,false);
        else
            ui->workspaceTab->setTabEnabled(3,true);
        QObject::disconnect(ui->plotList, SIGNAL(currentCellChanged(int,int,int,int)), this, SLOT(clickToPlot()));
        QObject::connect(ui->plotList, SIGNAL(currentCellChanged(int,int,int,int)), this, SLOT(clickToPlot()));

        //errorcheck
        QString fname(pintTemplate.outDirectory+"/error.txt");
        QFile file(fname);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            emit closeScreenDialog();
            return true;
        }
        QTextStream in(&file);
        QString line = in.readLine();
        QStringList list;
        while(!line.isNull())
        {
            if(line[0]!='#' && line!="")
            {
                istringstream iss(line.toStdString().c_str());
                string sub;
                iss >> sub;
                list << QString::fromUtf8(sub.c_str());
            }
            line = in.readLine();
        }
        file.close();
        for(int j(0); j<ui->plotList->rowCount(); j++)
        {
            bool okPeak(true);
            for(int i(0); i<list.size(); i++)
            {
                QString cmp(list.at(i)+"_");
                if(cmp.length()<ui->plotList->item(j,0)->text().length())
                {
                    if(equal(cmp.begin(), cmp.end(), ui->plotList->item(j,0)->text().begin()))
                    {
                        ui->plotList->item(j,0)->setBackgroundColor(Qt::red);
                        ui->plotList->item(j,0)->setTextColor(Qt::white);
                        ui->plotList->item(j,1)->setTextColor(Qt::white);
                        ui->plotList->item(j,1)->setBackgroundColor(Qt::red);
                        ui->plotList->item(j,1)->setText("FAILED");
                        errorIntegration = true;
                        okPeak=false;
                        break;
                    }
                }
            }
            if(okPeak)
            {
                ui->plotList->item(j,0)->setBackgroundColor(Qt::white);
                ui->plotList->item(j,0)->setTextColor(Qt::black);
            }
        }
        emit closeScreenDialog();

        return true;
    }
}

void workspace::updatePlotFilesEval(QStringList strList)
{
    threadsDone++;
    handleThreadingPlotFile();
    if(strList.count()!=2)return;
    QTableWidgetItem *item2 = new QTableWidgetItem (strList.at(0));
    item2->setFlags(item2->flags() ^ Qt::ItemIsEditable);
    ui->plotList->setItem(strList.at(1).toInt(),1,item2);

    if(threadsDone==threadsCount)
    {
        ui->plotList->setHorizontalHeaderItem(0, new QTableWidgetItem("Peaks"));
        ui->plotList->setHorizontalHeaderItem(1, new QTableWidgetItem("Quality"));
        ui->plotList->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        ui->plotList->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Interactive);
        ui->plotList->setColumnWidth(1,60);
        if(priorSelection!="" && ui->plotList->rowCount()>0)
        {
            ui->workspaceTab->setTabEnabled(3,true);
            bool ok(false);
            for(int j(0); j<ui->plotList->rowCount(); j++)
            {
                if(priorSelection==ui->plotList->item(j,0)->text())
                {
                    ui->plotList->setCurrentCell(j,0);
                    viewPlot(j);
                    ok=true;
                    break;
                }
            }
            if(!ok)
            {
                ui->plotList->setCurrentCell(0,0);
                viewPlot(0);
            }
        }
        else if(ui->plotList->rowCount()>0)
        {
            ui->plotList->setCurrentCell(0,0);
            ui->workspaceTab->setTabEnabled(3,true);
            viewPlot(0);
        }
        else if(ui->plotList->rowCount() == 0 && ui->planeBox->maximum()==1)
        {
            ui->workspaceTab->setTabEnabled(3,false);
        }
        QObject::disconnect(ui->plotList, SIGNAL(currentCellChanged(int,int,int,int)), this, SLOT(clickToPlot()));
        QObject::connect(ui->plotList, SIGNAL(currentCellChanged(int,int,int,int)), this, SLOT(clickToPlot()));

        //errorcheck
        QString fname(pintTemplate.outDirectory+"/error.txt");
        QFile file(fname);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            emit closeScreenDialog();
            return;
        }
        QTextStream in(&file);
        QString line = in.readLine();
        QStringList list;
        while(!line.isNull())
        {
            if(line[0]!='#' && line!="")
            {
                istringstream iss(line.toStdString().c_str());
                string sub;
                iss >> sub;
                list << QString::fromUtf8(sub.c_str());
            }
            line = in.readLine();
        }
        file.close();
        for(int j(0); j<ui->plotList->rowCount(); j++)
        {
            bool okPeak(true);
            for(int i(0); i<list.size(); i++)
            {
                QString cmp(list.at(i)+"_");
                if(cmp.length()<ui->plotList->item(j,0)->text().length())
                {
                    if(equal(cmp.begin(), cmp.end(), ui->plotList->item(j,0)->text().begin()))
                    {
                        ui->plotList->item(j,0)->setBackgroundColor(Qt::red);
                        ui->plotList->item(j,0)->setTextColor(Qt::white);
                        ui->plotList->item(j,1)->setTextColor(Qt::white);
                        ui->plotList->item(j,1)->setBackgroundColor(Qt::red);
                        ui->plotList->item(j,1)->setText("FAILED");
                        errorIntegration = true;
                        okPeak=false;
                        break;
                    }
                }
            }
            if(okPeak)
            {
                ui->plotList->item(j,0)->setBackgroundColor(Qt::white);
                ui->plotList->item(j,0)->setTextColor(Qt::black);
            }
        }
        if(errorIntegration)
            ui->workspaceTab->setTabIcon(3,QIcon(":img/3dFits_upd_err.png"));
        emit closeScreenDialog();

    }
}

void workspace::update2DPlotFiles()
{
    ui->fit2DList->clear();
    QDir recordedDir(pintTemplate.outDirectory);
    QStringList tmp= recordedDir.entryList(QDir::Files);
    QStringList files;
    for(int u(0); u<tmp.count(); u++)
    {
        bool add(false);
        if(tmp.at(u).length()>4)
        {
            for(int s(0); s<tmp.at(u).length()-2;s++)
            {
                if(tmp.at(u)[s]=='o' && tmp.at(u)[s+1]=='u' && tmp.at(u)[s+2]=='t')
                    break;
                else if(tmp.at(u)[s]=='t' && tmp.at(u)[s+1]=='x' && tmp.at(u)[s+2]=='t')
                    break;
                else if(tmp.at(u)[s]=='n' && tmp.at(u)[s+1]=='o' && tmp.at(u)[s+2]=='e')
                    break;
                else if(s==tmp.at(u).length()-3)
                    add=true;
            }
        }
        if(add)
            files<<tmp.at(u);
    }
    files=sortList(files);
    ui->fit2DList->addItems(files);
    if(priorSelection2D!="" && ui->fit2DList->count()>0)
    {
        ui->workspaceTab->setTabEnabled(4,true);
        bool ok(false);
        for(int j(0); j<ui->fit2DList->count(); j++)
        {
            if(priorSelection2D==ui->fit2DList->item(j)->text())
            {
                ok=true;
                ui->fit2DList->setCurrentRow(j);
                viewPlot2D(j);
                break;
            }
        }
        if(!ok)
        {
            ui->fit2DList->setCurrentRow(0);
            viewPlot2D(0);
        }
    }
    else if(ui->fit2DList->count()>0)
    {
        ui->workspaceTab->setTabEnabled(4,true);
        ui->fit2DList->setCurrentRow(0);
        viewPlot2D(0);
    }
    else
        ui->workspaceTab->setTabEnabled(4,false);
}

QStringList workspace::sortList(QStringList files)
{
    if(files.size()==0)
        return files;
    QVector<QString> orderVec;
    for(int i(0); i<files.size(); i++)
    {
        QString name(files.at(i));
        QString number("");
        for(int k(0); k<name.length(); k++)
        {
            QString str("");
            str+=name[k];
            if(checkLegal(str))
                number+=str;
            else if(number!="")
                break;
        }
        if(number=="")
            orderVec.push_back("nan");
        else
            orderVec.push_back(number);
    }
    for(int i(0); i<orderVec.size(); i++)
    {
        for(int j(i+1); j<orderVec.size(); j++)
        {
            if(orderVec[j]!="nan")
            {
                if(orderVec[i]!="nan")
                {
                    if(orderVec[j].toInt()<orderVec[i].toInt())
                    {
                        QString tmp(orderVec[i]);
                        orderVec[i]=orderVec[j];
                        orderVec[j]=tmp;

                        files.swap(i,j);
                    }
                }
                else
                {
                    QString tmp(orderVec[i]);
                    orderVec[i]=orderVec[j];
                    orderVec[j]=tmp;
                    files.swap(i,j);
                }
            }
        }
    }
    return files;
}

QChar workspace::checkLegalFileName(QString str)
{
    QString illegalChars(" /?<>\\:*|\".,^:;+()[]%¤#!@£$€{}'´`~¨");
    for(int l(0); l<str.length(); l++)
    {
        for(int m(0); m<illegalChars.length(); m++)
        {
            if(str[l]==illegalChars[m])
            {
                QChar chr(illegalChars[m]);
                return chr;
            }
        }
    }
    return '1';
}

bool workspace::checkLegal(QString str)
{
    QString legal("0123456789");
    for(int l(0); l<str.length(); l++)
    {
        for(int m(0); m<legal.length(); m++)
        {
            if(str[l]==legal[m])
                break;
            else if(m==legal.length()-1 && l==str.length()-1)
                return false;
        }
    }
    return true;
}

void workspace::saveProject()
{
    QDir dir;
    dir = pintTemplate.projectDirectory;
    if(!dir.exists())
        dir.mkpath(pintTemplate.projectDirectory);
    QFile file(pintTemplate.saveFile);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

    saveDialog *sdlg = new saveDialog();
    sdlg->setWindowModality(Qt::ApplicationModal);
    sdlg->setStyleSheet("background:transparent;");
    sdlg->setAttribute(Qt::WA_TranslucentBackground);
    sdlg->setAttribute(Qt::WA_DeleteOnClose);
    sdlg->setWindowFlags(Qt::FramelessWindowHint);
    sdlg->show();
    disconnect(sdlg, SIGNAL(accepted()), sdlg, SLOT(deleteLater()));
    connect(sdlg, SIGNAL(accepted()), sdlg, SLOT(deleteLater()));

    QApplication::processEvents();
    writeConnectedPeaklist();
    QTextStream out(&file);
    out <<"#projectName\n"<<pintTemplate.projectName;
    out <<"\n#saveFile\n"<<pintTemplate.saveFile;
    out <<"\n#projectRootDirectory\n"<<pintTemplate.projectRootDirectory;
    out <<"\n#projectDirectory\n"<<pintTemplate.projectDirectory;
    out <<"\n#pipeData\n"<<pintTemplate.pipeData;
    out <<"\n#paramFile\n"<<pintTemplate.paramFile;
    out <<"\n#outDirectory\n"<<pintTemplate.outDirectory;
    out <<"\n#tmpOutDirectory\n"<<pintTemplate.tmpOutDirectory;
    out <<"\n#plotDirectory\n"<<pintTemplate.plotDirectory;
    out <<"\n#tmpPlotDirectory\n"<<pintTemplate.tmpPlotDirectory;
    out <<"\n#peakCenterParamFile\n"<<pintTemplate.peakCenterParamFile;
    out <<"\n#integratePeakList\n"<<pintTemplate.integratePeakList;
    out <<"\n#centerPeakList\n"<<pintTemplate.centerPeakList;
    out <<"\n#currentPeakID\n"<<QString::number(peakId);
    if(pintTemplate.spectrumFiles.size() > 0)
    {
        out <<"\n#spectrumFiles";
        for(int i(0); i<pintTemplate.spectrumFiles.size(); i++)
            out <<"\n"<<pintTemplate.spectrumFiles.at(i);
    }
    if(pintTemplate.peaklistFiles.size() > 0)
    {
        out <<"\n#peaklistFiles";
        for(int i(0); i<pintTemplate.peaklistFiles.size(); i++)
            out <<"\n"<<pintTemplate.peaklistFiles.at(i);
    }
    if(pintTemplate.otherFiles.size() > 0)
    {
        out <<"\n#otherFiles";
        for(int i(0); i<pintTemplate.otherFiles.size(); i++)
            out <<"\n"<<pintTemplate.otherFiles.at(i);
    }
    out << "\n#planeFiles\n"<<QString::number(ui->planeBox->maximum());
    if(pintTemplate.pintPeaklists.size() > 0)
    {
        for(int i(0); i<pintTemplate.pintPeaklists.size(); i++)
        {
            out <<"\n#connectedSpectrum";
            out <<"\n"<<pintTemplate.pintPeaklists.at(i).spectrum;
            out <<"\n#connectedPeaklist";
            for(int j(0); j<pintTemplate.pintPeaklists.at(i).peaklist.size(); j++)
            {
                out<<"\n";
                for(int k(0); k<pintTemplate.pintPeaklists.at(i).peaklist.at(j).size(); k++)
                    out<<pintTemplate.pintPeaklists.at(i).peaklist.at(j).at(k)<<" ";
            }
            out <<"\n#connectedEnd";
        }
    }
    if(pintTemplate.overlapVec.size()>0)
    {
        out <<"\n#overlapVector";
        for(int i(0); i<pintTemplate.overlapVec.size(); i++)
        {
            out << "\n";
            for(int j(0); j<pintTemplate.overlapVec.at(i).size(); j++)
                out<<pintTemplate.overlapVec.at(i).at(j)<<" ";
        }
        out <<"\n#endOverlapVector";
    }
    out<<"\n#spD";
    out<<"\n"<<QString::number(ui->spectrumDefineBox->currentIndex());
    out<<"\n#peD";
    out<<"\n"<<QString::number(ui->peaklistDefineBox->currentIndex());
    out<<"\n#prD";
    out<<"\n"<<QString::number(ui->procparDefineBox->currentIndex());
    file.close();
}

QString workspace::getNextLabelName(int val)
{
    //Automatic numbering of new peaks
    bool ok(false);
    int autBase2(autBase);
    if(ui->peaklistTable->rowCount()<2)
    {
        autBase2+=autIncrement;
        return autPrefix + QString::number(autBase2) + autSuffix;
    }
    while(!ok)
    {
        autBase2+=autIncrement;
        ok = true;
        for(int i(0); i<ui->peaklistTable->rowCount()-val; ++i)
        {
            if(autPrefix + QString::number(autBase2) + autSuffix==ui->peaklistTable->item(i,0)->text())
            {
                ok = false;
                break;
            }
        }
    }
    return autPrefix + QString::number(autBase2) + autSuffix;
}

void workspace::editAutomaticLabelAppearance()
{
    automaticLabelFormat aDialog(0, autBase+autIncrement, autIncrement, autPrefix, autSuffix);
    aDialog.setWindowModality(Qt::ApplicationModal);
    if(aDialog.exec())
    {
        autBase = aDialog.autBase - aDialog.autIncrement;
        autIncrement = aDialog.autIncrement;
        autPrefix = aDialog.autPrefix;
        autSuffix = aDialog.autSuffix;
        QString fname(qApp->applicationDirPath() + "/defaultAutomaticLabelFormat.dat");
        QFile file(fname);
        if(file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QTextStream out(&file);
            out << QString::number(autBase)<<"\n"<<QString::number(autIncrement)<<"\n"<<autPrefix<<"\n"<<autSuffix;
            file.close();
        }
    }
}

void workspace::writeConnectedPeaklist()
{
    for(int i(0); i<pintTemplate.pintPeaklists.size(); i++)
    {
        if(pintTemplate.pintPeaklists.at(i).spectrum==loadedSpectrum)
        {
            pintTemplate.pintPeaklists.remove(i);
            peaklistClass newClass;
            newClass.spectrum = loadedSpectrum;
            for(int j(0); j<ui->peaklistTable->rowCount(); j++)
            {
                QVector<QString> tmp;
                for(int k(0); k<ui->peaklistTable->columnCount(); k++)
                    tmp.push_back(ui->peaklistTable->item(j,k)->text());
                newClass.peaklist.push_back(tmp);
            }
            pintTemplate.pintPeaklists.push_back(newClass);
            break;
        }
    }
}

void workspace::readConnectedPeaklist(int idx)
{
    for(int i(0); i<pintTemplate.pintPeaklists.at(idx).peaklist.size(); i++)
    {
        ui->peaklistTable->insertRow(ui->peaklistTable->rowCount());
        for(int j(0); j<pintTemplate.pintPeaklists.at(idx).peaklist.at(i).size(); j++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText(pintTemplate.pintPeaklists.at(idx).peaklist.at(i).at(j));
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,j,item);
        }
    }
    ui->peaklistTable->horizontalHeader()->setStretchLastSection(true);
    createPeakLabels(0);
    ui->peaklistTable->disconnect();
    spectrumView3D->disconnect();
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
}

void workspace::abortIntegration()
{
    quitIntegration=true;
    ui->integrationBrowser->clear();
    ui->integrationBrowser->setText("Integration aborted. Clean-up in progress.");
    ui->warningIntegrationLabel->setMovie(movie2);
    movie2->start();
    extern bool cancelVar;
    cancelVar = true;
}

void workspace::abortIntegrationPrep()
{
    quitIntegration=true;
    ui->integrationBrowser->clear();
    ui->integrationBrowser->setText("Integration aborted. Clean-up in progress.");
    ui->integrationBrowser->append("Clean-up complete. A new integration may be performed now.");
    ui->warningIntegrationLabel->setMovie(movie2);
    movie2->start();
    extern bool cancelVar;
    cancelVar = true;
}

void workspace::writeIntegratePeaklist()
{
    QFile peakList(pintTemplate.integratePeakList);
    if (!peakList.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream out(&peakList);
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        if(i>0)
            out<<"\n";
        out << ui->peaklistTable->item(i,0)->text()<<" "<<ui->peaklistTable->item(i,1)->text()<<" "<<ui->peaklistTable->item(i,2)->text();
    }
    peakList.close();
}

void workspace::addSpectrumToParamBrowser()
{
    QString currentText(paramEdit->toPlainText());
    QStringList lines = currentText.split("\n");
    paramEdit->clear();
    bool addOl(true);
    for(int i(0); i<lines.count(); i++)
    {
        string str(lines.at(i).toStdString());
        istringstream iss(str);
        string sub;
        bool add(true);
        while(iss >> sub)
        {
            toUpper(sub);
            if(sub=="OVERLAP" || sub=="-OVERLAP" || sub=="#OVERLAP" || sub=="#-OVERLAP")
            {
                addOl = false;
                break;
            }
        }
        if(add)
            paramEdit->append(lines.at(i));
    }
    if(addOl)
        paramEdit->append("overlap auto");

}


void workspace::on_planeToPlotBox_toggled(bool checked)
{
    if(checked && ui->planeBox->maximum()>1)
        ui->planeBox->setEnabled(true);
    else
        ui->planeBox->setDisabled(true);
    updatePlotFiles();
}

void workspace::defineOverlapForPlots()
{
    //Enable showing overlaps in plots by using defined or automated overlaps
    //and the integrated peaklist.txt
    QVector<QStringList> tmp;
    pintTemplate.overlapVec = tmp;
    QString fname(pintTemplate.outDirectory+"/overlap.txt");
    //QFile file2(fname);
    //if(!file2.exists())
    {
        //No overlap file, use browser
        QString currentText(paramEdit->toPlainText());
        QStringList lines = currentText.split("\n");
        for(int i(0); i<lines.count(); i++)
        {
            string str(lines.at(i).toStdString());
            istringstream iss(str);
            string sub;
            bool isOverlap(true);
            QStringList list;
            while(iss >> sub)
            {
                string tmpsub(sub);
                toUpper(sub);
                if(isOverlap && sub != "AUTO")
                    list << QString::fromStdString(tmpsub.c_str());
                else if(sub=="-OVERLAP")
                    isOverlap=true;
            }
            if(isOverlap)
                pintTemplate.overlapVec.push_back(list);
        }
        return;
    }
    QFile file(fname);
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        return;
    }
    QTextStream in(&file);
    QString line = in.readLine();
    while(!line.isNull())
    {
        if(line!="")
        {
            istringstream iss(line.toStdString().c_str());
            string sub;
            bool isOverlap(false);
            QStringList list;
            while(iss >> sub)
            {
                if(isOverlap && sub != "auto")
                    list << QString::fromStdString(sub.c_str());
                else if(sub=="-overlap")
                    isOverlap=true;
            }
            if(isOverlap)
                pintTemplate.overlapVec.push_back(list);
        }
        line = in.readLine();
    }
    file.close();
}

void workspace::setup2DFitWidget()
{
    ui->customPlotFit->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    ui->customPlotFit->setMinimumSize(0,0);
    ui->customPlotFit->setMinimumHeight(0);
    ui->customPlotFit->setMinimumWidth(0);
    fitStyle = QCPScatterStyle::ssDisc;
    fitDataColor = QColor(0,0,0);
    fitFitColor = QColor(0,0,0);

    QPalette pal;
    pal.setColor(QPalette::Window, QRgb(0x121218));
    pal.setColor(QPalette::WindowText, QRgb(0xd6d6d6));
    ui->customPlotFit->setPalette(pal);
    ui->customPlotFit->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

    titleQCustomPlotFit = new QCPPlotTitle(ui->customPlotFit,"");
    titleQCustomPlotFit->setFont(QFont("Myriad Pro", 16, QFont::Bold));
    ui->customPlotFit->plotLayout()->insertRow(0);
    ui->customPlotFit->plotLayout()->addElement(0,0, titleQCustomPlotFit);
    QCPDocumentObject *plotObjectHandler = new QCPDocumentObject(this);
    ui->saveFitEdit->document()->documentLayout()->registerHandler(QCPDocumentObject::PlotTextFormat, plotObjectHandler);
}

void workspace::setup2DPlotWidget()
{
    ui->customPlotPlot->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    ui->customPlotPlot->setMinimumSize(0,0);
    ui->customPlotPlot->setMinimumHeight(0);
    ui->customPlotPlot->setMinimumWidth(0);
    plotStyle = QCPScatterStyle::ssDisc;
    plotDataColor = QColor(0,0,0);

    QPalette pal;
    pal.setColor(QPalette::Window, QRgb(0x121218));
    pal.setColor(QPalette::WindowText, QRgb(0xd6d6d6));
    ui->customPlotPlot->setPalette(pal);
    ui->customPlotPlot->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
    currentPlotIndex = -1;

    titleQCustomPlotPlot= new QCPPlotTitle(ui->customPlotPlot,"");
    titleQCustomPlotPlot->setFont(QFont("Myriad Pro", 16, QFont::Bold));
    ui->customPlotPlot->plotLayout()->insertRow(0);
    ui->customPlotPlot->plotLayout()->addElement(0,0, titleQCustomPlotPlot);
    QCPDocumentObject *plotObjectHandler2 = new QCPDocumentObject(this);
    ui->savePlotEdit->document()->documentLayout()->registerHandler(QCPDocumentObject::PlotTextFormat, plotObjectHandler2);
}

void workspace::updateParameterTable()
{
    QApplication::processEvents();
    ui->parametersTable->clearSelection();
    ui->parametersTable->clearContents();
    ui->parametersTable->setRowCount(0);
    ui->parametersTable->setColumnCount(0);
    QFile file(pintTemplate.outDirectory+"/parameters.txt");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        ui->workspaceTab->setTabEnabled(5,false);
        return;
    }
    QStringList sList;
    sList << "Residue number";
    QTextStream in(&file);
    QString line = in.readLine();
    if(!line.isNull())
    {
        //Parse header
        sList += line.split(QRegExp("( )|(\t)"), QString::SkipEmptyParts);
        for(int i(0); i<sList.count(); i++)
            ui->parametersTable->insertColumn(i);
        line = in.readLine();
    }
    ui->parametersTable->setHorizontalHeaderLabels(sList);
    while(!line.isNull())
    {
        if(line!="")
        {
            QTableWidgetItem *item2 = new QTableWidgetItem();
            item2->setText("");
            item2->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled|Qt::ItemIsEditable);
            ui->parametersTable->insertRow(ui->parametersTable->rowCount());
            ui->parametersTable->setItem(ui->parametersTable->rowCount()-1, 0, item2);
            QStringList list = line.split(QRegExp("( )|(\t)"), QString::SkipEmptyParts);
            for(int i(0); i<list.size(); i++)
            {
                QTableWidgetItem *item = new QTableWidgetItem();
                item->setText(list.at(i));
                item->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEnabled);
                ui->parametersTable->setItem(ui->parametersTable->rowCount()-1, i+1, item);
            }
        }
        line = in.readLine();
    }
    file.close();
    preparePlotBoxes();
    generatePeakNumbers();
    ui->parametersTable->resizeColumnsToContents();
    if(ui->parametersTable->rowCount()>0)
        ui->workspaceTab->setTabEnabled(5,true);
    else
        ui->workspaceTab->setTabEnabled(5,false);
}

void workspace::generatePeakNumbers()
{
    //Attempt to generate residue numbers from peak names
    for(int i(0); i<ui->parametersTable->rowCount();i++)
    {
        QString peak(ui->parametersTable->item(i,1)->text());
        QString resNo("");
        bool added(false);
        for(int j(0); j<peak.length(); j++)
        {
            if(peak.at(j).isNumber())
            {
                resNo+=(QString)peak.at(j);
                added=true;
            }
            else if(added)
                break;
        }
        ui->parametersTable->item(i,0)->setText(resNo);
    }
}

void workspace::preparePlotBoxes()
{
    ui->valuePlotBox->clear();
    ui->errorPlotBox->clear();
    for(int i(2); i<ui->parametersTable->columnCount(); i++)
    {
        ui->valuePlotBox->addItem(ui->parametersTable->horizontalHeaderItem(i)->text());
        ui->errorPlotBox->addItem(ui->parametersTable->horizontalHeaderItem(i)->text());
    }
    if(ui->valuePlotBox->count()>0)
    {
        ui->valuePlotBox->setCurrentIndex(0);
        ui->errorPlotBox->setCurrentIndex(1);
    }
}

void workspace::toggleParameters()
{
    disconnect(ui->errorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters()));
    disconnect(ui->noErrorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters2()));
    if(ui->errorButton->isChecked())
    {
        ui->noErrorButton->setChecked(false);
        ui->errorPlotBox->setEnabled(true);
    }
    else
    {
        ui->noErrorButton->setChecked(true);
        ui->errorPlotBox->setDisabled(true);
    }
    connect(ui->errorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters()));
    connect(ui->noErrorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters2()));
}

void workspace::toggleParameters2()
{
    disconnect(ui->errorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters()));
    disconnect(ui->noErrorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters2()));
    if(ui->noErrorButton->isChecked())
    {
        ui->errorButton->setChecked(false);
        ui->errorPlotBox->setEnabled(false);
    }
    else
    {
        ui->errorButton->setChecked(true);
        ui->errorPlotBox->setEnabled(true);
    }
    connect(ui->errorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters()));
    connect(ui->noErrorButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters2()));
}

void workspace::toggleParameters3()
{
    disconnect(ui->selectionButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters3()));
    disconnect(ui->allButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters4()));
    if(ui->selectionButton->isChecked())
        ui->allButton->setChecked(false);
    else
        ui->allButton->setChecked(true);
    connect(ui->selectionButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters3()));
    connect(ui->allButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters4()));
}

void workspace::toggleParameters4()
{
    disconnect(ui->selectionButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters3()));
    disconnect(ui->allButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters4()));
    if(ui->allButton->isChecked())
        ui->selectionButton->setChecked(false);
    else
        ui->selectionButton->setChecked(true);
    connect(ui->selectionButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters3()));
    connect(ui->allButton, SIGNAL(toggled(bool)), this, SLOT(toggleParameters4()));
}

void workspace::on_plotManualButton_clicked()
{
    if(ui->valuePlotBox->count()>0 && ui->parametersTable->rowCount()>0)
    {
        QVector<QStringList> tmp;
        plot2DVec = tmp;
        if(ui->selectionButton->isChecked())
        {
            for(int i(0); i<ui->parametersTable->rowCount(); i++)
            {
                if(ui->parametersTable->item(i,0)->isSelected())
                {
                    bool ok(false);
                    ui->parametersTable->item(i,0)->text().toDouble(&ok);
                    if(ok)
                        break;
                }
                else if(i==ui->parametersTable->rowCount()-1)
                {
                    QMessageBox::StandardButton dlg;
                    dlg = QMessageBox::warning(this, "PINT", "No valid values selected in the \"Residue number\" column", QMessageBox::Ok);
                    if(dlg==QMessageBox::Ok)
                        return;
                }
            }
            for(int i(0); i<ui->parametersTable->rowCount(); i++)
            {
                if(ui->parametersTable->item(i,0)->isSelected())
                {
                    bool ok(false);
                    ui->parametersTable->item(i,0)->text().toDouble(&ok);
                    if(ok)
                    {
                        QStringList list;
                        list <<ui->parametersTable->item(i,0)->text();
                        list <<ui->parametersTable->item(i,ui->valuePlotBox->currentIndex()+2)->text();
                        if(ui->errorButton->isChecked())
                            list <<ui->parametersTable->item(i,ui->errorPlotBox->currentIndex()+2)->text();
                        plot2DVec.push_back(list);
                    }
                }
            }
        }
        else
        {
            for(int i(0); i<ui->parametersTable->rowCount(); i++)
            {
                bool ok(false);
                ui->parametersTable->item(i,0)->text().toDouble(&ok);
                if(ok)
                    break;
                else if(i==ui->parametersTable->rowCount()-1)
                {
                    QMessageBox::StandardButton dlg;
                    dlg = QMessageBox::warning(this, "PINT", "No valid values available in the \"Residue number\" column", QMessageBox::Ok);
                    if(dlg==QMessageBox::Ok)
                        return;
                }
            }
            for(int i(0); i<ui->parametersTable->rowCount(); i++)
            {
                bool ok(false);
                ui->parametersTable->item(i,0)->text().toDouble(&ok);
                if(ok)
                {
                    QStringList list;
                    list <<ui->parametersTable->item(i,0)->text();
                    list <<ui->parametersTable->item(i,ui->valuePlotBox->currentIndex()+2)->text();
                    if(ui->errorButton->isChecked())
                        list <<ui->parametersTable->item(i,ui->errorPlotBox->currentIndex()+2)->text();
                    plot2DVec.push_back(list);
                }
            }
        }
        plotStr = ui->valuePlotBox->currentText();
        ui->xaxisTitleEdit->setText("Residue number");
        ui->yaxisTitleEdit->setText(ui->valuePlotBox->currentText());
        ui->titleEdit->setText(pintTemplate.projectName);
        if(!ui->workspaceTab->isTabEnabled(6))
            ui->workspaceTab->setTabEnabled(6,true);
        plot2D();
        ui->workspaceTab->setCurrentIndex(6);
    }
}

void workspace::plot2D()
{
    disconnect(ui->xaxisMinEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    disconnect(ui->xaxisMaxEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    disconnect(ui->yaxisMinEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    disconnect(ui->yaxisMaxEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    ui->customPlotPlot->clearGraphs();
    ui->customPlotPlot->clearPlottables();
    if(plot2DVec.size()==0)
        return;

    QString title("%1");
    titleQCustomPlotPlot->setText(title.arg(ui->titleEdit->text()));
    titleQCustomPlotPlot->setFont(QFont("Myriad Pro", ui->titleSizeBox->value(), QFont::Bold));

    bool error(false);
    if(plot2DVec.at(0).count()==3)
        error = true;
    QVector<double> x1(plot2DVec.size()), y1(plot2DVec.size()), y1err(plot2DVec.size());
    maxX=-9e99;
    maxY=-9e99;
    minX=9e99;
    minY=9e99;
    for(int i(0); i<plot2DVec.size(); i++)
    {
        if(plot2DVec.at(i).at(0).toDouble()<minX)
            minX = plot2DVec.at(i).at(0).toDouble();
        if(plot2DVec.at(i).at(0).toDouble()>maxX)
            maxX = plot2DVec.at(i).at(0).toDouble();
        if(plot2DVec.at(i).at(1).toDouble()<minY)
            minY = plot2DVec.at(i).at(1).toDouble();
        if(plot2DVec.at(i).at(1).toDouble()>maxY)
            maxY = plot2DVec.at(i).at(1).toDouble();
        x1[i] = plot2DVec.at(i).at(0).toDouble();
        y1[i] = plot2DVec.at(i).at(1).toDouble();
        if(error)
        {
            y1err[i] = plot2DVec.at(i).at(2).toDouble();
            if(plot2DVec.at(i).at(1).toDouble()-y1err[i]<minY)
                minY = plot2DVec.at(i).at(1).toDouble()-y1err[i];
            if(plot2DVec.at(i).at(1).toDouble()+y1err[i]>maxY)
                maxY = plot2DVec.at(i).at(1).toDouble()+y1err[i];
        }
    }
    if(ui->scatterButton->isChecked())
    {
        ui->customPlotPlot->addGraph();
        QPen dataPen;
        dataPen.setColor(plotDataColor);
        dataPen.setCapStyle(Qt::FlatCap);
        ui->customPlotPlot->graph(0)->setPen(dataPen);
        ui->customPlotPlot->graph(0)->setLineStyle(QCPGraph::lsNone);
        ui->customPlotPlot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc,15));
        ui->customPlotPlot->graph(0)->setErrorType(QCPGraph::etValue);

        QPen errorPen;
        errorPen.setCapStyle(Qt::FlatCap);
        errorPen.setColor(plotDataColor);
        errorPen.setWidth(2);
        if(error)
        {
            ui->customPlotPlot->graph(0)->setErrorPen(errorPen);
            ui->customPlotPlot->graph(0)->setDataValueError(x1, y1, y1err);
            ui->customPlotPlot->graph(0)->setErrorBarSkipSymbol(false);
        }
        else
        {
            ui->customPlotPlot->graph(0)->setPen(errorPen);
            ui->customPlotPlot->graph(0)->setData(x1, y1);
        }
    }
    else //Bar graph
    {
        QBrush dataPen(plotDataColor);
        dataPen.setStyle(Qt::SolidPattern);
        QPen errorPen;
        errorPen.setCapStyle(Qt::FlatCap);
        errorPen.setColor(QColor(0,0,0));
        errorPen.setWidth(2);
        for(int i(0); i<x1.size(); i++)
        {
            QCPStatisticalBox *data = new QCPStatisticalBox(ui->customPlotPlot->xAxis, ui->customPlotPlot->yAxis);
            ui->customPlotPlot->addPlottable(data);
            data->setBrush(dataPen);
            data->setWhiskerPen(errorPen);
            data->setWhiskerWidth(1);
            data->setWidth(0.5);
            data->setKey(x1[i]);
            data->setUpperQuartile(y1[i]);
            if(error)
            {
                if(y1[i]>0)
                    data->setMaximum(y1[i]+y1err[i]);
                else
                    data->setMaximum(y1[i]-y1err[i]);
            }
        }
    }

    ui->customPlotPlot->yAxis->setAutoTickStep(true);
    ui->customPlotPlot->yAxis2->setAutoTickStep(true);
    ui->customPlotPlot->xAxis->setAutoTickStep(true);
    ui->customPlotPlot->xAxis2->setAutoTickStep(true);

    ui->xaxisMaxEdit->setText(QString::number(maxX));
    ui->xaxisMinEdit->setText(QString::number(minX));
    double comp2(1.05);
    if(maxY<0)
        comp2 = 0.95;
    ui->yaxisMaxEdit->setText(QString::number(maxY*comp2));
    double comp(0.95);
    if(minY<0)
        comp = 1.05;
    ui->yaxisMinEdit->setText(QString::number(minY*comp));
    ui->customPlotPlot->xAxis->setRange(minX-1, maxX+1);
    ui->customPlotPlot->xAxis2->setRange(minX-1, maxX+1);
    ui->customPlotPlot->yAxis->setRange(minY*comp, maxY*comp2);
    ui->customPlotPlot->yAxis2->setRange(minY*comp, maxY*comp2);
    ui->customPlotPlot->xAxis->setAutoTickCount(9);
    ui->customPlotPlot->xAxis2->setAutoTickCount(9);

    ui->customPlotPlot->xAxis->setTickLengthIn(0);
    ui->customPlotPlot->xAxis->setTickLengthOut(6);
    ui->customPlotPlot->xAxis->setSubTickLengthIn(0);
    ui->customPlotPlot->xAxis->setSubTickLengthOut(3);

    ui->customPlotPlot->yAxis->setTickLengthIn(0);
    ui->customPlotPlot->yAxis->setTickLengthOut(6);
    ui->customPlotPlot->yAxis->setSubTickLengthIn(0);
    ui->customPlotPlot->yAxis->setSubTickLengthOut(3);

    ui->customPlotPlot->axisRect()->setupFullAxesBox();

    ui->customPlotPlot->xAxis->setLabelFont(QFont("Myriad Pro", ui->xaxisSizeBox->value()));
    ui->customPlotPlot->xAxis->setLabel("Residue");
    ui->customPlotPlot->yAxis->setLabelFont(QFont("Myriad Pro", ui->yaxisSizeBox->value()));
    ui->customPlotPlot->yAxis->setLabel(ui->valuePlotBox->currentText());
    ui->customPlotPlot->replot();
    connect(ui->xaxisMinEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    connect(ui->xaxisMaxEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    connect(ui->yaxisMinEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
    connect(ui->yaxisMaxEdit, SIGNAL(textChanged(QString)), this, SLOT(setManualPlotRanges()));
}

void workspace::on_titleEdit_textChanged(const QString &arg1)
{
    titleQCustomPlotPlot->setText(arg1);
    ui->customPlotPlot->replot();
}

void workspace::on_scatterButton_toggled(bool checked)
{
    Q_UNUSED(checked)
    plot2D();
}

void workspace::on_xaxisTitleEdit_textChanged(const QString &arg1)
{
    ui->customPlotPlot->xAxis->setLabel(arg1);
    ui->customPlotPlot->xAxis->setLabelFont(QFont("Myriad Pro", ui->xaxisSizeBox->value()));
    ui->customPlotPlot->replot();
}

void workspace::on_yaxisTitleEdit_textChanged(const QString &arg1)
{
    ui->customPlotPlot->yAxis->setLabel(arg1);
    ui->customPlotPlot->yAxis->setLabelFont(QFont("Myriad Pro", ui->yaxisSizeBox->value()));
    ui->customPlotPlot->replot();
}

void workspace::setManualPlotRanges()
{
    bool ok(false);
    minX=ui->xaxisMinEdit->text().toDouble(&ok);
    if(!ok)return;
    maxX=ui->xaxisMaxEdit->text().toDouble(&ok);
    if(!ok)return;
    minY=ui->yaxisMinEdit->text().toDouble(&ok);
    if(!ok)return;
    maxY=ui->yaxisMaxEdit->text().toDouble(&ok);
    if(!ok)return;
    if((maxY-minY)/ui->ytickBox_Plot->value() + (maxY-minY)/(ui->ySubTickBox_Plot->value()+1) > 100.0)
    {
        ui->customPlotPlot->yAxis->setAutoTickStep(true);
        ui->customPlotPlot->yAxis2->setAutoTickStep(true);
        ui->customPlotPlot->yAxis->setAutoTickCount(9);
        ui->customPlotPlot->yAxis2->setAutoTickCount(9);
    }
    if((maxX-minX)/ui->xtickBox_Plot->value() + (maxX-minX)/(ui->xsubTickBox_Plot->value()+1) > 100.0)
    {
        ui->customPlotPlot->xAxis->setAutoTickStep(true);
        ui->customPlotPlot->xAxis2->setAutoTickStep(true);
        ui->customPlotPlot->xAxis->setAutoTickCount(9);
        ui->customPlotPlot->xAxis2->setAutoTickCount(9);
    }
    ui->customPlotPlot->xAxis->setRange(minX, maxX);
    ui->customPlotPlot->xAxis2->setRange(minX, maxX);
    ui->customPlotPlot->yAxis->setRange(minY, maxY);
    ui->customPlotPlot->yAxis2->setRange(minY, maxY);
    ui->customPlotPlot->replot();
}

void workspace::on_titleSizeBox_valueChanged(int arg1)
{
    if(arg1>0)
        titleQCustomPlotPlot->setFont(QFont("Myriad Pro", arg1, QFont::Bold));
    else
        titleQCustomPlotPlot->setText("");
    ui->customPlotPlot->replot();
}

void workspace::on_xaxisSizeBox_valueChanged(int arg1)
{
    ui->customPlotPlot->xAxis->setLabelFont(QFont("Myriad Pro", arg1));
    ui->customPlotPlot->replot();
}

void workspace::on_yaxisSizeBox_valueChanged(int arg1)
{
    ui->customPlotPlot->yAxis->setLabelFont(QFont("Myriad Pro", arg1));
    ui->customPlotPlot->replot();
}

void workspace::on_xtickBox_Plot_valueChanged(double arg1)
{
    if((maxX-minX)/arg1 >100.0)
        return;
    ui->customPlotPlot->xAxis->setAutoTickStep(false);
    ui->customPlotPlot->xAxis2->setAutoTickStep(false);
    ui->customPlotPlot->xAxis->setTickStep(arg1);
    ui->customPlotPlot->xAxis2->setTickStep(arg1);
    ui->customPlotPlot->replot();
}

void workspace::on_ytickBox_Plot_valueChanged(double arg1)
{
    if((maxY-minY)/arg1 >100.0)
        return;
    ui->customPlotPlot->yAxis->setAutoTickStep(false);
    ui->customPlotPlot->yAxis->setTickStep(arg1);
    ui->customPlotPlot->yAxis2->setAutoTickStep(false);
    ui->customPlotPlot->yAxis2->setTickStep(arg1);
    ui->customPlotPlot->replot();
}

void workspace::on_xtickBox_Fit_valueChanged(double arg1)
{
    if((maxXfit-minXfit)/arg1 >100.0)
        return;
    ui->customPlotFit->xAxis->setAutoTickStep(false);
    ui->customPlotFit->xAxis2->setAutoTickStep(false);
    ui->customPlotFit->xAxis->setTickStep(arg1);
    ui->customPlotFit->xAxis2->setTickStep(arg1);
    ui->customPlotFit->replot();
}

void workspace::on_ytickBox_Fit_valueChanged(double arg1)
{
    if((maxYfit-minYfit)/arg1 >100.0)
        return;
    ui->customPlotFit->yAxis->setAutoTickStep(false);
    ui->customPlotFit->yAxis2->setAutoTickStep(false);
    ui->customPlotFit->yAxis->setTickStep(arg1);
    ui->customPlotFit->yAxis2->setTickStep(arg1);
    ui->customPlotFit->replot();
}

void workspace::setManualPlotRangesFit()
{
    bool ok(false);
    minXfit=ui->xaxisMinEditFit->text().toDouble(&ok);
    if(!ok)return;
    maxXfit=ui->xaxisMaxEditFit->text().toDouble(&ok);
    if(!ok)return;
    minYfit=ui->yaxisMinEditFit->text().toDouble(&ok);
    if(!ok)return;
    maxYfit=ui->yaxisMaxEditFit->text().toDouble(&ok);
    if(!ok)return;
    if(ui->lockFitStepY->isChecked() && (maxYfit-minYfit)/(ui->ytickBox_Fit->value()+1) > 100.0)
    {
        ui->customPlotFit->yAxis->setAutoTickStep(true);
        ui->customPlotFit->yAxis2->setAutoTickStep(true);
        ui->customPlotFit->yAxis->setAutoTickCount(9);
        ui->customPlotFit->yAxis2->setAutoTickCount(9);
    }
    if(ui->lockFitStepX->isChecked() && (maxXfit-minXfit)/(ui->xtickBox_Fit->value()+1) > 100.0)
    {
        ui->customPlotFit->xAxis->setAutoTickStep(true);
        ui->customPlotFit->xAxis2->setAutoTickStep(true);
        ui->customPlotFit->xAxis->setAutoTickCount(9);
        ui->customPlotFit->xAxis2->setAutoTickCount(9);
    }
    ui->customPlotFit->xAxis->setRange(minXfit, maxXfit);
    ui->customPlotFit->xAxis2->setRange(minXfit, maxXfit);
    ui->customPlotFit->yAxis->setRange(minYfit, maxYfit);
    ui->customPlotFit->yAxis2->setRange(minYfit, maxYfit);
    ui->customPlotFit->replot();
}

void workspace::on_subTickXFit_valueChanged(int arg1)
{
    ui->customPlotFit->xAxis->setAutoSubTicks(false);
    ui->customPlotFit->xAxis2->setAutoSubTicks(false);
    ui->customPlotFit->xAxis->setSubTickCount(arg1);
    ui->customPlotFit->xAxis2->setSubTickCount(arg1);
    ui->customPlotFit->replot();
}

void workspace::on_subTickYFit_valueChanged(int arg1)
{
    ui->customPlotFit->yAxis->setAutoSubTicks(false);
    ui->customPlotFit->yAxis->setSubTickCount(arg1);
    ui->customPlotFit->yAxis2->setAutoSubTicks(false);
    ui->customPlotFit->yAxis2->setSubTickCount(arg1);
    ui->customPlotFit->replot();
}

void workspace::on_xaxisTitleEditFit_textChanged(const QString &arg1)
{
    ui->customPlotFit->xAxis->setLabel(arg1);
    ui->customPlotFit->xAxis->setLabelFont(QFont("Myriad Pro", ui->xaxisSizeBoxFit->value()));
    ui->customPlotFit->replot();
}

void workspace::on_yaxisTitleEditFit_textChanged(const QString &arg1)
{
    ui->customPlotFit->yAxis->setLabel(arg1);
    ui->customPlotFit->yAxis->setLabelFont(QFont("Myriad Pro", ui->yaxisSizeBoxFit->value()));
    ui->customPlotFit->replot();
}

void workspace::on_xaxisSizeBoxFit_valueChanged(int arg1)
{
    ui->customPlotFit->xAxis->setLabelFont(QFont("Myriad Pro", arg1));
    ui->customPlotFit->replot();
}

void workspace::on_yaxisSizeBoxFit_valueChanged(int arg1)
{
    ui->customPlotFit->yAxis->setLabelFont(QFont("Myriad Pro", arg1));
    ui->customPlotFit->replot();
}

void workspace::on_fitLegendButton_toggled(bool checked)
{
    ui->customPlotFit->legend->setVisible(checked);
    ui->customPlotFit->replot();
}

void workspace::on_titleEditFit_textChanged(const QString &arg1)
{
    titleQCustomPlotFit->setText(arg1);
    ui->customPlotFit->replot();
}

void workspace::on_titleSizeBoxFit_valueChanged(int arg1)
{
    if(arg1>0)
        titleQCustomPlotFit->setFont(QFont("Myriad Pro", arg1, QFont::Bold));
    else
        titleQCustomPlotFit->setText("");
    ui->customPlotFit->replot();
}


void workspace::on_fitDataColorButton_clicked()
{
    QColor color = QColorDialog::getColor(fitDataColor, this);
    if(color.isValid())
    {
        fitDataColor = color;
        QString style("rgb(%1, %2, %3);");
        ui->fitDataColorButton->setStyleSheet("QPushButton#fitDataColorButton{\nbackground-color:"+ style.arg(color.red()).arg(color.green()).arg(color.blue()) +"\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}\nQPushButton#fitDataColorButton:pressed {\n border-style: inset;\n}\nQPushButton#fitDataColorButton:hover:!pressed {\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}");

        if(ui->customPlotFit->graphCount()>1)
        {
            QPen dataPen;
            dataPen.setColor(fitDataColor);
            dataPen.setCapStyle(Qt::FlatCap);
            ui->customPlotFit->graph(1)->setPen(dataPen);
            ui->customPlotFit->graph(1)->setLineStyle(QCPGraph::lsNone);
            ui->customPlotFit->graph(1)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDisc,15));
            ui->customPlotFit->graph(1)->setErrorType(QCPGraph::etValue);
            QPen errorPen;
            errorPen.setCapStyle(Qt::FlatCap);
            errorPen.setColor(fitDataColor);
            errorPen.setWidth(2);
            ui->customPlotFit->graph(1)->setErrorPen(errorPen);
            ui->customPlotFit->replot();
        }
    }
}

void workspace::on_fitFitColorButton_clicked()
{
    QColor color = QColorDialog::getColor(fitFitColor, this);
    if(color.isValid())
    {
        fitFitColor = color;
        QString style("rgb(%1, %2, %3);");
        ui->fitFitColorButton->setStyleSheet("QPushButton#fitFitColorButton{\nbackground-color:"+ style.arg(color.red()).arg(color.green()).arg(color.blue()) +"\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}\nQPushButton#fitFitColorButton:pressed {\n border-style: inset;\n}\nQPushButton#fitFitColorButton:hover:!pressed {\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}");

        if(ui->customPlotFit->graphCount()>0)
        {
            QPen errorPen;
            errorPen.setColor(fitFitColor);
            errorPen.setCapStyle(Qt::FlatCap);
            errorPen.setWidth(2);
            ui->customPlotFit->graph(0)->setPen(errorPen);
            ui->customPlotFit->replot();
        }
    }
}

void workspace::stopFitSave()
{
    abortFitSave = true;
}

void workspace::on_saveFitButton_clicked()
{
    if(ui->fit2DList->count()==0)
        return;
    if(ui->allFitButton->isChecked())
    {
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT", "PINT will save all available fitted graphs to a specified folder.\n"
                                                 "Any current static settings will be applied to the saved graphs.", QMessageBox::Ok);
        if(dlg==QMessageBox::Ok)
        {
            QString directory = QFileDialog::getExistingDirectory(this,tr("Choose save directory"), previousDir);
            if (!directory.isEmpty())
            {
                bool merge=false;

                abortFitSave = false;
                iDialog = new integrationStatusDialog();
                iDialog->setWindowModality(Qt::ApplicationModal);
                disconnect(iDialog, SIGNAL(rejected()), this, SLOT(stopFitSave()));
                connect(iDialog, SIGNAL(rejected()), this, SLOT(stopFitSave()));
                disconnect(iDialog, SIGNAL(rejected()), iDialog, SLOT(deleteLater()));
                connect(iDialog, SIGNAL(rejected()), iDialog, SLOT(deleteLater()));
                iDialog->hideElements();
                iDialog->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
                iDialog->setMaximumHeight(100);
                iDialog->show();
                QString str("Saving 0/");
                str+=QString::number(ui->fit2DList->count());
                iDialog->updateLabel(str);
                iDialog->updateProgress(0);

                int index(ui->fit2DList->currentRow());
                previousDir = directory;
                QString fileName(directory +"/merged.pdf");
                for(int i(0); i<ui->fit2DList->count(); i++)
                {
                    viewPlot2D(i);
                    if(!merge)
                    {
                        fileName =directory;
                        fileName+="/"+ ui->fit2DList->item(i)->text();
                        if(ui->fitPng->isChecked())
                        {
                            fileName+=".png";
                            ui->customPlotFit->savePng(fileName, 880, 630, 1,-1);
                        }
                        else
                        {
                            fileName+=".pdf";
                            ui->customPlotFit->savePdf(fileName, false, 880, 630,0,0);
                        }
                    }
                    else
                    {
                        QTextCursor cursor = ui->saveFitEdit->textCursor();
                        cursor.insertText(QString(QChar::ObjectReplacementCharacter), QCPDocumentObject::generatePlotFormat(ui->customPlotFit, 880, 630));
                        ui->saveFitEdit->setTextCursor(cursor);
                    }
                    QString str2("Saving ");
                    str2+=QString::number(i) + "/" + QString::number(ui->fit2DList->count());
                    iDialog->updateLabel(str2);
                    iDialog->updateProgress((int)(100*i/ui->fit2DList->count()));
                    qApp->processEvents();
                    if(abortFitSave)
                        break;
                }
                if(merge && !abortFitSave)
                {
                    QPrinter printer;
                    printer.setFullPage(true);
                    printer.setPaperSize(QPrinter::A4);
                    printer.setOrientation(QPrinter::Landscape);
                    printer.setOutputFormat(QPrinter::PdfFormat);
                    printer.setOutputFileName(fileName);
                    ui->saveFitEdit->document()->print(&printer);
                }
                ui->saveFitEdit->clear();
                iDialog->reject();
                if(index>=0)
                    viewPlot2D(index);
            }
        }
    }
    else
    {
        QString types;
        if(ui->fitPng->isChecked())
            types = "Images (*.png)";
        else
            types = "Images (*.pdf)";

        QString fileName = QFileDialog::getSaveFileName(this, tr("Save File"),
                                                        previousDir, tr(types.toStdString().c_str()));
        if(fileName!="")
        {
            if(ui->fitPng->isChecked())
                ui->customPlotFit->savePng(fileName, 880, 630, 1,-1);
            else
                ui->customPlotFit->savePdf(fileName, false, 880, 630,0,0);
        }
    }
}

void workspace::spectrumBox_update()
{
    if(nDim == 3)
    {
        if(pintTemplate.pipeData)
        {
            setNoDim();
            ui->spectrumPlaneBox->setEnabled(true);
            pipeDataTemplate pipe;
            FILE *fp;
            if(!(fp = fopen(ui->spectrumBox->currentText().toStdString().c_str(), "rb")))
                return;
            fread(pipe.header, 4, 512, fp);
            fclose(fp);
            ui->spectrumPlaneBox->setMaximum((int) pipe.header[NPLANE]);
            ui->spectrumPlaneLabel->setText("<html><head/><body><p align=\"right\"><span style=\" color:#000000;\">Plane</span></p></body></html>");
        }
        else
        {
            ui->spectrumPlaneBox->setEnabled(true);
            ui->spectrumPlaneBox->setMaximum(nPlane);
            ui->spectrumPlaneLabel->setText("<html><head/><body><p align=\"right\"><span style=\" color:#000000;\">Plane</span></p></body></html>");
        }
    }
    else
    {
        ui->spectrumPlaneBox->setDisabled(true);
        ui->spectrumPlaneBox->setValue(1);
        ui->spectrumPlaneBox->setMaximum(1);
        ui->spectrumPlaneLabel->setText("<html><head/><body><p align=\"right\"><span style=\" color:#808080;\">Plane</span></p></body></html>");
    }
}

void workspace::on_plotDataColorButton_clicked()
{
    QColor color = QColorDialog::getColor(plotDataColor, this);
    if(color.isValid())
    {
        plotDataColor = color;
        QString style("rgb(%1, %2, %3);");
        ui->plotDataColorButton->setStyleSheet("QPushButton#plotDataColorButton{\nbackground-color:"+ style.arg(color.red()).arg(color.green()).arg(color.blue()) +"\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}\nQPushButton#plotDataColorButton:pressed {\n border-style: inset;\n}\nQPushButton#plotDataColorButton:hover:!pressed {\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}");

        if(ui->customPlotPlot->graphCount()>0)
        {
            QPen dataPen;
            dataPen.setCapStyle(Qt::FlatCap);
            dataPen.setColor(plotDataColor);
            ui->customPlotPlot->graph(0)->setPen(dataPen);
            QPen errorPen;
            errorPen.setCapStyle(Qt::FlatCap);
            errorPen.setColor(QColor(0,0,0));
            errorPen.setWidth(2);
            ui->customPlotPlot->graph(0)->setErrorPen(errorPen);
        }
        else if(ui->customPlotPlot->plottableCount()>0)
        {
            QVector<double> x1(ui->customPlotPlot->plottableCount()), y1(ui->customPlotPlot->plottableCount()), y1err(ui->customPlotPlot->plottableCount());
            for(int i(0); i<ui->customPlotPlot->plottableCount(); i++)
            {
                QCPStatisticalBox *data = static_cast<QCPStatisticalBox *>(ui->customPlotPlot->plottable(i));
                x1[i] = data->key();
                y1[i] = data->upperQuartile();
                y1err[i] = data->maximum();
            }
            ui->customPlotPlot->clearPlottables();
            QBrush dataPen(plotDataColor);
            dataPen.setStyle(Qt::SolidPattern);
            QPen errorPen;
            errorPen.setCapStyle(Qt::FlatCap);
            errorPen.setColor(QColor(0,0,0));
            errorPen.setWidth(2);
            for(int i(0); i<x1.size(); i++)
            {
                QCPStatisticalBox *data = new QCPStatisticalBox(ui->customPlotPlot->xAxis, ui->customPlotPlot->yAxis);
                ui->customPlotPlot->addPlottable(data);
                data->setBrush(dataPen);
                data->setWhiskerPen(errorPen);
                data->setWhiskerWidth(1);
                data->setWidth(0.5);
                data->setKey(x1[i]);
                data->setUpperQuartile(y1[i]);
                data->setMaximum(y1err[i]);
            }
        }
        ui->customPlotPlot->replot();
    }
}

void workspace::on_xsubTickBox_Plot_valueChanged(int arg1)
{
    ui->customPlotPlot->xAxis->setAutoSubTicks(false);
    ui->customPlotPlot->xAxis2->setAutoSubTicks(false);
    ui->customPlotPlot->xAxis->setSubTickCount(arg1);
    ui->customPlotPlot->xAxis2->setSubTickCount(arg1);
    ui->customPlotPlot->replot();
}

void workspace::on_ySubTickBox_Plot_valueChanged(int arg1)
{
    ui->customPlotPlot->yAxis->setAutoSubTicks(false);
    ui->customPlotPlot->yAxis->setSubTickCount(arg1);
    ui->customPlotPlot->yAxis2->setAutoSubTicks(false);
    ui->customPlotPlot->yAxis2->setSubTickCount(arg1);
    ui->customPlotPlot->replot();
}

void workspace::on_savePlotButton_clicked()
{
    if(ui->customPlotPlot->plottableCount()>0 || ui->customPlotPlot->graphCount()>0)
    {
        QString types;
        if(ui->plotPng->isChecked())
            types = "Images (*.png)";
        else
            types = "Images (*.pdf)";

        QString fileName = QFileDialog::getSaveFileName(this, tr("Save File"),
                                                        previousDir, tr(types.toStdString().c_str()));
        if(fileName!="")
        {
            if(ui->plotPng->isChecked())
                ui->customPlotPlot->savePng(fileName, 880, 630, 1,-1);
            else
                ui->customPlotPlot->savePdf(fileName, false,880, 630,0,0);
        }
    }
}

void workspace::togglePlotMode(bool mode3D)
{
    if(togglingStates) return;
    togglingStates=true;
    if(!ui->view3DButton->isEnabled())
        return;
    if(spectrumView3D->moveModeEnabled || contourPlot->moveModeEnabled)
    {
        spectrumView3D->exitMoveMode();
        contourPlot->exitMoveMode();
    }
    if(mode3D)
    {
        ui->spectrumContourWidget->hide();
        ui->spectrum2DWidget->show();
        ui->zMaxEdit->show();
        ui->zMaxLabel->show();
        ui->zMinEdit->show();
        ui->zMinLabel->show();
        ui->adjustZButton->show();
        ui->autoAdjustZButton->show();
        ui->flipZButton->show();
        ui->intensityGroupBox->show();
        ui->contourLevelsBox->hide();
        ui->spectroGramLabel->hide();
        ui->spectroGramLabel_2->hide();
        ui->spectrogramToggleButton->hide();
        ui->labelsToggleButton->hide();

        QVector< QVector<QString>> rowVector;
        for(int i(0); i<ui->peaklistTable->rowCount(); i++)
        {
            QVector<QString> colVector;
            for(int j(0); j<ui->peaklistTable->columnCount(); j++)
                colVector.push_back(ui->peaklistTable->item(i,j)->text());
            rowVector.push_back(colVector);
        }
        if(stateVector.size()==0)
        {
            stateVector.push_back(rowVector);
            statePeakId.push_back(peakId);
            currentState++;
        }
        else
        {
            stateVector[stateVector.size()-1] = rowVector;
            statePeakId[stateVector.size()-1] = peakId;
        }
        restoringState = true;
        restoreStateFromVec();
    }
    else
    {
        ui->spectrum2DWidget->hide();
        ui->spectrumContourWidget->show();
        ui->zMaxEdit->hide();
        ui->zMaxLabel->hide();
        ui->zMinEdit->hide();
        ui->zMinLabel->hide();
        ui->adjustZButton->hide();
        ui->autoAdjustZButton->hide();
        ui->flipZButton->hide();
        ui->intensityGroupBox->hide();
        ui->contourLevelsBox->show();
        ui->spectroGramLabel->show();
        ui->spectroGramLabel_2->show();
        ui->spectrogramToggleButton->show();
        ui->labelsToggleButton->show();
    }
    togglingStates=false;
}

void workspace::setupContourWidget(pipeDataTemplate pipe)
{
    minX=9e99;
    maxX=-9e99;
    minY=9e99;
    maxY=-9e99;
    double minZ(9e99), maxZ(-9e99);
    for(int i(0); i<(int)pipe.f1.size(); i++)
    {
        if(minX>pipe.f1[i])
            minX = pipe.f1[i];
        if(maxX<pipe.f1[i])
            maxX = pipe.f1[i];
    }
    for(int i(0); i<(int)pipe.f2.size(); i++)
    {
        if(minY>pipe.f2[i])
            minY = pipe.f2[i];
        if(maxY<pipe.f2[i])
            maxY = pipe.f2[i];
    }
    for(int i(0); i<(int)pipe.y.size(); i++)
    {
        if(minZ>pipe.y[i])
            minZ = pipe.y[i];
        if(maxZ<pipe.y[i])
            maxZ = pipe.y[i];
    }
    double stepYf1(-pipe.swF1/(double)pipe.sizeF1);
    stepYf1/=pipe.obsF1;
    double stepXf2(-pipe.swF2/(double)pipe.sizeF2);
    stepXf2/=pipe.obsF2;

    vector< vector< float > > yVec, f1Vec, f2Vec;
    vector< float >tmpVec, tmpVec1, tmpVec2;

    int countCol(0);
    for(int i(0); i<(int)pipe.y.size(); i++)
    {
        tmpVec.push_back(pipe.y[i]);
        tmpVec1.push_back(pipe.f1[i]);
        tmpVec2.push_back(pipe.f2[i]);
        countCol++;
        if(countCol == pipe.sizeF2)
        {
            yVec.push_back(tmpVec);
            f1Vec.push_back(tmpVec1);
            f2Vec.push_back(tmpVec2);
            vector< float >newVec;
            tmpVec = newVec;
            tmpVec1 = newVec;
            tmpVec2 = newVec;
            countCol = 0;
        }
    }
    contourPlot->detachAll();
    contourPlot->disconnect();
    specmode = contourPlot->modeSpec;
    ui->contourLayout->removeWidget(contourPlot);
    contourPlot->deleteLater();
    contourPlot = new generateContourPlot();
    contourPlot->setAutoDelete(true);
    ui->contourLayout->addWidget(contourPlot);
    contourPlot->setTheme(themeVector[themeList->currentIndex()]);
    contourPlot->show();
    double sum(.0), sqSum(.0), ndata(0);
    for(int i(0); i<(int)yVec.size(); i++)
        for(int j(0); j<(int)yVec[i].size(); j++)
        {
            sum+= yVec[i][j];
            sqSum+= yVec[i][j]*yVec[i][j];
            ndata+=1.0;
        }
    if(ndata>1)
        sdev = sqrt(1.0/(ndata-1.0)*(sqSum-sum*sum/ndata));
    sum=.0;
    sqSum=.0;
    ndata=0;
    for(int i(0); i<(int)yVec.size(); i++)
        for(int j(0); j<(int)yVec[i].size(); j++)
        {
            if(fabs(yVec[i][j])>2*sdev)
                continue;
            sum+= yVec[i][j];
            sqSum+= yVec[i][j]*yVec[i][j];
            ndata+=1.0;
        }
    if(ndata>1)
        sdev = sqrt(1.0/(ndata-1.0)*(sqSum-sum*sum/ndata));
    contourPlot->setData(pipe.firstF1/pipe.obsF1, pipe.firstF2/pipe.obsF2, stepYf1, stepXf2, yVec, minX, maxX, minY, maxY, minZ, maxZ);
    setupContourLevels(2*sdev, minZ, maxZ);
    updateContourLevels();
    updateContourLevelsMin();
    contourPlot->toggleSpectrogramManual(specmode);
    if(ui->view3DButton->isChecked())
        ui->spectrumContourWidget->hide();
    else
        ui->spectrumContourWidget->show();
}

void workspace::on_valuePlotBox_currentIndexChanged(int index)
{
    if(index+1 < ui->errorPlotBox->count())
    {
        QString str("d"+ui->valuePlotBox->currentText().toLower());
        if(ui->errorPlotBox->itemText(index+1).toLower() == str)
            ui->errorPlotBox->setCurrentIndex(index+1);
    }
}

void workspace::on_view3DButton_clicked()
{
    if(!ui->view3DButton->isEnabled())
        return;
    if(ui->view3DButton->isChecked())
        ui->contourButton->setChecked(false);
    else
        ui->contourButton->setChecked(true);
}

void workspace::on_contourButton_clicked()
{
    if(!ui->view3DButton->isEnabled())
    {
        ui->contourButton->setChecked(true);
        return;
    }
    if(ui->contourButton->isChecked())
        ui->view3DButton->setChecked(false);
    else
        ui->view3DButton->setChecked(true);
}

void workspace::on_contourMinIntensity_textChanged(const QString &arg1)
{
    Q_UNUSED(arg1)
    updateContourLevels();
}

void workspace::on_contourLevels_valueChanged(int arg1)
{
    Q_UNUSED(arg1)
    updateContourLevels();
}

void workspace::on_contourStep_textChanged(const QString &arg1)
{
    Q_UNUSED(arg1)
    updateContourLevels();
}

void workspace::on_contourMinIntensityMin_textChanged(const QString &arg1)
{
    Q_UNUSED(arg1)
    updateContourLevelsMin();
}

void workspace::on_contourLevelsMin_valueChanged(int arg1)
{
    Q_UNUSED(arg1)
    updateContourLevelsMin();
}

void workspace::on_contourStepMin_textChanged(const QString &arg1)
{
    Q_UNUSED(arg1)
    updateContourLevelsMin();
}

void workspace::updateContourLevels()
{
    if(!contourPlot->loadedSpectrum)
        return;
    bool ok(false);
    double min(ui->contourMinIntensity->text().toDouble(&ok));
    if(!ok)
        return;
    if(min<0)
        return;
    double step(ui->contourStep->text().toDouble(&ok));
    if(!ok)
        return;
    if(step<=0)
        return;
    int levels(ui->contourLevels->value());
    contourPlot->updateContourLevels(levels, step, min);
}

void workspace::updateContourLevelsMin()
{
    if(!contourPlot->loadedSpectrum)
        return;
    bool ok(false);
    double min(ui->contourMinIntensityMin->text().toDouble(&ok));
    if(!ok)
        return;
    if(min>0)
        return;
    double step(ui->contourStepMin->text().toDouble(&ok));
    if(!ok)
        return;
    if(step>=0)
        return;
    int levels(ui->contourLevelsMin->value());
    contourPlot->updateContourLevelsMin(levels, step, min);
}

void workspace::on_spectrogramToggleButton_clicked()
{
    if(!contourPlot->loadedSpectrum)
        return;
    contourPlot->toggleSpectrogram();
}

void workspace::updateContourPlotLabels(int row, int col)
{
    Q_UNUSED(col)
    QVector<QString> strVec;
    for(int i(0); i<9; ++i)
    {
        if(i==3)
            continue;
        strVec.push_back(ui->peaklistTable->item(row,i)->text());
    }
    contourPlot->updateContourPlotLabels(strVec);
}

void workspace::readContourPeaklist(int rowNo)
{
    QVector<QVector<QString> >peaklist;
    for(int i(rowNo); i<ui->peaklistTable->rowCount(); i++)
    {
        QVector<QString> peakVec;
        for(int j(0); j<9; ++j)
        {
            if(j==3)
                continue;
            peakVec.push_back(ui->peaklistTable->item(i,j)->text());
        }
        peaklist.push_back(peakVec);
    }
    if(rowNo==0 && peaklist.size()>0)
        contourPlot->readPeaklist(peaklist, true);
    else if(peaklist.size()>0)
        contourPlot->readPeaklist(peaklist, false);
    else
        contourPlot->detachAll();
}

void workspace::updateContourZoomManual(float minF1, float maxF1, float minF2, float maxF2)
{
    contourPlot->updateZoom(minF1, maxF1, minF2, maxF2);

}

void workspace::updateContourZoom()
{
    disconnect(contourPlot, SIGNAL(contourZoomed(float,float,float,float)), this, SLOT(update3DZoom(float,float,float,float)));
#ifdef Q_OS_MAC
    displayInformation("Ctrl-double click or double click with the right mouse button to zoom out",true,0);
#else
    displayInformation("Double click with the right mouse button to zoom out",true,0);
#endif
    contourPlot->updateZoom(spectrumView3D->spectrum_graph->axisX()->min(), spectrumView3D->spectrum_graph->axisX()->max(),
                            spectrumView3D->spectrum_graph->axisZ()->min(), spectrumView3D->spectrum_graph->axisZ()->max());
    connect(contourPlot, SIGNAL(contourZoomed(float,float,float,float)), this, SLOT(update3DZoom(float,float,float,float)));
}

void workspace::update3DZoom(float minF1, float maxF1, float minF2, float maxF2)
{
#ifdef Q_OS_MAC
    displayInformation("Ctrl-double click or double click with the right mouse button to zoom out",true,0);
#else
    displayInformation("Double click with the right mouse button to zoom out",true,0);
#endif
    disconnect(spectrumView3D, SIGNAL(zoomed()), this, SLOT(updateContourZoom()));
    spectrumView3D->setAxisF1Range(minF2, maxF2);
    spectrumView3D->setAxisF2Range(minF1, maxF1);
    connect(spectrumView3D, SIGNAL(zoomed()), this, SLOT(updateContourZoom()));
}

void workspace::highlightContour()
{
    deselectContour();
    QStringList strList;
    for(int i(0); i<ui->peaklistTable->selectedItems().count(); i++)
    {
        if(ui->peaklistTable->selectedItems().at(i)->column()==0)
            strList << ui->peaklistTable->item(ui->peaklistTable->selectedItems().at(i)->row(),4)->text();
    }
    if(strList.count()>0)
        contourPlot->highlightItems(strList);
}

void workspace::deselectContour()
{
    QVector<QVector<QString> >peaklist;
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        QVector<QString> peakVec;
        for(int j(0); j<9; ++j)
        {
            if(j==3)
                continue;
            peakVec.push_back(ui->peaklistTable->item(i,j)->text());
        }
        peaklist.push_back(peakVec);
    }
    if(peaklist.count()>0)
        contourPlot->clearSelectedItems(peaklist);
}

void workspace::highlightContourFromIdx(QString peakidx)
{
    if(peakidx == "DESELECT")
    {
        ui->peaklistTable->clearSelection();
        return;
    }
    if(!ctrlPressed && !contourPlot->selectingFromRect)
        deselectTable();

    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        if(peakidx==ui->peaklistTable->item(i,4)->text())
        {
            if(ui->peaklistTable->item(i,0)->isSelected() && !contourPlot->selectingFromRect)
                ui->peaklistTable->item(i,0)->setSelected(false);
            else
                ui->peaklistTable->item(i,0)->setSelected(true);
            break;
        }
    }
}

void workspace::syncCtrl(bool pressed)
{
    ctrlPressed = pressed;
    spectrumView3D->ctrlPressed = pressed;
}

void workspace::updatePeakListFromContour(QString peakidx, QPointF point)
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    contourPlot->replotContour = false;
    storeState();
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        if(peakidx==ui->peaklistTable->item(i,4)->text())
        {
            ui->peaklistTable->item(i,2)->setText(QString::number(point.x()));
            ui->peaklistTable->item(i,1)->setText(QString::number(point.y()));
            QPoint closestPoint(0,0);
            double diff(9e99);
            for(int k(0); k<spectrumView3D->spectrum_renderPlotProxy->rowCount(); k++)
                for(int j(0); j<spectrumView3D->spectrum_renderPlotProxy->columnCount(); j++)
                {
                    float val(qSqrt(qPow(point.x()-spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x(),2) + qPow(point.y() - spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().z(),2)));
                    if(diff > val)
                    {
                        diff = val;
                        closestPoint = QPoint(k,j);
                    }
                }
            ui->peaklistTable->item(i,3)->setText(QString::number(spectrumView3D->spectrum_renderPlotProxy->itemAt(closestPoint)->y()));
            updatePeakLabels(i,2);
            break;
        }
    }
    contourPlot->replotContour = true;
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    ui->peaklistTable->clearSelection();
}

void workspace::setupContourLevels(double sDev, double minZ,double maxZ)
{
    bool posLock(ui->lockContourPos->isChecked());
    bool negLock(ui->lockContourNeg->isChecked());
    if(!posLock)
    {
        ui->contourMinIntensity->setText(QString::number(sDev));
        ui->contourLevels->setValue(10);
        QString val(QString::number((maxZ-sDev)/10.0));
        if(val<0)
            val ="1000.0";
        ui->contourStep->setText(val);
    }
    if(!negLock)
    {
        ui->contourMinIntensityMin->setText(QString::number(-sDev));
        ui->contourLevelsMin->setValue(10);
        QString val(QString::number((minZ+sDev)/10.0));
        if(val>0)
            val ="-1000.0";
        ui->contourStepMin->setText(val);
    }
    if(!negLock && !posLock)
    {
        bool ok, ok2;
        double val1, val2;
        val1=ui->contourStepMin->text().toDouble(&ok);
        val2=ui->contourStep->text().toDouble(&ok2);
        if(!ok || !ok2)
            return;
        if(val1*val1<val2*val2)
            ui->contourStepMin->setText("-"+ui->contourStep->text());
        else
            ui->contourStep->setText(ui->contourStepMin->text().mid(1));
    }
}

void workspace::on_contourPosColorButton_clicked()
{
    QColor tmpColor(QColorDialog::getColor());
    if(!tmpColor.isValid())
        return;
    posContourColor = tmpColor;
    contourPlot->posContourColor = tmpColor;
    contourPlot->updateContourColors();
    QString sheet("QPushButton#contourPosColorButton {\nbackground-color: ");
    QString stle("rgb(%1, %2, %3);");
    sheet += stle.arg(tmpColor.red()).arg(tmpColor.green()).arg((tmpColor.blue()));
    sheet += "\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}\nQPushButton#contourPosColorButton:pressed {\n border-style: inset;\n}\nQPushButton#contourPosColorButton:hover:!pressed {\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}";
    ui->contourPosColorButton->setStyleSheet(sheet);
}

void workspace::on_contourNegColorButton_clicked()
{
    QColor tmpColor(QColorDialog::getColor());
    if(!tmpColor.isValid())
        return;
    negContourColor = tmpColor;
    contourPlot->negContourColor = tmpColor;
    contourPlot->updateContourColors();
    QString sheet("QPushButton#contourNegColorButton {\nbackground-color: ");
    QString stle("rgb(%1, %2, %3);");
    sheet += stle.arg(tmpColor.red()).arg(tmpColor.green()).arg((tmpColor.blue()));
    sheet += "\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}\nQPushButton#contourPosColorButton:pressed {\n border-style: inset;\n}\nQPushButton#contourPosColorButton:hover:!pressed {\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}";
    ui->contourNegColorButton->setStyleSheet(sheet);
}

void workspace::defineOverlap()
{
    displayInformation("Select a minimum of two peaks and press Ctrl+O", true, 0);

    if(ui->workspaceTab->currentIndex()!=1 || ui->peaklistTable->selectedItems().count()==0)
        return;
    int count(0);
    for(int i(0); i<ui->peaklistTable->selectedItems().count(); i++)
    {
        if(ui->peaklistTable->selectedItems().at(i)->column()==0)
            count++;
        else if(i==ui->peaklistTable->selectedItems().count()-1)
            return;
        if(count==2)
            break;
    }
    if(count<2)
        return;
    QString str("");
    for(int i(0); i<ui->peaklistTable->selectedItems().count(); i++)
        if(ui->peaklistTable->selectedItems().at(i)->column()==0)
            str+=" "+ui->peaklistTable->selectedItems().at(i)->text();
    displayInformation("Added overlap to the parameter browser", true, 0);

    QString currentText(paramEdit->toPlainText());
    QStringList lines = currentText.split("\n");
    paramEdit->clear();
    for(int i(0); i<lines.count(); i++)
    {
        bool autoOl(false);
        bool addOl(false);
        string str(lines.at(i).toStdString());
        istringstream iss(str);
        string sub;
        while(iss >> sub)
        {
            toUpper(sub);
            if(addOl)
            {
                if(sub == "AUTO")
                    autoOl = true;
                else
                    addOl = false;
            }
            if(sub=="OVERLAP" || sub=="-OVERLAP")
                addOl = true;
            if(autoOl)
                break;
        }
        if(!autoOl)
            paramEdit->append(lines.at(i));
    }
    paramEdit->append("-overlap"+str);
}

void workspace::setupCompleter(bool startUp)
{
    QStringList list;
    for(int i(0); i<ui->spectrumList->count(); i++)
        list << ui->spectrumList->item(i)->text();
    for(int i(0); i<ui->peaklistList->count(); i++)
        list << ui->peaklistList->item(i)->text();
    for(int i(0); i<ui->otherList->count(); i++)
        list << ui->otherList->item(i)->text();
    QFile file(":/completer_lib.txt");
    if (!file.open(QFile::ReadOnly))
        return;
    while (!file.atEnd())
    {
        QByteArray line = file.readLine();
        if (!line.isEmpty())
            list << line.trimmed();
    }
    file.close();
    for(int i(0); i<ui->peaklistTable->rowCount(); ++i)
        list << ui->peaklistTable->item(i,0)->text().trimmed();
    if(!startUp)
        completer->deleteLater();
    completer = new customCompleter(list, 0);
    completer->setCaseSensitivity(Qt::CaseInsensitive);
    if(startUp)
    {
        paramEdit = new completerTextEdit();
        paramEdit->setFont(QFont("Courier", 11));
        ui->paramLayout->addWidget(paramEdit);
        disconnect(paramEdit);
        connect(paramEdit, SIGNAL(cursorPositionChanged()), this, SLOT(checkIntegrationHelp()));
        connect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
    }
    paramEdit->setCompleter(completer);
}

bool workspace::errorCheckParamFile()
{
    ui->integrationBrowser->clear();
    ui->warningPeaklistLabel->clear();
    ui->warningProcparLabel->clear();
    ui->warningSpectrumLabel->clear();
    QStringList list;
    bool error(false);
    //QString errorHtml = "<p style=\"color: #000000; background-color: #ffffff\"></p><p style=\"color: #ffffff; background-color: #ff0000\">%1</p><p style=\"color: #000000; background-color: #ffffff\"></p>";
    QString errorHtml = "<span style=\"color: #000000; background-color: #ffffff\"></span><span style=\"color: #ffffff; background-color: #ff0000\">%1</span><span style=\"color: #000000; background-color: #ffffff\"></span>";
    QFile file(":/completer_lib.txt");
    if (!file.open(QFile::ReadOnly))
        return true;
    while (!file.atEnd())
    {
        QByteArray line = file.readLine();
        if (!line.isEmpty())
            list << line.trimmed();
    }
    file.close();

    QSize size;
    size.setHeight(20);
    size.setWidth(20);
    movie->setScaledSize(size);
    bool movStart(false);
    QFile param(pintTemplate.paramFile);
    if (!param.open(QIODevice::ReadOnly | QIODevice::Text))
        return true;
    paramEdit->clear();
    QTextCursor cursor = paramEdit->textCursor();
    cursor.movePosition(QTextCursor::End);
    paramEdit->setTextCursor(cursor);
    bool procpar(false);
    bool spectrum(false);
    bool peaklist(false);
    while (!param.atEnd())
    {
        QByteArray line = param.readLine();
        QString str(line.trimmed());
        if(str.length()>0)
        {
            if(str[0]!='#')
            {
                if(str[0]!='-')
                    str = "-" + str;
                for(int i(0); i<list.count(); i++)
                {
                    if(list.at(i).length()<=str.mid(1).length())
                    {
                        if(list.at(i).toUpper()==str.mid(1,list.at(i).length()).toUpper())
                        {
                            if(str.mid(1,list.at(i).length()).toUpper() == "SPECTRUM" ||
                                    str.mid(1,list.at(i).length()).toUpper() == "SPECTRUMLIST")
                            {
                                spectrum = true;
                                if(ui->spectrumDefineBox->currentIndex() != 1)
                                {
                                    ui->warningSpectrumLabel->setMovie(movie);
                                    movStart=true;
                                    ui->integrationBrowser->append("Either specify the spectrum in the \"Spectrum\" box or in the \"Parameter browser\", but not in both.\n");
                                    error = true;
                                    str = errorHtml.arg(str);
                                }
                            }
                            if(str.mid(1,list.at(i).length()).toUpper() == "PEAKLIST")
                            {
                                peaklist = true;
                                if(ui->peaklistDefineBox->currentIndex() != 1)
                                {
                                    ui->warningPeaklistLabel->setMovie(movie);
                                    movStart=true;
                                    ui->integrationBrowser->append("Either specify the peaklist in the \"Peaklist\" box or in the \"Parameter browser\", but not in both.\n");
                                    error = true;
                                    str = errorHtml.arg(str);
                                }
                            }
                            if(str.mid(1,list.at(i).length()).toUpper() == "PROCPAR")
                            {
                                procpar = true;
                                if(ui->procparDefineBox->currentIndex() != 1)
                                {
                                    ui->warningProcparLabel->setMovie(movie);
                                    movStart=true;
                                    if(ui->procparDefineBox->currentIndex() == 0)
                                        ui->integrationBrowser->append("The \"Array file\" box has the setting that no array file will be used.\n");
                                    else
                                        ui->integrationBrowser->append("Specify the procpar file in the \"Parameter browser\" or in the \"Array file\" box.\n");
                                    error = true;
                                    str = errorHtml.arg(str);
                                }
                            }
                            if(str.mid(1,list.at(i).length()).toUpper() == "VDLIST")
                            {
                                procpar = true;
                                if(ui->procparDefineBox->currentIndex() != 1)
                                {
                                    ui->warningProcparLabel->setMovie(movie);
                                    movStart=true;
                                    if(ui->procparDefineBox->currentIndex() == 0)
                                        ui->integrationBrowser->append("The \"Array file\" box has the setting that no array file will be used.\n");
                                    else
                                        ui->integrationBrowser->append("Specify the vdlist file in the \"Parameter browser\" or in the \"Array file\" box.\n");
                                    error = true;
                                    str = errorHtml.arg(str);
                                }
                            }
                            break;
                        }
                    }
                    if(i==list.count()-1)
                    {
                        error = true;
                        ui->integrationBrowser->append("\""+str+"\" unsupported option!");
                        str = errorHtml.arg(str);
                    }
                }
            }
        }
        paramEdit->append(str.trimmed());
    }
    param.close();
    if(ui->spectrumDefineBox->currentIndex() == 0 && loadedSpectrum=="")
    {
        ui->warningSpectrumLabel->setMovie(movie);
        movStart=true;
        ui->integrationBrowser->append("No spectrum has been loaded in the \"Spectra\" tab.\n");
        error = true;
    }
    if(ui->peaklistDefineBox->currentIndex() == 0 && (loadedSpectrum=="" || ui->peaklistTable->rowCount()==0))
    {
        ui->warningPeaklistLabel->setMovie(movie);
        movStart=true;
        ui->integrationBrowser->append("No peaklist has been loaded in the \"Spectra\" tab.\n");
        error = true;
    }
    if(!procpar &&  ui->procparDefineBox->currentIndex() == 1)
    {
        ui->warningProcparLabel->setMovie(movie);
        movStart=true;
        ui->integrationBrowser->append("Specify the array file in the \"Parameter browser\" or in the \"Array file\" box.\n");
        error = true;
    }
    if(!spectrum && ui->spectrumDefineBox->currentIndex()==1)
    {
        ui->warningSpectrumLabel->setMovie(movie);
        movStart=true;
        ui->integrationBrowser->append("Specify the spectrum in the \"Parameter browser\" or in the \"Spectrum\" box.\n");
        error = true;
    }
    if(!peaklist && ui->peaklistDefineBox->currentIndex()==1)
    {
        ui->warningPeaklistLabel->setMovie(movie);
        movStart=true;
        ui->integrationBrowser->append("Specify the peaklist in the \"Parameter browser\" or in the \"Peaklist\" box.\n");
        error = true;
    }
    if(movStart)
        movie->start();
    QFile paramOut(pintTemplate.paramFile);
    if (!paramOut.open(QIODevice::WriteOnly | QIODevice::Text))
        return true;
    QTextStream out(&paramOut);
    out << paramEdit->toPlainText();
    paramOut.close();
    if(!error)
    {
        QString fnam(pintTemplate.paramFile+".tmp");
        if (QFile::exists(fnam))
            QFile::remove(fnam);
        QFile::copy(pintTemplate.paramFile, fnam);
        QFile pApp(fnam);
        if(pApp.open(QIODevice::WriteOnly | QIODevice::Append))
        {
            QTextStream out2(&pApp);
            if(!peaklist)
            {
                if(ui->peaklistDefineBox->currentIndex() == 0)
                    out2 << (QString) ("\n-peaklist \"" + pintTemplate.integratePeakList + "\"");
                else
                    out2 << (QString) ("\n-peaklist \"" + ui->peaklistDefineBox->currentText() + "\"");
            }
            if(!spectrum)
            {
                if(ui->spectrumDefineBox->currentIndex() == 0)
                    out2 << (QString) ("\n-spectrum \"" + loadedSpectrum + "\"");
                else
                    out2 << (QString) ("\n-spectrum \"" + ui->spectrumDefineBox->currentText() + "\"");
            }
            if(!procpar)
            {
                if(ui->procparDefineBox->currentIndex()>1)
                {
                    if(ui->procparRadioButton->isChecked())
                        out2 << (QString) ("\n-procpar \"" + ui->procparDefineBox->currentText()+ "\"");
                    else
                        out2 << (QString) ("\n-vdlist \"" + ui->procparDefineBox->currentText())+ "\"";
                }
            }
            pApp.close();
        }
    }
    return error; //No error
}

void workspace::checkIntegrationHelp()
{
    disconnect(paramEdit, SIGNAL(cursorPositionChanged()), this, SLOT(checkIntegrationHelp()));
    QTextCursor cursor(paramEdit->textCursor());
    cursor.select(QTextCursor::WordUnderCursor);
    const QString sel = cursor.selectedText();
    if(sel.length()==0)
    {
        connect(paramEdit, SIGNAL(cursorPositionChanged()), this, SLOT(checkIntegrationHelp()));
        return;
    }
    QStringList list;
    QFile file(":/completer_lib.txt");
    if (!file.open(QFile::ReadOnly))
    {
        connect(paramEdit, SIGNAL(cursorPositionChanged()), this, SLOT(checkIntegrationHelp()));
        return;
    }
    while (!file.atEnd())
    {
        QByteArray line = file.readLine();
        if (!line.isEmpty())
            list << line.trimmed();
    }
    file.close();
    for(int i(0); i<list.count(); i++)
    {
        if(sel.toUpper() == list.at(i).toUpper() || sel.toUpper() == "-"+list.at(i).toUpper())
        {
            integrationSyntaxHelp(i);
            break;
        }
    }
    connect(paramEdit, SIGNAL(cursorPositionChanged()), this, SLOT(checkIntegrationHelp()));
}

void workspace::integrationSyntaxHelp(int index)
{
    integrationSyntaxMessages msg;
    displayInformation(msg.getMessage(index), false, 1);
}

void workspace::readParamFile()
{
    QFile file(pintTemplate.paramFile);
    if (!file.open(QFile::ReadOnly))
        return;
    while (!file.atEnd())
    {
        QByteArray line = file.readLine();
        if (!line.isEmpty())
            paramEdit->append(line.trimmed());
    }
    file.close();
}

void workspace::on_integrateButton_clicked()
{
    integrate();
}

void workspace::loadIntegrationTemplates()
{
    integrationTemplatesClass itc;
    tmpltVec = itc.tmpltVec;
    for(int i(0); i<itc.list.size(); i++)
        ui->templateList->addItem(itc.list.at(i));
    defaultTemplateCount = itc.defaultTemplateCount;
    disconnect(ui->templateList, SIGNAL(doubleClicked(QModelIndex)), this, SLOT(readIntegrationTemplate(QModelIndex)));
    connect(ui->templateList, SIGNAL(doubleClicked(QModelIndex)), this, SLOT(readIntegrationTemplate(QModelIndex)));
}

void workspace::readIntegrationTemplate(QModelIndex item)
{
    disconnect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
    if(parameterEditChanged)
    {
        QMessageBox dlg;
        dlg.setText("Loading a template will discard any changes.");
        dlg.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        dlg.setDefaultButton(QMessageBox::Cancel);
        dlg.setWindowTitle("PINT");
        int ret = dlg.exec();
        switch (ret)
        {
        case QMessageBox::Ok: break;
        default:
            connect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
            return;
        }
    }
    paramEdit->clear();
    for(int i(1); i<tmpltVec.at(item.row()).count(); i++)
        paramEdit->append(tmpltVec.at(item.row()).at(i));
    parameterEditChanged = false;
    connect(paramEdit, SIGNAL(textChanged()), this, SLOT(toggleParamBool()));
}

void workspace::toggleParamBool()
{
    parameterEditChanged = true;
    ui->warningIntegrationLabel->clear();
}

void workspace::on_saveTemplateButton_clicked()
{
    bool ok;
    QString fileName = QInputDialog::getText(this, tr("PINT"),
                                             tr("Template name:"), QLineEdit::Normal,
                                             "", &ok);
    if (ok && !fileName.isEmpty())
    {
        QString dirName(qApp->applicationDirPath() + "/templates");
        QDir dir(dirName);
        if (!dir.exists()) dir.mkpath(".");
        QString str(fileName);
        str = str.simplified();
        str.replace( " ", "" );
        dirName+="/" + str + ".tmplt";
        bool ow(false);
        if(fileExists(dirName))
        {
            QMessageBox dlg;
            dlg.setText("The template name already exists. Do you want to overwrite it?");
            dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
            dlg.setDefaultButton(QMessageBox::No);
            dlg.setWindowTitle("PINT");
            int ret = dlg.exec();
            switch (ret)
            {
            case QMessageBox::No:
                return;
            default: QFile::remove(dirName); ow=true; break;
            }
        }
        QFile file(dirName);
        if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QMessageBox::StandardButton dlg;
            dlg = QMessageBox::warning(this, "PINT", "PINT cannot write to the application directory. Ensure that the application directories are not write protected and restart PINT.", QMessageBox::Ok);
            Q_UNUSED(dlg)
            return;
        }
        QTextStream out(&file);
        out<<fileName<<"\n";
        out<<paramEdit->toPlainText();
        file.close();
        QStringList lst;
        lst << fileName;
        lst << paramEdit->toPlainText();
        if(ow)
        {
            for(int j(0); j<ui->templateList->count(); ++j)
            {
                if(fileName == ui->templateList->item(j)->text())
                {
                    tmpltVec[j] = lst;
                    break;
                }
            }
        }
        else
        {
            tmpltVec.push_back(lst);
            ui->templateList->addItem(fileName);
        }
    }
}

void workspace::on_removeTemplateButton_clicked()
{
    if(ui->templateList->selectedItems().count()==1)
    {
        for(int i(defaultTemplateCount); i<ui->templateList->count(); i++)
        {
            if(ui->templateList->item(i)->isSelected())
            {
                QMessageBox dlg;
                dlg.setText("Do you want to delete the selected template?");
                dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                dlg.setDefaultButton(QMessageBox::No);
                dlg.setWindowTitle("PINT");
                int ret = dlg.exec();
                switch (ret)
                {
                case QMessageBox::Yes: break;
                default: return;
                }
                QString str(ui->templateList->item(i)->text());
                str = str.simplified();
                str.replace( " ", "" );
                QString dirName(qApp->applicationDirPath() + "/templates/" + str + ".tmplt");
                if(fileExists(dirName))
                    QFile::remove(dirName);
                qDeleteAll(ui->templateList->selectedItems());
                tmpltVec.remove(i);
                return;
            }
        }
    }
}

void workspace::on_labelsToggleButton_clicked()
{
    if(labelsToggled)
        labelsToggled = false;
    else
        labelsToggled = true;
    contourPlot->toggleLabels(labelsToggled);
}

void workspace::flipZAxis()
{
    //To enable easier viewing of negative intensities, this function flips the z-axis values
    if(!spectrumView3D->spectrum_graph->axisY()->reversed())
        spectrumView3D->spectrum_graph->axisY()->setReversed(true);
    else
        spectrumView3D->spectrum_graph->axisY()->setReversed(false);
}

void workspace::adjustZAxis()
{
    //Scale intensity axis to user defined settings
    bool ok(true), ok2(true);
    double zMin(ui->zMinEdit->text().toDouble(&ok)), zMax(ui->zMaxEdit->text().toDouble(&ok2));
    if(!ok || !ok2) return;
    if(zMin>=zMax) return;
    spectrumView3D->spectrum_graph->axisY()->setMin(zMin);
    spectrumView3D->spectrum_graph->axisY()->setMax(zMax);
}

void workspace::autoAdjustZAxis()
{
    ui->zMinEdit->setText(QString::number(cutoffSliderMin));
    ui->zMaxEdit->setText(QString::number(cutoffSliderMax));
    spectrumView3D->spectrum_graph->axisY()->setMin(cutoffSliderMin);
    spectrumView3D->spectrum_graph->axisY()->setMax(cutoffSliderMax+spectrumView3D->marginal);
}

void workspace::viewRegionInSpectrum()
{
    if(loadedSpectrum!="")
    {
        disconnect(contourPlot, SIGNAL(contourZoomed(float,float,float,float)), this, SLOT(update3DZoom(float,float,float,float)));
        disconnect(spectrumView3D, SIGNAL(zoomed()), this, SLOT(updateContourZoom()));
        setTabFromShortcut(1);
        updateContourZoomManual(plotView3D->plot_graph->axisZ()->min(), plotView3D->plot_graph->axisZ()->max(), plotView3D->plot_graph->axisX()->min(), plotView3D->plot_graph->axisX()->max());
        spectrumView3D->setAxisF1Range(plotView3D->plot_graph->axisZ()->min(), plotView3D->plot_graph->axisZ()->max());
        spectrumView3D->setAxisF2Range(plotView3D->plot_graph->axisX()->min(), plotView3D->plot_graph->axisX()->max());
        connect(contourPlot, SIGNAL(contourZoomed(float,float,float,float)), this, SLOT(update3DZoom(float,float,float,float)));
        connect(spectrumView3D, SIGNAL(zoomed()), this, SLOT(updateContourZoom()));
    }
    else
        displayInformation("No spectrum is loaded in the spectrum viewer", true, 2);
}

void workspace::openFileViewer(QListWidgetItem* item)
{
    QFile file(item->text());
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        errMsg="Could not open the file";
        displayError();
        return;
    }
    file.close();
    fileViewer fVDialog(0,item->text());
    fVDialog.setWindowFlags(Qt::WindowTitleHint | Qt::WindowCloseButtonHint);
    fVDialog.setWindowModality(Qt::ApplicationModal);
    if(fVDialog.exec())
    {
        return;
    }
}

void workspace::on_peaklistFormatButton_clicked()
{
    editPeaklistFormat();
}

void workspace::editPeaklistFormat()
{
    //Specify peaklist format
    peaklistDialog plDialog;
    plDialog.setWindowFlags(Qt::WindowTitleHint | Qt::WindowCloseButtonHint);
    plDialog.setWindowModality(Qt::ApplicationModal);
    if(plDialog.exec())
    {
        peaklistFormat[0] = plDialog.header;
        peaklistFormat[1] = plDialog.assignment;
        peaklistFormat[2] = plDialog.f1;
        peaklistFormat[3] = plDialog.f2;
    }
}

void workspace::initializePeaklistFormat()
{
    peaklistFormat.push_back(2);
    peaklistFormat.push_back(1);
    peaklistFormat.push_back(2);
    peaklistFormat.push_back(3);

    QString fname(qApp->applicationDirPath() + "/defaultPeaklistTemplate.dat");
    if(fileExists(fname))
    {
        QFile file(fname);
        bool ok(true);
        QVector<int> templateVec;
        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            int count(0);
            QString line = file.readLine();
            while (!line.isNull())
            {
                if(count<4)
                {
                    templateVec.push_back(line.toInt(&ok));
                    if(!ok)
                        break;
                }
                else
                    break;
                count++;
                line = file.readLine();
            }
            file.close();
            if(ok)
            {
                peaklistFormat[0] = templateVec.at(0);
                peaklistFormat[1] = templateVec.at(1);
                peaklistFormat[2] = templateVec.at(2);
                peaklistFormat[3] = templateVec.at(3);
            }
        }
    }
}

void workspace::initializeAutomaticLabelFormat()
{
    QString fname(qApp->applicationDirPath() + "/defaultAutomaticLabelFormat.dat");
    if(fileExists(fname))
    {
        QFile file(fname);
        bool ok(true);
        QString pref("");
        QString suff("");
        int base(0);
        int incr(1);
        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            int count(0);
            QString line = file.readLine();
            while (!line.isNull())
            {
                switch(count)
                {
                case 0:
                    base = line.toInt(&ok);
                    if(!ok)
                    {
                        file.close();
                        return;
                    }
                    break;
                case 1:
                    incr = line.toInt(&ok);
                    if(!ok)
                    {
                        file.close();
                        return;
                    }
                    else if(incr<1)
                    {
                        file.close();
                        return;
                    }
                    break;
                case 2:
                    pref = line;
                    break;
                case 3:
                    suff = line;
                    break;
                default:
                    break;
                }

                count++;
                line = file.readLine();
            }
            file.close();
            if(ok && count>3)
            {
                autBase = base;
                autIncrement = incr;
                autPrefix = pref.trimmed();
                autSuffix = suff.trimmed();
            }
        }
    }
}

void workspace::tutorialTriggered()
{
    Player *play = new Player();
    play->setWindowModality(Qt::ApplicationModal);
    play->setAttribute(Qt::WA_DeleteOnClose);
    play->showMaximized();
}

void workspace::helpTriggered()
{
    QFile HelpFile(":/User_Manual.pdf");
    HelpFile.copy(qApp->applicationDirPath().append("/User_Manual.pdf"));
    QDesktopServices::openUrl(QUrl::fromLocalFile(qApp->applicationDirPath().append("/User_Manual.pdf")));
}

void workspace::on_savePeaklistButton_clicked()
{
    if(ui->peaklistTable->rowCount()==0)
        return;
    QString types("Text files (*.txt)");
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save Peaklist"),
                                                    previousDir, tr(types.toStdString().c_str()));
    if(fileName!="")
    {
        QFile file(fileName);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
            return;
        QTextStream out(&file);
        for(int j(0); j<ui->peaklistTable->rowCount(); j++)
        {
            for(int k(0); k<3; k++)
            {
                out<<ui->peaklistTable->item(j,k)->text();
                if(k<2)
                    out<<"\t";
                else if(j<ui->peaklistTable->rowCount()-1)
                    out<<"\n";
            }
        }
        file.close();
    }
}

void workspace::toggleInfoBrowser()
{
    fitInfoBrowser->setVisible(!fitInfoBrowser->isVisible());
}

void workspace::on_spectrumDefineBox_currentIndexChanged(int index)
{
    Q_UNUSED(index)
    ui->warningSpectrumLabel->clear();
}

void workspace::on_peaklistDefineBox_currentIndexChanged(int index)
{
    ui->warningPeaklistLabel->clear();
    if(index>1)
        ui->viewPeaklistButton->setEnabled(true);
    else
        ui->viewPeaklistButton->setEnabled(false);
}

void workspace::on_procparDefineBox_currentIndexChanged(int index)
{
    ui->warningProcparLabel->clear();
    if(index>1)
        ui->viewProcparButton->setEnabled(true);
    else
        ui->viewProcparButton->setEnabled(false);
}

void workspace::on_viewPeaklistButton_clicked()
{
    viewFromBrowser(0);
}

void workspace::on_viewProcparButton_clicked()
{
    viewFromBrowser(1);
}

void workspace::viewFromBrowser(int target)
{
    QString name("");
    if(target == 0)
    {
        if(ui->peaklistDefineBox->currentIndex()>1)
            name = ui->peaklistDefineBox->currentText();
        else return;
    }
    else
    {
        if(ui->procparDefineBox->currentIndex()>1)
            name = ui->procparDefineBox->currentText();
        else return;
    }
    if(name=="")
        return;
    fileViewer fVDialog(0, name);
    fVDialog.setWindowFlags(Qt::WindowTitleHint | Qt::WindowCloseButtonHint);
    fVDialog.setWindowModality(Qt::ApplicationModal);
    if(fVDialog.exec())
    {
        return;
    }
}

void workspace::on_loadPeaklistIntegrationButton_clicked()
{
    QFile file(pintTemplate.outDirectory+"/peaklist.txt");
    if(!file.exists() || loadedSpectrum=="")
        return;
    QMessageBox dlg;
    dlg.setText("Loading the peaklist from the performed integration\nwill discard any peaks in the current peaklist table.\nDo you want to continue?");
    dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
    dlg.setDefaultButton(QMessageBox::Cancel);
    dlg.setWindowTitle("PINT");
    int ret = dlg.exec();
    if(ret==QMessageBox::Cancel) return;
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    spectrumView3D->clearSelectedItems();
    spectrumView3D->selectionVector.clear();
    ui->peaklistTable->clearSelection();
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        spectrumView3D->deleteFromSelectionVector("peak" + ui->peaklistTable->item(i,4)->text());
        spectrumView3D->removeCustomLabel(ui->peaklistTable->item(i,4)->text().toInt());
        ui->peaklistTable->removeRow(i);
        i--;
    }
    peakId=0;
    ui->peaklistTable->clearSelection();
    contourPlot->detachAll();
    QApplication::processEvents();
    storeState();
    QApplication::processEvents();

    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));

    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        errMsg="Could not open the peaklist";
        storeState();
        displayError();
        connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
        connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
        connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
        return;
    }
    QTextStream in(&file);
    generateIntensities = false;
    QString line("not_null");
    bool readAgain(true);
    errMsg="";
    line = in.readLine();
    int errCount(0);
    while(!line.isNull())
    {
        if(readAgain)
        {
            line = in.readLine();
            readAgain=false;
            continue;
        }
        istringstream iss(line.toStdString().c_str());
        string sub;
        int col(1);
        bool importOk(false);
        QString ass(""), f1(""), f2("");
        while(iss >> sub)
        {
            if(1 == col) //assignment
                ass = QString::fromStdString(sub.c_str());
            else if(2 == col) //f1
                f1 = QString::number(atof(sub.c_str()));
            else if(3 == col) //f2
                f2 = QString::number(atof(sub.c_str()));
            if(ass!="" && f1!="" && f2!="")
            {
                bool convOk;
                f1.toDouble(&convOk);
                if(!convOk)
                    break;
                f2.toDouble(&convOk);
                if(!convOk)
                    break;
                importOk = true;
                ui->peaklistTable->insertRow(ui->peaklistTable->rowCount());
                for(int i(0); i<3; i++)
                {
                    QTableWidgetItem *item = new QTableWidgetItem;
                    switch(i)
                    {
                    case 0:
                    {
                        item->setText(ass);
                        break;
                    }
                    case 1:
                    {
                        item->setText(f1);
                        break;
                    }
                    case 2:
                    {
                        item->setText(f2);
                        break;
                    }
                    default: break;
                    }
                    ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,i,item);
                }
                break;
            }
            col++;
        }
        if(!importOk)
        {
            errCount++;
            if(errCount<6)
                errMsg+= line + "\n";
            line = in.readLine();
        }
        else
        {
            generateIntensities = true;
            QTableWidgetItem *item0 = new QTableWidgetItem;
            item0->setText("0");
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,3,item0);
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText(QString::number(peakId++));
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 4, item);
            QTableWidgetItem *item2 = new QTableWidgetItem;
            foldedClass fold(isPeakFolded(ui->peaklistTable->item(ui->peaklistTable->rowCount()-1,1)->text(),ui->peaklistTable->item(ui->peaklistTable->rowCount()-1,2)->text()));
            item2->setText(QString::number(fold.foldedF1));
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 5, item2);
            QTableWidgetItem *item5 = new QTableWidgetItem;
            item5->setText(QString::number(fold.foldedF2));
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 6, item5);
            QTableWidgetItem *item3 = new QTableWidgetItem;
            item3->setText(QString::number(fold.foldedF1val));
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 7, item3);
            QTableWidgetItem *item4 = new QTableWidgetItem;
            item4->setText(QString::number(fold.foldedF2val));
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 8, item4);
            line = in.readLine();
        }
    }
    file.close();

    if(errCount>0)
    {
        errMsg = "Could not read data from the integration peaklist";
        displayError();
    }
    ui->peaklistTable->horizontalHeader()->setStretchLastSection(true);

    if(ui->peaklistTable->rowCount()>0)
    {
        createPeakLabels(0);
        readContourPeaklist(0);
        storeState();
    }
    else if(errCount == 0 && ui->peaklistTable->rowCount()==0)
    {
        errMsg = "No data to read from the integration peaklist.";
        displayError();
    }

    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    spectrumView3D->exitMoveMode();
    contourPlot->exitMoveMode();
}

QString workspace::randomTip()
{
    QString str("");
    int high(5); //Number of messages - 1
    int msg(qrand() % (high + 1));
    QString sc;
    sc = "Ctrl+O";
    switch(msg)
    {
    case 0: str="Click with the middle mouse button to comment/uncomment a line in the parameter browser."; break;
    case 1: str="All peaks in the current peaklist in the \"Spectra\" tab can be accessed by the auto-completer."; break;
    case 2: str="Everytime a spectrum is loaded the calculated noise is used for the integration."; break;
    case 3: str="The easiest way to define overlaps is to select peaks in the \"Spectra\" tab and press " +sc+ " for each overlap."; break;
    case 4: str="All files used for plotting are accessible from the \"plot\" directory of the project."; break;
#ifdef Q_OS_MAC
    case 5: str="To quickly switch between tabs in the interface, use the fn+F1-F7 keys."; break;
#else
    case 5: str="To quickly switch between tabs in the interface, use the F1-F7 keys."; break;
#endif
    default: str=""; break;
    }
    return str;
}

void workspace::handleSaveType(int sender)
{
    disconnect(ui->fitPng, SIGNAL(toggled(bool)), plotSignalMapperType, SLOT(map()));
    disconnect(ui->fitPdf, SIGNAL(toggled(bool)), plotSignalMapperType, SLOT(map()));
    if(sender)
    {
        ui->fitPng->setChecked(true);
        ui->fitPdf->setChecked(false);
    }
    else
    {
        ui->fitPng->setChecked(false);
        ui->fitPdf->setChecked(true);
    }

    connect(ui->fitPng, SIGNAL(toggled(bool)), plotSignalMapperType, SLOT(map()));
    connect(ui->fitPdf, SIGNAL(toggled(bool)), plotSignalMapperType, SLOT(map()));
}
void workspace::handleSaveType2(int sender)
{
    disconnect(ui->plotPng, SIGNAL(toggled(bool)), plotSignalMapperType2, SLOT(map()));
    disconnect(ui->plotPdf, SIGNAL(toggled(bool)), plotSignalMapperType2, SLOT(map()));
    if(sender)
    {
        ui->plotPng->setChecked(true);
        ui->plotPdf->setChecked(false);
    }
    else
    {
        ui->plotPng->setChecked(false);
        ui->plotPdf->setChecked(true);
    }

    connect(ui->plotPng, SIGNAL(toggled(bool)), plotSignalMapperType2, SLOT(map()));
    connect(ui->plotPdf, SIGNAL(toggled(bool)), plotSignalMapperType2, SLOT(map()));
}

QString workspace::getFitQuality(QString fname)
{
    QString fit("N/A");
    fstream file;
    string fnam=pintTemplate.plotDirectory.toStdString()+"/"+fname.toStdString();
    file.open(fnam.c_str(), ios::in);

    if(file.is_open())
    {
        int sampleCountX(0);
        int sampleCountZ(0);
        int tmpCount(0);
        string last("");
        vector<vector<float> >dataVec;
        string line;
        while(getline(file, line))
        {
            vector<float> tmpVec;
            if(line=="")
                continue;
            istringstream iss(line);
            string sub;
            int counter(1);
            while(iss>>sub)
            {
                if(counter==1)
                {
                    if(last!=sub)
                    {
                        sampleCountX++;
                        if(sampleCountZ<2)
                            sampleCountZ=tmpCount+1;
                    }
                    else
                        tmpCount++;
                    tmpVec.push_back(atof(sub.c_str()));
                    last=sub;
                }
                else if(counter==2)
                    tmpVec.push_back(atof(sub.c_str()));
                else if(counter==3)
                    tmpVec.push_back(atof(sub.c_str()));
                else if(counter==4)
                    tmpVec.push_back(atof(sub.c_str()));
                else
                    break;
                counter++;
            }
            dataVec.push_back(tmpVec);
        }
        file.close();
        if(dataVec.size()<16 || sampleCountX<4 || dataVec.size()/(sampleCountX+1)<4)
            return fit;
        float tmpMinZ(9e99), tmpMaxZ(-9e99);
        for(unsigned int i(0); i<dataVec.size(); i++)
        {
            if(dataVec[i][2]>tmpMaxZ)
                tmpMaxZ=dataVec[i][2];
            if(dataVec[i][2]<tmpMinZ)
                tmpMinZ=dataVec[i][2];
            if(dataVec[i][3]>tmpMaxZ)
                tmpMaxZ=dataVec[i][3];
            if(dataVec[i][3]<tmpMinZ)
                tmpMinZ=dataVec[i][3];
            if(dataVec[i][2]-dataVec[i][3]>tmpMaxZ)
                tmpMaxZ=dataVec[i][2]-dataVec[i][3];
            if(dataVec[i][2]-dataVec[i][3]<tmpMinZ)
                tmpMinZ=dataVec[i][2]-dataVec[i][3];
        }
        float sampleMaxY(tmpMaxZ);
        float sampleMinY(tmpMinZ);
        int noisePoints(0);
        double valSum(.0);
        for (int i = 0 ; i <sampleCountZ; i++)
        {
            for (unsigned int j = i; j <dataVec.size(); j+=sampleCountZ) {
                double vMin(dataVec[j][3]);
                double vMax(dataVec[j][2]);
                if(vMax<vMin)
                {
                    double tmp(vMax);
                    vMax=vMin;
                    vMin=tmp;
                }
                double val(fabs((vMax-vMin)/(sampleMaxY-sampleMinY)));
                val*= (1.1 + fabs(dataVec[j][2])/(sampleMaxY-sampleMinY));
                if((fabs(dataVec[j][2])/(sampleMaxY-sampleMinY)) < 0.04)
                    noisePoints++;
                if(val>1.0)
                    val = 1.0;
                valSum+=val;
            }
        }
        valSum/=(dataVec.size()-noisePoints+1);
        if(valSum<0.05)
            fit= "✪✪✪✪";
        else if(valSum<0.1)
            fit= "✪✪✪";
        else if (valSum<0.15)
            fit= "✪✪";
        else
            fit= "✪";
    }
    return fit;
}

void workspace::on_defaultContentButton_clicked()
{
    if(!ui->workspaceTab->isTabEnabled(0))
        return;
    QMessageBox dlg;
    dlg.setText("Do you want to set the current content of the \"Parameter browser\" as default for newly created projects?");
    dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
    dlg.setDefaultButton(QMessageBox::Yes);
    dlg.setWindowTitle("PINT");
    int ret = dlg.exec();
    switch (ret)
    {
    case QMessageBox::Yes:
    {
        QFile file(qApp->applicationDirPath()+"/defaultParameterBrowser.txt");
        if(file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QTextStream out(&file);
            out << paramEdit->toHtml();
            file.close();
        }
        else
        {
            QMessageBox::StandardButton dlg;
            dlg = QMessageBox::warning(this, "PINT", "Could not save to the application directory.\nEnsure that the application directory is not write protected.", QMessageBox::Ok);
            if(dlg==QMessageBox::Ok)
                return;
        }
    }
    default:
        break;
    }
}

void workspace::importDefaultParameterEdit()
{
    QFile file(qApp->applicationDirPath()+"/defaultParameterBrowser.txt");
    if(file.exists())
    {
        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QTextStream in(&file);
            paramEdit->clear();
            paramEdit->append(in.readAll());
            file.close();
        }
    }
}

void workspace::pickPeaks(double minF1, double maxF1, double minF2, double maxF2)
{
    if(loadedSpectrum=="")
        return;
    QVector<QVector3D> maxVec;
    bool ok;
    float noise(ui->contourMinIntensity->text().toFloat(&ok));
    if(!ok) return;
    float minNoise(ui->contourMinIntensityMin->text().toFloat(&ok));
    if(!ok) return;
    bool overload(false);
    for(int k(1); k<spectrumView3D->spectrum_renderPlotProxy->rowCount()-1; ++k)
    {
        if(overload)
            break;
        if(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,0)->position().z()>maxF1 ||
                spectrumView3D->spectrum_renderPlotProxy->itemAt(k,0)->position().z()<minF1)
            continue;
        for(int j(1); j<spectrumView3D->spectrum_renderPlotProxy->columnCount()-1; ++j)
        {
            if(maxVec.size()>500)
            {
                overload=true;
                break;
            }
            if(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x()>maxF2 ||
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().x()<minF2)
                continue;
            if(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y() > noise &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j+1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j-1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j+1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j-1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j-1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()> spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j+1)->position().y())
                maxVec.push_back(QVector3D(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->x(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->y(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->z()));
            else if(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y() < minNoise &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j+1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j-1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k+1,j)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j+1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j-1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j-1)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j)->position().y() &&
                    spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->position().y()< spectrumView3D->spectrum_renderPlotProxy->itemAt(k-1,j+1)->position().y())
                maxVec.push_back(QVector3D(spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->x(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->y(),spectrumView3D->spectrum_renderPlotProxy->itemAt(k,j)->z()));
        }
    }
    if(overload)
    {
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT", "Peak picking was aborted as >500 peaks were detected.\nPlease adjust the tolerance of the peak picker by altering the intensity cutoff in the contour plot and try again.", QMessageBox::Ok);
        if(dlg==QMessageBox::Ok)return;
        return;
    }
    else if(maxVec.size()>100)
    {
        QMessageBox dlg;
        dlg.setText(QString::number(maxVec.size())+" new peaks will be added.\nTo adjust the tolerance of the peak picker, alter the intensity cutoff in the contour plot.\nDo you want to continue?");
        dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        dlg.setDefaultButton(QMessageBox::Yes);
        dlg.setWindowTitle("PINT");
        int ret = dlg.exec();
        switch (ret)
        {
        case QMessageBox::Yes:
            break;
        default:
            return;
        }
    }
    else if(maxVec.size()==0)
        return;
    int rowNo(ui->peaklistTable->rowCount());
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    generateIntensities = false;
    for(int u(0); u<maxVec.size(); ++u)
    {
        ui->peaklistTable->insertRow(ui->peaklistTable->rowCount());
        QString ass(getNextLabelName(1)), f1(QString::number(maxVec.at(u).z())), f2(QString::number(maxVec.at(u).x())), yInt((QString::number(maxVec.at(u).y())));
        for(int i(0); i<3; i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            switch(i)
            {
            case 0:
            {
                item->setText(ass);
                break;
            }
            case 1:
            {
                item->setText(f1);
                break;
            }
            case 2:
            {
                item->setText(f2);
                break;
            }
            default: break;
            }
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,i,item);
        }
        QTableWidgetItem *item0 = new QTableWidgetItem;
        item0->setText(yInt);
        ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,3,item0);
        QTableWidgetItem *item = new QTableWidgetItem;
        item->setText(QString::number(peakId++));
        ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 4, item);
        QTableWidgetItem *item2 = new QTableWidgetItem;
        foldedClass fold(isPeakFolded(ui->peaklistTable->item(ui->peaklistTable->rowCount()-1,1)->text(),ui->peaklistTable->item(ui->peaklistTable->rowCount()-1,2)->text()));
        item2->setText(QString::number(fold.foldedF1));
        ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 5, item2);
        QTableWidgetItem *item5 = new QTableWidgetItem;
        item5->setText(QString::number(fold.foldedF2));
        ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 6, item5);
        QTableWidgetItem *item3 = new QTableWidgetItem;
        item3->setText(QString::number(fold.foldedF1val));
        ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 7, item3);
        QTableWidgetItem *item4 = new QTableWidgetItem;
        item4->setText(QString::number(fold.foldedF2val));
        ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 8, item4);
    }

    ui->peaklistTable->horizontalHeader()->setStretchLastSection(true);
    createPeakLabels(rowNo);
    readContourPeaklist(rowNo);
    storeState();
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updateContourPlotLabels(int,int)));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(storeState()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightContour()));
}

void workspace::on_peaklistFormatButton2_clicked()
{
    editPeaklistFormat();
}

void workspace::on_centerPeakModeBox_currentIndexChanged(int index)
{
    if(index==1)
        displayInformation("The peak centering mode \"Overlapped peaks\" is optimized to center crowded regions.\nPeak positions will not be optimized prior centering the peaks.",false, 0);
    else
        displayInformation("The peak centering mode \"Resolved peaks\" is optimized to center resolved regions.\nPeak positions will be optimized by finding local maxima prior centering the peaks.",false, 0);
}
