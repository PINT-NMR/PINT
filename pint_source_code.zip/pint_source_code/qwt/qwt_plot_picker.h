#ifndef QWT_PLOT_PICKER_H
#define QWT_PLOT_PICKER_H

#include "qwt_global.h"
#include "qwt_picker.h"
#include <qvector.h>

class QwtPlot;

class QWT_EXPORT QwtPlotPicker: public QwtPicker
{
    Q_OBJECT

public:
    explicit QwtPlotPicker( QWidget *canvas );
    virtual ~QwtPlotPicker();
    explicit QwtPlotPicker( int xAxis, int yAxis, QWidget * );
    explicit QwtPlotPicker( int xAxis, int yAxis,
        RubberBand rubberBand, DisplayMode trackerMode, QWidget * );
    virtual void setAxis( int xAxis, int yAxis );
    int xAxis() const;
    int yAxis() const;
    QwtPlot *plot();
    const QwtPlot *plot() const;
    QWidget *canvas();
    const QWidget *canvas() const;

Q_SIGNALS:

    void selected( const QPointF &pos );
    void selected( const QRectF &rect );
    void selected( const QVector<QPointF> &pa );
    void appended( const QPointF &pos );
    void moved( const QPointF &pos );

protected:
    QRectF scaleRect() const;
    QRectF invTransform( const QRect & ) const;
    QRect transform( const QRectF & ) const;
    QPointF invTransform( const QPoint & ) const;
    QPoint transform( const QPointF & ) const;
    virtual QwtText trackerText( const QPoint & ) const;
    virtual QwtText trackerTextF( const QPointF & ) const;
    virtual void move( const QPoint & );
    virtual void append( const QPoint & );
    virtual bool end( bool ok = true );

private:
    int d_xAxis;
    int d_yAxis;
};

#endif
