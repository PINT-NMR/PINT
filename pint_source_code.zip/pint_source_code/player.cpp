#include "player.h"

#include "playercontrols.h"
#include "playlistmodel.h"

#include <QMediaService>
#include <QMediaPlaylist>
#include <QVideoProbe>
#include <QMediaMetaData>
#include <QtWidgets>
#include <QDirIterator>

bool variantLessThan(const QVariant &v1, const QVariant &v2)
{
    return v1.toString() < v2.toString();
}

Player::Player(QWidget *parent)
    : QWidget(parent), player(new QMediaPlayer(this)), playlist(new QMediaPlaylist()),
      videoWidget(new VideoWidget(this)), coverLabel(0), slider(new QSlider(Qt::Horizontal)),labelDuration(new QLabel()),
      playlistModel(new PlaylistModel(this)), playlistView (new QListView()), trackInfo(""), statusInfo(""), duration(0)
{

    // owned by PlaylistModel

    player->setPlaylist(playlist);
    connect(player, SIGNAL(durationChanged(qint64)), SLOT(durationChanged(qint64)));
    connect(player, SIGNAL(positionChanged(qint64)), SLOT(positionChanged(qint64)));
    connect(player, SIGNAL(metaDataChanged()), SLOT(metaDataChanged()));
    connect(playlist, SIGNAL(currentIndexChanged(int)), SLOT(playlistPositionChanged(int)));
    connect(player, SIGNAL(mediaStatusChanged(QMediaPlayer::MediaStatus)),
            this, SLOT(statusChanged(QMediaPlayer::MediaStatus)));
    connect(player, SIGNAL(bufferStatusChanged(int)), this, SLOT(bufferingProgress(int)));
    connect(player, SIGNAL(error(QMediaPlayer::Error)), this, SLOT(displayErrorMessage()));

    auto pal = videoWidget->palette();
    pal.setBrush(QPalette::Background, QBrush(QPixmap(":img/bgui.png")));
    videoWidget->setPalette(pal);

    player->setVideoOutput(videoWidget);
    playlistModel->setPlaylist(playlist);
    playlistView->setStyleSheet("QListView{color: white;\nbackground-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));\n    border-color: rgba(71,78,81,255);\n    border-width: 2px;\n    border-style: solid;\n    padding: 1px 0px 1px 3px; /*This makes text colour work*/\n}\n\nQListWidget::item{\n selection-background-color: white;\nselection-color: black\n}");
    playlistView->setModel(playlistModel);
    playlistView->setCurrentIndex(playlistModel->index(playlist->currentIndex(), 0));

    connect(playlistView, SIGNAL(activated(QModelIndex)), this, SLOT(jump(QModelIndex)));

    slider->setRange(0, player->duration() / 1000);
    connect(slider, SIGNAL(sliderMoved(int)), this, SLOT(seek(int)));

    PlayerControls *controls = new PlayerControls(this);
    controls->setState(player->state());
    controls->setVolume(player->volume());
    controls->setMuted(controls->isMuted());

    connect(controls, SIGNAL(play()), player, SLOT(play()));
    connect(controls, SIGNAL(pause()), player, SLOT(pause()));
    connect(controls, SIGNAL(stop()), player, SLOT(stop()));
    connect(controls, SIGNAL(next()), playlist, SLOT(next()));
    connect(controls, SIGNAL(previous()), this, SLOT(previousClicked()));
    connect(controls, SIGNAL(changeVolume(int)), player, SLOT(setVolume(int)));
    connect(controls, SIGNAL(changeMuting(bool)), player, SLOT(setMuted(bool)));

    connect(controls, SIGNAL(stop()), videoWidget, SLOT(update()));

    connect(player, SIGNAL(stateChanged(QMediaPlayer::State)),
            controls, SLOT(setState(QMediaPlayer::State)));
    connect(player, SIGNAL(volumeChanged(int)), controls, SLOT(setVolume(int)));
    connect(player, SIGNAL(mutedChanged(bool)), controls, SLOT(setMuted(bool)));


    QBoxLayout *displayLayout = new QHBoxLayout();
    displayLayout->addWidget(videoWidget, 2);
    QBoxLayout *vLayout = new QVBoxLayout();
    QBoxLayout *h2Layout = new QHBoxLayout();
    QBoxLayout *controlLayout = new QHBoxLayout();
    QBoxLayout *layout = new QVBoxLayout();

    QLabel *pintLabel = new QLabel();
    pintLabel->setPixmap(QPixmap(":img/rc_icon.png"));
    pintLabel->setMaximumSize(50,50);
    pintLabel->setScaledContents(true);
    pintLabel->setLayoutDirection(Qt::RightToLeft);
    QLabel *topicLabel = new QLabel();
    topicLabel->setFont(QFont("Myriad Pro", 25, QFont::Bold));
    topicLabel->setText("Tutorials");
    h2Layout->addWidget(topicLabel);
    h2Layout->addWidget(pintLabel);
    vLayout->addLayout(h2Layout);
    vLayout->addWidget(playlistView,3);
    displayLayout->addLayout(vLayout);
    //displayLayout->addWidget(playlistView);

    controlLayout->setMargin(0);
    controlLayout->addWidget(controls);
    controlLayout->addStretch(1);

    layout->addLayout(displayLayout);
    QHBoxLayout *hLayout = new QHBoxLayout();
    hLayout->addWidget(slider);
    hLayout->addWidget(labelDuration);
    layout->addLayout(hLayout);
    layout->addLayout(controlLayout);

    setLayout(layout);

    if (!player->isAvailable()) {
        QMessageBox::warning(this, tr("Service not available"),
                             tr("The QMediaPlayer object does not have a valid service.\n"\
                                "Please check the media service plugins are installed."));

        controls->setEnabled(false);
        playlistView->setEnabled(false);
    }

    metaDataChanged();

    QStringList arguments;
    QString dir(qApp->applicationDirPath() + "/tutorials/" );
    QDirIterator it(dir, QStringList() << "*.avi", QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext())
        arguments << it.next();
    QDirIterator it2(dir, QStringList() << "*.mp4", QDir::Files, QDirIterator::Subdirectories);
    while (it2.hasNext())
        arguments << it2.next();
    QDirIterator it3(dir, QStringList() << "*.ogv", QDir::Files, QDirIterator::Subdirectories);
    while (it3.hasNext())
        arguments << it3.next();
    qSort(arguments.begin(), arguments.end(), variantLessThan);
    addToPlaylist(arguments);
}

Player::~Player()
{
}

void Player::closeEvent(QCloseEvent *event)
{
    player->stop();
    QWidget::closeEvent(event);
}

void Player::addToPlaylist(const QStringList& fileNames)
{
    foreach (QString const &argument, fileNames) {
        QFileInfo fileInfo(argument);
        if (fileInfo.exists()) {
            QUrl url = QUrl::fromLocalFile(fileInfo.absoluteFilePath());
            if (fileInfo.suffix().toLower() == QLatin1String("m3u")) {
                playlist->load(url);
            } else
                playlist->addMedia(url);
        } else {
            QUrl url(argument);
            if (url.isValid()) {
                playlist->addMedia(url);
            }
        }
    }
}

void Player::durationChanged(qint64 duration)
{
    this->duration = duration/1000;
    slider->setMaximum(duration / 1000);
}

void Player::positionChanged(qint64 progress)
{
    if (!slider->isSliderDown()) {
        slider->setValue(progress / 1000);
    }
    updateDurationInfo(progress / 1000);
}

void Player::metaDataChanged()
{
    if (player->isMetaDataAvailable()) {
        setTrackInfo(QString("%1 - %2")
                .arg(player->metaData(QMediaMetaData::AlbumArtist).toString())
                .arg(player->metaData(QMediaMetaData::Title).toString()));

        if (coverLabel) {
            QUrl url = player->metaData(QMediaMetaData::CoverArtUrlLarge).value<QUrl>();

            coverLabel->setPixmap(!url.isEmpty()
                    ? QPixmap(url.toString())
                    : QPixmap());
        }
    }
}

void Player::previousClicked()
{
    // Go to previous track if we are within the first 5 seconds of playback
    // Otherwise, seek to the beginning.
    if(player->position() <= 5000)
        playlist->previous();
    else
        player->setPosition(0);
}

void Player::jump(const QModelIndex &index)
{
    if (index.isValid()) {
        playlist->setCurrentIndex(index.row());
        player->play();
    }
}

void Player::playlistPositionChanged(int currentItem)
{
    playlistView->setCurrentIndex(playlistModel->index(currentItem, 0));
}

void Player::seek(int seconds)
{
    player->setPosition(seconds * 1000);
}

void Player::statusChanged(QMediaPlayer::MediaStatus status)
{
    handleCursor(status);

    // handle status message
    switch (status) {
    case QMediaPlayer::UnknownMediaStatus:
    case QMediaPlayer::NoMedia:
    case QMediaPlayer::LoadedMedia:
    case QMediaPlayer::BufferingMedia:
    case QMediaPlayer::BufferedMedia:
        setStatusInfo(QString());
        break;
    case QMediaPlayer::LoadingMedia:
        setStatusInfo(tr("Loading..."));
        break;
    case QMediaPlayer::StalledMedia:
        setStatusInfo(tr("Media Stalled"));
        break;
    case QMediaPlayer::EndOfMedia:
        QApplication::alert(this);
        break;
    case QMediaPlayer::InvalidMedia:
        displayErrorMessage();
        break;
    }
}

void Player::handleCursor(QMediaPlayer::MediaStatus status)
{
#ifndef QT_NO_CURSOR
    if (status == QMediaPlayer::LoadingMedia ||
        status == QMediaPlayer::BufferingMedia ||
        status == QMediaPlayer::StalledMedia)
        setCursor(QCursor(Qt::BusyCursor));
    else
        unsetCursor();
#endif
}

void Player::bufferingProgress(int progress)
{
    setStatusInfo(tr("Buffering %4%").arg(progress));
}

void Player::setTrackInfo(const QString &info)
{
    trackInfo = info;
    if (!statusInfo.isEmpty())
        setWindowTitle(QString("%1 | %2").arg(trackInfo).arg(statusInfo));
    else
        setWindowTitle(trackInfo);
}

void Player::setStatusInfo(const QString &info)
{
    statusInfo = info;
    if (!statusInfo.isEmpty())
        setWindowTitle(QString("%1 | %2").arg(trackInfo).arg(statusInfo));
    else
        setWindowTitle(trackInfo);
}

void Player::displayErrorMessage()
{
    setStatusInfo(player->errorString());
}

void Player::updateDurationInfo(qint64 currentInfo)
{
    QString tStr;
    if (currentInfo || duration) {
        QTime currentTime((currentInfo/3600)%60, (currentInfo/60)%60, currentInfo%60, (currentInfo*1000)%1000);
        QTime totalTime((duration/3600)%60, (duration/60)%60, duration%60, (duration*1000)%1000);
        QString format = "mm:ss";
        if (duration > 3600)
            format = "hh:mm:ss";
        tStr = currentTime.toString(format) + " / " + totalTime.toString(format);
    }
    labelDuration->setText(tStr);
}
