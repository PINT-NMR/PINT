#ifndef FILEVIEWER_H
#define FILEVIEWER_H

#include <QDialog>
#include <QString>
#include <QFile>

namespace Ui {
class fileViewer;
}

class fileViewer : public QDialog
{
    Q_OBJECT

public:
    explicit fileViewer(QWidget *parent = 0, QString fname = "");
    ~fileViewer();

private slots:
    void readFile(QString fname);
    void searchNext();
    void searchPrevious();

private:
    Ui::fileViewer *ui;
};

#endif // FILEVIEWER_H
