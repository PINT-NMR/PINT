#ifndef SCREENDIALOG_H
#define SCREENDIALOG_H

#include <QDialog>
#include <QMovie>
#include <QKeyEvent>

namespace Ui {
class screenDialog;
}

class screenDialog : public QDialog
{
    Q_OBJECT

public:
    explicit screenDialog(QWidget *parent = 0);
    ~screenDialog();

public slots:
    bool eventFilter(QObject *obj, QEvent *event);

private:
    Ui::screenDialog *ui;
    QMovie *movie;
    int ctrlInt;

signals:
    void ctrl(bool c);
};

#endif // SCREENDIALOG_H
