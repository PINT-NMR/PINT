#include "projecttemplate.h"
projectTemplate::projectTemplate() :
    projectName(""), saveFile(""), projectRootDirectory(""), pipeData(true),
    paramFile(""), outDirectory(""), tmpOutDirectory(""), plotDirectory(""),
    tmpPlotDirectory(""), projectDirectory(""), spectrumFiles(0), peaklistFiles(0),
    otherFiles(0), peakCenterParamFile(""), centerPeakList(""), integratePeakList(""),
    pintPeaklists(0), currentPeakID(""), overlapVec(0), planeMax(0),spD(0),prD(0),peD(0)
{

}

projectTemplate::~projectTemplate()
{
}

