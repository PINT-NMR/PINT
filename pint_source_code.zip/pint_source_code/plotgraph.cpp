#include "plotgraph.h"
#include <QtDataVisualization/QValue3DAxis>
#include <QtDataVisualization/Q3DTheme>
#include <QtGui/QImage>
#include <iostream>
#include <fstream>
#include <sstream>
#include <Q3DInputHandler>
#include <QApplication>
#include <QtTest/QtTestWidgets>
#include <QtMath>


#define PI 3.14159265

using namespace std;

plotGraph::plotGraph(QObject *parent, Q3DSurface *surface)
    : QObject(parent), plot_graph(surface), activeTheme(spectrumThemes()), plot_renderPlotProxy(0), plot_renderPlotProxy2(0), plot_renderPlotProxy3(0),
      index(-1), plot_renderPlotSeries(0), plot_renderPlotSeries2(0), plot_renderPlotSeries3(0), newRow(0), minIntensity(.0), maxIntensity(1.0), marginal(.0f),
      minF1(.0), maxF1(1.0), minF2(.0), maxF2(1.0), m_animationCameraX(0), target(QVector3D(0,0,0)),
      moveForward(false), moveBackward(false), moveRight(false), moveLeft(false), moveYFlag(false),
      moveXFlag(false), cameraTimer(new QTimer(this)), m_selectionAnimation(new QPropertyAnimation(this)), m_previouslyAnimatedItem(0), m_previouslyAnimatedItem2(0),
      m_selectionItem(0), selectedSeries(false), disabled(false), m_stepF1(.0), m_stepF2(.0), currentTitle(""),
      m_rangeMinX(.0), m_rangeMinZ(.0), m_stepX(1.0), m_stepZ(1.0), gradientDiff(QLinearGradient()), color1(QColor(80,80,80)), color2(QColor(240,240,240)),
      diffActive(true), itemsActive(true), gridActive(false), gridActive2(false), gridActive3(true)
{
    setupVisuals();
    overrideCamera();
}

plotGraph::~plotGraph()
{
    delete plot_graph;
}

void plotGraph::overrideCamera()
{
    //Custom handlers
    plot_graph->installEventFilter(this);
    connect(cameraTimer, SIGNAL(timeout()), this, SLOT(customCamera()));
    cameraTimer->start();
}

void plotGraph::toggleItems()
{
    if(itemsActive)
        itemsActive=false;
    else
        itemsActive=true;
    for(int i(0); i<plot_graph->customItems().count(); i++)
        plot_graph->customItems().at(i)->setVisible(itemsActive);
}

void plotGraph::toggleDiffPlot()
{
    if(plot_graph->seriesList().count()<2)
        return;
    if(diffActive)
    {
        plot_graph->seriesList().at(2)->setVisible(false);
        diffActive=false;
    }
    else
    {
        plot_graph->seriesList().at(2)->setVisible(true);
        diffActive=true;
    }
}

void plotGraph::toggleGrid(int model)
{
    if(plot_graph->seriesList().count()<1)
        return;
    if(model==0)
    {
        if(!gridActive)
        {
            plot_graph->seriesList().at(0)->setDrawMode(QSurface3DSeries::DrawSurfaceAndWireframe);
            gridActive=true;
        }
        else
        {
            plot_graph->seriesList().at(0)->setDrawMode(QSurface3DSeries::DrawWireframe);
            gridActive=false;
        }
    }
    else if(model==1)
    {
        if(!gridActive2)
        {
            plot_graph->seriesList().at(1)->setDrawMode(QSurface3DSeries::DrawSurfaceAndWireframe);
            gridActive2=true;
        }
        else
        {
            plot_graph->seriesList().at(1)->setDrawMode(QSurface3DSeries::DrawWireframe);
            gridActive2=false;
        }
    }
    else
    {
        if(!gridActive3)
        {
            plot_graph->seriesList().at(2)->setDrawMode(QSurface3DSeries::DrawSurfaceAndWireframe);
            gridActive3=true;
        }
        else
        {
            plot_graph->seriesList().at(2)->setDrawMode(QSurface3DSeries::DrawSurface);
            gridActive3=false;
        }

    }

}

void plotGraph::setColor(QColor color, int model)
{
    if(model==0)
    {
        color1=color;
        if(plot_graph->seriesList().count()<1)
            return;
        plot_graph->seriesList().at(0)->setBaseColor(color1);
        plot_graph->seriesList().at(0)->setColorStyle(Q3DTheme::ColorStyleUniform);
    }
    else
    {
        color2=color;
        if(plot_graph->seriesList().count()<2)
            return;
        plot_graph->seriesList().at(1)->setBaseColor(color2);
        plot_graph->seriesList().at(1)->setColorStyle(Q3DTheme::ColorStyleUniform);
    }

}

bool plotGraph::eventFilter(QObject *obj, QEvent *event)
{
    if(event->type() == QEvent::MouseButtonDblClick && obj == plot_graph)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        if(Qt::RightButton == mouseEvent->button())
            autoZoom();
    }
    else if(event->type() == QEvent::Wheel && obj == plot_graph)
    {
        QWheelEvent *wheelEvent = static_cast<QWheelEvent *>(event);
        int zoomLevel = plot_graph->scene()->activeCamera()->zoomLevel();
        if (zoomLevel > 500)
            zoomLevel = 500;
        else if (zoomLevel < 50)
            zoomLevel = 50;
        else if (zoomLevel > 200)
            zoomLevel += wheelEvent->angleDelta().y() / 20;
        else if (zoomLevel > 100)
            zoomLevel += wheelEvent->angleDelta().y() / 12;
        else
            zoomLevel += wheelEvent->angleDelta().y() / 8;
        plot_graph->scene()->activeCamera()->setZoomLevel(zoomLevel);
        return true;
    }
    else if(event->type() == QEvent::KeyPress && obj == plot_graph)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == 87)
        {
            moveForward = true; moveBackward= false; moveYFlag = true;//W
        }
        else if(keyEvent->key() == 83)
        {
            moveBackward= true; moveForward = false; moveYFlag = true;//S
        }
        else if(keyEvent->key() == 65)
        {
            moveLeft = true; moveRight = false; moveXFlag = true;//A
        }
        else if(keyEvent->key() == 68)
        {
            moveRight = true; moveLeft = false; moveXFlag = true;//D
        }
        return true;
    }
    else if(event->type() == QEvent::KeyRelease)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == 87)
            moveForward= false;//W
        else if(keyEvent->key() == 83)
            moveBackward= false;//S
        else if(keyEvent->key() == 65)
            moveLeft= false;//A
        else if(keyEvent->key() == 68)
            moveRight = false;//D
        return true;
    }
    return false;
}

void plotGraph::customCamera()
{
    if(moveYFlag)
    {
        if(!moveForward && !moveBackward)
            moveYFlag = false;
        else
        {
            double moveLevel=.01;
            if(moveForward)
            {
                plot_graph->scene()->activeCamera()->setTarget(QVector3D(sin(plot_graph->scene()->activeCamera()->xRotation()*PI/180.0)*moveLevel+plot_graph->scene()->activeCamera()->target().x(),-1.0,cos(plot_graph->scene()->activeCamera()->xRotation()*PI/180.0)*moveLevel+plot_graph->scene()->activeCamera()->target().z()));
            }
            else if(moveBackward)
            {
                plot_graph->scene()->activeCamera()->setTarget(QVector3D(sin(plot_graph->scene()->activeCamera()->xRotation()*PI/180.0)*-1.0*moveLevel+plot_graph->scene()->activeCamera()->target().x(),-1.0,cos(plot_graph->scene()->activeCamera()->xRotation()*PI/180.0)*-1.0*moveLevel+plot_graph->scene()->activeCamera()->target().z()));
            }
        }
    }
    if(moveXFlag)
    {
        if(!moveLeft && !moveRight)
            moveXFlag=false;
        else
        {
            double moveLevel(.01);
            if(moveRight)
                plot_graph->scene()->activeCamera()->setTarget(QVector3D(cos(plot_graph->scene()->activeCamera()->xRotation()*PI/180.0)*moveLevel+plot_graph->scene()->activeCamera()->target().x(),-1.0,-sin(plot_graph->scene()->activeCamera()->xRotation()*PI/180.0)*moveLevel+plot_graph->scene()->activeCamera()->target().z()));
            else if(moveLeft)
                plot_graph->scene()->activeCamera()->setTarget(QVector3D(cos(plot_graph->scene()->activeCamera()->xRotation()*PI/180.0)*-1.0*moveLevel+plot_graph->scene()->activeCamera()->target().x(),-1.0,-sin(plot_graph->scene()->activeCamera()->xRotation()*PI/180.0)*-1.0*moveLevel+plot_graph->scene()->activeCamera()->target().z()));
        }
    }
}

void plotGraph::setupVisuals()
{
    plot_graph->setAxisX(new QValue3DAxis());
    plot_graph->setAxisY(new QValue3DAxis());
    plot_graph->setAxisZ(new QValue3DAxis());
    plot_graph->axisZ()->setReversed(true); //F2 dimension is reversed
    plot_graph->axisX()->setReversed(true);
    plot_graph->axisX()->setTitle("F2 (ppm)");
    plot_graph->axisY()->setTitle("Intensity");
    plot_graph->axisZ()->setTitle("F1 (ppm)");
    plot_graph->axisX()->setTitleVisible(true);
    plot_graph->axisY()->setTitleVisible(true);
    plot_graph->axisZ()->setTitleVisible(true);
    plot_graph->axisX()->setLabelAutoRotation(30);
    plot_graph->axisY()->setLabelAutoRotation(90);
    plot_graph->axisZ()->setLabelAutoRotation(30);
    plot_graph->axisX()->setLabelFormat("%.3f");
    plot_graph->axisZ()->setLabelFormat("%.3f");
    plot_graph->setHorizontalAspectRatio(1.5);
    plot_graph->setShadowQuality(QAbstract3DGraph::ShadowQualityNone);
    plot_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetFrontHigh);
    plot_graph->scene()->activeCamera()->setZoomLevel(100.0f);
    m_selectionAnimation->setPropertyName("scaling");
    m_selectionAnimation->setDuration(500);
    m_selectionAnimation->setLoopCount(-1);
}

void plotGraph::autoZoom()
{
    plot_graph->scene()->activeCamera()->setZoomLevel(80.0f);
    plot_graph->scene()->activeCamera()->setXRotation(-125.0f);
    plot_graph->scene()->activeCamera()->setYRotation(15.0f);
}

void plotGraph::clearPlots()
{
    moveForward=false;
    moveBackward=false;
    moveRight=false;
    moveLeft=false;
    moveYFlag=false;
    moveXFlag=false;
    m_previouslyAnimatedItem=0;
    m_previouslyAnimatedItem2=0;
    m_selectionItem=0;
    selectedSeries=false;
    disabled=false;
    if(plot_graph->seriesList().count()>0)
    {
        plot_graph->removeSeries(plot_graph->seriesList().at(0));
        plot_graph->removeSeries(plot_graph->seriesList().at(1));
        plot_graph->removeSeries(plot_graph->seriesList().at(2));
    }
}

void plotGraph::renderPlot(QTableWidgetItem* item, std::string plotDir, int graphNo, QVector<QStringList> overlapVec, QString peaklist)
{
    plot_graph->removeCustomItems();
    while(graphNo<5)
    {
        if(graphNo==2)
        {
            if(plot_renderPlotProxy3)
            {
                plot_graph->removeSeries(plot_graph->seriesList().at(2));
                delete plot_renderPlotProxy3;
                delete plot_renderPlotSeries3;
                plot_renderPlotProxy3 = 0;
                plot_renderPlotSeries3 = 0;
            }
            if(plot_renderPlotProxy2)
            {
                plot_graph->removeSeries(plot_graph->seriesList().at(1));
                delete plot_renderPlotProxy2;
                delete plot_renderPlotSeries2;
                plot_renderPlotProxy2 = 0;
                plot_renderPlotSeries2 = 0;
            }
            if(plot_renderPlotProxy)
            {
                plot_graph->removeSeries(plot_graph->seriesList().at(0));
                delete plot_renderPlotProxy;
                delete plot_renderPlotSeries;
                plot_renderPlotProxy = 0;
                plot_renderPlotSeries = 0;
            }
        }

        double maxI(0.0), minI(1.0);
        if(plotDir.length()<1)
            return;
        fstream file;
        string fname=plotDir+"/"+item->text().toUtf8().data();
        file.open(fname.c_str(), ios::in);
        int sampleCountX(0); // No. of datapoints in X dimension
        int sampleCountZ(0); // No. of datapoints in Y dimension
        int tmpCount(0);
        string last("");
        vector<vector<float> >dataVec;
        if(file.is_open())
        {
            string line;
            while(getline(file, line))
            {
                vector<float> tmpVec;
                if(line=="")
                    continue;
                istringstream iss(line);
                string sub;
                int counter(1);
                while(iss>>sub)
                {
                    if(counter==1)
                    {
                        if(last!=sub)
                        {
                            sampleCountX++;
                            if(sampleCountZ<2)
                                sampleCountZ=tmpCount+1;
                        }
                        else
                            tmpCount++;
                        tmpVec.push_back(atof(sub.c_str()));
                        last=sub;
                    }
                    else if(counter==2)
                        tmpVec.push_back(atof(sub.c_str()));
                    else if(counter==3)
                        tmpVec.push_back(atof(sub.c_str()));
                    else if(counter==4)
                        tmpVec.push_back(atof(sub.c_str()));
                    else
                        break;
                    counter++;
                }
                dataVec.push_back(tmpVec);
            }
        }
        else
            return;
        file.close();
        if(dataVec.size()<16 || sampleCountX<4 || dataVec.size()/(sampleCountX+1)<4)
        {
            addCustomErrorLabel("Too few datapoints to plot a surface graph!");
            return;
        }
        float tmpMinX(9e99), tmpMaxX(-9e99);
        float tmpMinY(9e99), tmpMaxY(-9e99);
        float tmpMinZ(9e99), tmpMaxZ(-9e99);
        for(unsigned int i(0); i<dataVec.size(); i++)
        {
            if(dataVec[i][0]>tmpMaxX)
                tmpMaxX=dataVec[i][0];
            if(dataVec[i][0]<tmpMinX)
                tmpMinX=dataVec[i][0];
            if(dataVec[i][1]>tmpMaxY)
                tmpMaxY=dataVec[i][1];
            if(dataVec[i][1]<tmpMinY)
                tmpMinY=dataVec[i][1];
            if(dataVec[i][2]>tmpMaxZ)
                tmpMaxZ=dataVec[i][2];
            if(dataVec[i][2]<tmpMinZ)
                tmpMinZ=dataVec[i][2];
            if(dataVec[i][3]>tmpMaxZ)
                tmpMaxZ=dataVec[i][3];
            if(dataVec[i][3]<tmpMinZ)
                tmpMinZ=dataVec[i][3];
            if(dataVec[i][2]-dataVec[i][3]>tmpMaxZ)
                tmpMaxZ=dataVec[i][2]-dataVec[i][3];
            if(dataVec[i][2]-dataVec[i][3]<tmpMinZ)
                tmpMinZ=dataVec[i][2]-dataVec[i][3];
        }
        float sampleMaxX(tmpMaxX); //Min/Max values for data
        float sampleMinX(tmpMinX);
        float sampleMaxY(tmpMaxZ);
        float sampleMinY(tmpMinZ);
        float sampleMaxZ(tmpMaxY);
        float sampleMinZ(tmpMinY);

        if(graphNo==2)
        {
            plot_renderPlotProxy = new QSurfaceDataProxy(this);
            plot_renderPlotSeries= new QSurface3DSeries(plot_renderPlotProxy);
            plot_renderPlotSeries->setName(QString::number(graphNo));
        }
        else if(graphNo==3)
        {
            plot_renderPlotProxy2 = new QSurfaceDataProxy(this);
            plot_renderPlotSeries2= new QSurface3DSeries(plot_renderPlotProxy2);
            plot_renderPlotSeries2->setName(QString::number(graphNo));
        }
        else if(graphNo==4)
        {
            plot_renderPlotProxy3 = new QSurfaceDataProxy(this);
            plot_renderPlotSeries3= new QSurface3DSeries(plot_renderPlotProxy3);
            plot_renderPlotSeries3->setName(QString::number(graphNo));
        }

        if(graphNo!=4)
        {
            QSurfaceDataArray *dataArray = new QSurfaceDataArray;
            dataArray->reserve(dataVec.size());
            for (int i = 0 ; i <sampleCountZ; i++)
            {
                QSurfaceDataRow *newRow = new QSurfaceDataRow(sampleCountX);
                int index2 = 0;
                for (unsigned int j = i; j <dataVec.size(); j+=sampleCountZ) {
                    (*newRow)[index2++].setPosition(QVector3D(dataVec[j][0], dataVec[j][graphNo], dataVec[j][1]));
                }
                *dataArray << newRow;
            }
            if(graphNo==2)
                plot_renderPlotProxy->resetArray(dataArray);
            else
                plot_renderPlotProxy2->resetArray(dataArray);
        }
        else
        {
            QSurfaceDataArray *dataArray = new QSurfaceDataArray();
            dataArray->reserve(dataVec.size());
            double valSum(.0);
            for (int i = 0 ; i <sampleCountZ; i++)
            {
                QSurfaceDataRow *newRow = new QSurfaceDataRow(sampleCountX);
                int index2 = 0;
                for (unsigned int j = i; j <dataVec.size(); j+=sampleCountZ) {
                    double vMin(dataVec[j][3]);
                    double vMax(dataVec[j][2]);
                    if(vMax<vMin)
                    {
                        double tmp(vMax);
                        vMax=vMin;
                        vMin=tmp;
                    }
                    double val(fabs((vMax-vMin)/(sampleMaxY-sampleMinY)));
                    val*= (1.2 + fabs(dataVec[j][2])/(sampleMaxY-sampleMinY));

                    if(val>1.0)
                        val = 1.0;
                    if(val < minI)
                        minI = val;
                    if(val > maxI)
                        maxI = val;
                    valSum+=val;
                    (*newRow)[index2++].setPosition(QVector3D(dataVec[j][0], sampleMinY+val*0.05*(sampleMaxY-sampleMinY), dataVec[j][1]));
                }
                *dataArray << newRow;
            }
            valSum/=dataVec.size();
            plot_renderPlotProxy3->resetArray(dataArray);
        }

        if(gridActive && graphNo==2)
            plot_renderPlotSeries->setDrawMode(QSurface3DSeries::DrawSurfaceAndWireframe);
        else if(gridActive2 && graphNo==3)
            plot_renderPlotSeries2->setDrawMode(QSurface3DSeries::DrawSurfaceAndWireframe);
        else if(graphNo==4)
        {
            if(gridActive3)
                plot_renderPlotSeries3->setDrawMode(QSurface3DSeries::DrawSurfaceAndWireframe);
            else
                plot_renderPlotSeries3->setDrawMode(QSurface3DSeries::DrawSurface);
        }
        else if(graphNo==2)
            plot_renderPlotSeries->setDrawMode(QSurface3DSeries::DrawWireframe);
        else if(graphNo==3)
            plot_renderPlotSeries2->setDrawMode(QSurface3DSeries::DrawWireframe);

        if(graphNo==2)
        {
            plot_renderPlotSeries->setFlatShadingEnabled(true);
            plot_graph->addSeries(plot_renderPlotSeries);
            plot_renderPlotSeries->setItemLabelFormat(QStringLiteral("Exp.:@xLabel, @zLabel, @yLabel"));
        }
        if(graphNo==3)
        {
            plot_renderPlotSeries2->setFlatShadingEnabled(true);
            plot_graph->addSeries(plot_renderPlotSeries2);
            plot_renderPlotSeries2->setItemLabelFormat(QStringLiteral("Fitted:@xLabel, @zLabel, @yLabel"));
        }
        if(graphNo==4)
        {
            plot_renderPlotSeries3->setFlatShadingEnabled(true);
            plot_graph->addSeries(plot_renderPlotSeries3);
            plot_graph->seriesList().at(0)->setUserDefinedMesh(":/img/point_item.obj");
            plot_graph->seriesList().at(1)->setUserDefinedMesh(":/img/point_item.obj");
            plot_graph->seriesList().at(2)->setUserDefinedMesh(":/img/point_item.obj");
            plot_graph->seriesList().at(0)->setMesh(QSurface3DSeries::MeshUserDefined);
            plot_graph->seriesList().at(1)->setMesh(QSurface3DSeries::MeshUserDefined);
            plot_graph->seriesList().at(2)->setMesh(QSurface3DSeries::MeshUserDefined);
            plot_graph->seriesList().at(0)->setMeshSmooth(true);
            plot_graph->seriesList().at(1)->setMeshSmooth(true);
            plot_graph->seriesList().at(2)->setMeshSmooth(true);

            plot_graph->seriesList().at(0)->setSingleHighlightColor(activeTheme.selectionPointerColor);
            plot_graph->seriesList().at(1)->setSingleHighlightColor(activeTheme.selectionPointerColor);
            plot_graph->seriesList().at(2)->setSingleHighlightColor(activeTheme.selectionPointerColor);


            plot_graph->axisX()->setLabelFormat("%.3f");
            plot_graph->axisY()->setLabelFormat("%.0f");
            plot_graph->axisZ()->setLabelFormat("%.3f");
            plot_graph->axisX()->setRange(sampleMinX, sampleMaxX);
            plot_graph->axisY()->setRange(sampleMinY, sampleMaxY+qSqrt(qPow(sampleMaxY*.20,2)));
            plot_graph->axisZ()->setRange(sampleMinZ, sampleMaxZ);
            plot_graph->axisX()->setLabelAutoRotation(30);
            plot_graph->axisY()->setLabelAutoRotation(90);
            plot_graph->axisZ()->setLabelAutoRotation(30);
            plot_graph->axisX()->setReversed(false); //F2 dimension is reversed
            //plot_graph->axisZ()->setReversed(true); //F2 dimension is reversed

            plot_graph->axisX()->setTitle("F1 (ppm)");
            plot_graph->axisY()->setTitle("Intensity");
            plot_graph->axisZ()->setTitle("F2 (ppm)");
            plot_graph->axisX()->setTitleVisible(true);
            plot_graph->axisZ()->setTitleVisible(true);
            //! [8]
            m_rangeMinX = sampleMinX;
            m_rangeMinZ = sampleMinZ;
            m_stepX = (sampleMaxX - sampleMinX) / float(sampleCountX - 1.0);
            m_stepZ = (sampleMaxZ - sampleMinZ) / float(sampleCountZ - 1.0);

            //! [8]
            plot_graph->setHorizontalAspectRatio(1);
            //plot_graph->activeTheme()->setType(Q3DTheme::Theme(1));
            //
            //plot_graph->activeTheme()->setBackgroundColor(Qt::black);
            //plot_graph->activeTheme()->setWindowColor(Qt::black);
            //
            plot_graph->seriesList().at(0)->setBaseColor(color1);
            plot_graph->seriesList().at(1)->setBaseColor(color2);
            plot_renderPlotSeries->setItemLabelFormat(QStringLiteral("Diff.:@xLabel, @zLabel"));

            //The difference map will be color coded according to the deviation between experimental and fitted data
            //The used thresholds are >99%, >95%, >90% correctness of relative intensity for each plotted point
            //>99% = darkgreen/green, >95% = green, >90% = yellow, <85% = Red
            //Example: A red coordinate has a deviation between exp.-fitted graphs at F1/F2 that is larger than 10% of the intensity
            //of the experimental data. Exp. data intensity = 100, fitted data intensity = 85 or 105 => red color

            gradientDiff.setColorAt(.0, QColor(0,155,0));
            gradientDiff.setColorAt(.05*0.05, QColor(0,255,0));
            gradientDiff.setColorAt(.10*0.05, QColor(255,255,0));
            gradientDiff.setColorAt(.15*0.05, QColor(255,0,0));
            gradientDiff.setColorAt(1.0, QColor(255,0,0));

            plot_graph->seriesList().at(2)->setBaseGradient(gradientDiff);
            plot_graph->seriesList().at(2)->setColorStyle(Q3DTheme::ColorStyleRangeGradient);
            plot_graph->seriesList().at(0)->setColorStyle(Q3DTheme::ColorStyleUniform);
            plot_graph->seriesList().at(1)->setColorStyle(Q3DTheme::ColorStyleUniform);
            if(!diffActive)
                plot_graph->seriesList().at(2)->setVisible(false);
            //Add custom items for labels and check overlaps
            QStringList peaks;
            if(item->text().length()>7)
                peaks << item->text().mid(0,item->text().length()-8);
            bool done(false);
            for(int i(0); i<overlapVec.size(); i++)
            {
                if(done)
                    break;
                for(int k(0); k<overlapVec.at(i).size(); k++)
                {
                    if(overlapVec.at(i).at(k).size()<item->text().size())
                    {
                        if(equal(overlapVec.at(i).at(k).begin(), overlapVec.at(i).at(k).end(), item->text().begin()))
                        {
                            for(int j(0); j<overlapVec.at(i).size(); j++)
                            {
                                if(j!=k)
                                    peaks<<overlapVec.at(i).at(j);
                            }
                            done=true;
                        }
                    }
                    if(done)
                        break;
                }
            }
            QFile peakFile(peaklist +"/peaklist.txt");
            if(!peakFile.open(QIODevice::ReadOnly | QIODevice::Text))
                return;
            QTextStream in(&peakFile);
            QString line = in.readLine();
            line = in.readLine();
            bool peakAdded(false);
            while(!line.isNull())
            {
                int idx(0);
                bool addPeak(false);
                float F1(.0), F2(.0);
                int count(0);
                if(line!="")
                {
                    istringstream iss(line.toStdString().c_str());
                    string sub;
                    while(iss >> sub)
                    {
                        if(addPeak)
                        {
                            bool ok(true);
                            if(count>0)
                            {
                                F2 = QString::fromStdString(sub.c_str()).toFloat(&ok);
                                break;
                            }
                            else
                            {
                                F1 = QString::fromStdString(sub.c_str()).toFloat(&ok);
                                count++;
                            }
                            if(!ok)
                                return;
                        }
                        else
                        {
                            for(int i(0); i<peaks.size();i++)
                                if(QString::fromStdString(sub.c_str())==peaks.at(i))
                                {
                                    idx=i;
                                    addPeak=true;
                                }
                            if(!addPeak)
                                break;
                        }
                    }
                }
                if(addPeak)
                {
                    addCustomLabel(peaks.at(idx), F1, F2);
                    peakAdded=true;
                    qApp->processEvents();
                }
                line = in.readLine();
            }
            peakFile.close();
            if(!peakAdded)
            {
                QFile errFile(peaklist+"/error.txt");
                if(errFile.open(QIODevice::ReadOnly| QIODevice::Text))
                {
                    if(item->text().length()>7)
                    {
                        QTextStream errIn(&errFile);
                        QString errLine = errIn.readLine();
                        QStringList errList;
                        while(!errLine.isNull())
                        {
                            if(errLine[0]!='#' && errLine!="")
                            {
                                istringstream iss(errLine.toStdString().c_str());
                                string sub;
                                iss >> sub;
                                errList << QString::fromUtf8(sub.c_str());
                            }
                            errLine = errIn.readLine();
                        }
                        errFile.close();
                        peakAdded = true;
                        for(int u(0); u<errList.count(); ++u)
                        {
                            if(errList.at(u)==item->text().mid(0,item->text().length()-8))
                            {
                                peakAdded =false;
                                break;
                            }
                        }
                    }
                }
                if(!peakAdded)
                    addCustomErrorLabel("Integration failed!");
                else
                    addCustomErrorLabel((item->text().mid(0,item->text().length()-8)) + ": results are not reported.");
            }
        }
        graphNo++;
    }
    qApp->processEvents();
}


void plotGraph::adjustIntensityMin(double min)
{
    setAxisIntensityRange(min, maxIntensity+marginal);
}

void plotGraph::setAxisIntensityRange(double min, double max)
{
    plot_graph->axisY()->setRange(min, max);
}

void plotGraph::handleElementSelected(QAbstract3DGraph::ElementType type, QString label)
{
    (void) label;
    //Controls what happens when an item is selected
    if(m_selectionItem)
    {
        plot_graph->removeCustomItem(m_selectionItem);
        m_selectionItem = 0;
    }
    else
    {
        m_selectionItem = 0;
    }
    if( type == QAbstract3DGraph::ElementSeries)
    {
        QPoint point = plot_graph->selectedSeries()->selectedPoint();
        plot_graph->clearSelection();
        QCustom3DItem *selection = new QCustom3DItem(this);
        selection->setMeshFile(":/img/point_item.obj");

        selection->setScaling(QVector3D(.02f,.05f,.02f));
        QImage color = QImage(2,2, QImage::Format_RGB32);
        color.fill(activeTheme.selectionPointerColor);
        selection->setTextureImage(color);
        selection->setPosition(QVector3D(plot_renderPlotProxy->itemAt(point)->x(), plot_renderPlotProxy->itemAt(point)->y(), plot_renderPlotProxy->itemAt(point)->z()));
        plot_graph->addCustomItem(selection);
        m_selectionItem = selection;
        disconnect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
        connect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
        disconnect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
        selectedSeries=false;
    }
    disabled=false;
}

void plotGraph::changeTheme(spectrumThemes theme)
{
    activeTheme = theme;
    plot_graph->activeTheme()->setBackgroundColor(theme.gridBgColor);
    plot_graph->activeTheme()->setWindowColor(theme.areaColor);
    plot_graph->activeTheme()->setLabelBackgroundColor(theme.axisColor);
    plot_graph->activeTheme()->setLabelTextColor(theme.axisTextColor);
    plot_graph->activeTheme()->setLabelBorderEnabled(theme.gridToggled);
    //plot_graph->activeTheme()->setGridLineColor(theme.gridlineColor);

    if(plot_graph->seriesList().count()>0)
    {
        plot_graph->seriesList().at(0)->setBaseColor(color1);
        plot_graph->seriesList().at(1)->setBaseColor(color2);
        plot_graph->seriesList().at(2)->setBaseGradient(gradientDiff);

        plot_graph->seriesList().at(0)->setColorStyle(Q3DTheme::ColorStyleUniform);
        plot_graph->seriesList().at(1)->setColorStyle(Q3DTheme::ColorStyleUniform);
        plot_graph->seriesList().at(2)->setColorStyle(Q3DTheme::ColorStyleRangeGradient);
    }

    if(m_selectionItem)
    {
        QImage color = QImage(2,2, QImage::Format_RGB32);
        color.fill(theme.selectionPointerColor);
        m_selectionItem->setTextureImage(color);
    }
    if(plot_graph->seriesList().count()>0)
        emit redraw(index);
}

void plotGraph::setAxisF1Range(float min, float max)
{
    plot_graph->axisX()->setRange(min, max);
}

void plotGraph::setAxisF2Range(float min, float max)
{
    plot_graph->axisZ()->setRange(min, max);
}

void plotGraph::addCustomLabel(QString label, float F1, float F2)
{
    float diff(9.9e99);
    QPoint closestPoint(0,0);
    for(int k(0); k<plot_graph->seriesList().at(1)->dataProxy()->rowCount(); k++)
        for(int j(0); j<plot_graph->seriesList().at(1)->dataProxy()->columnCount(); j++)
        {
            float val(qSqrt(qPow(F1-plot_graph->seriesList().at(1)->dataProxy()->itemAt(k,j)->position().x(),2) + qPow(F2 - plot_graph->seriesList().at(1)->dataProxy()->itemAt(k,j)->position().z(),2)));
            if(diff > val)
            {
                diff = val;
                closestPoint = QPoint(k,j);
            }
        }

    QCustom3DItem *item = new QCustom3DItem();
    item->setMeshFile(":/img/point_item.obj");
    QVector3D position(F1,plot_graph->seriesList().at(1)->dataProxy()->itemAt(closestPoint)->y(), F2);
    item->setPosition(position);
    item->setScaling(QVector3D(.03f, .07f, .03f));
    QImage color = QImage(2,2, QImage::Format_RGB32);
    color.fill(Qt::black);
    item->setTextureImage(color);
    QCustom3DLabel *peaklabel = new QCustom3DLabel();
    peaklabel->setText(label);
    peaklabel->setPosition(QVector3D(position.x(),position.y()+(plot_graph->axisY()->max()-plot_graph->axisY()->min())/10.0,position.z()));
    peaklabel->setScaling(QVector3D(.7f, .7f, .7f));
    peaklabel->setFacingCamera(true);
    peaklabel->setBackgroundColor(activeTheme.labelBgColor);
    peaklabel->setTextColor(activeTheme.labelBorderColor);
    item->setVisible(itemsActive);
    peaklabel->setVisible(itemsActive);
    plot_graph->addCustomItem(item);
    plot_graph->addCustomItem(peaklabel);
}

void plotGraph::addCustomErrorLabel(QString str)
{
    QFont titleFont = QFont("Myriad Pro", 30);
    QCustom3DLabel *titleLabel = new QCustom3DLabel(str, titleFont,
                                                    QVector3D(0.0f, 1.2f, 0.0f),
                                                    QVector3D(1.0f, 1.0f, 0.0f),
                                                    QQuaternion());
    titleLabel->setParent(this);
    titleLabel->setBackgroundColor(QColor(Qt::red));
    titleLabel->setTextColor(QColor(Qt::white));
    titleLabel->setPositionAbsolute(true);
    titleLabel->setFacingCamera(true);
    plot_graph->addCustomItem(titleLabel);
}
