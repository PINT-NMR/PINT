#ifndef TEXTSTYLE_H
#define TEXTSTYLE_H
#include "QGraphicsDropShadowEffect"
#include <QObject>

class textStyle : public QObject
{
    Q_OBJECT
public:
    textStyle(QObject *parent);
    ~textStyle();
    QGraphicsDropShadowEffect *shadow ;
    QGraphicsDropShadowEffect *shadow2 ;

private slots:
    void blurEffect();
};

#endif // TEXTSTYLE_H
