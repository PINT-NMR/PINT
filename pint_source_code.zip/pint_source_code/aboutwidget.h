#ifndef ABOUTWIDGET_H
#define ABOUTWIDGET_H

#include <QWidget>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>

namespace Ui {
class aboutWidget;
}

class aboutWidget : public QWidget
{
    Q_OBJECT

public:
    explicit aboutWidget(QWidget *parent = 0, double sF = 1.0);
    ~aboutWidget();
    double scaleFactor;
    void scaleWidget();

private:
    Ui::aboutWidget *ui;

signals:
    void goBack();

private slots:
    void on_closeButton_clicked();
    void setupCosmeticChanges();
    QFont scaleFont(QFont fnt);
    void checkUpdates();
    void replyFinished(QNetworkReply* reply);
    void anchorClicked(const QUrl &url);

};

#endif // ABOUTWIDGET_H
