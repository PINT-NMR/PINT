#include "fileviewer.h"
#include "ui_fileviewer.h"


fileViewer::fileViewer(QWidget *parent, QString fname) :
    QDialog(parent),
    ui(new Ui::fileViewer)
{
    ui->setupUi(this);
    connect(ui->closeButton, SIGNAL(clicked(bool)), this, SLOT(accept()));
    readFile(fname);
    connect(ui->nextButton, SIGNAL(clicked(bool)), this, SLOT(searchNext()));
    connect(ui->searchEdit, SIGNAL(returnPressed()), this, SLOT(searchNext()));
    connect(ui->previousButton, SIGNAL(clicked(bool)), this, SLOT(searchPrevious()));
}

fileViewer::~fileViewer()
{
    delete ui;
}

void fileViewer::readFile(QString fnam)
{
    QFile file(fnam);
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        reject();
    ui->fileBrowser->setText(file.read(5e6));
    file.close();
}

void fileViewer::searchNext()
{
    QString str(ui->searchEdit->text());
    if(str.isEmpty())
        return;
    if(!ui->fileBrowser->find(str))
    {
        ui->fileBrowser->moveCursor(QTextCursor::Start);
        ui->fileBrowser->find(str);
    }
}

void fileViewer::searchPrevious()
{
    QString str(ui->searchEdit->text());
    if(str.isEmpty())
        return;
    if(!ui->fileBrowser->find(str, QTextDocument::FindBackward))
    {
        ui->fileBrowser->moveCursor(QTextCursor::End);
        ui->fileBrowser->find(str, QTextDocument::FindBackward);
    }
}
