#ifndef READSPECTRUMWORKER_H
#define READSPECTRUMWORKER_H

#include <QString>
#include <QObject>
#include "pipedatatemplate.h"

class readSpectrumWorker : public QObject
{
    Q_OBJECT

public:
    readSpectrumWorker(pipeDataTemplate argument, pipeDataTemplate argument2, QObject* parent = 0, int s=1, QString fnam = "", bool type = true, bool planeBoxEnabled = false, int planeBoxVal = 1, int dim = 0);
    ~readSpectrumWorker();
    pipeDataTemplate pipe;
    pipeDataTemplate moddedPipe;
    int skip;
    QString fname;
    bool nmrpipe;
    bool planeEnabled;
    int planeVal;
    int nDim;
    float maxF1;
    float maxF2;
    float minF1;
    float minF2;
    float cutoffSliderMin;
    float cutoffSliderMax;

public slots:
    void process();

signals:
    void finished(pipeDataTemplate, float, float, float, float, float, float);
};

#endif // READSPECTRUMWORKER_H
