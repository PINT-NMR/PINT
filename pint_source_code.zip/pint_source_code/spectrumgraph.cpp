#include "spectrumgraph.h"
#include <QtDataVisualization/QValue3DAxis>
#include <QtDataVisualization/Q3DTheme>
#include <QtGui/QImage>
#include <iostream>
#include <fstream>
#include <sstream>
#include <Q3DInputHandler>
#include <QApplication>
#include <QtTest/QtTestWidgets>
#include <math.h>

#define PI 3.14159265

using namespace std;

SpectrumGraph::SpectrumGraph(QObject *parent, Q3DSurface *surface)
    : QObject(parent), spectrum_graph(surface), peakIsSelected(false), ctrlPressed(false),
      dragging(false), startDragPosition(0,0), selectionVector(0), lmbPressed(false),
      moveModeEnabled(false), activeTheme(spectrumThemes()), spectrum_renderPlotProxy(0),
      toggledMode(1), previousF1Scale(0), previousF2Scale(0), zoomCounter(0),
      minF1(.0), maxF1(.0), minF2(.0), maxF2(.0), marginal(.0f), spectrum_renderPlotSeries(0),
      newRow(0), ctrlInt(16777249), minIntensity(.0), maxIntensity(.0), m_animationCameraX(0),
      target(QVector3D(0,0,0)), moveForward(false), moveBackward(false), moveRight(false),
      moveLeft(false), moveYFlag(false), moveXFlag(false), cameraTimer(new QTimer(this)),
      m_selectionAnimation(new QPropertyAnimation(this)), m_previouslyAnimatedItem(0), m_previouslyAnimatedItem2(0),
      m_selectionItem(0), selectedHighlightLabel(0), m_previousScaling(QVector3D(0,0,0)),
      m_previousScaling2(QVector3D(0,0,0)), m_previousColor(QColor(0,0,0)), m_previousPosition(QVector3D(0,0,0)),
      draggedItem(0), deb(0), selectedSeries(false), disabled(false), m_stepF1(1.0), m_stepF2(1.0),
      gotDragStartPoint(false), getDragEndPoint(false), moveModeLabel(false), moveLabelText(""), validMove(false),
      moveObjName(""), rendered(false)
{
    setupVisuals();
    overrideCamera();
    for(int i(0); i<10; i++)
    {
        previousF1Scale.push_back(QPointF(0.0,1.0));
        previousF2Scale.push_back(QPointF(0.0,1.0));
    }
}

SpectrumGraph::~SpectrumGraph()
{
    delete spectrum_graph;
}

void SpectrumGraph::overrideCamera()
{
    //Custom handlers
    spectrum_graph->installEventFilter(this);
    connect(cameraTimer, SIGNAL(timeout()), this, SLOT(customCamera()));
    cameraTimer->start();
}

bool SpectrumGraph::eventFilter(QObject *obj, QEvent *event)
{
    if(event->type() == QEvent::MouseButtonDblClick && obj == spectrum_graph)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        if(Qt::RightButton == mouseEvent->button())
        {
            undoZoom();
        }
    }
    else if(event->type() == QEvent::MouseButtonPress && obj == spectrum_graph)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        if(Qt::LeftButton == mouseEvent->button())
        {
            lmbPressed=true;
        }
        else if(Qt::RightButton == mouseEvent->button() && lmbPressed)
        {
            return true;
        }
        else if(Qt::RightButton == mouseEvent->button() && toggledMode!=1)
        {
            emit infoPeakMode("Rotation is only enabled when the scale mode is active.\nPress Tab to toggle between modes.", true, 0);
            return true;
        }
    }
    else if(event->type() == QEvent::MouseMove && obj == spectrum_graph)
    {
        if(lmbPressed)
            handleDragging();
    }
    else if(event->type() == QEvent::MouseButtonRelease && obj == spectrum_graph)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        if(Qt::LeftButton == mouseEvent->button())
        {
            lmbPressed=false;
            if(dragging)
            {
                getDragEndPoint = true;
                QMouseEvent *click = new QMouseEvent(QEvent::MouseButtonPress,mouseEvent->pos(), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
                QMouseEvent *click2 = new QMouseEvent(QEvent::MouseButtonRelease,mouseEvent->pos(), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
                QCoreApplication::postEvent(spectrum_graph, click);
                QCoreApplication::postEvent(spectrum_graph, click2);
            }
            dragging= false;
            if(disabled)
                return true;
            disabled = true;
        }
    }
    else if(event->type() == QEvent::Wheel && obj == spectrum_graph)
    {
        QWheelEvent *wheelEvent = static_cast<QWheelEvent *>(event);
        int zoomLevel = spectrum_graph->scene()->activeCamera()->zoomLevel();
        double ctrl(0);
        if(ctrlPressed)
            ctrl=1;
        if (zoomLevel > 500)
            zoomLevel = 500;
        else if (zoomLevel < 50)
            zoomLevel = 50;
        else if (zoomLevel > 200)
            zoomLevel += (int) ((double) wheelEvent->angleDelta().y() / (20.0-ctrl*19.1));
        else if (zoomLevel > 100)
            zoomLevel += (int) ((double) wheelEvent->angleDelta().y() / (12.0-ctrl*10));
        else
            zoomLevel += wheelEvent->angleDelta().y() / 8;
        spectrum_graph->scene()->activeCamera()->setZoomLevel(zoomLevel);
        return true;
    }
    else if(event->type() == QEvent::KeyPress && obj == spectrum_graph && !lmbPressed)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        int key = keyEvent->key();
        Qt::KeyboardModifiers modifiers = keyEvent->modifiers();
        if(modifiers & Qt::ShiftModifier)
            key += Qt::SHIFT;
        if(modifiers & Qt::ControlModifier)
            key += Qt::CTRL;
        if(modifiers & Qt::AltModifier)
            key += Qt::ALT;
        if(modifiers & Qt::MetaModifier)
            key += Qt::META;
        if (QKeySequence(key) == QKeySequence(QKeySequence::SelectAll))
        {
            emit selectAll();
            emit pressCtrl(true);
            ctrlPressed=true;
            return true;
        }
        else if (QKeySequence(key) == QKeySequence(QKeySequence::Find))
        {
            emit foldPeak();
            return true;
        }
        if(keyEvent->key() == 87)
        {
            moveForward = true; moveBackward= false; moveYFlag = true;//W
        }
        else if(keyEvent->key() == 83)
        {
            moveBackward= true; moveForward = false; moveYFlag = true;//S
        }
        else if(keyEvent->key() == 65)
        {
            moveLeft = true; moveRight = false; moveXFlag = true;//A
        }
        else if(keyEvent->key() == 68)
        {
            moveRight = true; moveLeft = false; moveXFlag = true;//D
        }
        else if(keyEvent->key() == ctrlInt)
        {
            ctrlPressed=true;
            emit pressCtrl(true);
        }

        return true;
    }
    else if(event->type() == QEvent::KeyRelease)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == 87)
            moveForward= false;//W
        else if(keyEvent->key() == 83)
            moveBackward= false;//S
        else if(keyEvent->key() == 65)
            moveLeft= false;//A
        else if(keyEvent->key() == 68)
            moveRight = false;//D
        else if(keyEvent->key() == 16777220 || keyEvent->key() == 16777221) //RETURN
            emit createPeak();
        else if(keyEvent->key() == 32) //Space
            movePeakMode();
        else if(keyEvent->key() == 67 && ctrlPressed) //C, CenterPeaks
            emit centerPeaks();
        else if(keyEvent->key() == ctrlInt)
        {
            ctrlPressed=false;
            emit pressCtrl(false);
        }
        else if(keyEvent->key() == 16777216)//Escape
            exitMoveMode();
        else if(keyEvent->key() == 90 && ctrlPressed)//Z, Undo
            emit undoEvent();
        else if(keyEvent->key() == 89 && ctrlPressed)//Y, Redo
            emit redoEvent();
        return true;
    }
    return false;
}

void SpectrumGraph::exitMoveMode()
{
    peakIsSelected=false;
    moveModeEnabled = false;
    clearSelectedItems();
    selectionVector.clear();
    removeSelectionItem();
    emit infoPeakMode("", true, 0);
    emit deselectTable();
    emit defaultMoveModeFrame();
}

void SpectrumGraph::removeSelectionItem()
{
    if(m_selectionItem)
    {
        spectrum_graph->removeCustomItem(m_selectionItem);
        m_selectionItem = 0;
    }
}

void SpectrumGraph::movePeakMode()
{
    //Handle change of peak position
    if(moveModeEnabled)
    {
        if(validMove)
        {
            QVector3D position = m_selectionItem->position();
            spectrum_graph->removeCustomItem(m_selectionItem);
            m_selectionItem = 0;
            handleDeselection(selectionVector.at(0)->targetItem->objectName());
            emit updatePeakPosition(position, selectionVector.at(0)->targetItem->objectName().mid(4));
            moveModeEnabled=false;
            peakIsSelected=false;
            emit infoPeakMode("", true, 0);
            emit defaultMoveModeFrame();
        }
        return;
    }
    if(peakIsSelected && selectionVector.size()==1 && moveObjName!="")
    {
        moveModeEnabled = true;
        emit moveModeFrame();
        QImage color = QImage(2,2, QImage::Format_RGB32);
        color.fill(Qt::black);
        spectrum_graph->removeCustomItem(selectionVector.at(0)->selectedLabel);
        selectionVector.at(0)->nonselectedLabel->setScaling(selectionVector.at(0)->labelScaling);
        selectionVector.at(0)->pointerAnimation->stop();
        selectionVector.at(0)->targetItem->setScaling(selectionVector.at(0)->targetScaling);
        selectionVector.at(0)->targetItem->setTextureImage(color);
        selectionVector.remove(0);

        disconnect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
        disconnect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
        connect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
        QCustom3DItem *item(0);
        QCustom3DItem *item2(0);
        QString str(moveObjName);
        QString query;
        bool isPeak(true);
        if(str[0]=='p')
            query="label"+str.mid(4);
        else
        {
            query="peak"+str.mid(5);
            isPeak=false;
        }
        for(int i(0); i<spectrum_graph->customItems().count(); i++)
        {
            if(spectrum_graph->customItems().at(i)->objectName()==query)
                item2 = spectrum_graph->customItems().at(i);
            else if(spectrum_graph->customItems().at(i)->objectName()==str)
                item = spectrum_graph->customItems().at(i);
        }
        if(!isPeak)
        {
            QCustom3DItem *item3(item);
            item = item2;
            item2 = item3;
        }
        moveModeLabel = true;
        if(item && item2)
            selectionEffects(item, item2, moveLabelText);
        validMove=false;
        moveModeLabel = false;
        emit infoPeakMode("Moving peaks: Select a data point and press SPACE to move the peak.\nPress ESC to cancel.", false, 0);
    }
    else
    {
        emit infoPeakMode("Moving peaks:\nSelect a single peak and press SPACE", true, 0);
    }
}

void SpectrumGraph::handleDragging()
{
    if(gotDragStartPoint)
        dragging = true;
}

void SpectrumGraph::customCamera()
{
    if(moveYFlag)
    {
        if(!moveForward && !moveBackward)
            moveYFlag = false;
        else
        {
            double moveLevel=.01;
            if(moveForward)
            {
                spectrum_graph->scene()->activeCamera()->setTarget(QVector3D(sin(spectrum_graph->scene()->activeCamera()->xRotation()*PI/180.0)*moveLevel+spectrum_graph->scene()->activeCamera()->target().x(),-1.0,cos(spectrum_graph->scene()->activeCamera()->xRotation()*PI/180.0)*moveLevel+spectrum_graph->scene()->activeCamera()->target().z()));
            }
            else if(moveBackward)
            {
                spectrum_graph->scene()->activeCamera()->setTarget(QVector3D(sin(spectrum_graph->scene()->activeCamera()->xRotation()*PI/180.0)*-1.0*moveLevel+spectrum_graph->scene()->activeCamera()->target().x(),-1.0,cos(spectrum_graph->scene()->activeCamera()->xRotation()*PI/180.0)*-1.0*moveLevel+spectrum_graph->scene()->activeCamera()->target().z()));
            }
        }
    }
    if(moveXFlag)
    {
        if(!moveLeft && !moveRight)
            moveXFlag=false;
        else
        {
            double moveLevel(.01);
            if(moveRight)
                spectrum_graph->scene()->activeCamera()->setTarget(QVector3D(cos(spectrum_graph->scene()->activeCamera()->xRotation()*PI/180.0)*moveLevel+spectrum_graph->scene()->activeCamera()->target().x(),-1.0,-sin(spectrum_graph->scene()->activeCamera()->xRotation()*PI/180.0)*moveLevel+spectrum_graph->scene()->activeCamera()->target().z()));
            else if(moveLeft)
                spectrum_graph->scene()->activeCamera()->setTarget(QVector3D(cos(spectrum_graph->scene()->activeCamera()->xRotation()*PI/180.0)*-1.0*moveLevel+spectrum_graph->scene()->activeCamera()->target().x(),-1.0,-sin(spectrum_graph->scene()->activeCamera()->xRotation()*PI/180.0)*-1.0*moveLevel+spectrum_graph->scene()->activeCamera()->target().z()));
        }
    }
}

void SpectrumGraph::setupVisuals()
{
    spectrum_graph->setAxisX(new QValue3DAxis());
    spectrum_graph->setAxisY(new QValue3DAxis());
    spectrum_graph->setAxisZ(new QValue3DAxis());
    spectrum_graph->axisZ()->setReversed(true); //F2 dimension is reversed
    spectrum_graph->axisX()->setReversed(true);
    spectrum_graph->axisX()->setTitle("F2 (ppm)");
    spectrum_graph->axisY()->setTitle("Intensity");
    spectrum_graph->axisZ()->setTitle("F1 (ppm)");
    spectrum_graph->axisX()->setTitleVisible(true);
    spectrum_graph->axisY()->setTitleVisible(true);
    spectrum_graph->axisZ()->setTitleVisible(true);
    spectrum_graph->axisX()->setLabelAutoRotation(30);
    spectrum_graph->axisY()->setLabelAutoRotation(90);
    spectrum_graph->axisZ()->setLabelAutoRotation(30);
    spectrum_graph->axisX()->setLabelFormat("%.3f");
    spectrum_graph->axisZ()->setLabelFormat("%.3f");
    spectrum_graph->setHorizontalAspectRatio(1.5);
    spectrum_graph->setShadowQuality(QAbstract3DGraph::ShadowQualityNone);
    spectrum_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetFrontHigh);
    spectrum_graph->scene()->activeCamera()->setZoomLevel(100.0f);

    connect(spectrum_graph, &QAbstract3DGraph::selectedElementChanged, this, &SpectrumGraph::handleChange);
    m_selectionAnimation->setPropertyName("scaling");
    m_selectionAnimation->setDuration(500);
    m_selectionAnimation->setLoopCount(-1);
}

void SpectrumGraph::clearPlots(bool newSpec)
{
    peakIsSelected=false;
    moveForward=false;
    moveBackward=false;
    moveRight=false;
    moveLeft=false;
    moveYFlag=false;
    moveXFlag=false;
    m_previouslyAnimatedItem=0;
    m_previouslyAnimatedItem2=0;
    selectedHighlightLabel=0;
    m_selectionItem=0;
    lmbPressed=false;
    dragging=false;
    draggedItem=0;
    selectedSeries=false;
    disabled=false;
    if(!newSpec)
    {
        qDeleteAll(selectionVector);
        selectionVector.clear();
        return;
    }
    if(spectrum_graph->seriesList().count()>0)
        spectrum_graph->removeSeries(spectrum_graph->seriesList().at(0));
    for(int i(0); i<10; i++)
    {
        previousF1Scale[i]=QPointF(0.0,1.0);
        previousF2Scale[i]=QPointF(0.0,1.0);
    }

}

void SpectrumGraph::handleChange(QAbstract3DGraph::ElementType type)
{
    requestLabelTitle(type);
}

void SpectrumGraph::renderPlot(vector<double> f1, vector<double> f2, vector<double> y, int /*unused*/, int f2size)
{

    spectrum_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetFrontHigh);
    spectrum_graph->scene()->activeCamera()->setZoomLevel(100.0f);
    spectrum_graph->clearSelection();
    spectrum_graph->removeCustomItems();
    if(rendered)
    {
        delete spectrum_renderPlotProxy;
        delete spectrum_renderPlotSeries;
    }
    spectrum_renderPlotProxy = new QSurfaceDataProxy();
    spectrum_renderPlotSeries = new QSurface3DSeries(spectrum_renderPlotProxy);

    QSurfaceDataArray *dataArray = new QSurfaceDataArray;
    dataArray->reserve(f1.size());
    newRow = new QSurfaceDataRow(f2size);
    int index(0);
    for(unsigned int i(0); i<f1.size(); i++)
    {
        (*newRow)[index++].setPosition(QVector3D(f2[i],y[i],f1[i]));
        if(index==f2size)
        {
            *dataArray << newRow;
            newRow = new QSurfaceDataRow(f2size);
            index=0;
        }
    }
    spectrum_renderPlotProxy->resetArray(dataArray);

    spectrum_renderPlotSeries->setDrawMode(QSurface3DSeries::DrawSurface);
    spectrum_renderPlotSeries->setFlatShadingEnabled(true);
    spectrum_renderPlotSeries->setItemLabelFormat(QStringLiteral("@zLabel, @xLabel,@yLabel"));

    spectrum_graph->addSeries(spectrum_renderPlotSeries);

    double sampleMaxZ(f1[0]), sampleMinZ(f1[0]), sampleMaxX(f2[0]), sampleMinX(f2[0]), sampleMaxY(y[0]), sampleMinY(y[0]);
    for(unsigned int i(0); i< f1.size(); i++)
    {
        if(sampleMaxZ < f1[i])
            sampleMaxZ = f1[i];
        if(sampleMaxX < f2[i])
            sampleMaxX = f2[i];
        if(sampleMaxY < y[i])
            sampleMaxY = y[i];
        if(sampleMinZ > f1[i])
            sampleMinZ = f1[i];
        if(sampleMinX > f2[i])
            sampleMinX = f2[i];
        if(sampleMinY > y[i])
            sampleMinY = y[i];
    }
    marginal = (sampleMaxY-sampleMinY)*0.1;
    spectrum_graph->axisX()->setRange(sampleMinX, sampleMaxX);
    spectrum_graph->axisY()->setRange(sampleMinY, sampleMaxY+marginal);
    spectrum_graph->axisZ()->setRange(sampleMinZ, sampleMaxZ);
    minIntensity = sampleMinY;
    maxIntensity = sampleMaxY;
    minF1 = sampleMinX;
    maxF1 = sampleMaxX;
    minF2 = sampleMinZ;
    maxF2 = sampleMaxZ;
    previousF1Scale[0]=QPointF(minF1, maxF1);
    previousF2Scale[0]=QPointF(minF2, maxF2);

    spectrum_graph->seriesList().at(0)->setBaseGradient(activeTheme.plotGradient);
    spectrum_graph->seriesList().at(0)->setColorStyle(Q3DTheme::ColorStyleRangeGradient);
    spectrum_renderPlotSeries->setItemLabelVisible(false);
    disconnect(spectrum_graph, &QAbstract3DGraph::selectedElementChanged, this, &SpectrumGraph::handleChange);
    connect(spectrum_graph, &QAbstract3DGraph::selectedElementChanged, this, &SpectrumGraph::handleChange);
    spectrum_graph->installEventFilter(this);
    rendered = true;
}

void SpectrumGraph::adjustIntensityMin(double min)
{
    setAxisIntensityRange(min, maxIntensity+marginal);
}

void SpectrumGraph::setAxisIntensityRange(double min, double max)
{
    spectrum_graph->axisY()->setRange(min, max);
}

void SpectrumGraph::addCustomLabel(QString label, QVector3D position, int globalID, bool folded)
{
    QCustom3DItem *item = new QCustom3DItem();
    item->setParent(this);
    item->setMeshFile(":/img/point_item.obj");
    item->setPosition(position);
    item->setScaling(QVector3D(.01f,.02f,.01f));
    QImage color = QImage(2,2, QImage::Format_RGB32);
    color.fill(Qt::black);
    item->setTextureImage(color);
    QCustom3DLabel *peaklabel = new QCustom3DLabel();
    if(label.isEmpty())
        label="?";
    peaklabel->setText(label);
    peaklabel->setPosition(QVector3D(position.x(),position.y()+(maxIntensity-minIntensity)/30.0,position.z()));
    peaklabel->setScaling(QVector3D(.2f, .2f, .2f));
    peaklabel->setFacingCamera(true);
    QString objectNamePeak("peak"), objectNameLabel("label");
    objectNamePeak+=QString::number(globalID);
    objectNameLabel+=QString::number(globalID);
    item->setObjectName(objectNamePeak);
    peaklabel->setObjectName(objectNameLabel);
    if(!folded)
    {
        peaklabel->setBackgroundColor(activeTheme.labelBgColor);
        peaklabel->setTextColor(activeTheme.labelBorderColor);
    }
    else
    {
        peaklabel->setBackgroundColor(activeTheme.foldedBgColor);
        peaklabel->setTextColor(activeTheme.foldedBorderColor);
    }
    spectrum_graph->addCustomItem(item);
    spectrum_graph->addCustomItem(peaklabel);
}

void SpectrumGraph::removeCustomLabel(int globalID)
{    
    QString obj("peak"), obj2("label");
    obj+=QString::number(globalID);
    obj2+=QString::number(globalID);
    int count(0);
    for(int i(0); i<spectrum_graph->customItems().count(); i++)
    {
        if(count==2)
            return;
        if(spectrum_graph->customItems().at(i)->objectName()==obj || spectrum_graph->customItems().at(i)->objectName()==obj2)
        {
            spectrum_graph->removeCustomItem(spectrum_graph->customItems().at(i));
            count++;
            i--;

        }
    }
}

void SpectrumGraph::deleteFromSelectionVector(QString obj)
{
    QImage color = QImage(2,2, QImage::Format_RGB32);
    color.fill(Qt::black);
    for(int i(0); i<selectionVector.size(); i++)
    {
        if(selectionVector.at(i)->targetItem->objectName()==obj)
        {
            spectrum_graph->removeCustomItem(selectionVector.at(i)->selectedLabel);
            selectionVector.at(i)->nonselectedLabel->setScaling(selectionVector.at(i)->labelScaling);
            selectionVector.at(i)->pointerAnimation->stop();
            selectionVector.at(i)->targetItem->setScaling(selectionVector.at(i)->targetScaling);
            selectionVector.at(i)->targetItem->setTextureImage(color);
            selectionVector.remove(i);
            break;
        }
    }
}

bool SpectrumGraph::clearSelectedItemsExcept(QString obj)
{
    QString comp("peak"+obj);
    bool exist(false);
    QImage color = QImage(2,2, QImage::Format_RGB32);
    color.fill(Qt::black);
    for(int i(0); i<selectionVector.size(); i++)
    {
        if(selectionVector.at(i)->targetItem->objectName()==comp)
        {
            exist=true;
            continue;
        }
        spectrum_graph->removeCustomItem(selectionVector.at(i)->selectedLabel);
        selectionVector.at(i)->nonselectedLabel->setScaling(selectionVector.at(i)->labelScaling);
        selectionVector.at(i)->pointerAnimation->stop();
        selectionVector.at(i)->targetItem->setScaling(selectionVector.at(i)->targetScaling);
        selectionVector.at(i)->targetItem->setTextureImage(color);
        selectionVector.remove(i);
        i--;
    }
    return exist;
}

void SpectrumGraph::clearSelectedItems()
{
    QImage color = QImage(2,2, QImage::Format_RGB32);
    color.fill(Qt::black);
    for(int i(0); i<selectionVector.size(); i++)
    {
        spectrum_graph->removeCustomItem(selectionVector.at(i)->selectedLabel);
        selectionVector.at(i)->nonselectedLabel->setScaling(selectionVector.at(i)->labelScaling);
        selectionVector.at(i)->pointerAnimation->stop();
        selectionVector.at(i)->targetItem->setScaling(selectionVector.at(i)->targetScaling);
        selectionVector.at(i)->targetItem->setTextureImage(color);
    }
}

void SpectrumGraph::handleElementSelected(QAbstract3DGraph::ElementType type, QString label)
{
    //Controls what happens when an item is selected
    /*
    if(m_selectionItem && !moveModeEnabled)
    {
        spectrum_graph->removeCustomItem(m_selectionItem);
        m_selectionItem = 0;

    }
    else if(!moveModeEnabled)
    {
        m_selectionItem = 0;
    }
    */
    if(moveModeEnabled)
    {
        if(type == QAbstract3DGraph::ElementCustomItem)
        {
            validMove=false;
            spectrum_graph->clearSelection();
        }
        else if( type == QAbstract3DGraph::ElementSeries)
        {
            validMove=true;
            QPoint point = spectrum_graph->selectedSeries()->selectedPoint();
            spectrum_graph->clearSelection();
            emit deselectTable();

            if(!m_selectionItem)
            {
                QCustom3DItem *selection = new QCustom3DItem();
                selection->setMeshFile(":/img/point_item.obj");
                selection->setScaling(QVector3D(.02f,.05f,.02f));
                QImage color = QImage(2,2, QImage::Format_RGB32);
                color.fill(activeTheme.moveBgColor);
                selection->setTextureImage(color);
                selection->setPosition(QVector3D(spectrum_renderPlotProxy->itemAt(point)->x(), spectrum_renderPlotProxy->itemAt(point)->y(), spectrum_renderPlotProxy->itemAt(point)->z()));
                spectrum_graph->addCustomItem(selection);
                m_selectionItem = selection;
            }
            else
            {
                m_selectionItem->setPosition(QVector3D(spectrum_renderPlotProxy->itemAt(point)->x(), spectrum_renderPlotProxy->itemAt(point)->y(), spectrum_renderPlotProxy->itemAt(point)->z()));
            }
            peakIsSelected=false;
            disconnect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
            connect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
            disconnect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
            selectedSeries=false;
        }

        disabled = false;
        return;
    }
    moveObjName = "";

    if(type == QAbstract3DGraph::ElementCustomItem)
    {
        removeSelectionItem();
        getDragEndPoint = false;
        gotDragStartPoint=false;
        dragging = false;
        if(ctrlPressed)
        {
            for(int i(0); i<selectionVector.size(); i++)
            {
                if(selectionVector.at(i)->targetItem->objectName()==spectrum_graph->selectedCustomItem()->objectName())
                {
                    handleDeselection("");
                    return;
                }
            }
        }
        else
        {
            clearSelectedItems();
            selectionVector.clear();
        }
        disconnect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
        disconnect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
        connect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
        peakIsSelected=true;
        QCustom3DItem *item(0);
        QCustom3DItem *item2(0);
        QString str(spectrum_graph->selectedCustomItem()->objectName());
        moveObjName = str;
        QString query, querySignal;
        bool isPeak(true);
        if(str[0]=='p')
        {
            query="label"+str.mid(4);
            querySignal= str.mid(4);
        }
        else
        {
            query="peak"+str.mid(5);
            querySignal= str.mid(5);
            isPeak=false;
        }
        for(int i(0); i<spectrum_graph->customItems().count(); i++)
        {
            if(spectrum_graph->customItems().at(i)->objectName()==query)
                item2 = spectrum_graph->customItems().at(i);
        }
        if(!isPeak)
        {
            item = item2;
            item2 = spectrum_graph->selectedCustomItem();
        }
        else
            item = spectrum_graph->selectedCustomItem();
        if(item && item2)
            selectionEffects(item, item2, label);
        emit syncPeakTable(querySignal, true);
    }
    else if( type == QAbstract3DGraph::ElementSeries && !ctrlPressed)
    {
        QPoint point = spectrum_graph->selectedSeries()->selectedPoint();
        spectrum_graph->clearSelection();

        if(!getDragEndPoint)
        {
            startDragPosition = point;
            gotDragStartPoint=true;
        }
        else if(gotDragStartPoint)
        {
            gotDragStartPoint = false;
            getDragEndPoint = false;

            float x1, x2, z1, z2, tmp;
            x1 = spectrum_renderPlotProxy->itemAt(startDragPosition)->x();
            x2 = spectrum_renderPlotProxy->itemAt(point)->x();
            z1 = spectrum_renderPlotProxy->itemAt(startDragPosition)->z();
            z2 = spectrum_renderPlotProxy->itemAt(point)->z();
            if(x1 < x2)
            {
                tmp = x2;
                x2 = x1;
                x1 = tmp;
            }
            if(z1 < z2)
            {
                tmp = z2;
                z2 = z1;
                z1 = tmp;
            }

            if(toggledMode==0) // select mode
            {
                if(!ctrlPressed)
                {
                    clearSelectedItems();
                    selectionVector.clear();
                }
                disabled = false;
                emit selectPeaksWithinBorder(x1, x2, z1, z2);
                return;
            }
            else if(toggledMode==2) // pick mode
            {
                disabled = false;
                emit pickPeaksWithinBorder((double)z2, (double)z1, (double)x2, (double)x1);
                return;
            }
            else if(toggledMode==1)
            {
                //only change scales if drag range is larger than 10% of the current axes
                if(x1-x2 < .1 * (spectrum_graph->axisX()->max() - spectrum_graph->axisX()->min())
                        || z1-z2 < .1 * (spectrum_graph->axisZ()->max() - spectrum_graph->axisZ()->min()))
                {

                    if(!ctrlPressed)
                    {
                        clearSelectedItems();
                        selectionVector.clear();
                    }
                    disabled = false;
                }
                else
                {
                    if(spectrum_renderPlotProxy->itemAt(startDragPosition)->x()<spectrum_renderPlotProxy->itemAt(point)->x())
                        setAxisF1Range(spectrum_renderPlotProxy->itemAt(startDragPosition)->x(), spectrum_renderPlotProxy->itemAt(point)->x());
                    else
                        setAxisF1Range(spectrum_renderPlotProxy->itemAt(point)->x(), spectrum_renderPlotProxy->itemAt(startDragPosition)->x());
                    if(spectrum_renderPlotProxy->itemAt(startDragPosition)->z()<spectrum_renderPlotProxy->itemAt(point)->z())
                        setAxisF2Range(spectrum_renderPlotProxy->itemAt(startDragPosition)->z(), spectrum_renderPlotProxy->itemAt(point)->z());
                    else
                        setAxisF2Range(spectrum_renderPlotProxy->itemAt(point)->z(), spectrum_renderPlotProxy->itemAt(startDragPosition)->z());
                    zoomCounter++;
                    if(zoomCounter==10)
                    {
                        for(int i(1); i<9; i++)
                        {
                            previousF1Scale[i] = previousF1Scale[i+1];
                            previousF2Scale[i] = previousF2Scale[i+1];
                        }
                        zoomCounter=9;
                    }
                    previousF1Scale[zoomCounter] = QPointF(spectrum_graph->axisX()->min(), spectrum_graph->axisX()->max());
                    previousF2Scale[zoomCounter] = QPointF(spectrum_graph->axisZ()->min(), spectrum_graph->axisZ()->max());

                    if(!ctrlPressed)
                    {
                        clearSelectedItems();
                        selectionVector.clear();
                    }
                    disabled = false;
                    return;
                }
            }
            else
            {
                if(!ctrlPressed)
                {
                    clearSelectedItems();
                    selectionVector.clear();
                }
                disabled = false;
            }
        }
        else
        {
            getDragEndPoint = false;
        }

        emit deselectTable();
        if(!m_selectionItem)
        {
            QCustom3DItem *selection = new QCustom3DItem();
            selection->setMeshFile(":/img/point_item.obj");
            selection->setScaling(QVector3D(.02f,.05f,.02f));
            QImage color = QImage(2,2, QImage::Format_RGB32);
            color.fill(activeTheme.selectionPointerColor);
            selection->setTextureImage(color);
            selection->setPosition(QVector3D(spectrum_renderPlotProxy->itemAt(point)->x(), spectrum_renderPlotProxy->itemAt(point)->y(), spectrum_renderPlotProxy->itemAt(point)->z()));
            spectrum_graph->addCustomItem(selection);
            m_selectionItem = selection;
        }
        else
        {
            m_selectionItem->setPosition(QVector3D(spectrum_renderPlotProxy->itemAt(point)->x(), spectrum_renderPlotProxy->itemAt(point)->y(), spectrum_renderPlotProxy->itemAt(point)->z()));
        }
        peakIsSelected=false;
        disconnect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
        connect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
        disconnect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
        selectedSeries=false;
        if(!ctrlPressed)
        {
            clearSelectedItems();
            selectionVector.clear();
        }
    }
    else if(ctrlPressed)
    {
        gotDragStartPoint=false;
        getDragEndPoint = false;
        spectrum_graph->clearSelection();
    }
    else if(!ctrlPressed)
    {
        gotDragStartPoint=false;
        getDragEndPoint = false;
        clearSelectedItems();
        selectionVector.clear();
        emit deselectTable();
    }
    disabled=false;
}

void SpectrumGraph::createUserPeak()
{
    if(m_selectionItem)
    {
        QVector3D position = m_selectionItem->position();
        spectrum_graph->removeCustomItem(m_selectionItem);
        m_selectionItem = 0;
        emit addToPeakTable(position, "?");
    }
}

void SpectrumGraph::deleteUserPeak()
{
    emit deleteFromPeakTable();
}

void SpectrumGraph::highlightSelection(QString obj, QString label, bool isCtrlPressed, bool viewActive)
{
    if(m_selectionItem)
    {
        spectrum_graph->removeCustomItem(m_selectionItem);
        m_selectionItem = 0;
    }
    else
    {
        m_selectionItem = 0;
    }
    if(isCtrlPressed)
    {
        QString obj2("peak" + obj);
        for(int i(0); i<selectionVector.size(); i++)
        {
            if(selectionVector.at(i)->targetItem->objectName()==obj2)
            {
                handleDeselection(obj2);
                return;
            }
        }
    }
    else
    {
        bool ret(clearSelectedItemsExcept(obj));
        //selectionVector.clear();
        if(ret)
            return;
    }
    disconnect(this, SIGNAL(createPeak()), this, SLOT(createUserPeak()));
    disconnect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
    connect(this, SIGNAL(deletePeak()), this, SLOT(deleteUserPeak()));
    peakIsSelected=true;

    QCustom3DItem *item(0);
    QCustom3DItem *item2(0);
    QString str("peak");
    QString str2("label");
    str+=obj;
    str2+=obj;
    moveObjName = str;
    int count(0);
    for(int i(0); i<spectrum_graph->customItems().count(); i++)
    {
        if(count==2)
            break;
        if(spectrum_graph->customItems().at(i)->objectName()==str)
        {
            item = spectrum_graph->customItems().at(i);
            count++;
        }
        if(spectrum_graph->customItems().at(i)->objectName()==str2)
        {
            item2 = spectrum_graph->customItems().at(i);
            count++;
        }
    }
    if(item && item2)
        selectionEffects(item, item2, label);
    if(!isCtrlPressed && toggledMode!=0 && viewActive)
    {
        //centerCamera(item);
    }
    else if(toggledMode!=0)
    {
        spectrum_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetDirectlyAbove);
        spectrum_graph->scene()->activeCamera()->setZoomLevel(220.0f);
    }
}

void SpectrumGraph::selectionEffects(QCustom3DItem *item, QCustom3DItem *item2, QString label)
{
    customItemProperties *customItem = new customItemProperties();
    customItem->targetItem = item;
    customItem->targetScaling = item->scaling();
    customItem->nonselectedLabel = item2;
    customItem->labelScaling = customItem->nonselectedLabel->scaling();
    QPropertyAnimation *anim = new QPropertyAnimation();
    anim->setPropertyName("scaling");
    anim->setDuration(500);
    anim->setLoopCount(-1);
    anim->setTargetObject(item);
    anim->setStartValue(item->scaling());
    anim->setEndValue(item->scaling()*0.7f);
    anim->start();
    customItem->pointerAnimation = anim;

    QCustom3DLabel *peaklabel = new QCustom3DLabel();
    peaklabel->setText(label);
    moveLabelText = label;
    peaklabel->setPosition(QVector3D(item2->position().x(), item2->position().y()+(maxIntensity-minIntensity)/50.0, item2->position().z()));
    peaklabel->setScaling(item2->scaling()*2.0f);
    peaklabel->setFacingCamera(true);
    if(moveModeLabel)
    {
        peaklabel->setBackgroundColor(activeTheme.moveBgColor);
        peaklabel->setTextColor(activeTheme.moveBorderColor);
    }
    else
    {
        peaklabel->setBackgroundColor(activeTheme.selectedBgColor);
        peaklabel->setTextColor(activeTheme.selectedBorderColor);
    }
    peaklabel->setObjectName("dummy" + item2->objectName().mid(4));
    customItem->selectedLabel=peaklabel;
    spectrum_graph->addCustomItem(customItem->selectedLabel);
    customItem->nonselectedLabel->setScaling(customItem->nonselectedLabel->scaling()*0.0f);
    QImage color = QImage(2,2, QImage::Format_RGB32);
    if(moveModeLabel)
        color.fill(activeTheme.moveBgColor);
    else
        color.fill(Qt::black);
    //color.fill(activeTheme.selectedBgColor);
    customItem->targetItem->setTextureImage(color);

    selectionVector.push_back(customItem);
}

void SpectrumGraph::centerCamera(QCustom3DItem *item)
{
    spectrum_graph->scene()->activeCamera()->setZoomLevel(350);
    //spectrum_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetDirectlyAbove);
    spectrum_graph->scene()->activeCamera()->setCameraPreset(Q3DCamera::CameraPresetFrontHigh);
    spectrum_graph->scene()->activeCamera()->setYRotation(spectrum_graph->scene()->activeCamera()->yRotation()-10.0f);
    spectrum_graph->scene()->activeCamera()->setTarget(normalize(item->position().x(), item->position().y(), item->position().z()));
}

QVector3D SpectrumGraph::normalize(float x, float y, float z)
{
    /*
    case 1: return (1.0-2.0*(x-minF1)/(maxF1-minF1));
    case 2: return (-1.0+2.0*(x-minIntensity)/(maxIntensity-minIntensity));
    case 3: return (1.0-2.0*(x-minF2)/(maxF2-minF2));
    */
    float rangeF1 = (previousF1Scale[zoomCounter].y() - previousF1Scale[zoomCounter].x())/2.0;
    float rangeF2 = (previousF2Scale[zoomCounter].y() - previousF2Scale[zoomCounter].x())/2.0;
    //float rangeF1 = (spectrum_graph->axisX()->max() - spectrum_graph->axisX()->min())/2.0;
    //float rangeF2 = (spectrum_graph->axisZ()->max() - spectrum_graph->axisZ()->min())/2.0;
    float min, max;
    if(x-rangeF1 < minF1)
        min=minF1;
    else
        min=x-rangeF1;
    if(x+rangeF1 > maxF1)
        max=maxF1;
    else
        max=x+rangeF1;
    setAxisF1Range(min, max);
    if(z-rangeF2 < minF2)
        min=minF2;
    else
        min=z-rangeF2;
    if(z+rangeF2 > maxF2)
        max=maxF2;
    else
        max=z+rangeF2;
    setAxisF2Range(min, max);
    return QVector3D((1.0-2.0*(x-spectrum_graph->axisX()->min())/(spectrum_graph->axisX()->max()-spectrum_graph->axisX()->min())),
                     (-1.0+2.0*(y-spectrum_graph->axisY()->min())/(spectrum_graph->axisY()->max()-spectrum_graph->axisY()->min())),
                     (1.0-2.0*(z-spectrum_graph->axisZ()->min())/(spectrum_graph->axisZ()->max()-spectrum_graph->axisZ()->min())));
}

void SpectrumGraph::changeTheme(spectrumThemes theme)
{

    activeTheme = theme;
    spectrum_graph->activeTheme()->setBackgroundColor(theme.gridBgColor);
    spectrum_graph->activeTheme()->setWindowColor(theme.areaColor);
    spectrum_graph->activeTheme()->setLabelBackgroundColor(theme.axisColor);
    spectrum_graph->activeTheme()->setLabelTextColor(theme.axisTextColor);
    spectrum_graph->activeTheme()->setLabelBorderEnabled(theme.gridToggled);
    spectrum_graph->activeTheme()->setGridLineColor(theme.gridlineColor);

    if(spectrum_graph->seriesList().count()>0)
    {
        spectrum_graph->seriesList().at(0)->setColorStyle(Q3DTheme::ColorStyleRangeGradient);
        spectrum_graph->seriesList().at(0)->setBaseGradient(theme.plotGradient);
    }

    if(m_selectionItem)
    {
        QImage color = QImage(2,2, QImage::Format_RGB32);
        color.fill(theme.selectionPointerColor);
        m_selectionItem->setTextureImage(color);
    }

}

void SpectrumGraph::handleDeselection(QString obj)
{
    if(obj=="")
        obj=spectrum_graph->selectedCustomItem()->objectName();
    for(int i(0); i<selectionVector.size(); i++)
    {
        if(selectionVector.at(i)->targetItem->objectName()== obj|| selectionVector.at(i)->selectedLabel->objectName()==obj)
        {
            QImage color = QImage(2,2, QImage::Format_RGB32);
            color.fill(Qt::black);
            spectrum_graph->removeCustomItem(selectionVector.at(i)->selectedLabel);
            selectionVector.at(i)->nonselectedLabel->setScaling(selectionVector.at(i)->labelScaling);
            selectionVector.at(i)->pointerAnimation->stop();
            selectionVector.at(i)->targetItem->setScaling(selectionVector.at(i)->targetScaling);
            selectionVector.at(i)->targetItem->setTextureImage(color);
            emit syncPeakTable(selectionVector.at(i)->targetItem->objectName().mid(4), false);
            selectionVector.remove(i);
            if(selectionVector.size()==0)
                peakIsSelected=false;
            return;
        }
    }
}

void SpectrumGraph::setAxisF1Range(float min, float max)
{
    spectrum_graph->axisX()->setRange(min, max);
}

void SpectrumGraph::setAxisF2Range(float min, float max)
{
    spectrum_graph->axisZ()->setRange(min, max);
    emit zoomed();
}

void SpectrumGraph::undoZoom()
{
    zoomCounter--;
    if(zoomCounter<0)
        zoomCounter=0;
    setAxisF1Range(previousF1Scale[zoomCounter].x(), previousF1Scale[zoomCounter].y());
    setAxisF2Range(previousF2Scale[zoomCounter].x(), previousF2Scale[zoomCounter].y());
}
