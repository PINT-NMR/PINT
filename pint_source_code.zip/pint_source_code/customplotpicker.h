#ifndef CUSTOMPLOTPICKER_H
#define CUSTOMPLOTPICKER_H
#include <qwt/qwt_plot_picker.h>


class customPlotPicker: public QwtPlotPicker
{
public:
    customPlotPicker( QWidget *canvas ):
        QwtPlotPicker( canvas )
    {

        setTrackerMode( AlwaysOn );
        setKeyPattern(QwtEventPattern::KeySelect1, Qt::NoButton);

        QPen pen;
        pen.setWidth(3);
        pen.setColor(Qt::blue);
        setRubberBandPen(pen);
    }

    ~customPlotPicker()
    {
    }

    virtual QwtText trackerTextF( const QPointF &pos ) const
    {
        QColor bg( Qt::white );
        bg.setAlpha( 200 );

        QwtText text = QwtPlotPicker::trackerTextF( pos );
        text.setBackgroundBrush( QBrush( bg ) );
        return text;
    }
};

#endif // CUSTOMPLOTPICKER_H
