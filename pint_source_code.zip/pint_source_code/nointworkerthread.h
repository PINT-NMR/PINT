#ifndef NOINTWORKERTHREAD_H
#define NOINTWORKERTHREAD_H
#include "integration/peak.h"
#include "integration/pint.h"
#include "integration/output.h"
#include <QObject>

class noIntWorkerThread : public QObject {
    Q_OBJECT

public:
    noIntWorkerThread(PeakListType argument = PeakListType(), QObject* parent = 0, VecString arg = VecString(),
                      OutputType arg2 = OutputType());
    ~noIntWorkerThread();
    PeakListType peak;
    VecString error_msg;
    OutputType output;

public slots:
    void process();

signals:
    void finished();
};


#endif // NOINTWORKERTHREAD_H
