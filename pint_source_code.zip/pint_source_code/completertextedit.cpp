#include "completertextedit.h"
#include <QCompleter>
#include <QKeyEvent>
#include <QAbstractItemView>
#include <QtDebug>
#include <QApplication>
#include <QModelIndex>
#include <QAbstractItemModel>
#include <QScrollBar>

completerTextEdit::completerTextEdit(QWidget *parent)
: QTextEdit(parent), c(0)
{

}

completerTextEdit::~completerTextEdit()
{
}

void completerTextEdit::setCompleter(customCompleter *completer)
{
    if (c)
        QObject::disconnect(c, 0, this, 0);

    c = completer;

    if (!c)
        return;

    c->setWidget(this);
    c->setCompletionMode(QCompleter::PopupCompletion);
    c->setCaseSensitivity(Qt::CaseInsensitive);
    QObject::connect(c, SIGNAL(activated(QString)),
                     this, SLOT(insertCompletion(QString)));
}

customCompleter *completerTextEdit::completer() const
{
    return c;
}

void completerTextEdit::insertCompletion(const QString& completion)
{
    if (c->widget() != this)
        return;
    QTextCursor tc = textCursor();
    tc.select(QTextCursor::WordUnderCursor);
    tc.removeSelectedText();
    tc.insertText(completion);
    setTextCursor(tc);
}

QString completerTextEdit::textUnderCursor() const
{
    QTextCursor tc = textCursor();
    tc.select(QTextCursor::WordUnderCursor);
    return tc.selectedText();
}

void completerTextEdit::focusInEvent(QFocusEvent *e)
{
    if (c)
        c->setWidget(this);
    QTextEdit::focusInEvent(e);
}

void completerTextEdit::mousePressEvent(QMouseEvent *e)
{
    if(e->button() == Qt::MiddleButton)
    {

        QTextCursor tc  = cursorForPosition(e->pos());
        tc.select(QTextCursor::LineUnderCursor);
        if(tc.selectedText().trimmed().length()>0)
        {
            QString str;
            if(tc.selectedText().trimmed().at(0)=='#')
                str = tc.selectedText().trimmed().mid(1);
            else
                str = "#" + tc.selectedText().trimmed();
            tc.removeSelectedText();
            tc.insertText(str);
            setTextCursor(tc);
        }
    }
    else
        QTextEdit::mousePressEvent(e);
}

void completerTextEdit::keyPressEvent(QKeyEvent *e)
{
    if (c && c->popup()->isVisible()) {
        // The following keys are forwarded by the completer to the widget
       switch (e->key()) {
       case Qt::Key_Enter:
       case Qt::Key_Return:
       case Qt::Key_Escape:
       case Qt::Key_Tab:
       case Qt::Key_Backtab:
            e->ignore();
            return; // let the completer do default behavior
       default:
           break;
       }
    }

    bool isShortcut = ((e->modifiers() & Qt::ControlModifier) && e->key() == Qt::Key_E); // CTRL+E
    if (!c || !isShortcut) // do not process the shortcut when we have a completer
        QTextEdit::keyPressEvent(e);

    const bool ctrlOrShift = e->modifiers() & (Qt::ControlModifier | Qt::ShiftModifier);
#ifndef Q_OS_MAC
    if (!c || (ctrlOrShift && e->text().isEmpty()))
        return;
#endif

    bool hasModifier = (e->modifiers() != Qt::NoModifier) && !ctrlOrShift;
    QString completionPrefix = textUnderCursor();

    if (!isShortcut && (hasModifier || e->text().isEmpty()|| completionPrefix.length() < 2)) {
        c->popup()->hide();
        return;
    }

    //c->setCompletionPrefix(completionPrefix);
    c->update(textUnderCursor());
    c->popup()->setCurrentIndex(c->completionModel()->index(0, 0));
    QRect cr = cursorRect();
    cr.setWidth(c->popup()->sizeHintForColumn(0)
                + c->popup()->verticalScrollBar()->sizeHint().width());
    c->complete(cr);
}
