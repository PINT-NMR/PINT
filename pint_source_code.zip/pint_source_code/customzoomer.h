#ifndef CUSTOMZOOMER_H
#define CUSTOMZOOMER_H
#include <qwt/qwt_plot_zoomer.h>
#include <QMouseEvent>


class customZoomer: public QwtPlotZoomer
{
public:
    customZoomer( QWidget *canvas ):
        QwtPlotZoomer( canvas )
    {

        // disable MouseSelect2 ( default for zooming out )
        //setMousePattern(QwtEventPattern::MouseSelect1, Qt::NoButton );
        setMousePattern(QwtEventPattern::MouseSelect2, Qt::NoButton );
        setMousePattern(QwtEventPattern::MouseSelect3, Qt::NoButton );
        setMousePattern(QwtEventPattern::MouseSelect4, Qt::NoButton );
        setMousePattern(QwtEventPattern::MouseSelect5, Qt::NoButton );
        setMousePattern(QwtEventPattern::MouseSelect6, Qt::NoButton );
        setKeyPattern(QwtEventPattern::KeySelect1, Qt::NoButton);
        setTrackerMode(QwtPlotZoomer::AlwaysOff);
        QPen pen;
        pen.setWidth(3);
        setRubberBandPen(pen);
    }

    ~customZoomer()
    {
    }

    virtual void widgetMouseDoubleClickEvent( QMouseEvent *me )
    {
        if ( me->button() == Qt::RightButton)
            zoom( 0 );
    }
};

#endif // CUSTOMZOOMER_H
