#include "folddialog.h"
#include "ui_folddialog.h"
#include "textstyle.h"


foldDialog::foldDialog(QWidget *parent) :
    QDialog(parent), foldF1(0), foldF2(0),
    ui(new Ui::foldDialog)
{
    ui->setupUi(this);
    textStyle *styleType = new textStyle(this);
    ui->foldLabel->setGraphicsEffect(styleType->shadow);
}

foldDialog::~foldDialog()
{
    delete ui;
}

void foldDialog::on_okButton_clicked()
{
    accept();
}

void foldDialog::on_cancelButton_clicked()
{
    reject();
}

void foldDialog::on_downF1Button_clicked()
{
    foldF1++;
    ui->f1Label->setText("<html><head/><body><p align=\"center\"><span style=\" font-size:20pt; color:#ffffff;\">"+QString::number(foldF1)+"</span></p></body></html>");
}
void foldDialog::on_upF1Button_clicked()
{
    foldF1--;
    ui->f1Label->setText("<html><head/><body><p align=\"center\"><span style=\" font-size:20pt; color:#ffffff;\">"+QString::number(foldF1)+"</span></p></body></html>");
}

void foldDialog::on_downF2Button_clicked()
{
    foldF2++;
    ui->f2Label->setText("<html><head/><body><p align=\"center\"><span style=\" font-size:20pt; color:#ffffff;\">"+QString::number(foldF2)+"</span></p></body></html>");
}

void foldDialog::on_upF2Button_clicked()
{
    foldF2--;
    ui->f2Label->setText("<html><head/><body><p align=\"center\"><span style=\" font-size:20pt; color:#ffffff;\">"+QString::number(foldF2)+"</span></p></body></html>");
}
