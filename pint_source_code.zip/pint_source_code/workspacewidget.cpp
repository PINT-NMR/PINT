#include "workspacewidget.h"
#include "ui_workspacewidget.h"
#include "textstyle.h"
#include <QShortcut>
#include <QSignalMapper>
#include <QFileDialog>
#include <QDebug>
#include <QMessageBox>
#include <QTextStream>
#include <sstream>
#include "integration/mtpint.h"
#include "integration/nr3.h"

workspaceWidget::workspaceWidget(QWidget *parent) :
    QMainWindow(parent), previousDir(QDir::currentPath()), errMsg(""), loadedSpectrum(""), peakId(0),
    ui(new Ui::workspaceWidget)
{
    ui->setupUi(this);
    setupMenuBar();
    setupCosmeticChanges();
    setupSpectrumWidget(); //Setup 3D plot for spectra
    setupPlotWidget(); //Setup 3D plot for fits
    makeConnections();
}

workspaceWidget::~workspaceWidget()
{
    delete ui;
}

void workspaceWidget::setupMenuBar()
{
    menubar = new QMenuBar(this);
    changeActions(ui->tabWidget->currentIndex());
    menubar->show();
}

void workspaceWidget::setupSpectrumWidget()
{
    //This widget displays 3D HSQC spectra
    Q3DSurface *spectrum3DSurface = new Q3DSurface();
    QWidget *container = QWidget::createWindowContainer(spectrum3DSurface);
    container->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    container->setFocusPolicy(Qt::StrongFocus);
    QHBoxLayout *hLayout = new QHBoxLayout(ui->spectrum2DWidget);
    QVBoxLayout *vLayout = new QVBoxLayout();
    hLayout->addWidget(container, 1);
    hLayout->addLayout(vLayout);
    vLayout->setAlignment(Qt::AlignTop);
    spectrumView3D = new SpectrumGraph(spectrum3DSurface);
    connect(spectrumView3D, SIGNAL(requestLabelTitle(QAbstract3DGraph::ElementType)), this, SLOT(sendLabelTitle(QAbstract3DGraph::ElementType)));

    //Setup combo box for selecting themes for spectra
    QHBoxLayout *hLayout2 = new QHBoxLayout(ui->spectrumToolWidget);
    QLabel *themeLabel = new QLabel(QStringLiteral("<font color='white'>Theme</font>"));
    themeLabel->setFont(QFont("Myriad Pro", 12));
    hLayout2->addWidget(themeLabel);
    QComboBox *themeList = new QComboBox();
    themeList->addItem(QStringLiteral("Standard"));
    themeList->addItem(QStringLiteral("No boxes"));
    themeList->addItem(QStringLiteral("Dark gray"));
    themeList->addItem(QStringLiteral("Light gray"));
    themeList->addItem(QStringLiteral("Retro"));
    themeList->addItem(QStringLiteral("Black"));
    hLayout2->addWidget(themeList);

    QObject::connect(themeList, SIGNAL(currentIndexChanged(int)), spectrumView3D, SLOT(changeTheme(int)));
}

void workspaceWidget::setupPlotWidget()
{
    //This widget displays 3D plots for integrated peaks
    Q3DSurface *spectrum3DSurface = new Q3DSurface();
    QWidget *container = QWidget::createWindowContainer(spectrum3DSurface);
    container->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    container->setFocusPolicy(Qt::StrongFocus);
    QHBoxLayout *hLayout = new QHBoxLayout(ui->plotWidget);
    QVBoxLayout *vLayout = new QVBoxLayout();
    hLayout->addWidget(container, 1);
    hLayout->addLayout(vLayout);
    vLayout->setAlignment(Qt::AlignTop);
}

void workspaceWidget::readFromTemplate(projectTemplate tmplate)
{
    //Use tmplate to prepare the workspace accordingly
    pintTemplate = tmplate;
    for(int i(0); i<pintTemplate.spectrumFiles.size(); i++)
    {
        ui->spectrumList->addItem(pintTemplate.spectrumFiles.at(i));
        ui->spectrumBox->addItem(pintTemplate.spectrumFiles.at(i));
    }
    for(int i(0); i<pintTemplate.peaklistFiles.size(); i++)
    {
        ui->peaklistList->addItem(pintTemplate.peaklistFiles.at(i));
        ui->peaklistBox->addItem(pintTemplate.peaklistFiles.at(i));
    }
    for(int i(0); i<pintTemplate.otherFiles.size(); i++)
        ui->otherList->addItem(pintTemplate.otherFiles.at(i));
}

void workspaceWidget::setupCosmeticChanges()
{
    //Applies cosmetical changes to the GUI
    //Text shadow effect
    textStyle style, style2, style3, style4, style5, style6, style7, style8, style9, style10, style11, style12, style13, style14, style15; //Intentional, QGraphicsDropShadowEffect does not allow for multiple renders at once
    ui->labelPeaklist->setGraphicsEffect(style.shadow);
    ui->labelSpectra->setGraphicsEffect(style2.shadow);
    ui->spectraLabel->setGraphicsEffect(style3.shadow2);
    ui->peaklistLabel->setGraphicsEffect(style4.shadow2);
    ui->selectedLabel->setGraphicsEffect(style5.shadow2);
    ui->selectedLabel_2->setGraphicsEffect(style6.shadow2);
    ui->selectedLabel_3->setGraphicsEffect(style7.shadow2);
    ui->otherLabel->setGraphicsEffect(style8.shadow2);
    ui->labelOther->setGraphicsEffect(style9.shadow);
    ui->spectrumViewLabel->setGraphicsEffect(style10.shadow2);
    ui->integrateLabel->setGraphicsEffect(style11.shadow2);
    ui->labelParam->setGraphicsEffect(style12.shadow);
    ui->labelStatus->setGraphicsEffect(style13.shadow);
    ui->labelPeakOptions->setGraphicsEffect(style14.shadow);
    ui->spectrumPeaklistLabel->setGraphicsEffect(style15.shadow2);
    ui->peaklistTable->setColumnCount(5);
    ui->peaklistTable->setColumnHidden(4,true);
    qApp->processEvents();
}

void workspaceWidget::makeConnections()
{
    //<Shortcuts>
    //<Maintab>
    QShortcut *scFilesTab = new QShortcut(this);
    QShortcut *scSpectrumTab = new QShortcut(this);
    QShortcut *scIntegrationTab = new QShortcut(this);
    QShortcut *scPlotTab = new QShortcut(this);
    QShortcut *scDeletePeakListItem = new QShortcut(this);
    scFilesTab->setKey(Qt::Key_F1);
    scSpectrumTab->setKey(Qt::Key_F2);
    scIntegrationTab->setKey(Qt::Key_F3);
    scPlotTab->setKey(Qt::Key_F4);
    scDeletePeakListItem->setKey(Qt::Key_Delete);
    connect(scDeletePeakListItem, SIGNAL(activated()), this, SLOT(deleteFromPeaklist()));

    QSignalMapper* tabSignalMapper = new QSignalMapper (this) ;
    connect (scFilesTab, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (scSpectrumTab, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (scIntegrationTab, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;
    connect (scPlotTab, SIGNAL(activated()), tabSignalMapper, SLOT(map())) ;

    tabSignalMapper->setMapping (scFilesTab, 0) ;
    tabSignalMapper->setMapping (scSpectrumTab, 1) ;
    tabSignalMapper->setMapping (scIntegrationTab, 2) ;
    tabSignalMapper->setMapping (scPlotTab, 3) ;

    connect (tabSignalMapper, SIGNAL(mapped(int)), this, SLOT(setTabFromShortcut(int))) ;
    //</Maintab>
    //</Shortcuts>
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(spectrumView3D, SIGNAL(deselectTable()), this, SLOT(deselectTable()));
    connect(spectrumView3D, SIGNAL(addToPeakTable(QVector3D)), this, SLOT(createUserPeak(QVector3D)));
    connect(spectrumView3D, SIGNAL(deleteFromPeakTable(int)), this, SLOT(deleteUserPeak(int)));

    connect(ui->workspaceTab, SIGNAL(currentChanged(int)), this, SLOT(changeActions(int)));
}

void workspaceWidget::changeActions(int activeTab)
{
    //Edit actions so that they belong to the current tab
    switch(activeTab)
    {
    case 0: break;
    case 1: //Spectrum tab
    {
        QMenu* fileMenu = new QMenu("File");
        fileMenu->addAction("Main menu");
        break;
    }
    case 2: break;
    case 3: break;
    }
}

void workspaceWidget::setTabFromShortcut(int tabNo)
{
    ui->workspaceTab->setCurrentIndex(tabNo);
}

void workspaceWidget::on_spectrumButton_clicked()
{
    QStringList files(addFiles("Add spectra to the project"));
    if(!files.isEmpty())
    {
        QStringList unreadable;
        bool add(true);
        for(int i(0); i<files.size(); i++)
        {
            add=true;
            for(int j(0); j<ui->spectrumList->count(); j++)
            {
                if(files[i] == ui->spectrumList->item(j)->text())
                {
                    add=false;
                    break;
                }
            }
            if(add)
            {
                if(checkSpectrumFormat(files[i]))
                {
                    ui->spectrumList->addItem(files[i]);
                    ui->spectrumBox->addItem(files[i]);
                }
                else
                    unreadable << files[i];
            }
        }

        if(!unreadable.isEmpty())
        {
            //NOT DONE YET
            //Display an error listing all files in unreadable as format errors for spectrum files.
        }
    }
}

void workspaceWidget::on_peaklistButton_clicked()
{
    QStringList files(addFiles("Add peaklists to the project"));
    if(!files.isEmpty())
    {
        QStringList unreadable;
        bool add(true);
        for(int i(0); i<files.size(); i++)
        {
            add=true;
            for(int j(0); j<ui->peaklistList->count(); j++)
            {
                if(files[i] == ui->peaklistList->item(j)->text())
                {
                    add=false;
                    break;
                }
                else
                    unreadable << files[i];
            }
            if(add)
            {
                if(checkPeaklistFormat(files[i]))
                {
                    ui->peaklistList->addItem(files[i]);
                    ui->peaklistBox->addItem(files[i]);
                }
            }
        }
        if(!unreadable.isEmpty())
        {
            //NOT DONE YET
            //Display an error listing all files in unreadable as format errors for spectrum files.
        }
    }
}

void workspaceWidget::on_otherButton_clicked()
{
    QStringList files(addFiles("Add files to the project"));
    if(!files.isEmpty())
    {
        QStringList unreadable;
        bool add(true);
        for(int i(0); i<files.size(); i++)
        {
            add=true;
            for(int j(0); j<ui->otherList->count(); j++)
            {
                if(files[i] == ui->otherList->item(j)->text())
                {
                    add=false;
                    break;
                }
            }
            if(add)
                ui->otherList->addItem(files[i]);
        }

        if(!unreadable.isEmpty())
        {
            //NOT DONE YET
            //Display an error listing all files in unreadable as format errors for spectrum files.
        }
    }

}

void workspaceWidget::removeFiles(int source)
{
    switch(source)
    {
    case 0:
        for(unsigned int j(0); j<ui->spectrumList->selectedItems().count(); j++)
        {
            for(unsigned int i(0); i<ui->spectrumBox->count(); i++)
            {
                if(ui->spectrumBox->itemText(i)==ui->spectrumList->selectedItems().at(j)->text())
                    ui->spectrumBox->removeItem(i);
            }
            if(loadedSpectrum==ui->spectrumList->selectedItems().at(j)->text())
                spectrumView3D->clearPlots();
        }
        qDeleteAll(ui->spectrumList->selectedItems());
        break;
    case 1:
        for(unsigned int j(0); j<ui->peaklistList->selectedItems().count(); j++)
        {
            for(unsigned int i(0); i<ui->peaklistBox->count(); i++)
            {
                if(ui->peaklistBox->itemText(i)==ui->peaklistList->selectedItems().at(j)->text())
                    ui->peaklistBox->removeItem(i);
            }
        }
        qDeleteAll(ui->peaklistList->selectedItems());
        break;
    case 2: qDeleteAll(ui->otherList->selectedItems());
        break;
    }
}

void workspaceWidget::on_removeSelectedButton_clicked()
{
    removeFiles(0);
}

void workspaceWidget::on_removeSelectedButton_2_clicked()
{
    removeFiles(1);
}

void workspaceWidget::on_removeSelectedButton_3_clicked()
{
    removeFiles(2);
}

bool workspaceWidget::checkSpectrumFormat(QString file)
{
    //NOT DONE YET
    //Check if the added file is a readable spectrum
    return 1;
}

bool workspaceWidget::checkPeaklistFormat(QString file)
{
    //NOT DONE YET
    //Check if the added file is a readable peaklist
    return 1;
}

void workspaceWidget::on_integrateButton_clicked()
{
    //NOT DONE YET
    //Check if everything if setup correctly for integration

    //Integrate using mtPINT source files.
    //Important note, do not alter called files so changes to cmd version
    //can be easily imported
    //All mtPINT files are put in the integration directory
    //
    //Everytime files are updated, the following have to be made
    //1. Create a header file for mtpint.cpp
    //2. Rename main in mtpint to runPint
    QFile param(pintTemplate.paramFile);
    if (!param.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream out(&param);
    out << ui->paramEdit->toPlainText();
    param.close();
    runPint(pintTemplate.paramFile.toStdString(), pintTemplate.outDirectory.toStdString(), pintTemplate.plotDirectory.toStdString());
}

QStringList workspaceWidget::addFiles(QString str)
{
    QStringList files = QFileDialog::getOpenFileNames(this, str, previousDir);
    if(!files.empty())
        previousDir = QDir(files[files.size()-1]).absolutePath();
    return files;
}

void workspaceWidget::on_loadSpectrumButton_clicked()
{
    if(ui->spectrumBox->count()>0)
    {
        spectrumView3D->disconnect();
        spectrumView3D->spectrum_graph->removeCustomItems();
        spectrumView3D->spectrum_graph->clearSelection();
        ui->peaklistTable->disconnect();
        ui->peaklistTable->clearSelection();
        ui->peaklistTable->clearContents();
        ui->peaklistTable->setRowCount(0);
        peakId=0;
        read3DSpectrum();
        connect(spectrumView3D, SIGNAL(requestLabelTitle(QAbstract3DGraph::ElementType)), this, SLOT(sendLabelTitle(QAbstract3DGraph::ElementType)));
        connect(spectrumView3D, SIGNAL(deselectTable()), this, SLOT(deselectTable()));
        connect(spectrumView3D, SIGNAL(addToPeakTable(QVector3D)), this, SLOT(createUserPeak(QVector3D)));
        connect(spectrumView3D, SIGNAL(deleteFromPeakTable(int)), this, SLOT(deleteUserPeak(int)));
    }
}

void workspaceWidget::read3DSpectrum()
{
    if(pintTemplate.pipeData)
    {
        //Read and display a 3D spectrum for NMRpipe
        pipeDataTemplate pipe(readPipeHeader());
        if(errMsg!="")
        {
            displayError();
            return;
        }
        pipe = readPipeSpectrum(pipe);
        loadedSpectrum = ui->spectrumBox->currentText();
        spectrumView3D->clearPlots();
        spectrumView3D->renderPlot(pipe.f1,pipe.f2,pipe.y,pipe.sizeF1,pipe.sizeF2);
        ui->intensitySlider->setValue(0);
        ui->cutoffBox->setMaximum(cutoffSliderMax);
        ui->cutoffBox->setMinimum(cutoffSliderMin);
        connect(ui->cutoffBox, SIGNAL(valueChanged(double)), spectrumView3D, SLOT(adjustIntensityMin(double)));
        connect(ui->intensitySlider, SIGNAL(valueChanged(int)), this, SLOT(updateCutoffBox(int)));
        connect(ui->cutoffBox,SIGNAL(valueChanged(double)), this, SLOT(updateSlider(double)));
    }
    else
    {
        //Read and display a 3D spectrum for topspin
    }
}

void workspaceWidget::displayError()
{
    //Error occurred and is stored in errMsg
    QMessageBox::StandardButton dlg;
    dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
    if(dlg==QMessageBox::Ok)
    {
        errMsg=""; //We never have to worry about random errors when reseting the property before returning.
        return;
    }
}

void workspaceWidget::updateCutoffBox(int value)
{
    disconnect(ui->cutoffBox,SIGNAL(valueChanged(double)), this, SLOT(updateSlider(double)));
    ui->cutoffBox->setValue(cutoffSliderMin +(cutoffSliderMax-cutoffSliderMin)*(double)value/1000.0);
    connect(ui->cutoffBox,SIGNAL(valueChanged(double)), this, SLOT(updateSlider(double)));
}

void workspaceWidget::updateSlider(double value)
{
    disconnect(ui->intensitySlider, SIGNAL(valueChanged(int)), this, SLOT(updateCutoffBox(int)));
    ui->intensitySlider->setValue((int)(1000.0*ui->cutoffBox->value()/cutoffSliderMax));
    connect(ui->intensitySlider, SIGNAL(valueChanged(int)), this, SLOT(updateCutoffBox(int)));
}

pipeDataTemplate workspaceWidget::readPipeHeader()
{
    pipeDataTemplate pipe;
    //Read header
    FILE *fp;
    float temp;
    if(!(fp = fopen(ui->spectrumBox->currentText().toStdString().c_str(), "rb")))
    {
        errMsg="Cannot open" + ui->spectrumBox->currentText();
        return pipe;
    }
    fseek(fp, 9*4, 0);
    fread(&temp, 4, 1, fp);
    fclose(fp);
    int nDim = (int)(temp+0.5);
    if (nDim < 2 || nDim > 3)
    {
        errMsg = "Only 2D or 3D spectra are allowed";
        return pipe;
    }
    fp = fopen(ui->spectrumBox->currentText().toStdString().c_str(), "rb");
    fread(pipe.header, 4, 512, fp);
    fclose(fp);
    pipe.sizeF2 = pipe.header[99];
    pipe.swF2 = pipe.header[100];
    pipe.obsF2 = pipe.header[119];
    pipe.origF2 = pipe.header[101];
    pipe.sizeF1 = pipe.header[219];
    pipe.swF1 = pipe.header[229];
    pipe.obsF1 = pipe.header[218];
    pipe.origF1 = pipe.header[249];
    pipe.deltaF1 = -pipe.swF1/(double)pipe.sizeF1;
    pipe.deltaF2 = -pipe.swF2/(double)pipe.sizeF2;
    pipe.firstF1 = pipe.origF1 - pipe.deltaF1*((double)pipe.sizeF1-1.);
    pipe.firstF2 = pipe.origF2 - pipe.deltaF2*((double)pipe.sizeF2-1.);
    return pipe;
}
pipeDataTemplate workspaceWidget::readPipeSpectrum(pipeDataTemplate pipe)
{
    pipe.imin=0;
    pipe.jmin=0;
    pipe.imax=pipe.sizeF1;
    pipe.jmax=pipe.sizeF2;
    cutoffSliderMin=9.0e99;
    cutoffSliderMax=-9.0e99;
    FILE *fp;
    fp = fopen(ui->spectrumBox->currentText().toStdString().c_str(), "rb");
    for (int i(pipe.imin); i<pipe.imax; i++)
    {
        int j;
        for (j=pipe.jmin, fseek(fp, 2048+ i*pipe.sizeF2*4+j*4, 0); j<pipe.jmax; j++)
        {
            fread(&pipe._y, 4, 1, fp);
            pipe._F1 = (pipe.firstF1 + (i)*pipe.deltaF1)/pipe.obsF1;
            pipe._F2 = (pipe.firstF2 + (j)*pipe.deltaF2)/pipe.obsF2;
            pipe.f1.push_back(pipe._F1);
            pipe.f2.push_back(pipe._F2);
            pipe.y.push_back(pipe._y);
            if(pipe._y>cutoffSliderMax)
                cutoffSliderMax = pipe._y;
            if(pipe._y<cutoffSliderMin)
                cutoffSliderMin = pipe._y;
        }
    }
    fclose(fp);
    return pipe;
}

void workspaceWidget::on_hideHintButton_clicked()
{
    ui->hintWidget->close();
}

void workspaceWidget::on_loadPeaklistButton_clicked()
{
    if(ui->peaklistBox->count()>0 && spectrumView3D->spectrum_graph->seriesList().count()!=0)
    {
        disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
        QString fname= ui->peaklistBox->currentText();
        QFile file(fname);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            errMsg="Could not open the peaklist";
            displayError();
            connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
            return;
        }
        QTextStream in(&file);
        QString line = in.readLine();
        line = in.readLine();
        line = in.readLine();
        while(!line.isNull())
        {
            istringstream iss(line.toStdString().c_str());
            string sub;
            ui->peaklistTable->insertRow(ui->peaklistTable->rowCount());
            int col(0);
            while(iss >> sub)
            {
                QTableWidgetItem *item = new QTableWidgetItem;
                item->setText(QString::fromStdString(sub.c_str()));
                ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1,col++,item);
            }
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText(QString::number(peakId++));
            ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, 4, item);
            line = in.readLine();
        }
        file.close();
        ui->peaklistTable->horizontalHeader()->setStretchLastSection(true);
        createPeakLabels(0);
        connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
        disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
        connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    }
}

void workspaceWidget::createPeakLabels(int start)
{
    for(int i(start); i<ui->peaklistTable->rowCount(); i++)
    {
        spectrumView3D->addCustomLabel(ui->peaklistTable->item(i,0)->text(),QVector3D(ui->peaklistTable->item(i,2)->text().toDouble(),ui->peaklistTable->item(i,3)->text().toDouble(),ui->peaklistTable->item(i,1)->text().toDouble()), ui->peaklistTable->item(i,4)->text().toDouble());
    }
}

void workspaceWidget::updatePeakLabels(int row, int col)
{
    spectrumView3D->removeCustomLabel(ui->peaklistTable->item(row,4)->text().toInt());
    qApp->processEvents();
    spectrumView3D->addCustomLabel(ui->peaklistTable->item(row,0)->text(),QVector3D(ui->peaklistTable->item(row,2)->text().toDouble(),ui->peaklistTable->item(row,3)->text().toDouble(),ui->peaklistTable->item(row,1)->text().toDouble()), ui->peaklistTable->item(row,4)->text().toDouble());
}

void workspaceWidget::sendLabelTitle(QAbstract3DGraph::ElementType type)
{
    if(type == QAbstract3DGraph::ElementCustomItem)
    {
        if(spectrumView3D->spectrum_graph->selectedCustomItem()->objectName().isEmpty())
            return;
        spectrumView3D->resetSelection();
        QString label("");
        QString str(spectrumView3D->spectrum_graph->selectedCustomItem()->objectName());
        if(str[0]=='p')
            str=str.mid(4);
        else
            str=str.mid(5);
        for(int i(0); i<ui->peaklistTable->rowCount(); i++)
        {
            if(ui->peaklistTable->item(i,4)->text()==str)
            {
                label = ui->peaklistTable->item(i,0)->text();
                disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
                ui->peaklistTable->selectRow(i);
                connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
                break;
            }
        }
        spectrumView3D->handleElementSelected(type, label);
    }
    else if (type == QAbstract3DGraph::ElementSeries)
    {
        spectrumView3D->resetSelection();
        spectrumView3D->handleElementSelected(type, "");
    }
    else
    {
        spectrumView3D->resetSelection();
        spectrumView3D->handleElementSelected(type, "");
    }
}

void workspaceWidget::highlightPeak()
{
    int row(ui->peaklistTable->selectedItems().at(0)->row());
    spectrumView3D->highlightSelection(ui->peaklistTable->item(row,4)->text(), ui->peaklistTable->item(row,0)->text());
}

void workspaceWidget::deselectTable()
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    ui->peaklistTable->clearSelection();
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
}

void workspaceWidget::createUserPeak(QVector3D position)
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    ui->peaklistTable->insertRow(ui->peaklistTable->rowCount());
    for(int i(0); i<5; i++)
    {
        QTableWidgetItem *item = new QTableWidgetItem;
        switch (i)
        {
        case 0: item->setText("?"); break;
        case 1: item->setText(QString::number(position.z())); break;
        case 2: item->setText(QString::number(position.x())); break;
        case 3: item->setText(QString::number(position.y())); break;
        case 4: item->setText(QString::number(peakId++)); break;
        }
        ui->peaklistTable->setItem(ui->peaklistTable->rowCount()-1, i, item);
    }
    ui->peaklistTable->scrollToBottom();
    QModelIndex index = ui->peaklistTable->model()->index(ui->peaklistTable->rowCount()-1, 0, QModelIndex());
    ui->peaklistTable->edit(index);
    createPeakLabels(ui->peaklistTable->rowCount()-1);
    QApplication::processEvents();
    spectrumView3D->highlightSelection(ui->peaklistTable->item(ui->peaklistTable->rowCount()-1,4)->text(), ui->peaklistTable->item(ui->peaklistTable->rowCount()-1,0)->text());
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
}
void workspaceWidget::deleteUserPeak(int globalID)
{
    disconnect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    disconnect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
    for(int i(0); i<ui->peaklistTable->rowCount(); i++)
    {
        if(ui->peaklistTable->item(i,4)->text() == QString::number(globalID))
        {
            spectrumView3D->removeCustomLabel(globalID);
            ui->peaklistTable->removeRow(i);
            ui->peaklistTable->clearSelection();
            break;
        }
    }
    connect(ui->peaklistTable, SIGNAL(itemSelectionChanged()), this, SLOT(highlightPeak()));
    connect(ui->peaklistTable, SIGNAL(cellChanged(int,int)), this, SLOT(updatePeakLabels(int,int)));
}

void workspaceWidget::deleteFromPeaklist()
{
    //Check if QTableItem is selected
    //delete button has been pressed
    if(ui->workspaceTab->currentIndex()==1 && ui->peaklistTable->selectedItems().count()>0 && spectrumView3D->peakIsSelected)
    {
        spectrumView3D->deleteUserPeak();
    }
}
