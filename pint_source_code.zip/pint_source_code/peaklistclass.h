#ifndef PEAKLISTCLASS_H
#define PEAKLISTCLASS_H
#include <QString>
#include <QVector>

class peaklistClass
{
public:
    peaklistClass();
    ~peaklistClass();
    QString spectrum;
    QVector< QVector < QString> > peaklist;
};

#endif // PEAKLISTCLASS_H
