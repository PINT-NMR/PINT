#include "loadprojectwidget.h"
#include "ui_loadprojectwidget.h"
#include "textstyle.h"
#include <QDir>
#include <QDirIterator>
#include <QFileDialog>
#include <QDateTime>
#include <QProgressDialog>
#include <QMessageBox>
#include <QTextStream>
#include "peaklistclass.h"
#include <cstdlib>
#include <sstream>

loadProjectWidget::loadProjectWidget(QWidget *parent, double sF) :
    QWidget(parent), scaleFactor(sF), previousDir(QDir::currentPath()), includeSub(true),
    errMsg(""), lockAndLoad(false), ui(new Ui::loadProjectWidget)
{
    ui->setupUi(this);
    setupCosmeticChanges();
    createFilesTable();
    updateTable();
    if(scaleFactor!=1.0)
        scaleWidget();
    makeConnections();
}

loadProjectWidget::~loadProjectWidget()
{
    delete ui;
}

void loadProjectWidget::on_cancelButton_clicked(){emit goBack();}

void loadProjectWidget::setupCosmeticChanges()
{
    //Text shadow effect

    textStyle *style = new textStyle(this);
    textStyle *style2 = new textStyle(this);
    textStyle *style3 = new textStyle(this); //Intentional, QGraphicsDropShadowEffect does not allow for multiple renders at once
    ui->labelPINT->setGraphicsEffect(style->shadow);
    ui->labelVersion->setGraphicsEffect(style2->shadow);
    ui->label_LoadProject->setGraphicsEffect(style3->shadow);

    //Load Directory text
    QFile file(qApp->applicationDirPath()+"/settings.txt");
    if(!file.exists())
    {
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT",
                                   "PINT could not detect a directory dedicated for PINT projects.\nDo you want to specify a default folder for all of your projects now?",
                                   QMessageBox::Yes | QMessageBox::No);
        if(dlg==QMessageBox::No)
            ui->directoryEdit->setText(qApp->applicationDirPath());
        else
        {
            QString directory = QFileDialog::getExistingDirectory(this,tr("Choose project directory"), previousDir);
            if (directory.isEmpty())
                ui->directoryEdit->setText(qApp->applicationDirPath());
            else
            {
                if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
                    ui->directoryEdit->setText(qApp->applicationDirPath());
                else
                {
                    QTextStream out(&file);
                    out << directory;
                    file.close();
                    ui->directoryEdit->setText(directory);
                    QMessageBox::StandardButton infoDlg;
                    infoDlg = QMessageBox::information(this, "PINT", "If you need to change the default path in the future, please delete or modify "+qApp->applicationDirPath()+"/settings.txt", QMessageBox::Ok);
                    Q_UNUSED(infoDlg)
                }
            }
        }
    }
    else
    {
        if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QMessageBox::StandardButton warn;
            warn=  QMessageBox::warning(this,"PINT", "Your application directory is read/write protected. This may cause the software to fail reading certain files.\nTo fix this, edit the read/write properties of the "+qApp->applicationDirPath()+" folder and its contents.", QMessageBox::Ok);
            if(warn == QMessageBox::Ok)
                ui->directoryEdit->setText(qApp->applicationDirPath());
        }
        else
        {
            QTextStream in(&file);
            QString line(in.readLine());
            file.close();
            QDir dirCheck(line);
            if(dirCheck.exists())
                ui->directoryEdit->setText(line);
            else
            {
                QMessageBox::StandardButton dlg;
                dlg = QMessageBox::warning(this, "PINT",
                                           "The default directory does not exists.\nDo you want to specify a new default folder for all of your projects now?",
                                           QMessageBox::Yes | QMessageBox::No);
                if(dlg==QMessageBox::Yes)
                {
                    QString directory = QFileDialog::getExistingDirectory(this,tr("Choose project directory"), previousDir);
                    if (directory.isEmpty())
                        ui->directoryEdit->setText(qApp->applicationDirPath());
                    else
                    {
                        if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
                            ui->directoryEdit->setText(qApp->applicationDirPath());
                        else
                        {
                            QTextStream out(&file);
                            out << directory;
                            file.close();
                            ui->directoryEdit->setText(directory);
                            QMessageBox::StandardButton infoDlg;
                            infoDlg = QMessageBox::information(this, "PINT", "If you need to change the default path in the future, please delete or modify "+qApp->applicationDirPath()+"/settings.txt", QMessageBox::Ok);
                            Q_UNUSED(infoDlg)
                        }
                    }
                }
                else
                    ui->directoryEdit->setText(qApp->applicationDirPath());
            }
        }
    }
    previousDir = ui->directoryEdit->text();
}

void loadProjectWidget::on_subButton_clicked()
{
    if(includeSub)
        includeSub=false;
    else
        includeSub=true;
    emit subChanged();
}

void loadProjectWidget::makeConnections()
{
    connect(this, SIGNAL(subChanged()), this, SLOT(toggleSubs()));
    connect(ui->filesTable, SIGNAL(cellDoubleClicked(int,int)), this, SLOT(openFileOfItem(int,int)));
}

void loadProjectWidget::toggleSubs()
{
    if(includeSub)
    {
        //Include subdirectories when searching for a project file
        ui->subButton->setIcon(QIcon(":img/go.png"));
        ui->subButton->setStyleSheet("QPushButton#subButton {\nbackground-color: "
                                     "qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, "
                                     "stop:0 rgba(92, 133, 71, 255), stop:1 rgba(105, 156, 90, 255));\n border-style: "
                                     "outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\ncolor: "
                                     "white;\n}\nQPushButton#subButton:pressed {\n	background-color: qlineargradient(spread:pad, "
                                     "x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(57, 82, 44, 255), stop:1 rgba(63, 93, "
                                     "54, 255));\n border-style: inset;\ncolor: white;\n}\nQPushButton#subButton:hover:!pressed {"
                                     "\nbackground-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, "
                                     "stop:0 rgba(120, 173, 94, 255), stop:1 rgba(142, 207, 123, 255));\n border-style: outset;\nborder-radius:"
                                     "10px;\nborder-width: 1px;\nborder-color: gray;\ncolor: white;\n}");

    }
    else
    {
        ui->subButton->setIcon(QIcon(":img/close.png"));
        ui->subButton->setStyleSheet("QPushButton#subButton {\nbackground-color: qlineargradient(spread:pad, "
                                     "x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(155, 57, 57, 255), "
                                     "stop:1 rgba(188, 82, 83, 255));\n border-style: outset;\nborder-radius: 10px;"
                                     "\nborder-width: 1px;\nborder-color: gray;\ncolor: white;\n}\nQPushButton#subButton:pressed {\n"
                                     "background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0"
                                     "rgba(107, 36, 37, 255), stop:1 rgba(167, 58, 60, 255));\n border-style: inset;\ncolor: white;\n}\n"
                                     "QPushButton#subButton:hover:!pressed {\nbackground-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, "
                                     "x2:0.5, y2:0.335955, stop:0 rgba(222, 82, 82, 255), stop:1 rgba(238, 105, 105, 255));\n border-style: "
                                     "outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\ncolor: white;\n}");
    }
    updateTable();
}

void loadProjectWidget::on_browseButton_clicked()
{
    QString directory = QFileDialog::getExistingDirectory(this,tr("Load project"), previousDir);
    previousDir = directory;
    if (!directory.isEmpty())
    {
        ui->directoryEdit->setText(directory);
        updateTable();
    }
}

void loadProjectWidget::createFilesTable()
{
    ui->filesTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    QStringList labels;
    labels << tr("Filename") << tr("Last modified");
    ui->filesTable->setHorizontalHeaderLabels(labels);
    ui->filesTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    ui->filesTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    ui->filesTable->verticalHeader()->hide();
    ui->filesTable->setShowGrid(false);
}

void loadProjectWidget::updateTable()
{
    while (ui->filesTable->rowCount() > 0)
        ui->filesTable->removeRow(0);
    QDir currentDir = QDir(ui->directoryEdit->text());
    QStringList files;
    QString fileName("*.ppro");
    if(includeSub)
    {
        QDirIterator it(currentDir.path(), QStringList() << "*.ppro", QDir::Files | QDir::NoSymLinks, QDirIterator::Subdirectories);
        QProgressDialog progress(this);
        progress.setWindowModality(Qt::WindowModal);
        progress.setLabelText("Searching files...");
        progress.setCancelButtonText(tr("&Cancel"));
        progress.setRange(0,0);
        progress.show();
        while (it.hasNext())
        {
            files << it.next();
            if (progress.wasCanceled())
                break;
        }
        progress.cancel();
    }
    else
        files = currentDir.entryList(QStringList(fileName), QDir::Files | QDir::NoSymLinks);
    QString appDir(qApp->applicationDirPath()+"/Example_files/");
    bool exist(false);
    for(int i(0); i<files.size(); ++i)
    {
        if(files.at(i) == appDir+"CaM_Tr2C_CPMG/CaM_Tr2C_CPMG.ppro"
                || files.at(i) == appDir+"CaM_Tr2C_R1/CaM_Tr2C_R1.ppro"
                || files.at(i) == appDir+"CaM_Tr2C_R1rho/CaM_Tr2C_R1rho.ppro"
                || files.at(i) == appDir+"CaM_Tr2C_NOE/CaM_Tr2C_NOE.ppro")
        {
            files.removeAt(i);
            --i;
        }
    }
    if(!exist)
    {
        QFile file(appDir+"CaM_Tr2C_CPMG/CaM_Tr2C_CPMG.ppro");
        if(file.exists())
        {
            QStringList strList;
            bool newInstall(false);
            if(file.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                QTextStream in(&file);
                QString line = in.readLine();
                if(line=="NEWINSTALL")
                {
                    newInstall = true;
                    while(!in.atEnd())
                    {
                        line = in.readLine();
                        strList << line;
                    }
                }
                file.close();
            }
            bool ok(true);
            if(newInstall)
            {
                QFile fileOut(appDir+"CaM_Tr2C_CPMG/CaM_Tr2C_CPMG.ppro");
                if(fileOut.open(QIODevice::WriteOnly | QIODevice::Text))
                {
                    QTextStream out (&fileOut);
                    for(int i(0); i<strList.size(); ++i)
                    {
                        if(i==3)
                            out<<appDir+"CaM_Tr2C_CPMG/CaM_Tr2C_CPMG.ppro\n";
                        else if(i==5)
                            out<<qApp->applicationDirPath()+"/Example_files"<<"\n";
                        else if(i==7)
                            out<<appDir<<"CaM_Tr2C_CPMG\n";
                        else if(i==11)
                            out<<appDir<<"CaM_Tr2C_CPMG/param.pint\n";
                        else if(i==13)
                            out<<appDir<<"CaM_Tr2C_CPMG/out\n";
                        else if(i==15)
                            out<<appDir<<"CaM_Tr2C_CPMG/tmp_out\n";
                        else if(i==17)
                            out<<appDir<<"CaM_Tr2C_CPMG/plot\n";
                        else if(i==19)
                            out<<appDir<<"CaM_Tr2C_CPMG/tmp_plot\n";
                        else if(i==21)
                            out<<appDir<<"CaM_Tr2C_CPMG/paramCenterPeak.pint\n";
                        else if(i==23)
                            out<<appDir<<"CaM_Tr2C_CPMG/peaklist.list\n";
                        else if(i==25)
                            out<<appDir<<"CaM_Tr2C_CPMG/centerPeakList.list\n";
                        else if(i==29)
                            out<<appDir<<"CaM_Tr2C_CPMG/CaM_CPMG.ft3\n";
                        else if(i==31)
                            out<<appDir<<"CaM_Tr2C_CPMG/CPMG_peaklist.txt\n";
                        else if(i==33)
                            out<<appDir<<"CaM_Tr2C_CPMG/procpar\n";
                        else if(i==35)
                            out<<appDir<<"CaM_Tr2C_CPMG/CaM_CPMG.ft3\n";
                        else
                            out << strList.at(i)<<"\n";
                    }
                    fileOut.close();
                }
                else
                    ok = false;
            }
            if(ok)
                files << appDir+"CaM_Tr2C_CPMG/CaM_Tr2C_CPMG.ppro";
        }
        QFile file2(appDir+"CaM_Tr2C_R1/CaM_Tr2C_R1.ppro");
        if(file2.exists())
        {
            QStringList strList;
            bool newInstall(false);
            if(file2.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                QTextStream in(&file2);
                QString line = in.readLine();
                if(line=="NEWINSTALL")
                {
                    newInstall = true;
                    while(!in.atEnd())
                    {
                        line = in.readLine();
                        strList << line;
                    }
                }
                file2.close();
            }
            bool ok(true);
            if(newInstall)
            {
                QFile fileOut(appDir+"CaM_Tr2C_R1/CaM_Tr2C_R1.ppro");
                if(fileOut.open(QIODevice::WriteOnly | QIODevice::Text))
                {
                    QTextStream out (&fileOut);
                    for(int i(0); i<strList.size(); ++i)
                    {
                        if(i==3)
                            out<<appDir+"CaM_Tr2C_R1/CaM_Tr2C_R1.ppro\n";
                        else if(i==5)
                            out<<qApp->applicationDirPath()+"/Example_files"<<"\n";
                        else if(i==7)
                            out<<appDir<<"CaM_Tr2C_R1\n";
                        else if(i==11)
                            out<<appDir<<"CaM_Tr2C_R1/param.pint\n";
                        else if(i==13)
                            out<<appDir<<"CaM_Tr2C_R1/out\n";
                        else if(i==15)
                            out<<appDir<<"CaM_Tr2C_R1/tmp_out\n";
                        else if(i==17)
                            out<<appDir<<"CaM_Tr2C_R1/plot\n";
                        else if(i==19)
                            out<<appDir<<"CaM_Tr2C_R1/tmp_plot\n";
                        else if(i==21)
                            out<<appDir<<"CaM_Tr2C_R1/paramCenterPeak.pint\n";
                        else if(i==23)
                            out<<appDir<<"CaM_Tr2C_R1/peaklist.list\n";
                        else if(i==25)
                            out<<appDir<<"CaM_Tr2C_R1/centerPeakList.list\n";
                        else if(i==29)
                            out<<appDir<<"CaM_Tr2C_R1/CaM_R1.ft3\n";
                        else if(i==31)
                            out<<appDir<<"CaM_Tr2C_R1/R1_peaklist.txt\n";
                        else if(i==33)
                            out<<appDir<<"CaM_Tr2C_R1/procpar\n";
                        else if(i==35)
                            out<<appDir<<"CaM_Tr2C_R1/CaM_R1.ft3\n";
                        else
                            out << strList.at(i)<<"\n";
                    }
                    fileOut.close();
                }
                else
                    ok = false;
            }
            if(ok)
                files << appDir+"CaM_Tr2C_R1/CaM_Tr2C_R1.ppro";
        }
        QFile file3(appDir+"CaM_Tr2C_R1rho/CaM_Tr2C_R1rho.ppro");
        if(file3.exists())
        {
            QStringList strList;
            bool newInstall(false);
            if(file3.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                QTextStream in(&file3);
                QString line = in.readLine();
                if(line=="NEWINSTALL")
                {
                    newInstall = true;
                    while(!in.atEnd())
                    {
                        line = in.readLine();
                        strList << line;
                    }
                }
                file3.close();
            }
            bool ok(true);
            if(newInstall)
            {
                QFile fileOut(appDir+"CaM_Tr2C_R1rho/CaM_Tr2C_R1rho.ppro");
                if(fileOut.open(QIODevice::WriteOnly | QIODevice::Text))
                {
                    QTextStream out (&fileOut);
                    for(int i(0); i<strList.size(); ++i)
                    {
                        if(i==3)
                            out<<appDir+"CaM_Tr2C_R1rho/CaM_Tr2C_R1rho.ppro\n";
                        else if(i==5)
                            out<<qApp->applicationDirPath()+"/Example_files"<<"\n";
                        else if(i==7)
                            out<<appDir<<"CaM_Tr2C_R1rho\n";
                        else if(i==11)
                            out<<appDir<<"CaM_Tr2C_R1rho/param.pint\n";
                        else if(i==13)
                            out<<appDir<<"CaM_Tr2C_R1rho/out\n";
                        else if(i==15)
                            out<<appDir<<"CaM_Tr2C_R1rho/tmp_out\n";
                        else if(i==17)
                            out<<appDir<<"CaM_Tr2C_R1rho/plot\n";
                        else if(i==19)
                            out<<appDir<<"CaM_Tr2C_R1rho/tmp_plot\n";
                        else if(i==21)
                            out<<appDir<<"CaM_Tr2C_R1rho/paramCenterPeak.pint\n";
                        else if(i==23)
                            out<<appDir<<"CaM_Tr2C_R1rho/peaklist.list\n";
                        else if(i==25)
                            out<<appDir<<"CaM_Tr2C_R1rho/centerPeakList.list\n";
                        else if(i==29)
                            out<<appDir<<"CaM_Tr2C_R1rho/CaM_R1rho.ft3\n";
                        else if(i==31)
                            out<<appDir<<"CaM_Tr2C_R1rho/R1rho_peaklist.txt\n";
                        else if(i==33)
                            out<<appDir<<"CaM_Tr2C_R1rho/procpar\n";
                        else if(i==34)
                            out<<appDir<<"CaM_Tr2C_R1rho/expfit.txt\n";
                        else if(i==36)
                            out<<appDir<<"CaM_Tr2C_R1rho/CaM_R1rho.ft3\n";
                        else if(i==156)
                            out<<"-r2fromr1rhoR1List "<<appDir+"CaM_Tr2C_R1rho/expfit.txt\n";
                        else
                            out << strList.at(i)<<"\n";
                    }
                    fileOut.close();
                }
                else
                    ok = false;
                QFile data(appDir+"CaM_Tr2C_R1rho/param.pint");
                if(data.open(QIODevice::Text | QIODevice::ReadOnly))
                {
                    QString dataText = data.readAll();
                    QRegularExpression re("-r2fromr1rhoR1List C:/Users/marni/Desktop/BETA_TESTS/CaM_Tr2C_R1rho/expfit.txt");
                    QString replacementText("-r2fromr1rhoR1List "+appDir+"CaM_Tr2C_R1rho/expfit.txt\n");
                    dataText.replace(re, replacementText);
                    data.close();
                    QFile newData(appDir+"CaM_Tr2C_R1rho/param.pint");
                    if(newData.open(QFile::WriteOnly | QFile::Truncate)) {
                        QTextStream out(&newData);
                        out << dataText;
                        newData.close();
                    }
                }
            }
            if(ok)
                files << appDir+"CaM_Tr2C_R1rho/CaM_Tr2C_R1rho.ppro";
        }
        QFile file4(appDir+"CaM_Tr2C_NOE/CaM_Tr2C_NOE.ppro");
        if(file4.exists())
        {
            QStringList strList;
            bool newInstall(false);
            if(file4.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                QTextStream in(&file4);
                QString line = in.readLine();
                if(line=="NEWINSTALL")
                {
                    newInstall = true;
                    while(!in.atEnd())
                    {
                        line = in.readLine();
                        strList << line;
                    }
                }
                file4.close();
            }
            bool ok(true);
            if(newInstall)
            {
                QFile fileOut(appDir+"CaM_Tr2C_NOE/CaM_Tr2C_NOE.ppro");
                if(fileOut.open(QIODevice::WriteOnly | QIODevice::Text))
                {
                    QTextStream out (&fileOut);
                    for(int i(0); i<strList.size(); ++i)
                    {
                        if(i==3)
                            out<<appDir+"CaM_Tr2C_NOE/CaM_Tr2C_NOE.ppro\n";
                        else if(i==5)
                            out<<qApp->applicationDirPath()+"/Example_files"<<"\n";
                        else if(i==7)
                            out<<appDir<<"CaM_Tr2C_NOE\n";
                        else if(i==11)
                            out<<appDir<<"CaM_Tr2C_NOE/param.pint\n";
                        else if(i==13)
                            out<<appDir<<"CaM_Tr2C_NOE/out\n";
                        else if(i==15)
                            out<<appDir<<"CaM_Tr2C_NOE/tmp_out\n";
                        else if(i==17)
                            out<<appDir<<"CaM_Tr2C_NOE/plot\n";
                        else if(i==19)
                            out<<appDir<<"CaM_Tr2C_NOE/tmp_plot\n";
                        else if(i==21)
                            out<<appDir<<"CaM_Tr2C_NOE/paramCenterPeak.pint\n";
                        else if(i==23)
                            out<<appDir<<"CaM_Tr2C_NOE/peaklist.list\n";
                        else if(i==25)
                            out<<appDir<<"CaM_Tr2C_NOE/centerPeakList.list\n";
                        else if(i==29)
                            out<<appDir<<"CaM_Tr2C_NOE/CaM_NOE.ft3\n";
                        else if(i==31)
                            out<<appDir<<"CaM_Tr2C_NOE/NOE_peaklist.txt\n";
                        else if(i==33)
                            out<<appDir<<"CaM_Tr2C_NOE/procpar\n";
                        else if(i==35)
                            out<<appDir<<"CaM_Tr2C_NOE/CaM_NOE.ft3\n";
                        else
                            out << strList.at(i)<<"\n";
                    }
                    fileOut.close();
                }
                else
                    ok = false;
            }
            if(ok)
                files << appDir+"CaM_Tr2C_NOE/CaM_Tr2C_NOE.ppro";
        }
    }
    if(files.size()>0)
    {
        ui->filesTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
        for(int i(0); i<files.size(); i++)
        {
            QFile file(currentDir.absoluteFilePath(files[i]));
            QDateTime modified = QFileInfo(file).lastModified();

            QTableWidgetItem *fileNameItem = new QTableWidgetItem(files[i]);
            fileNameItem->setFlags(fileNameItem->flags() ^ Qt::ItemIsEditable);
            QTableWidgetItem *lastModified = new QTableWidgetItem(modified.toString());
            lastModified->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            lastModified->setFlags(lastModified->flags() ^ Qt::ItemIsEditable);

            int row = ui->filesTable->rowCount();
            ui->filesTable->insertRow(row);
            ui->filesTable->setItem(row, 0, fileNameItem);
            ui->filesTable->setItem(row, 1, lastModified);
        }
    }
    else
    {
        ui->filesTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
        QTableWidgetItem *fileNameItem = new QTableWidgetItem("Could not find a project file in the specified directory.");
        ui->filesTable->insertRow(0);
        ui->filesTable->setItem(0, 0, fileNameItem);
    }
}

void loadProjectWidget::openFileOfItem(int row, int col)
{
    if(lockAndLoad) return;
    lockAndLoad=true;
    Q_UNUSED(col) //Avoid compiler warnings for unused variables, in this case needed to connect the signal correctly

    //Open a file that was double clicked. It is linked correctly. Fix the data handling.
    //row == 0 col==0 is the first file. col==1 must be allowed but still open col==0 files.

    QString fname(ui->filesTable->item(row, 0)->text());
    QFile file(fname);
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        errMsg="Could not open the project";
        displayError();
        lockAndLoad=false;
        return;
    }
    QTextStream in(&file);
    projectTemplate tmplate;
    tmplate.planeMax=1;
    peaklistClass peakClass;
    QVector<QVector<QString > > tmpVector;
    QString spectrum("");

    int fileType(-1);
    while(!in.atEnd())
    {
        QString line = in.readLine();
        if(line=="")
            continue;
        else if(line=="#spectrumFiles")
        {
            fileType = 1;
            continue;
        }
        else if(line == "#peaklistFiles")
        {
            fileType = 2;
            continue;
        }
        else if(line == "#otherFiles")
        {
            fileType = 3;
            continue;
        }
        else if(line == "#projectRootDirectory")
        {
            fileType = 4;
            continue;
        }
        else if(line == "#projectName")
        {
            fileType = 5;
            continue;
        }
        else if(line == "#projectDirectory")
        {
            fileType = 6;
            continue;
        }
        else if(line == "#paramFile")
        {
            fileType = 7;
            continue;
        }
        else if(line == "#outDirectory")
        {
            fileType = 8;
            continue;
        }
        else if(line == "#plotDirectory")
        {
            fileType = 9;
            continue;
        }
        else if(line == "#pipeData")
        {
            fileType = 10;
            continue;
        }
        else if(line == "#peakCenterParamFile")
        {
            fileType = 11;
            continue;
        }
        else if(line == "#centerPeakList")
        {
            fileType = 12;
            continue;
        }
        else if(line == "#tmpOutDirectory")
        {
            fileType = 13;
            continue;
        }
        else if(line == "#tmpPlotDirectory")
        {
            fileType = 14;
            continue;
        }
        else if(line == "#saveFile")
        {
            fileType = 15;
            continue;
        }
        else if(line == "#connectedSpectrum")
        {
            fileType = 16;
            continue;
        }
        else if(line == "#connectedPeaklist")
        {
            fileType = 17;
            continue;
        }
        else if(line == "#connectedEnd")
        {
            fileType = 18;
        }
        else if(line == "#integratePeakList")
        {
            fileType = 19;
            continue;
        }
        else if(line == "#currentPeakID")
        {
            fileType = 20;
            continue;
        }
        else if(line == "#overlapVector")
        {
            fileType = 21;
            continue;
        }
        else if(line == "#endOverlapVector")
        {
            fileType = 22;
        }
        else if(line == "#planeFiles")
        {
            fileType = 23;
            continue;
        }
        else if(line == "#spD")
        {
            fileType = 24;
            continue;
        }
        else if(line == "#peD")
        {
            fileType = 25;
            continue;
        }
        else if(line == "#prD")
        {
            fileType = 26;
            continue;
        }
        /*
        if(line=="")
        {
            line=in.readLine();
            continue;
        }
        else if(line=="#spectrumFiles")
        {
            fileType = 1;
            line=in.readLine();
            continue;
        }
        else if(line == "#peaklistFiles")
        {
            fileType = 2;
            line=in.readLine();
            continue;
        }
        else if(line == "#otherFiles")
        {
            fileType = 3;
            line=in.readLine();
            continue;
        }
        else if(line == "#projectRootDirectory")
        {
            fileType = 4;
            line=in.readLine();
            continue;
        }
        else if(line == "#projectName")
        {
            fileType = 5;
            line=in.readLine();
            continue;
        }
        else if(line == "#projectDirectory")
        {
            fileType = 6;
            line=in.readLine();
            continue;
        }
        else if(line == "#paramFile")
        {
            fileType = 7;
            line=in.readLine();
            continue;
        }
        else if(line == "#outDirectory")
        {
            fileType = 8;
            line=in.readLine();
            continue;
        }
        else if(line == "#plotDirectory")
        {
            fileType = 9;
            line=in.readLine();
            continue;
        }
        else if(line == "#pipeData")
        {
            fileType = 10;
            line=in.readLine();
            continue;
        }
        else if(line == "#peakCenterParamFile")
        {
            fileType = 11;
            line=in.readLine();
            continue;
        }
        else if(line == "#centerPeakList")
        {
            fileType = 12;
            line=in.readLine();
            continue;
        }
        else if(line == "#tmpOutDirectory")
        {
            fileType = 13;
            line=in.readLine();
            continue;
        }
        else if(line == "#tmpPlotDirectory")
        {
            fileType = 14;
            line=in.readLine();
            continue;
        }
        else if(line == "#saveFile")
        {
            fileType = 15;
            line=in.readLine();
            continue;
        }
        else if(line == "#connectedSpectrum")
        {
            fileType = 16;
            line=in.readLine();
            continue;
        }
        else if(line == "#connectedPeaklist")
        {
            fileType = 17;
            line=in.readLine();
            continue;
        }
        else if(line == "#connectedEnd")
        {
            fileType = 18;
        }
        else if(line == "#integratePeakList")
        {
            fileType = 19;
            line=in.readLine();
            continue;
        }
        else if(line == "#currentPeakID")
        {
            fileType = 20;
            line=in.readLine();
            continue;
        }
        else if(line == "#overlapVector")
        {
            fileType = 21;
            line=in.readLine();
            continue;
        }
        else if(line == "#endOverlapVector")
        {
            fileType = 22;
        }
        else if(line == "#planeFiles")
        {
            fileType = 23;
            line = in.readLine();
            continue;
        }
        else if(line == "#spD")
        {
            fileType = 24;
            line = in.readLine();
            continue;
        }
        else if(line == "#peD")
        {
            fileType = 25;
            line = in.readLine();
            continue;
        }
        else if(line == "#prD")
        {
            fileType = 26;
            line = in.readLine();
            continue;
        }
        */
        switch(fileType)
        {
        case 1: tmplate.spectrumFiles.push_back(line); break;
        case 2: tmplate.peaklistFiles.push_back(line); break;
        case 3: tmplate.otherFiles.push_back(line); break;
        case 4: tmplate.projectRootDirectory = line; break;
        case 5: tmplate.projectName = line; break;
        case 6: tmplate.projectDirectory = line; break;
        case 7: tmplate.paramFile = line; break;
        case 8: tmplate.outDirectory = line; break;
        case 9: tmplate.plotDirectory = line; break;
        case 10:
            if(line=="0")
                tmplate.pipeData = false;
            else
                tmplate.pipeData = true;
            break;
        case 11: tmplate.peakCenterParamFile = line; break;
        case 12: tmplate.centerPeakList = line; break;
        case 13: tmplate.tmpOutDirectory= line; break;
        case 14: tmplate.tmpPlotDirectory= line; break;
        case 15: tmplate.saveFile= line; break;
        case 16: spectrum = line; break;
        case 17:
        {
            QVector<QString> tmpVec;
            std::string lin(line.toStdString());
            std::istringstream iss(lin);
            std::string sub;
            while(iss >> sub)
                tmpVec.push_back(QString::fromStdString(sub.c_str()));
            tmpVector.push_back(tmpVec);
            break;
        }
        case 18:
        {
            peakClass.spectrum = spectrum;
            peakClass.peaklist = tmpVector;
            QVector<QVector<QString > > newVec;
            tmpVector = newVec;
            tmplate.pintPeaklists.push_back(peakClass);
            break;
        }
        case 19: tmplate.integratePeakList= line; break;
        case 20: tmplate.currentPeakID = line; break;
        case 21:
        {
            std::string lin(line.toStdString());
            std::istringstream iss(lin);
            std::string sub;
            QStringList list;
            while(iss >> sub)
                list << QString::fromStdString(sub.c_str());
            tmplate.overlapVec.push_back(list);
            break;
        }
        case 22:
        {
            break;
        }
        case 23:
        {
            bool ok;
            int a(line.toInt(&ok));
            if(ok)
                tmplate.planeMax = a;
            break;
        }
        case 24:
        {
            bool ok;
            int a(line.toInt(&ok));
            if(ok)
                tmplate.spD = a;
            break;
        }
        case 25:
        {
            bool ok;
            int a(line.toInt(&ok));
            if(ok)
                tmplate.peD = a;
            break;
        }
        case 26:
        {
            bool ok;
            int a(line.toInt(&ok));
            if(ok)
                tmplate.prD = a;
            break;
        }
        default: break;
        }
        //line=in.readLine();
    }
    file.close();
    if(validateTemplate(tmplate, fname))
    {
        if(errMsg!="")
        {
            errMsg="";
            QMessageBox::StandardButton dlg;
            dlg = QMessageBox::warning(this, "PINT",
                                       "The loaded project was corrected according to the displayed error messages, but it has not been saved yet.\nDo you want to continue to work with this project and accept the changes made?",
                                       QMessageBox::Yes | QMessageBox::No);
            if(dlg==QMessageBox::No)
            {
                lockAndLoad=false;
                return;
            }
        }
        emit openProject(tmplate);
    }
    else
    {
        errMsg="The loaded project is corrupted. Aborting.";
        displayError();
        lockAndLoad=false;
        return;
    }
}

bool loadProjectWidget::validateTemplate(projectTemplate &tmplate, QString fname)
{
    //Check if all needed parameters are imported and if the project has been
    //moved to another directory.
    bool err(false);
    if(tmplate.saveFile != fname)
    {
        QFileInfo file(fname);
        errMsg="The project has been moved to another location since the last session.\n"
               "PINT will update the project directory to "+file.absolutePath();
        err = true;
        displayError();
        tmplate.saveFile = fname;
        for(int i(file.absolutePath().length()-2); i>=0; --i)
        {
            if(file.absolutePath().at(i) == '/')
            {
                tmplate.projectRootDirectory = file.absolutePath().mid(0,i);
                break;
            }
        }
        tmplate.projectDirectory = file.absolutePath();
        tmplate.paramFile = file.absolutePath() + "/param.pint";
        tmplate.outDirectory = file.absolutePath() + "/out";
        tmplate.tmpOutDirectory = file.absolutePath() + "/tmp_out";
        tmplate.plotDirectory = file.absolutePath() + "/plot";
        tmplate.tmpPlotDirectory = file.absolutePath() + "/tmp_plot";
        tmplate.peakCenterParamFile = file.absolutePath() + "/paramCenterPeak.pint";
        tmplate.integratePeakList = file.absolutePath() + "/peaklist.list";
        tmplate.centerPeakList = file.absolutePath() + "/centerPeakList.list";
    }
    if(tmplate.projectDirectory=="" || tmplate.paramFile=="" ||tmplate.outDirectory==""
            || tmplate.tmpOutDirectory=="" || tmplate.plotDirectory=="" || tmplate.tmpPlotDirectory==""
            || tmplate.peakCenterParamFile=="" || tmplate.integratePeakList=="" || tmplate.centerPeakList=="")
        return false;
    if(tmplate.projectName=="")
        tmplate.projectName = "PINT_PROJECT";
    tmplate.spectrumFiles = checkFile(tmplate.spectrumFiles);
    tmplate.peaklistFiles = checkFile(tmplate.peaklistFiles);
    tmplate.otherFiles = checkFile(tmplate.otherFiles);
    for(int k(0); k<tmplate.pintPeaklists.count(); ++k)
    {
        for(int i(0); i<tmplate.spectrumFiles.count(); ++i)
        {
            if(tmplate.pintPeaklists.at(k).spectrum == tmplate.spectrumFiles.at(i))
                break;
            else if(i ==tmplate.spectrumFiles.count()-1)
            {
                tmplate.pintPeaklists.removeAt(k);
                --k;
            }
        }
    }
    if(tmplate.currentPeakID=="")
        tmplate.currentPeakID="0";
    if(errMsg!="")
    {
        displayError();
        err =true;
    }
    if(err)
        errMsg="Error";
    return true;
}

QVector<QString> loadProjectWidget::checkFile(QVector<QString> vec)
{
    for(int i(0); i<vec.count(); ++i)
    {
        QFile file(vec.at(i));
        if(!file.exists())
        {
            errMsg+=vec.at(i)+" was removed from project because it does not exist.\n";
            vec.removeAt(i);
            --i;
        }
    }
    return vec;
}

void loadProjectWidget::displayError()
{
    //Error occurred and is stored in errMsg
    QMessageBox::StandardButton dlg;
    dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
    if(dlg==QMessageBox::Ok)
    {
        errMsg=""; //We never have to worry about random errors when reseting the property before returning.
        return;
    }
}

void loadProjectWidget::scaleWidget()
{
    //Buttons
    ui->browseButton->setMinimumSize(ui->browseButton->minimumSize().width()*scaleFactor, ui->browseButton->minimumSize().height()*scaleFactor);
    ui->browseButton->setMaximumSize(ui->browseButton->minimumSize());
    ui->browseButton->setIconSize(ui->browseButton->iconSize()*scaleFactor);
    ui->cancelButton->setMinimumSize(ui->cancelButton->minimumSize().width()*scaleFactor, ui->cancelButton->minimumSize().height()*scaleFactor);
    ui->cancelButton->setMaximumSize(ui->cancelButton->minimumSize());
    ui->cancelButton->setIconSize(ui->cancelButton->iconSize()*scaleFactor);
    ui->subButton->setMinimumSize(ui->subButton->minimumSize().width()*scaleFactor, ui->subButton->minimumSize().height()*scaleFactor);
    ui->subButton->setMaximumSize(ui->subButton->minimumSize());
    ui->subButton->setIconSize(ui->subButton->iconSize()*scaleFactor);

    //Labels
    ui->browseLabel->setFont(scaleFont(ui->browseLabel->font()));
    ui->cancelLabel->setFont(scaleFont(ui->cancelLabel->font()));
    ui->labelDirectory->setFont(scaleFont(ui->labelDirectory->font()));
    ui->labelPINT->setFont(scaleFont(ui->labelPINT->font()));
    ui->labelVersion->setFont(scaleFont(ui->labelVersion->font()));
    ui->label_LoadProject->setFont(scaleFont(ui->label_LoadProject->font()));
    ui->subLabel->setFont(scaleFont(ui->subLabel->font()));

    ui->directoryEdit->setFont(scaleFont(ui->directoryEdit->font()));
    ui->filesTable->setMinimumSize(ui->filesTable->minimumWidth()*scaleFactor, ui->filesTable->minimumHeight()*scaleFactor);

    QStringList labels;
    labels << tr("Filename") << tr("Last modified");

    ui->filesTable->horizontalHeader()->setFont(scaleFont(ui->filesTable->font()));
    ui->filesTable->setHorizontalHeaderLabels(labels);
}

QFont loadProjectWidget::scaleFont(QFont fnt)
{
    fnt.setPointSizeF(fnt.pointSizeF()*scaleFactor);
    return fnt;
}
