#ifndef CUSTOMITEMPROPERTIES_H
#define CUSTOMITEMPROPERTIES_H

#include <QtDataVisualization/Q3DSurface>
#include <QPropertyAnimation>
#include <QtDataVisualization/QCustom3DLabel>
#include <QObject>

using namespace QtDataVisualization;
using namespace std;

class customItemProperties : public QObject
{
    Q_OBJECT
public:
    customItemProperties(QObject *parent = 0);
    ~customItemProperties();
    QPropertyAnimation *pointerAnimation;
    QCustom3DItem *targetItem;
    QCustom3DItem *nonselectedLabel;
    QCustom3DLabel *selectedLabel;
    QVector3D labelScaling;
    QVector3D targetScaling;
};

#endif // CUSTOMITEMPROPERTIES_H
