#ifndef WORKSPACEWIDGET_H
#define WORKSPACEWIDGET_H

#include <QMainWindow>
#include "projecttemplate.h"
#include <QtDataVisualization/Q3DSurface>
#include <stdlib.h>
#include "spectrumgraph.h"
#include "pipedatatemplate.h"
#include <QMenuBar>

using namespace QtDataVisualization;
using namespace std;

namespace Ui {
class workspaceWidget;
}

class workspaceWidget : public QMainWindow
{
    Q_OBJECT

public:
    explicit workspaceWidget(QWidget *parent = 0);
    ~workspaceWidget();

public slots:
    void readFromTemplate(projectTemplate tmplate);
    void sendLabelTitle(QAbstract3DGraph::ElementType type);

private:
    Ui::workspaceWidget *ui;
    projectTemplate pintTemplate;
    QString previousDir;
    SpectrumGraph *spectrumView3D;
    float cutoffSliderMax;
    float cutoffSliderMin;
    QString errMsg;
    QString loadedSpectrum;
    int peakId;
    QMenuBar *menubar;

private slots:
    void makeConnections();
    void setupCosmeticChanges();
    void setTabFromShortcut(int tabNo);
    void setupSpectrumWidget();
    void setupPlotWidget();
    void on_spectrumButton_clicked();
    void on_peaklistButton_clicked();
    void on_otherButton_clicked();
    void removeFiles(int source);
    void on_removeSelectedButton_clicked();
    void on_removeSelectedButton_2_clicked();
    void on_removeSelectedButton_3_clicked();
    bool checkSpectrumFormat(QString file);
    bool checkPeaklistFormat(QString file);
    void on_integrateButton_clicked();
    QStringList addFiles(QString str);
    void on_loadSpectrumButton_clicked();
    void read3DSpectrum();
    pipeDataTemplate readPipeHeader();
    pipeDataTemplate readPipeSpectrum(pipeDataTemplate pipe);
    void updateCutoffBox(int value);
    void updateSlider(double value);
    void displayError();
    void on_hideHintButton_clicked();
    void on_loadPeaklistButton_clicked();
    void createPeakLabels(int start);
    void updatePeakLabels(int row, int col);
    void highlightPeak();
    void deselectTable();
    void createUserPeak(QVector3D position);
    void deleteUserPeak(int globalID);
    void deleteFromPeaklist();
    void changeActions(int activeTab);
    void setupMenuBar();
};

#endif // WORKSPACEWIDGET_H
