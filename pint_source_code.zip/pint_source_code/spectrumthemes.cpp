#include "spectrumthemes.h"

spectrumThemes::spectrumThemes() :
    builtin(false), style(""), labelBorderColor(QColor(0,0,0)), labelBgColor(QColor(0,0,0)),
    foldedBorderColor(QColor(0,0,0)), foldedBgColor(QColor(0,0,0)), selectedBorderColor(QColor(0,0,0)),
    selectedBgColor(QColor(0,0,0)), moveBorderColor(QColor(0,0,0)), moveBgColor(QColor(0,0,0)),
    selectionPointerColor(QColor(0,0,0)), gridlineColor(QColor(0,0,0)), gridBgColor(QColor(0,0,0)),
    areaColor(QColor(0,0,0)), axisColor(QColor(0,0,0)), axisTextColor(QColor(0,0,0)), markerColor(QColor(0,0,0)),
    gridToggled(true), color1(QColor(0,0,0)), color2(QColor(0,0,0)), color3(QColor(0,0,0)), color4(QColor(0,0,0)),
    color5(QColor(0,0,0)), color6(QColor(0,0,0)), stop1(.0), stop2(.0), stop3(.0), stop4(.0), stop5(.0), stop6(.0),
    plotGradient(QLinearGradient()), gradientButtonStylesheet("")
{
}

spectrumThemes::~spectrumThemes()
{
}
