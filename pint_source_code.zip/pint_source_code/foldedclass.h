#ifndef FOLDEDCLASS_H
#define FOLDEDCLASS_H
#include <QString>

class foldedClass
{
public:
    foldedClass();
    ~foldedClass();
    float foldedF1val;
    float foldedF2val;
    int foldedF1;
    int foldedF2;
};

#endif // FOLDEDCLASS_H
