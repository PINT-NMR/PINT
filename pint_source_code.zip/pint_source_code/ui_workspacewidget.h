/********************************************************************************
** Form generated from reading UI file 'workspacewidget.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WORKSPACEWIDGET_H
#define UI_WORKSPACEWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_workSpaceWidget
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_15;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_14;
    QTabWidget *workspaceTab;
    QWidget *projectFileTab;
    QGridLayout *gridLayout_2;
    QVBoxLayout *verticalLayout_16;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer_10;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *verticalLayout_8;
    QLabel *labelSpectra;
    QListWidget *spectrumList;
    QVBoxLayout *verticalLayout_5;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *spectrumButton;
    QSpacerItem *horizontalSpacer;
    QLabel *spectraLabel;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *removeSelectedButton;
    QSpacerItem *horizontalSpacer_6;
    QLabel *selectedLabel;
    QSpacerItem *horizontalSpacer_9;
    QVBoxLayout *verticalLayout_13;
    QHBoxLayout *horizontalLayout_6;
    QVBoxLayout *verticalLayout_7;
    QLabel *labelPeaklist;
    QListWidget *peaklistList;
    QVBoxLayout *verticalLayout_6;
    QSpacerItem *verticalSpacer_2;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *peaklistButton;
    QSpacerItem *horizontalSpacer_4;
    QLabel *peaklistLabel;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *removeSelectedButton_2;
    QSpacerItem *horizontalSpacer_8;
    QLabel *selectedLabel_2;
    QHBoxLayout *horizontalLayout_7;
    QVBoxLayout *verticalLayout_9;
    QLabel *labelOther;
    QListWidget *otherList;
    QVBoxLayout *verticalLayout_10;
    QSpacerItem *verticalSpacer_4;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_12;
    QPushButton *otherButton;
    QSpacerItem *horizontalSpacer_13;
    QLabel *otherLabel;
    QVBoxLayout *verticalLayout_12;
    QHBoxLayout *horizontalLayout_9;
    QSpacerItem *horizontalSpacer_14;
    QPushButton *removeSelectedButton_3;
    QSpacerItem *horizontalSpacer_15;
    QLabel *selectedLabel_3;
    QSpacerItem *horizontalSpacer_11;
    QSpacerItem *verticalSpacer_3;
    QWidget *spectrumTab;
    QGridLayout *gridLayout_6;
    QVBoxLayout *verticalLayout_26;
    QVBoxLayout *verticalLayout_18;
    QLabel *spectrumViewLabel;
    QHBoxLayout *horizontalLayout_20;
    QComboBox *spectrumBox;
    QPushButton *loadSpectrumButton;
    QGridLayout *gridLayout_3;
    QRadioButton *view3DButton;
    QRadioButton *contourButton;
    QFrame *line;
    QVBoxLayout *verticalLayout_17;
    QLabel *spectrumPeaklistLabel;
    QHBoxLayout *horizontalLayout_21;
    QComboBox *peaklistBox;
    QPushButton *loadPeaklistButton;
    QPushButton *savePeaklistButton;
    QTableWidget *peaklistTable;
    QWidget *hintWidget;
    QVBoxLayout *verticalLayout_25;
    QHBoxLayout *horizontalLayout_22;
    QSpacerItem *horizontalSpacer_22;
    QLabel *hideHintLabel;
    QPushButton *hideHintButton;
    QHBoxLayout *horizontalLayout_16;
    QLabel *navLabel1;
    QLabel *navLabel2;
    QLabel *deleteLabel;
    QLabel *deleteLabel2;
    QHBoxLayout *horizontalLayout_17;
    QLabel *zoomLabel;
    QLabel *zoomLabel2;
    QLabel *returnLabel;
    QLabel *returnLabel2;
    QHBoxLayout *horizontalLayout_18;
    QLabel *rotateLabel;
    QLabel *rotateLabel2;
    QLabel *spaceLabel;
    QLabel *spaceLabel2;
    QHBoxLayout *horizontalLayout_19;
    QLabel *selectLabel;
    QLabel *selectLabel_2;
    QVBoxLayout *verticalLayout_24;
    QWidget *spectrum2DWidget;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_21;
    QWidget *spectrumToolWidget;
    QLabel *cutoffLabel;
    QSlider *intensitySlider;
    QDoubleSpinBox *cutoffBox;
    QWidget *integrationTab;
    QGridLayout *gridLayout_5;
    QHBoxLayout *horizontalLayout_15;
    QSpacerItem *horizontalSpacer_20;
    QHBoxLayout *horizontalLayout_14;
    QVBoxLayout *verticalLayout_23;
    QLabel *labelPeakOptions;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_22;
    QVBoxLayout *verticalLayout_20;
    QLabel *labelParam;
    QTextEdit *paramEdit;
    QVBoxLayout *verticalLayout_21;
    QLabel *labelStatus;
    QTextBrowser *statusBrowser;
    QHBoxLayout *horizontalLayout_13;
    QVBoxLayout *verticalLayout_19;
    QHBoxLayout *horizontalLayout_12;
    QSpacerItem *horizontalSpacer_16;
    QPushButton *integrateButton;
    QSpacerItem *horizontalSpacer_17;
    QLabel *integrateLabel;
    QSpacerItem *horizontalSpacer_18;
    QProgressBar *progressBar;
    QSpacerItem *horizontalSpacer_19;
    QWidget *plotTab;
    QGridLayout *gridLayout_4;
    QWidget *plotWidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *workSpaceWidget)
    {
        if (workSpaceWidget->objectName().isEmpty())
            workSpaceWidget->setObjectName(QStringLiteral("workSpaceWidget"));
        workSpaceWidget->resize(1010, 690);
        centralwidget = new QWidget(workSpaceWidget);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(410, 210, 2, 2));
        verticalLayout_15 = new QVBoxLayout(layoutWidget);
        verticalLayout_15->setObjectName(QStringLiteral("verticalLayout_15"));
        verticalLayout_15->setContentsMargins(0, 0, 0, 0);
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        workspaceTab = new QTabWidget(centralwidget);
        workspaceTab->setObjectName(QStringLiteral("workspaceTab"));
        QFont font;
        font.setFamily(QStringLiteral("Myriad Pro"));
        font.setPointSize(11);
        font.setBold(false);
        font.setWeight(50);
        workspaceTab->setFont(font);
        workspaceTab->setStyleSheet(QLatin1String("QTabWidget::pane {\n"
"    border-top: 2px solid white;\n"
"	border-color: 2 px solid #000000;\n"
"	border-radius: 7px;\n"
" 	background: qradialgradient(\n"
"	   cx: 0.5, cy: -1.8,\n"
"	   fx: 0.5, fy: 0,\n"
"	   radius: 2, \n"
"	   stop: 0 #787878,\n"
"	   stop: 1 #bebebe);\n"
"	  font: bold;\n"
"}\n"
"\n"
"QTabWidget::tab-bar {\n"
"    left: 5px; \n"
"}\n"
"\n"
"QTabBar::tab {\n"
"    border: 2px solid #C4C4C3;\n"
"    border-bottom-color: #C4C4C3;\n"
"    min-width: 20ex;\n"
"    padding: 5px;\n"
"	border-radius: 4px;\n"
"margin: 1;\n"
"}\n"
"\n"
"QTabBar::tab:selected, QTabBar::tab:hover {\n"
"    background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                stop: 0 #fafafa, stop: 0.4 #f4f4f4,\n"
"                                stop: 0.5 #e7e7e7, stop: 1.0 #fafafa);\n"
"}\n"
"\n"
"QTabBar::tab:selected {\n"
"    border-color: #9B9B9B;\n"
"    border-bottom-color: #C2C7CB;\n"
"}\n"
"\n"
"QTabBar::tab:!selected {\n"
"    margin-top: 1px;\n"
"    background: qlineargradient(x1:"
                        " 0, y1: 0, x2: 0, y2: 1,\n"
"                                stop: 0 #b0b0b0, stop: 0.3 #e7e7e7,\n"
"                                stop: 0.4 #e7e7e7, stop: 1.0 #b0b0b0);\n"
"}\n"
"\n"
"QTabBar::tab:first:selected {\n"
"    margin-left: 0;\n"
"}\n"
"\n"
"QTabBar::tab:last:selected {\n"
"    margin-right: 0; /* the last selected tab has nothing to overlap with on the right */\n"
"}"));
        projectFileTab = new QWidget();
        projectFileTab->setObjectName(QStringLiteral("projectFileTab"));
        gridLayout_2 = new QGridLayout(projectFileTab);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setObjectName(QStringLiteral("verticalLayout_16"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_10);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        labelSpectra = new QLabel(projectFileTab);
        labelSpectra->setObjectName(QStringLiteral("labelSpectra"));
        QFont font1;
        font1.setFamily(QStringLiteral("Myriad Pro"));
        font1.setPointSize(16);
        font1.setBold(true);
        font1.setItalic(false);
        font1.setUnderline(true);
        font1.setWeight(75);
        labelSpectra->setFont(font1);

        verticalLayout_8->addWidget(labelSpectra);

        spectrumList = new QListWidget(projectFileTab);
        spectrumList->setObjectName(QStringLiteral("spectrumList"));
        spectrumList->setMinimumSize(QSize(0, 0));
        QFont font2;
        font2.setFamily(QStringLiteral("Myriad Pro"));
        font2.setPointSize(12);
        spectrumList->setFont(font2);
        spectrumList->setStyleSheet(QLatin1String("QListWidget{\n"
"    color: white;\n"
"background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));\n"
"    border-color: rgba(71,78,81,255);\n"
"    border-width: 2px;\n"
"    border-style: solid;\n"
"    padding: 1px 0px 1px 3px; /*This makes text colour work*/\n"
"}\n"
"QListWidget::item:selected{\n"
"color: black;\n"
"}"));
        spectrumList->setFrameShape(QFrame::NoFrame);
        spectrumList->setFrameShadow(QFrame::Sunken);
        spectrumList->setLineWidth(1);
        spectrumList->setSelectionMode(QAbstractItemView::ContiguousSelection);

        verticalLayout_8->addWidget(spectrumList);


        horizontalLayout_5->addLayout(verticalLayout_8);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer_2 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        spectrumButton = new QPushButton(projectFileTab);
        spectrumButton->setObjectName(QStringLiteral("spectrumButton"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(spectrumButton->sizePolicy().hasHeightForWidth());
        spectrumButton->setSizePolicy(sizePolicy);
        spectrumButton->setMinimumSize(QSize(40, 40));
        spectrumButton->setMaximumSize(QSize(40, 40));
        spectrumButton->setStyleSheet(QLatin1String("QPushButton#spectrumButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#spectrumButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#spectrumButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/img/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        spectrumButton->setIcon(icon);
        spectrumButton->setIconSize(QSize(35, 35));

        horizontalLayout->addWidget(spectrumButton);

        horizontalSpacer = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        verticalLayout->addLayout(horizontalLayout);

        spectraLabel = new QLabel(projectFileTab);
        spectraLabel->setObjectName(QStringLiteral("spectraLabel"));
        QFont font3;
        font3.setFamily(QStringLiteral("Myriad Pro"));
        font3.setPointSize(12);
        font3.setBold(false);
        font3.setItalic(false);
        font3.setUnderline(false);
        font3.setWeight(50);
        spectraLabel->setFont(font3);

        verticalLayout->addWidget(spectraLabel);


        verticalLayout_5->addLayout(verticalLayout);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalSpacer_5 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        removeSelectedButton = new QPushButton(projectFileTab);
        removeSelectedButton->setObjectName(QStringLiteral("removeSelectedButton"));
        sizePolicy.setHeightForWidth(removeSelectedButton->sizePolicy().hasHeightForWidth());
        removeSelectedButton->setSizePolicy(sizePolicy);
        removeSelectedButton->setMinimumSize(QSize(40, 40));
        removeSelectedButton->setMaximumSize(QSize(40, 40));
        removeSelectedButton->setStyleSheet(QLatin1String("QPushButton#removeSelectedButton {\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
"    border-style: outset;\n"
"	border-radius: 10px;\n"
"    border-width: 1px;\n"
"    border-color: gray;\n"
"}\n"
"QPushButton#removeSelectedButton:pressed {\n"
"	\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
"    border-style: inset;\n"
"}\n"
"QPushButton#removeSelectedButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/img/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        removeSelectedButton->setIcon(icon1);
        removeSelectedButton->setIconSize(QSize(35, 35));

        horizontalLayout_3->addWidget(removeSelectedButton);

        horizontalSpacer_6 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_6);


        verticalLayout_3->addLayout(horizontalLayout_3);

        selectedLabel = new QLabel(projectFileTab);
        selectedLabel->setObjectName(QStringLiteral("selectedLabel"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(selectedLabel->sizePolicy().hasHeightForWidth());
        selectedLabel->setSizePolicy(sizePolicy1);
        selectedLabel->setMaximumSize(QSize(1000, 1000));
        selectedLabel->setFont(font3);

        verticalLayout_3->addWidget(selectedLabel);


        verticalLayout_5->addLayout(verticalLayout_3);


        horizontalLayout_5->addLayout(verticalLayout_5);


        horizontalLayout_10->addLayout(horizontalLayout_5);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_9);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        labelPeaklist = new QLabel(projectFileTab);
        labelPeaklist->setObjectName(QStringLiteral("labelPeaklist"));
        labelPeaklist->setFont(font1);

        verticalLayout_7->addWidget(labelPeaklist);

        peaklistList = new QListWidget(projectFileTab);
        peaklistList->setObjectName(QStringLiteral("peaklistList"));
        peaklistList->setMinimumSize(QSize(0, 0));
        peaklistList->setFont(font2);
        peaklistList->setStyleSheet(QLatin1String("QListWidget{\n"
"    color: white;\n"
"background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));\n"
"    border-color: rgba(71,78,81,255);\n"
"    border-width: 2px;\n"
"    border-style: solid;\n"
"    padding: 1px 0px 1px 3px; /*This makes text colour work*/\n"
"}\n"
"QListWidget::item:selected{\n"
"color: black;\n"
"}"));
        peaklistList->setSelectionMode(QAbstractItemView::ContiguousSelection);

        verticalLayout_7->addWidget(peaklistList);


        horizontalLayout_6->addLayout(verticalLayout_7);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_6->addItem(verticalSpacer_2);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        peaklistButton = new QPushButton(projectFileTab);
        peaklistButton->setObjectName(QStringLiteral("peaklistButton"));
        sizePolicy.setHeightForWidth(peaklistButton->sizePolicy().hasHeightForWidth());
        peaklistButton->setSizePolicy(sizePolicy);
        peaklistButton->setMinimumSize(QSize(40, 40));
        peaklistButton->setMaximumSize(QSize(40, 40));
        peaklistButton->setStyleSheet(QLatin1String("QPushButton#peaklistButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#peaklistButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#peaklistButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        peaklistButton->setIcon(icon);
        peaklistButton->setIconSize(QSize(35, 35));

        horizontalLayout_2->addWidget(peaklistButton);

        horizontalSpacer_4 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);


        verticalLayout_2->addLayout(horizontalLayout_2);

        peaklistLabel = new QLabel(projectFileTab);
        peaklistLabel->setObjectName(QStringLiteral("peaklistLabel"));
        peaklistLabel->setFont(font3);

        verticalLayout_2->addWidget(peaklistLabel);


        verticalLayout_6->addLayout(verticalLayout_2);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalSpacer_7 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_7);

        removeSelectedButton_2 = new QPushButton(projectFileTab);
        removeSelectedButton_2->setObjectName(QStringLiteral("removeSelectedButton_2"));
        sizePolicy.setHeightForWidth(removeSelectedButton_2->sizePolicy().hasHeightForWidth());
        removeSelectedButton_2->setSizePolicy(sizePolicy);
        removeSelectedButton_2->setMinimumSize(QSize(40, 40));
        removeSelectedButton_2->setMaximumSize(QSize(40, 40));
        removeSelectedButton_2->setStyleSheet(QLatin1String("QPushButton#removeSelectedButton_2 {\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
"    border-style: outset;\n"
"	border-radius: 10px;\n"
"    border-width: 1px;\n"
"    border-color: gray;\n"
"}\n"
"QPushButton#removeSelectedButton_2:pressed {\n"
"	\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
"    border-style: inset;\n"
"}\n"
"QPushButton#removeSelectedButton_2:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        removeSelectedButton_2->setIcon(icon1);
        removeSelectedButton_2->setIconSize(QSize(35, 35));

        horizontalLayout_4->addWidget(removeSelectedButton_2);

        horizontalSpacer_8 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_8);


        verticalLayout_4->addLayout(horizontalLayout_4);

        selectedLabel_2 = new QLabel(projectFileTab);
        selectedLabel_2->setObjectName(QStringLiteral("selectedLabel_2"));
        sizePolicy1.setHeightForWidth(selectedLabel_2->sizePolicy().hasHeightForWidth());
        selectedLabel_2->setSizePolicy(sizePolicy1);
        selectedLabel_2->setMaximumSize(QSize(1000, 1000));
        selectedLabel_2->setFont(font3);

        verticalLayout_4->addWidget(selectedLabel_2);


        verticalLayout_6->addLayout(verticalLayout_4);


        horizontalLayout_6->addLayout(verticalLayout_6);


        verticalLayout_13->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        labelOther = new QLabel(projectFileTab);
        labelOther->setObjectName(QStringLiteral("labelOther"));
        labelOther->setFont(font1);

        verticalLayout_9->addWidget(labelOther);

        otherList = new QListWidget(projectFileTab);
        otherList->setObjectName(QStringLiteral("otherList"));
        otherList->setMinimumSize(QSize(0, 0));
        otherList->setFont(font2);
        otherList->setStyleSheet(QLatin1String("QListWidget{\n"
"    color: white;\n"
"background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));\n"
"    border-color: rgba(71,78,81,255);\n"
"    border-width: 2px;\n"
"    border-style: solid;\n"
"    padding: 1px 0px 1px 3px; /*This makes text colour work*/\n"
"}\n"
"QListWidget::item:selected{\n"
"color: black;\n"
"}"));
        otherList->setSelectionMode(QAbstractItemView::ContiguousSelection);

        verticalLayout_9->addWidget(otherList);


        horizontalLayout_7->addLayout(verticalLayout_9);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_4);

        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        horizontalSpacer_12 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_12);

        otherButton = new QPushButton(projectFileTab);
        otherButton->setObjectName(QStringLiteral("otherButton"));
        sizePolicy.setHeightForWidth(otherButton->sizePolicy().hasHeightForWidth());
        otherButton->setSizePolicy(sizePolicy);
        otherButton->setMinimumSize(QSize(40, 40));
        otherButton->setMaximumSize(QSize(40, 40));
        otherButton->setStyleSheet(QLatin1String("QPushButton#otherButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#otherButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#otherButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        otherButton->setIcon(icon);
        otherButton->setIconSize(QSize(35, 35));

        horizontalLayout_8->addWidget(otherButton);

        horizontalSpacer_13 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_13);


        verticalLayout_11->addLayout(horizontalLayout_8);

        otherLabel = new QLabel(projectFileTab);
        otherLabel->setObjectName(QStringLiteral("otherLabel"));
        otherLabel->setFont(font3);

        verticalLayout_11->addWidget(otherLabel);


        verticalLayout_10->addLayout(verticalLayout_11);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        horizontalSpacer_14 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_14);

        removeSelectedButton_3 = new QPushButton(projectFileTab);
        removeSelectedButton_3->setObjectName(QStringLiteral("removeSelectedButton_3"));
        sizePolicy.setHeightForWidth(removeSelectedButton_3->sizePolicy().hasHeightForWidth());
        removeSelectedButton_3->setSizePolicy(sizePolicy);
        removeSelectedButton_3->setMinimumSize(QSize(40, 40));
        removeSelectedButton_3->setMaximumSize(QSize(40, 40));
        removeSelectedButton_3->setStyleSheet(QLatin1String("QPushButton#removeSelectedButton_3 {\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
"    border-style: outset;\n"
"	border-radius: 10px;\n"
"    border-width: 1px;\n"
"    border-color: gray;\n"
"}\n"
"QPushButton#removeSelectedButton_3:pressed {\n"
"	\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
"    border-style: inset;\n"
"}\n"
"QPushButton#removeSelectedButton_3:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        removeSelectedButton_3->setIcon(icon1);
        removeSelectedButton_3->setIconSize(QSize(35, 35));

        horizontalLayout_9->addWidget(removeSelectedButton_3);

        horizontalSpacer_15 = new QSpacerItem(20, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_15);


        verticalLayout_12->addLayout(horizontalLayout_9);

        selectedLabel_3 = new QLabel(projectFileTab);
        selectedLabel_3->setObjectName(QStringLiteral("selectedLabel_3"));
        sizePolicy1.setHeightForWidth(selectedLabel_3->sizePolicy().hasHeightForWidth());
        selectedLabel_3->setSizePolicy(sizePolicy1);
        selectedLabel_3->setMaximumSize(QSize(1000, 1000));
        selectedLabel_3->setFont(font3);

        verticalLayout_12->addWidget(selectedLabel_3);


        verticalLayout_10->addLayout(verticalLayout_12);


        horizontalLayout_7->addLayout(verticalLayout_10);


        verticalLayout_13->addLayout(horizontalLayout_7);


        horizontalLayout_10->addLayout(verticalLayout_13);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_11);


        verticalLayout_16->addLayout(horizontalLayout_10);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_16->addItem(verticalSpacer_3);


        gridLayout_2->addLayout(verticalLayout_16, 0, 0, 1, 1);

        workspaceTab->addTab(projectFileTab, QString());
        spectrumTab = new QWidget();
        spectrumTab->setObjectName(QStringLiteral("spectrumTab"));
        gridLayout_6 = new QGridLayout(spectrumTab);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        verticalLayout_26 = new QVBoxLayout();
        verticalLayout_26->setObjectName(QStringLiteral("verticalLayout_26"));
        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setObjectName(QStringLiteral("verticalLayout_18"));
        spectrumViewLabel = new QLabel(spectrumTab);
        spectrumViewLabel->setObjectName(QStringLiteral("spectrumViewLabel"));
        spectrumViewLabel->setFont(font3);

        verticalLayout_18->addWidget(spectrumViewLabel);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        spectrumBox = new QComboBox(spectrumTab);
        spectrumBox->setObjectName(QStringLiteral("spectrumBox"));
        spectrumBox->setMinimumSize(QSize(200, 40));
        QFont font4;
        font4.setFamily(QStringLiteral("Myriad Pro"));
        font4.setPointSize(10);
        font4.setBold(false);
        font4.setWeight(50);
        spectrumBox->setFont(font4);
        spectrumBox->setStyleSheet(QLatin1String("	color: white;\n"
"	background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));\n"
"	border-color: rgba(71,78,81,255);\n"
"    border-width: 2px;\n"
"    border-style: solid;\n"
"    padding: 1px 0px 1px 3px; /*This makes text colour work*/"));

        horizontalLayout_20->addWidget(spectrumBox);

        loadSpectrumButton = new QPushButton(spectrumTab);
        loadSpectrumButton->setObjectName(QStringLiteral("loadSpectrumButton"));
        sizePolicy.setHeightForWidth(loadSpectrumButton->sizePolicy().hasHeightForWidth());
        loadSpectrumButton->setSizePolicy(sizePolicy);
        loadSpectrumButton->setMinimumSize(QSize(40, 40));
        loadSpectrumButton->setMaximumSize(QSize(40, 40));
        loadSpectrumButton->setStyleSheet(QLatin1String("QPushButton#loadSpectrumButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#loadSpectrumButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#loadSpectrumButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        loadSpectrumButton->setIcon(icon);
        loadSpectrumButton->setIconSize(QSize(35, 35));

        horizontalLayout_20->addWidget(loadSpectrumButton);


        verticalLayout_18->addLayout(horizontalLayout_20);


        verticalLayout_26->addLayout(verticalLayout_18);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        view3DButton = new QRadioButton(spectrumTab);
        view3DButton->setObjectName(QStringLiteral("view3DButton"));
        view3DButton->setFont(font2);
        view3DButton->setStyleSheet(QLatin1String("QRadioButton{\n"
"color: white;\n"
"}\n"
"QRadioButton::indicator {\n"
"    width: 25px;\n"
"    height: 25px;\n"
"}\n"
"QRadioButton::indicator::unchecked {\n"
"	image: url(:/img/radio_unchecked.png);\n"
"}\n"
"\n"
"QRadioButton::indicator:unchecked:hover {\n"
"    image: url(:/img/radio_unchecked_hover.png);\n"
"}\n"
"\n"
"QRadioButton::indicator::checked {\n"
"	image: url(:/img/radio_checked.png);\n"
"}"));
        view3DButton->setChecked(true);

        gridLayout_3->addWidget(view3DButton, 0, 0, 1, 1);

        contourButton = new QRadioButton(spectrumTab);
        contourButton->setObjectName(QStringLiteral("contourButton"));
        contourButton->setFont(font2);
        contourButton->setStyleSheet(QLatin1String("QRadioButton{\n"
"color: white;\n"
"}\n"
"QRadioButton::indicator {\n"
"    width: 25px;\n"
"    height: 25px;\n"
"}\n"
"QRadioButton::indicator::unchecked {\n"
"	image: url(:/img/radio_unchecked.png);\n"
"}\n"
"\n"
"QRadioButton::indicator:unchecked:hover {\n"
"    image: url(:/img/radio_unchecked_hover.png);\n"
"}\n"
"\n"
"QRadioButton::indicator::checked {\n"
"	image: url(:/img/radio_checked.png);\n"
"}\n"
""));

        gridLayout_3->addWidget(contourButton, 1, 0, 1, 1);


        verticalLayout_26->addLayout(gridLayout_3);

        line = new QFrame(spectrumTab);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_26->addWidget(line);

        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setObjectName(QStringLiteral("verticalLayout_17"));
        spectrumPeaklistLabel = new QLabel(spectrumTab);
        spectrumPeaklistLabel->setObjectName(QStringLiteral("spectrumPeaklistLabel"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(spectrumPeaklistLabel->sizePolicy().hasHeightForWidth());
        spectrumPeaklistLabel->setSizePolicy(sizePolicy2);
        spectrumPeaklistLabel->setFont(font3);

        verticalLayout_17->addWidget(spectrumPeaklistLabel);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        peaklistBox = new QComboBox(spectrumTab);
        peaklistBox->setObjectName(QStringLiteral("peaklistBox"));
        peaklistBox->setMinimumSize(QSize(200, 40));
        peaklistBox->setFont(font4);
        peaklistBox->setStyleSheet(QLatin1String("	color: white;\n"
"	background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));\n"
"	border-color: rgba(71,78,81,255);\n"
"    border-width: 2px;\n"
"    border-style: solid;\n"
"    padding: 1px 0px 1px 3px; /*This makes text colour work*/"));

        horizontalLayout_21->addWidget(peaklistBox);

        loadPeaklistButton = new QPushButton(spectrumTab);
        loadPeaklistButton->setObjectName(QStringLiteral("loadPeaklistButton"));
        sizePolicy.setHeightForWidth(loadPeaklistButton->sizePolicy().hasHeightForWidth());
        loadPeaklistButton->setSizePolicy(sizePolicy);
        loadPeaklistButton->setMinimumSize(QSize(40, 40));
        loadPeaklistButton->setMaximumSize(QSize(40, 40));
        loadPeaklistButton->setStyleSheet(QLatin1String("QPushButton#loadPeaklistButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#loadPeaklistButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#loadPeaklistButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        loadPeaklistButton->setIcon(icon);
        loadPeaklistButton->setIconSize(QSize(35, 35));

        horizontalLayout_21->addWidget(loadPeaklistButton);

        savePeaklistButton = new QPushButton(spectrumTab);
        savePeaklistButton->setObjectName(QStringLiteral("savePeaklistButton"));
        sizePolicy.setHeightForWidth(savePeaklistButton->sizePolicy().hasHeightForWidth());
        savePeaklistButton->setSizePolicy(sizePolicy);
        savePeaklistButton->setMinimumSize(QSize(40, 40));
        savePeaklistButton->setMaximumSize(QSize(40, 40));
        savePeaklistButton->setStyleSheet(QLatin1String("QPushButton#savePeaklistButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#savePeaklistButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#savePeaklistButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/img/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        savePeaklistButton->setIcon(icon2);
        savePeaklistButton->setIconSize(QSize(35, 35));

        horizontalLayout_21->addWidget(savePeaklistButton);


        verticalLayout_17->addLayout(horizontalLayout_21);


        verticalLayout_26->addLayout(verticalLayout_17);

        peaklistTable = new QTableWidget(spectrumTab);
        if (peaklistTable->columnCount() < 4)
            peaklistTable->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        peaklistTable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        peaklistTable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        peaklistTable->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        peaklistTable->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        peaklistTable->setObjectName(QStringLiteral("peaklistTable"));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(peaklistTable->sizePolicy().hasHeightForWidth());
        peaklistTable->setSizePolicy(sizePolicy3);
        peaklistTable->setFont(font2);
        peaklistTable->setStyleSheet(QLatin1String("QTableWidget{\n"
"    color: white;\n"
"background-color: qlineargradient(spread:pad, x1:0.511364, y1:0.966, x2:0.506, y2:0.052, stop:0 rgba(43, 47, 50, 255), stop:1 rgba(61, 61, 61, 255));\n"
"    border-color: rgba(71,78,81,255);\n"
"    border-width: 2px;\n"
"    border-style: solid;\n"
"    padding: 1px 0px 1px 3px; /*This makes text colour work*/\n"
"}\n"
"QTableWidget::item:selected{\n"
"color: black;\n"
"}"));
        peaklistTable->setEditTriggers(QAbstractItemView::DoubleClicked|QAbstractItemView::EditKeyPressed);
        peaklistTable->setSelectionMode(QAbstractItemView::SingleSelection);
        peaklistTable->setShowGrid(false);
        peaklistTable->horizontalHeader()->setDefaultSectionSize(70);
        peaklistTable->horizontalHeader()->setMinimumSectionSize(20);
        peaklistTable->horizontalHeader()->setStretchLastSection(false);

        verticalLayout_26->addWidget(peaklistTable);

        hintWidget = new QWidget(spectrumTab);
        hintWidget->setObjectName(QStringLiteral("hintWidget"));
        verticalLayout_25 = new QVBoxLayout(hintWidget);
        verticalLayout_25->setObjectName(QStringLiteral("verticalLayout_25"));
        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_22);

        hideHintLabel = new QLabel(hintWidget);
        hideHintLabel->setObjectName(QStringLiteral("hideHintLabel"));
        sizePolicy2.setHeightForWidth(hideHintLabel->sizePolicy().hasHeightForWidth());
        hideHintLabel->setSizePolicy(sizePolicy2);
        QFont font5;
        font5.setFamily(QStringLiteral("Myriad Pro"));
        font5.setPointSize(11);
        font5.setBold(false);
        font5.setItalic(false);
        font5.setUnderline(false);
        font5.setWeight(50);
        hideHintLabel->setFont(font5);

        horizontalLayout_22->addWidget(hideHintLabel);

        hideHintButton = new QPushButton(hintWidget);
        hideHintButton->setObjectName(QStringLiteral("hideHintButton"));
        sizePolicy.setHeightForWidth(hideHintButton->sizePolicy().hasHeightForWidth());
        hideHintButton->setSizePolicy(sizePolicy);
        hideHintButton->setMinimumSize(QSize(20, 20));
        hideHintButton->setMaximumSize(QSize(20, 20));
        hideHintButton->setStyleSheet(QLatin1String("QPushButton#hideHintButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(155, 57, 57, 255), stop:1 rgba(188, 82, 83, 255));\n"
" border-style: outset;\n"
"border-radius: 5px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"color: white;\n"
"}\n"
"QPushButton#hideHintButton:pressed {\n"
"	background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(107, 36, 37, 255), stop:1 rgba(167, 58, 60, 255));\n"
" border-style: inset;\n"
"color: white;\n"
"}\n"
"QPushButton#hideHintButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(222, 82, 82, 255), stop:1 rgba(238, 105, 105, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"color: white;\n"
"}"));
        hideHintButton->setIcon(icon1);
        hideHintButton->setIconSize(QSize(15, 15));

        horizontalLayout_22->addWidget(hideHintButton);


        verticalLayout_25->addLayout(horizontalLayout_22);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        navLabel1 = new QLabel(hintWidget);
        navLabel1->setObjectName(QStringLiteral("navLabel1"));
        navLabel1->setMaximumSize(QSize(40, 40));
        navLabel1->setPixmap(QPixmap(QString::fromUtf8(":/img/wasd.png")));
        navLabel1->setScaledContents(true);

        horizontalLayout_16->addWidget(navLabel1);

        navLabel2 = new QLabel(hintWidget);
        navLabel2->setObjectName(QStringLiteral("navLabel2"));
        sizePolicy2.setHeightForWidth(navLabel2->sizePolicy().hasHeightForWidth());
        navLabel2->setSizePolicy(sizePolicy2);
        navLabel2->setFont(font5);

        horizontalLayout_16->addWidget(navLabel2);

        deleteLabel = new QLabel(hintWidget);
        deleteLabel->setObjectName(QStringLiteral("deleteLabel"));
        deleteLabel->setMaximumSize(QSize(40, 40));
        deleteLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/delete.png")));
        deleteLabel->setScaledContents(true);

        horizontalLayout_16->addWidget(deleteLabel);

        deleteLabel2 = new QLabel(hintWidget);
        deleteLabel2->setObjectName(QStringLiteral("deleteLabel2"));
        sizePolicy2.setHeightForWidth(deleteLabel2->sizePolicy().hasHeightForWidth());
        deleteLabel2->setSizePolicy(sizePolicy2);
        deleteLabel2->setFont(font5);

        horizontalLayout_16->addWidget(deleteLabel2);


        verticalLayout_25->addLayout(horizontalLayout_16);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        zoomLabel = new QLabel(hintWidget);
        zoomLabel->setObjectName(QStringLiteral("zoomLabel"));
        zoomLabel->setMaximumSize(QSize(40, 40));
        zoomLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/mouse_scroll.png")));
        zoomLabel->setScaledContents(true);

        horizontalLayout_17->addWidget(zoomLabel);

        zoomLabel2 = new QLabel(hintWidget);
        zoomLabel2->setObjectName(QStringLiteral("zoomLabel2"));
        sizePolicy2.setHeightForWidth(zoomLabel2->sizePolicy().hasHeightForWidth());
        zoomLabel2->setSizePolicy(sizePolicy2);
        zoomLabel2->setFont(font5);

        horizontalLayout_17->addWidget(zoomLabel2);

        returnLabel = new QLabel(hintWidget);
        returnLabel->setObjectName(QStringLiteral("returnLabel"));
        returnLabel->setMaximumSize(QSize(40, 40));
        returnLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/return.png")));
        returnLabel->setScaledContents(true);

        horizontalLayout_17->addWidget(returnLabel);

        returnLabel2 = new QLabel(hintWidget);
        returnLabel2->setObjectName(QStringLiteral("returnLabel2"));
        sizePolicy2.setHeightForWidth(returnLabel2->sizePolicy().hasHeightForWidth());
        returnLabel2->setSizePolicy(sizePolicy2);
        returnLabel2->setFont(font5);

        horizontalLayout_17->addWidget(returnLabel2);


        verticalLayout_25->addLayout(horizontalLayout_17);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        rotateLabel = new QLabel(hintWidget);
        rotateLabel->setObjectName(QStringLiteral("rotateLabel"));
        rotateLabel->setMaximumSize(QSize(40, 40));
        rotateLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/mouse_r_click.png")));
        rotateLabel->setScaledContents(true);

        horizontalLayout_18->addWidget(rotateLabel);

        rotateLabel2 = new QLabel(hintWidget);
        rotateLabel2->setObjectName(QStringLiteral("rotateLabel2"));
        sizePolicy2.setHeightForWidth(rotateLabel2->sizePolicy().hasHeightForWidth());
        rotateLabel2->setSizePolicy(sizePolicy2);
        rotateLabel2->setFont(font5);

        horizontalLayout_18->addWidget(rotateLabel2);

        spaceLabel = new QLabel(hintWidget);
        spaceLabel->setObjectName(QStringLiteral("spaceLabel"));
        spaceLabel->setMaximumSize(QSize(40, 40));
        spaceLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/space.png")));
        spaceLabel->setScaledContents(true);

        horizontalLayout_18->addWidget(spaceLabel);

        spaceLabel2 = new QLabel(hintWidget);
        spaceLabel2->setObjectName(QStringLiteral("spaceLabel2"));
        sizePolicy2.setHeightForWidth(spaceLabel2->sizePolicy().hasHeightForWidth());
        spaceLabel2->setSizePolicy(sizePolicy2);
        spaceLabel2->setFont(font5);

        horizontalLayout_18->addWidget(spaceLabel2);


        verticalLayout_25->addLayout(horizontalLayout_18);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        selectLabel = new QLabel(hintWidget);
        selectLabel->setObjectName(QStringLiteral("selectLabel"));
        selectLabel->setMaximumSize(QSize(40, 40));
        selectLabel->setPixmap(QPixmap(QString::fromUtf8(":/img/mouse_l_click.png")));
        selectLabel->setScaledContents(true);

        horizontalLayout_19->addWidget(selectLabel);

        selectLabel_2 = new QLabel(hintWidget);
        selectLabel_2->setObjectName(QStringLiteral("selectLabel_2"));
        sizePolicy2.setHeightForWidth(selectLabel_2->sizePolicy().hasHeightForWidth());
        selectLabel_2->setSizePolicy(sizePolicy2);
        selectLabel_2->setFont(font5);

        horizontalLayout_19->addWidget(selectLabel_2);


        verticalLayout_25->addLayout(horizontalLayout_19);


        verticalLayout_26->addWidget(hintWidget);


        gridLayout_6->addLayout(verticalLayout_26, 0, 0, 1, 1);

        verticalLayout_24 = new QVBoxLayout();
        verticalLayout_24->setObjectName(QStringLiteral("verticalLayout_24"));
        spectrum2DWidget = new QWidget(spectrumTab);
        spectrum2DWidget->setObjectName(QStringLiteral("spectrum2DWidget"));

        verticalLayout_24->addWidget(spectrum2DWidget);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        horizontalSpacer_21 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_21);

        spectrumToolWidget = new QWidget(spectrumTab);
        spectrumToolWidget->setObjectName(QStringLiteral("spectrumToolWidget"));

        horizontalLayout_11->addWidget(spectrumToolWidget);

        cutoffLabel = new QLabel(spectrumTab);
        cutoffLabel->setObjectName(QStringLiteral("cutoffLabel"));
        cutoffLabel->setFont(font3);

        horizontalLayout_11->addWidget(cutoffLabel);

        intensitySlider = new QSlider(spectrumTab);
        intensitySlider->setObjectName(QStringLiteral("intensitySlider"));
        intensitySlider->setMaximumSize(QSize(200, 16777215));
        intensitySlider->setMaximum(1000);
        intensitySlider->setOrientation(Qt::Horizontal);

        horizontalLayout_11->addWidget(intensitySlider);

        cutoffBox = new QDoubleSpinBox(spectrumTab);
        cutoffBox->setObjectName(QStringLiteral("cutoffBox"));

        horizontalLayout_11->addWidget(cutoffBox);


        verticalLayout_24->addLayout(horizontalLayout_11);


        gridLayout_6->addLayout(verticalLayout_24, 0, 1, 1, 1);

        workspaceTab->addTab(spectrumTab, QString());
        integrationTab = new QWidget();
        integrationTab->setObjectName(QStringLiteral("integrationTab"));
        gridLayout_5 = new QGridLayout(integrationTab);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_20);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        verticalLayout_23 = new QVBoxLayout();
        verticalLayout_23->setObjectName(QStringLiteral("verticalLayout_23"));
        labelPeakOptions = new QLabel(integrationTab);
        labelPeakOptions->setObjectName(QStringLiteral("labelPeakOptions"));
        labelPeakOptions->setFont(font1);

        verticalLayout_23->addWidget(labelPeakOptions);

        tabWidget = new QTabWidget(integrationTab);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        QFont font6;
        font6.setFamily(QStringLiteral("Myriad Pro"));
        font6.setPointSize(11);
        tabWidget->setFont(font6);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tabWidget->addTab(tab_2, QString());

        verticalLayout_23->addWidget(tabWidget);


        horizontalLayout_14->addLayout(verticalLayout_23);

        verticalLayout_22 = new QVBoxLayout();
        verticalLayout_22->setObjectName(QStringLiteral("verticalLayout_22"));
        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setObjectName(QStringLiteral("verticalLayout_20"));
        labelParam = new QLabel(integrationTab);
        labelParam->setObjectName(QStringLiteral("labelParam"));
        labelParam->setFont(font1);

        verticalLayout_20->addWidget(labelParam);

        paramEdit = new QTextEdit(integrationTab);
        paramEdit->setObjectName(QStringLiteral("paramEdit"));
        paramEdit->setFont(font2);

        verticalLayout_20->addWidget(paramEdit);


        verticalLayout_22->addLayout(verticalLayout_20);

        verticalLayout_21 = new QVBoxLayout();
        verticalLayout_21->setObjectName(QStringLiteral("verticalLayout_21"));
        labelStatus = new QLabel(integrationTab);
        labelStatus->setObjectName(QStringLiteral("labelStatus"));
        labelStatus->setFont(font1);

        verticalLayout_21->addWidget(labelStatus);

        statusBrowser = new QTextBrowser(integrationTab);
        statusBrowser->setObjectName(QStringLiteral("statusBrowser"));
        QSizePolicy sizePolicy4(QSizePolicy::MinimumExpanding, QSizePolicy::Expanding);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(statusBrowser->sizePolicy().hasHeightForWidth());
        statusBrowser->setSizePolicy(sizePolicy4);
        statusBrowser->setMinimumSize(QSize(0, 0));

        verticalLayout_21->addWidget(statusBrowser);


        verticalLayout_22->addLayout(verticalLayout_21);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setObjectName(QStringLiteral("verticalLayout_19"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_16);

        integrateButton = new QPushButton(integrationTab);
        integrateButton->setObjectName(QStringLiteral("integrateButton"));
        integrateButton->setStyleSheet(QLatin1String("QPushButton#integrateButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#integrateButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#integrateButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/img/integrate.png"), QSize(), QIcon::Normal, QIcon::Off);
        integrateButton->setIcon(icon3);
        integrateButton->setIconSize(QSize(35, 35));

        horizontalLayout_12->addWidget(integrateButton);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_17);


        verticalLayout_19->addLayout(horizontalLayout_12);

        integrateLabel = new QLabel(integrationTab);
        integrateLabel->setObjectName(QStringLiteral("integrateLabel"));
        integrateLabel->setFont(font3);

        verticalLayout_19->addWidget(integrateLabel);


        horizontalLayout_13->addLayout(verticalLayout_19);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_18);

        progressBar = new QProgressBar(integrationTab);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setValue(24);

        horizontalLayout_13->addWidget(progressBar);


        verticalLayout_22->addLayout(horizontalLayout_13);


        horizontalLayout_14->addLayout(verticalLayout_22);


        horizontalLayout_15->addLayout(horizontalLayout_14);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_19);


        gridLayout_5->addLayout(horizontalLayout_15, 0, 0, 1, 1);

        workspaceTab->addTab(integrationTab, QString());
        plotTab = new QWidget();
        plotTab->setObjectName(QStringLiteral("plotTab"));
        gridLayout_4 = new QGridLayout(plotTab);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        plotWidget = new QWidget(plotTab);
        plotWidget->setObjectName(QStringLiteral("plotWidget"));

        gridLayout_4->addWidget(plotWidget, 0, 0, 1, 1);

        workspaceTab->addTab(plotTab, QString());

        verticalLayout_14->addWidget(workspaceTab);


        gridLayout->addLayout(verticalLayout_14, 0, 0, 1, 1);

        workSpaceWidget->setCentralWidget(centralwidget);
        menubar = new QMenuBar(workSpaceWidget);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1010, 21));
        workSpaceWidget->setMenuBar(menubar);
        statusbar = new QStatusBar(workSpaceWidget);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        workSpaceWidget->setStatusBar(statusbar);

        retranslateUi(workSpaceWidget);

        workspaceTab->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(workSpaceWidget);
    } // setupUi

    void retranslateUi(QMainWindow *workSpaceWidget)
    {
        workSpaceWidget->setWindowTitle(QApplication::translate("workSpaceWidget", "MainWindow", 0));
        labelSpectra->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Spectra</span></p></body></html>", 0));
        spectrumButton->setText(QString());
        spectraLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Add spectrum</span></p></body></html>", 0));
        removeSelectedButton->setText(QString());
        selectedLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Remove selected</span></p></body></html>", 0));
        labelPeaklist->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Peaklists</span></p></body></html>", 0));
        peaklistButton->setText(QString());
        peaklistLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Add peaklist</span></p></body></html>", 0));
        removeSelectedButton_2->setText(QString());
        selectedLabel_2->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Remove selected</span></p></body></html>", 0));
        labelOther->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Other files</span></p></body></html>", 0));
        otherButton->setText(QString());
        otherLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Add file</span></p></body></html>", 0));
        removeSelectedButton_3->setText(QString());
        selectedLabel_3->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Remove selected</span></p></body></html>", 0));
        workspaceTab->setTabText(workspaceTab->indexOf(projectFileTab), QApplication::translate("workSpaceWidget", "Project files ( F1 )", 0));
        spectrumViewLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">View spectrum</span></p></body></html>", 0));
        loadSpectrumButton->setText(QString());
        view3DButton->setText(QApplication::translate("workSpaceWidget", "3D view", 0));
        contourButton->setText(QApplication::translate("workSpaceWidget", "Contour plot", 0));
        spectrumPeaklistLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Peaklist</span></p></body></html>", 0));
        loadPeaklistButton->setText(QString());
        savePeaklistButton->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = peaklistTable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("workSpaceWidget", "Peakname", 0));
        QTableWidgetItem *___qtablewidgetitem1 = peaklistTable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("workSpaceWidget", "F1 (ppm)", 0));
        QTableWidgetItem *___qtablewidgetitem2 = peaklistTable->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("workSpaceWidget", "F2 (ppm)", 0));
        QTableWidgetItem *___qtablewidgetitem3 = peaklistTable->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("workSpaceWidget", "Intensity", 0));
        hideHintLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"right\"><span style=\" color:#ffffff;\">Hide hints</span></p></body></html>", 0));
        hideHintButton->setText(QString());
        navLabel1->setText(QString());
        navLabel2->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Navigate</span></p></body></html>", 0));
        deleteLabel->setText(QString());
        deleteLabel2->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Delete peak</span></p></body></html>", 0));
        zoomLabel->setText(QString());
        zoomLabel2->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Zoom</span></p></body></html>", 0));
        returnLabel->setText(QString());
        returnLabel2->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Create peak</span></p></body></html>", 0));
        rotateLabel->setText(QString());
        rotateLabel2->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Rotate</span></p></body></html>", 0));
        spaceLabel->setText(QString());
        spaceLabel2->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Center peak</span></p></body></html>", 0));
        selectLabel->setText(QString());
        selectLabel_2->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Select</span></p></body></html>", 0));
        cutoffLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p><span style=\" color:#ffffff;\">Cutoff</span></p></body></html>", 0));
        workspaceTab->setTabText(workspaceTab->indexOf(spectrumTab), QApplication::translate("workSpaceWidget", "Spectrum viewer ( F2 )", 0));
        labelPeakOptions->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Peak integration options</span></p></body></html>", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("workSpaceWidget", "Tab 1", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("workSpaceWidget", "Tab 2", 0));
        labelParam->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Parameter file</span></p></body></html>", 0));
        paramEdit->setHtml(QApplication::translate("workSpaceWidget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Myriad Pro'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", 0));
        labelStatus->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Integration status</span></p></body></html>", 0));
        integrateButton->setText(QString());
        integrateLabel->setText(QApplication::translate("workSpaceWidget", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Integrate</span></p></body></html>", 0));
        workspaceTab->setTabText(workspaceTab->indexOf(integrationTab), QApplication::translate("workSpaceWidget", "Integration ( F3 )", 0));
        workspaceTab->setTabText(workspaceTab->indexOf(plotTab), QApplication::translate("workSpaceWidget", "Plots ( F4 )", 0));
    } // retranslateUi

};

namespace Ui {
    class workSpaceWidget: public Ui_workSpaceWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WORKSPACEWIDGET_H
