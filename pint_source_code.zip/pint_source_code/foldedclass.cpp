#include "foldedclass.h"

foldedClass::foldedClass() :
    foldedF1val(.0), foldedF2val(.0),
    foldedF1(0), foldedF2(0)
{
}

foldedClass::~foldedClass()
{
}
