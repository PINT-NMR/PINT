#include "generatecontourplot.h"

#include <qprinter.h>
#include <qprintdialog.h>
#include <qnumeric.h>
#include <qwt/qwt_color_map.h>
#include <qwt/qwt_scale_widget.h>
#include <qwt/qwt_scale_draw.h>
#include <qwt/qwt_plot_zoomer.h>
#include <qwt/qwt_plot_layout.h>
#include <qwt/qwt_plot_renderer.h>
#include <qwt/qwt_scale_engine.h>
#include <qwt/qwt_plot_magnifier.h>
#include <qwt/qwt_plot_picker.h>
#include <qwt/qwt_symbol.h>
#include <qwt/qwt_plot_marker.h>
#include <qwt/qwt_text.h>
#include <qwt/qwt_picker_machine.h>
#include "generatecontourplot.h"
#include <qmath.h>
#include <QMouseEvent>
#include <QObject>


class SpectrogramData: public QwtRasterData
{
public:

    vector<vector<float> >yV;
    double firstF1;
    double firstF2;
    double stepYf1;
    double stepXf2;


    SpectrogramData(double ff1, double ff2, double stepf1, double stepf2,
                    vector< vector<float> >yVec, double minX, double maxX,
                    double minY, double maxY, double minZ, double maxZ) :
        yV(yVec), firstF1(ff1), firstF2(ff2), stepYf1(stepf1), stepXf2(stepf2)
    {
        setInterval( Qt::XAxis, QwtInterval( minY, maxY ) );
        setInterval( Qt::YAxis, QwtInterval( minX, maxX ) );
        setInterval( Qt::ZAxis, QwtInterval( minZ, maxZ ) );
    }

    ~SpectrogramData()
    {
    }

    virtual double value( double x, double y ) const
    {
        //Bilinear interpolation
        int j((int)((firstF2-x)/(-1.0*stepXf2)));
        int i((int)((firstF1-y)/(-1.0*stepYf1)));

        if(i+1>(int)yV.size()-1) i--;
        if(j+1>(int)yV[0].size()-1) j--;

        double x1(firstF2+stepXf2*(j+1));
        double x2(firstF2+stepXf2*j);
        double y1(firstF1+stepYf1*(i+1));
        double y2(firstF1+stepYf1*i);

        double R1( yV[i+1][j+1]*(x2-x)/(x2-x1) + yV[i+1][j]*(x-x1)/(x2-x1) );
        double R2( yV[i][j+1]*(x2-x)/(x2-x1) + yV[i][j]*(x-x1)/(x2-x1) );
        double R3(R1*(y2-y)/(y2-y1) + R2*(y-y1)/(y2-y1));

        return R3;
    }
};


class SingleColorMapRGB: public QwtLinearColorMap
{
public:
    SingleColorMapRGB():
        QwtLinearColorMap( Qt::black, Qt::black, QwtColorMap::RGB )
    {
    }
    ~SingleColorMapRGB()
    {
    }
};

class CustomColorMapRGB: public QwtLinearColorMap
{
public:
    CustomColorMapRGB(spectrumThemes grad):
        QwtLinearColorMap( grad.color6, grad.color1, QwtColorMap::Indexed )
    {
        addColorStop( grad.stop2, grad.color2);
        addColorStop( grad.stop3, grad.color3);
        addColorStop( grad.stop4, grad.color4);
        addColorStop( grad.stop5, grad.color5);
    }
    ~CustomColorMapRGB()
    {
    }
};

class LinearColorMapIndexed: public QwtLinearColorMap
{
public:
    LinearColorMapIndexed():
        QwtLinearColorMap( Qt::darkCyan, Qt::red, QwtColorMap::Indexed )
    {
        addColorStop( 0.1, Qt::cyan );
        addColorStop( 0.3, Qt::green );
        addColorStop( 0.95, Qt::yellow );
    }
    ~LinearColorMapIndexed()
    {
    }
};

class customLinearColorMapIndexed: public QwtLinearColorMap
{
public:
    customLinearColorMapIndexed(QColor startC, QColor stopC, double rN, double yN, double gN, double wN, double w
                                , double wP, double gP, double yP, double rP):
        QwtLinearColorMap( startC, stopC, QwtColorMap::Indexed )
    {
        if(rN >= 0.0)
            addColorStop(rN, Qt::red);
        if(yN >= 0.0)
            addColorStop(yN, Qt::red);
        if(gN >= 0.0)
            addColorStop(gN, Qt::green);
        if(wN >= 0.0)
            addColorStop(wN, Qt::white);
        addColorStop(w, Qt::white);
        if(wP<1.0)
            addColorStop(wP, Qt::white);
        if(gP<1.0)
            addColorStop(gP, Qt::green);
        if(yP<1.0)
            addColorStop(yP, Qt::yellow);
        if(rP<1.0)
            addColorStop(rP, Qt::red);
    }
    ~customLinearColorMapIndexed()
    {
    }
};

void generateContourPlot::detachAll()
{
    //Extremely important to detach all items before class destruction!
    //May cause memory errors upon application exit.
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();
    QwtPlot *plot = qobject_cast<QwtPlot *>( w );
    for(int i(0); i<plot->itemList().count(); i++)
    {
        if(plot->itemList().at(i)->title().text()!="SPEC" && plot->itemList().at(i)->title().text()!="negSPEC")
        {
            plot->itemList().at(i)->detach();
            i--;
        }
    }
    markerExist = false;
    replot();
}

generateContourPlot::~generateContourPlot()
{
    if(rendered)
    {
        detachAll();
        disconnect(picker);
        disconnect(pickerDrag);
        disconnect(zoomer);
        disconnect(panner);
        disconnect(canvasTimer);
        disconnect(zoom);
        delete d_spectrogram; d_spectrogram = NULL;
        delete neg_spectrogram; neg_spectrogram = NULL;
        delete picker; picker = NULL;
        delete pickerDrag; pickerDrag = NULL;
        delete zoomer; zoomer = NULL;
        delete panner; panner = NULL;
        delete canvasTimer; canvasTimer = NULL;
        delete zoom; zoom = NULL;
    }
}

generateContourPlot::generateContourPlot( QWidget *parent ):
    QwtPlot( parent ), ctrlInt(16777249), contourLevelsNumber(10), contourLevelsNumberMin(10),
    contourMin(.0), contourMinMin(.0), contourStep(100000.0), contourStepMin(-100000.0), dragMode(0),
    ctrlPressed(false), selectedList(0), replotContour(true), moveModeEnabled(false),
    selectingFromRect(false), modeSpec(0), posContourColor(QColor(0,0,0)), negContourColor(QColor(0,0,0)),
    loadedSpectrum(false), f1Min(.0), f1Max(.0), f2Min(.0), f2Max(.0), d_spectrogram(0), neg_spectrogram(0),
    d_mapType(0), moveForward(false), moveBackward(false), moveRight(false), moveLeft(false), moveYFlag(false),
    moveXFlag(false), canvasTimer(0), d_alpha(255), iMin(.0), iMax(.0), spectrogramBG(true), zoomer(0),
    themeGradient(spectrumThemes()), zoom(0), panner(0), picker(0), pickerDrag(0), plotExist(false), validMove(false),
    movePoint(""), tempExist(false), moveToPoint(QPointF(.0,.0)), markerExist(false), labelsTogg(true), rendered(false)
{
    QFont font;
    font.setPointSize(10);
    QwtText title;
    title.setFont(font);
    QwtScaleWidget *leftAxis = axisWidget( QwtPlot::yLeft);
    title.setText("F1 (ppm)");
    leftAxis->setTitle(title);

    QwtScaleWidget *bottomAxis = axisWidget( QwtPlot::xBottom);
    title.setText("F2 (ppm)");
    bottomAxis->setTitle(title);

    this->axisScaleEngine( QwtPlot::yLeft )->setAttribute(QwtScaleEngine::Inverted,true );
    this->axisScaleEngine( QwtPlot::xBottom )->setAttribute(QwtScaleEngine::Inverted,true );
    canvas()->installEventFilter(this);
}

void generateContourPlot::setTheme(spectrumThemes theme)
{
    themeGradient = theme;
}

bool generateContourPlot::eventFilter(QObject *obj, QEvent *event)
{
    Q_UNUSED(obj)
    if(event->type() == QEvent::KeyPress)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == 87)
        {
            moveForward = true; moveBackward= false; moveYFlag = true;//W
            return true;
        }
        else if(keyEvent->key() == 83)
        {
            moveBackward= true; moveForward = false; moveYFlag = true;//S
            return true;
        }
        else if(keyEvent->key() == 65)
        {
            moveLeft = true; moveRight = false; moveXFlag = true;//A
            return true;
        }
        else if(keyEvent->key() == 68)
        {
            moveRight = true; moveLeft = false; moveXFlag = true;//D
            return true;
        }
        else if(keyEvent->key() == ctrlInt)
        {
            ctrlPressed = true;
            emit ctrlPressedSync(true);
#ifdef Q_OS_MAC
            //picker->setMousePattern( QwtEventPattern::MouseSelect1, Qt::RightButton, Qt::MetaModifier);
            picker->setMousePattern( QwtEventPattern::MouseSelect1, Qt::LeftButton, Qt::ControlModifier );
#else
            picker->setMousePattern( QwtEventPattern::MouseSelect1, Qt::LeftButton, Qt::ControlModifier );
#endif
        }
        else if(keyEvent->key() == 32) //Space
            return true;
    }
    else if(event->type() == QEvent::KeyRelease)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == 87)
            moveForward= false;//W
        else if(keyEvent->key() == 83)
            moveBackward= false;//S
        else if(keyEvent->key() == 65)
            moveLeft= false;//A
        else if(keyEvent->key() == 68)
            moveRight = false;//D
        else if(keyEvent->key() == 16777216)//Escape
        {
            if(moveModeEnabled)
                exitMoveMode();
            if(markerExist)
            {
                QWidget *w = canvas();
                if ( w )
                    w = w->parentWidget();
                QwtPlot *plot = qobject_cast<QwtPlot *>( w );

                for(int i(0); i<plot->itemList().count(); i++)
                {
                    if(plot->itemList().at(i)->title().text() == "POINT")
                    {
                        plot->itemList().at(i)->detach();
                        replot();
                        markerExist = false;
                        break;
                    }
                }
            }
            emit deselect();
        }
        else if(keyEvent->key() == ctrlInt)
        {
            ctrlPressed = false;
            emit ctrlPressedSync(false);
            picker->setMousePattern( QwtEventPattern::MouseSelect1, Qt::LeftButton);
        }
        else if(keyEvent->key() == 32) //Space
            movePeakMode();
        else if(keyEvent->key() == 16777220 || keyEvent->key() == 16777221) //RETURN
        {
            if(markerExist)
            {
                QVector3D vec(0,0,0);
                QWidget *w = canvas();
                if ( w )
                    w = w->parentWidget();
                QwtPlot *plot = qobject_cast<QwtPlot *>( w );

                for(int i(0); i<plot->itemList().count(); i++)
                {
                    if(plot->itemList().at(i)->title().text() == "POINT")
                    {
                        QwtPlotMarker *item = static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
                        plot->itemList().at(i)->detach();
                        vec = QVector3D(item->value().x(),0,item->value().y());
                        markerExist = false;
                        break;
                    }
                }
                if(vec.x()!=0 || vec.y()!=0 || vec.z()!=0)
                    emit createPeak(vec,"??");
            }
        }
    }
    return false;
}

void generateContourPlot::updateCanvasScales()
{
    if(moveYFlag)
    {
        if(!moveForward && !moveBackward)
            moveYFlag = false;
        else
        {
            double max(axisScaleDiv(0).lowerBound());
            double min(axisScaleDiv(0).upperBound());
            if(moveForward)
            {
                moveCanvasManual(0,75.0/(max-min),0);
            }
            else if(moveBackward)
            {
                moveCanvasManual(0,-75.0/(max-min),0);
            }
        }
    }
    if(moveXFlag)
    {
        if(!moveLeft && !moveRight)
            moveXFlag=false;
        else
        {
            double max(axisScaleDiv(2).lowerBound());
            double min(axisScaleDiv(2).upperBound());
            if(moveRight)
            {
                moveCanvasManual(-25.0/(max-min),0,2);
            }
            else if(moveLeft)
            {
                moveCanvasManual(25.0/(max-min),0,2);
            }
        }
    }
}

void generateContourPlot::moveCanvasManual( double dx, double dy, int axis)
{
    //Handles key events (WASD)
    if ( dx == 0 && dy == 0 )
        return;

    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();

    QwtPlot *plot = qobject_cast<QwtPlot *>( w );
    if ( plot == NULL )
        return;

    const bool doAutoReplot = plot->autoReplot();
    plot->setAutoReplot( false );

    const QwtScaleMap map = plot->canvasMap( axis );

    const double p1 = map.transform( plot->axisScaleDiv( axis ).lowerBound() );
    const double p2 = map.transform( plot->axisScaleDiv( axis ).upperBound() );

    double d1, d2;
    if ( axis == QwtPlot::xBottom || axis == QwtPlot::xTop )
    {
        d1 = map.invTransform( p1 - dx );
        d2 = map.invTransform( p2 - dx );
    }
    else
    {
        d1 = map.invTransform( p1 - dy );
        d2 = map.invTransform( p2 - dy );
    }
    if(axis ==0 && (d2<f1Max && d1>f1Min)) //F1
        plot->setAxisScale( axis, d1, d2 );
    else if(axis ==2 && (d2<f2Max && d1>f2Min)) //F2
        plot->setAxisScale( axis, d1, d2 );

    plot->setAutoReplot( doAutoReplot );
    plot->replot();
}

void generateContourPlot::updateContourLevels(int levels, double step, double min)
{
    contourMin = min;
    contourStep = step;
    contourLevelsNumber = levels;
    QList<double> contourLevels;
    for ( double level = contourMin; level < contourMin+contourLevelsNumber*contourStep; level += contourStep )
        contourLevels += level;
    if(contourLevels.size()==0 || contourLevelsNumber==0)
        d_spectrogram->setDisplayMode( QwtPlotSpectrogram::ContourMode, false );
    else
    {
        d_spectrogram->setDisplayMode( QwtPlotSpectrogram::ContourMode, true );
        d_spectrogram->setContourLevels( contourLevels );
    }
    replot();
}

void generateContourPlot::updateContourLevelsMin(int levels, double step, double min)
{
    contourMinMin = min;
    contourStepMin = step;
    contourLevelsNumberMin = levels;
    QList<double> contourLevelsMin;
    for ( double level = contourMinMin; level > contourMinMin + contourStepMin*contourLevelsNumberMin; level += contourStepMin )
    {
        contourLevelsMin += level;
    }
    if(contourLevelsMin.size()==0 || contourLevelsNumberMin==0)
        neg_spectrogram->setDisplayMode( QwtPlotSpectrogram::ContourMode, false );
    else
    {
        neg_spectrogram->setDisplayMode( QwtPlotSpectrogram::ContourMode, true );
        neg_spectrogram->setContourLevels( contourLevelsMin );
    }
    replot();
}

void generateContourPlot::setData(double firstF1, double firstF2, double stepYf1, double stepXf2, vector< vector<float> >yVec, double minX, double maxX, double minY, double maxY, double minZ, double maxZ)
{
    loadedSpectrum = true;
    f1Min = minX;
    f1Max = maxX;
    f2Min = minY;
    f2Max = maxY;
    iMin = minZ;
    iMax = maxZ;
    if(rendered)
    {
        disconnect(picker);
        disconnect(pickerDrag);
        disconnect(zoomer);
        disconnect(panner);
        disconnect(canvasTimer);
        delete d_spectrogram;
        delete neg_spectrogram;
        delete picker;
        delete pickerDrag;
        delete zoomer;
        delete panner;
        delete canvasTimer;
        d_spectrogram = NULL;
        neg_spectrogram = NULL;
        picker = NULL;
        pickerDrag = NULL;
        zoomer = NULL;
        panner = NULL;
        canvasTimer = NULL;
    }
    d_spectrogram = new QwtPlotSpectrogram();
    neg_spectrogram = new QwtPlotSpectrogram();
    d_spectrogram->setRenderThreadCount( 0 ); // use system specific thread count
    neg_spectrogram->setRenderThreadCount( 0 ); // use system specific thread count
    d_spectrogram->setCachePolicy( QwtPlotRasterItem::PaintCache );
    neg_spectrogram->setCachePolicy( QwtPlotRasterItem::PaintCache );

    QList<double> contourLevels;
    for ( double level = contourMin; level < contourMin + contourLevelsNumber*contourStep; level += contourStep )
        contourLevels += level;
    d_spectrogram->setContourLevels( contourLevels );

    QList<double> contourLevelsMin;
    for ( double level = contourMinMin; level > contourMinMin + contourStepMin*contourLevelsNumberMin; level += contourStepMin )
        contourLevelsMin += level;
    neg_spectrogram->setContourLevels( contourLevelsMin );


    d_spectrogram->setData( new SpectrogramData(firstF1, firstF2, stepYf1, stepXf2, yVec, minX, maxX, minY, maxY, minZ, maxZ) );
    neg_spectrogram->setData( new SpectrogramData(firstF1, firstF2, stepYf1, stepXf2, yVec, minX, maxX, minY, maxY, minZ, maxZ) );
    d_spectrogram->setTitle("SPEC");
    neg_spectrogram->setTitle("negSPEC");
    d_spectrogram->attach( this );
    neg_spectrogram->attach( this );
    plotExist = true;

    setAxisScale( QwtPlot::yLeft, d_spectrogram->data()->interval( Qt::YAxis ).maxValue(), d_spectrogram->data()->interval( Qt::YAxis ).minValue() );
    setAxisScale( QwtPlot::xBottom, d_spectrogram->data()->interval( Qt::XAxis ).maxValue(), d_spectrogram->data()->interval( Qt::XAxis ).minValue() );


    const QwtInterval zInterval = d_spectrogram->data()->interval( Qt::ZAxis );

    // A color bar on the right axis
    QwtScaleWidget *rightAxis = axisWidget( QwtPlot::yRight );
    rightAxis->setTitle( "Intensity" );
    rightAxis->setColorBarEnabled( true );

    setAxisScale( QwtPlot::yRight, zInterval.minValue(), zInterval.maxValue() );
    enableAxis( QwtPlot::yRight );

    plotLayout()->setAlignCanvasToScales( true );


    picker = new customPlotPicker( canvas() );
    pickerDrag = new customPlotPicker( canvas() );
    connect(picker, SIGNAL(selected(QPointF)), this, SLOT(selectPoint(QPointF)));
    connect(pickerDrag, SIGNAL(selected(QRectF)), this, SLOT(selectRect(QRectF)));
    picker->setAxis(2,0);
    picker->setStateMachine(new QwtPickerClickPointMachine());
    pickerDrag->setStateMachine(new QwtPickerDragRectMachine());
    pickerDrag->setRubberBand(QwtPicker::RectRubberBand);
    pickerDrag->setTrackerMode(QwtPicker::AlwaysOff);
    if(dragMode==1)
    {
        pickerDrag->setEnabled(false);
    }

    zoomer = new customZoomer( canvas() );

    panner = new QwtPlotPanner( canvas() );
    panner->setAxisEnabled( QwtPlot::yRight, false );
    panner->setMouseButton( Qt::RightButton );

    connect(zoomer, SIGNAL(zoomed(QRectF)), this, SLOT(update3DZoom()));
    connect(panner, SIGNAL(panned(int,int)), this, SLOT(update3DZoom()));


    const QFontMetrics fm( axisWidget( QwtPlot::yLeft )->font() );
    QwtScaleDraw *sd = axisScaleDraw( QwtPlot::yLeft );
    sd->setMinimumExtent( fm.width( "100.00" ) );

    showContour(true);
    setupWheelZooming(minY, maxY, minX ,maxX);
    canvasTimer = new QTimer(this);
    connect(canvasTimer, SIGNAL(timeout()), this, SLOT(updateCanvasScales()));
    canvasTimer->start();
    changeTheme(themeGradient);
    rendered = true;
}

void generateContourPlot::setupWheelZooming(double minX,double maxX,double minY,double maxY)
{
    zoom = new customMagnifier( canvas(), minX, maxX, minY, maxY );
    zoom->setAxisEnabled(Qt::XAxis,true);
    zoom->setAxisEnabled(QwtPlot::yRight, false);
    zoom->setAxisEnabled(Qt::YAxis,false);
    zoom->setMouseButton(Qt::NoButton);
    connect(zoom, SIGNAL(zoomed()), this, SLOT(update3DZoom()));
}

void generateContourPlot::showContour( bool on )
{
    d_spectrogram->setDisplayMode( QwtPlotSpectrogram::ContourMode, on );
    neg_spectrogram->setDisplayMode( QwtPlotSpectrogram::ContourMode, on );
    replot();
}

void generateContourPlot::showSpectrogram( bool on )
{
    d_spectrogram->setDisplayMode( QwtPlotSpectrogram::ImageMode, on );
    d_spectrogram->setDefaultContourPen(
                on ? QPen( Qt::black, 0 ) : QPen( Qt::NoPen ) );

    replot();
}

void generateContourPlot::setColorMap( int type )
{
    QwtScaleWidget *axis = axisWidget( QwtPlot::yRight );
    const QwtInterval zInterval = d_spectrogram->data()->interval( Qt::ZAxis );

    d_mapType = type;

    int alpha = d_alpha;
    switch( type )
    {
    case 0:
    {
        if(!plotExist)
        {
            d_spectrogram->setColorMap( new LinearColorMapIndexed() );
            axis->setColorMap( zInterval, new LinearColorMapIndexed() );
        }
        else
        {
            double range = iMax-iMin;
            double zero = (double)qPow(iMin*iMin,0.5)/range;
            bool posLargest(true);
            if(zero>0.5)
                posLargest = false;
            double colorRange(1-zero);
            if(!posLargest)
                colorRange = 1-colorRange;
            double rN, yN, gN, wN, w, wP, gP, yP, rP;
            rN = zero - colorRange*0.60;
            yN = zero - colorRange*0.30;
            gN = zero - colorRange*0.05;
            wN = zero - colorRange*0.025;
            w = zero;
            wP = zero + colorRange*0.025;
            gP = zero + colorRange*0.05;
            yP = zero + colorRange*0.30;
            rP = zero + colorRange*0.60;
            QColor startC(Qt::darkRed), stopC(Qt::darkRed);
            if(rN >= 0.0)
            {
                if(rN>0.2)
                    startC = Qt::red;
            }
            else if(yN >= 0.0)
                startC = Qt::yellow;
            else if(gN >= 0.0)
                startC = Qt::green;
            else
                startC = Qt::white;

            if(wP>1.0)
                stopC = Qt::white;
            else if(gP>1.0)
                stopC = Qt::green;
            else if(yP>1.0)
                stopC = Qt::yellow;
            else if(rP>1.0)
                stopC = Qt::red;

            d_spectrogram->setColorMap( new customLinearColorMapIndexed(startC, stopC, rN, yN, gN, wN, w, wP, gP, yP, rP) );
            axis->setColorMap( zInterval, new customLinearColorMapIndexed(startC, stopC, rN, yN, gN, wN, w, wP, gP, yP, rP) );
        }
        break;
    }
    case 1:
    {
        alpha = 255;
        d_spectrogram->setColorMap( new SingleColorMapRGB() );
        axis->setColorMap( zInterval, new SingleColorMapRGB() );
        break;
    }
    default:
    {
        alpha = 255;
        d_spectrogram->setColorMap( new CustomColorMapRGB(themeGradient) );
        axis->setColorMap( zInterval, new CustomColorMapRGB(themeGradient) );
    }
    }
    d_spectrogram->setAlpha( alpha );

    replot();
}

void generateContourPlot::toggleSpectrogramManual(int mode)
{
    if(mode==0)
    {
        setColorMap(0);
        spectrogramBG = true;
        QPen pen;
        pen.setColor(Qt::black);
        d_spectrogram->setDefaultContourPen(pen);
        pen.setWidth(3);
        zoomer->setRubberBandPen(pen);
    }
    else if(mode==1)
    {
        d_spectrogram->setAlpha( 0 );
        spectrogramBG = true;
    }
    else
    {
        setColorMap(1);
        spectrogramBG = false;
        QPen pen;
        pen.setColor(Qt::white);
        d_spectrogram->setDefaultContourPen(pen);
        pen.setWidth(3);
        zoomer->setRubberBandPen(pen);
    }
    replot();
    modeSpec = mode;
}

void generateContourPlot::toggleSpectrogram()
{
    if(!spectrogramBG)
    {
        setColorMap(0);
        spectrogramBG = true;
        QPen pen;
        pen.setColor(Qt::black);
        pen.setWidth(3);
        zoomer->setRubberBandPen(pen);
        modeSpec=0;
    }
    else
    {
        modeSpec=1;
        d_spectrogram->setAlpha( 0 );
        spectrogramBG = false;
    }
    /*
    //else if(d_spectrogram->alpha() == 255)
    else
    {
        modeSpec=2;
        setColorMap(1);
        spectrogramBG = false;
        QPen pen;
        pen.setColor(Qt::white);
        pen.setWidth(3);
        zoomer->setRubberBandPen(pen);
    }
    */
    replot();
}

void generateContourPlot::changeTheme(spectrumThemes grad)
{
    themeGradient = grad;
    if(!loadedSpectrum)
        return;
    spectrogramBG = true;
    QPen pen;
    pen.setColor(grad.gridlineColor);
    d_spectrogram->setDefaultContourPen(pen);
    pen.setWidth(3);
    zoomer->setRubberBandPen(pen);
    d_spectrogram->setAlpha( 255 );
    setColorMap(0);
}

void generateContourPlot::readPeaklist(QVector<QVector<QString> > peaklist, bool detAll)
{
    if(!replotContour)
        return;
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();

    QwtPlot *plot = qobject_cast<QwtPlot *>( w );
    if(detAll)
        detachAll();

    QPen customPen;
    customPen.setWidth(2);
    customPen.setColor(themeGradient.markerColor);

    for(int i(0); i<peaklist.size(); i++)
    {
        int factor(8);
        if(peaklist.at(i).at(0).length()<6)
            factor = 11;
        QColor borderColor(themeGradient.labelBorderColor);
        QColor bgColor(themeGradient.labelBgColor);
        bool foldedF1(false);
        bool foldedF2(false);
        if(peaklist.at(i).at(5).toFloat()!=0)
            foldedF1=true;
        if(peaklist.at(i).at(4).toFloat()!=0)
            foldedF2=true;
        if(foldedF1 || foldedF2) //peak is folded
        {
            borderColor = themeGradient.foldedBorderColor;
            bgColor = themeGradient.foldedBgColor;
        }

        QwtSymbol *sym=new QwtSymbol(QwtSymbol::XCross,QBrush(themeGradient.markerColor),customPen,QSize(15,15));
        QwtSymbol *sym2=new QwtSymbol(QwtSymbol::Rect,QBrush(bgColor),QPen(borderColor),QSize(peaklist.at(i).at(0).length()*factor,15));
        QwtPlotMarker *mark=new QwtPlotMarker;
        QwtPlotMarker *label=new QwtPlotMarker;
        mark->setSymbol(sym);
        QwtText txt(peaklist.at(i).at(0));
        txt.setColor(borderColor);
        txt.setFont(QFont("Courier",8));
        label->setLabel(txt);
        label->setSymbol(sym2);
        float F1(peaklist.at(i).at(2).toFloat());
        float F2(peaklist.at(i).at(1).toFloat());
        if(foldedF1)
            F1 = peaklist.at(i).at(7).toFloat();
        if(foldedF2)
            F2 = peaklist.at(i).at(6).toFloat();
        label->setValue(F1,F2-0.1);
        mark->setValue(F1,F2);


        QString title("m"+peaklist.at(i).at(3));
        mark->setTitle((QwtText)title);
        title[0]='l';
        label->setTitle((QwtText)title);
        label->setVisible(labelsTogg);
        mark->attach(plot);
        label->attach(plot);
    }
    replot();
}

void generateContourPlot::updateContourPlotLabels(QVector<QString> vec)
{
    if(!replotContour)
        return;
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();
    QwtPlot *plot = qobject_cast<QwtPlot *>( w );
    QString compLabel("l"+vec.at(3)), compMarker("m"+vec.at(3));
    QColor borderColor(themeGradient.labelBorderColor);
    QColor bgColor(themeGradient.labelBgColor);
    bool foldedF1(false);
    bool foldedF2(false);
    if(vec.at(5).toFloat()!=0)
        foldedF1=true;
    if(vec.at(4).toFloat()!=0)
        foldedF2=true;
    if(foldedF1 || foldedF2) //peak is folded
    {
        borderColor = themeGradient.foldedBorderColor;
        bgColor = themeGradient.foldedBgColor;
    }
    QPen customPen;
    customPen.setColor(themeGradient.markerColor);
    customPen.setWidth(2);
    for(int i(0); i<plot->itemList().count(); i++)
    {
        if(compLabel == plot->itemList().at(i)->title().text())
        {
            QwtPlotMarker *label= static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
            int factor(8);
            if(vec.at(0).length()<6)
                factor = 11;
            QwtSymbol *sym2=new QwtSymbol(QwtSymbol::Rect,QBrush(bgColor),QPen(borderColor),QSize(vec.at(0).length()*factor,15));
            label->setSymbol(sym2);
            QwtText txt(vec.at(0));
            txt.setColor(borderColor);
            txt.setFont(QFont("Courier",8));
            label->setLabel(txt);
            float F1(vec.at(2).toFloat()), F2(vec.at(1).toFloat());
            if(foldedF1)
                F1 = vec.at(7).toFloat();
            if(foldedF2)
                F2 = vec.at(6).toFloat();
            label->setValue(F1,F2-0.1);
            plot->itemList().at(i)->detach();
            label->attach(plot);
            label->setVisible(labelsTogg);
            compLabel = "NULL";
            if(compMarker == "NULL")
                break;
            i = 0;
        }
        if(compMarker== plot->itemList().at(i)->title().text())
        {
            QwtPlotMarker *mark= static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
            QwtSymbol *sym=new QwtSymbol(QwtSymbol::XCross,QBrush(themeGradient.markerColor),customPen,QSize(15,15));
            float F1(vec.at(2).toFloat()), F2(vec.at(1).toFloat());
            if(foldedF1)
                F1 = vec.at(7).toFloat();
            if(foldedF2)
                F2 = vec.at(6).toFloat();
            mark->setValue(F1,F2);
            plot->itemList().at(i)->detach();
            mark->setSymbol(sym);
            mark->attach(plot);
            compMarker= "NULL";
            if(compLabel== "NULL")
                break;
            i = 0;
        }
    }
    replot();
}

void generateContourPlot::deletePeak(QString peak)
{
    if(!replotContour)
        return;
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();
    QwtPlot *plot = qobject_cast<QwtPlot *>( w );
    QString compLabel("l"+peak), compMarker("m"+peak);
    for(int i(0); i<plot->itemList().count(); i++)
    {
        if(compLabel == plot->itemList().at(i)->title().text())
        {
            plot->itemList().at(i)->detach();
            compLabel = "NULL";
            if(compMarker == "NULL")
                break;
            i = 0;
        }
        if(compMarker== plot->itemList().at(i)->title().text())
        {
            plot->itemList().at(i)->detach();
            compMarker= "NULL";
            if(compLabel == "NULL")
                break;
            i = 0;
        }
    }
    replot();
}
void generateContourPlot::updateZoom(float minF1, float maxF1, float minF2, float maxF2)
{
    disconnect(zoom, SIGNAL(zoomed()), this, SLOT(update3DZoom()));
    disconnect(zoomer, SIGNAL(zoomed(QRectF)), this, SLOT(update3DZoom()));
    disconnect(panner, SIGNAL(panned(int,int)), this, SLOT(update3DZoom()));
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();
    QwtPlot *plt = qobject_cast<QwtPlot *>( w );
    if ( plt == NULL )
        return;
    const bool autoReplot = plt->autoReplot();
    plt->setAutoReplot( false );
    plt->setAxisScale( 0, maxF2, minF2 );
    plt->setAxisScale( 2, maxF1, minF1 );
    plt->setAutoReplot( autoReplot );
    plt->replot();
    connect(zoom, SIGNAL(zoomed()), this, SLOT(update3DZoom()));
    connect(zoomer, SIGNAL(zoomed(QRectF)), this, SLOT(update3DZoom()));
    connect(panner, SIGNAL(panned(int,int)), this, SLOT(update3DZoom()));
}

void generateContourPlot::update3DZoom()
{
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();
    QwtPlot *plt = qobject_cast<QwtPlot *>( w );
    if ( plt == NULL )
        return;
    emit contourZoomed(plt->axisInterval(0).maxValue(),plt->axisInterval(0).minValue(),
                       plt->axisInterval(2).maxValue(),plt->axisInterval(2).minValue());
}

void generateContourPlot::clearSelectedItems(QVector<QVector<QString> > peaklist)
{
    if(!replotContour)
        return;
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();

    QwtPlot *plot = qobject_cast<QwtPlot *>( w );
    detachAll();

    QPen customPen;
    customPen.setWidth(2);
    customPen.setColor(themeGradient.markerColor);

    for(int i(0); i<peaklist.size(); i++)
    {
        int factor(8);
        if(peaklist.at(i).at(0).length()<6)
            factor = 11;
        QColor borderColor(themeGradient.labelBorderColor);
        QColor bgColor(themeGradient.labelBgColor);
        bool foldedF1(false);
        bool foldedF2(false);
        if(peaklist.at(i).at(5).toFloat()!=0)
            foldedF1=true;
        if(peaklist.at(i).at(4).toFloat()!=0)
            foldedF2=true;
        if(foldedF1 || foldedF2) //peak is folded
        {
            borderColor = themeGradient.foldedBorderColor;
            bgColor = themeGradient.foldedBgColor;
        }


        QwtSymbol *sym=new QwtSymbol(QwtSymbol::XCross,QBrush(themeGradient.markerColor),customPen,QSize(15,15));
        QwtSymbol *sym2=new QwtSymbol(QwtSymbol::Rect,QBrush(bgColor),QPen(borderColor),QSize(peaklist.at(i).at(0).length()*factor,15));
        QwtPlotMarker *mark=new QwtPlotMarker;
        QwtPlotMarker *label=new QwtPlotMarker;
        mark->setSymbol(sym);
        QwtText txt(peaklist.at(i).at(0));
        txt.setColor(borderColor);
        txt.setFont(QFont("Courier",8));
        label->setLabel(txt);
        label->setSymbol(sym2);
        float F1(peaklist.at(i).at(2).toFloat());
        float F2(peaklist.at(i).at(1).toFloat());

        if(foldedF1)
            F1 = peaklist.at(i).at(7).toFloat();
        if(foldedF2)
            F2 = peaklist.at(i).at(6).toFloat();
        label->setValue(F1,F2-0.1);
        mark->setValue(F1,F2);

        QString title("m"+peaklist.at(i).at(3));
        mark->setTitle((QwtText)title);
        title[0]='l';
        label->setTitle((QwtText)title);
        mark->attach(plot);
        label->setVisible(labelsTogg);
        label->attach(plot);
    }
    replot();
}

void generateContourPlot::highlightItems(QStringList list)
{
    if(!replotContour)
        return;
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();
    QwtPlot *plot = qobject_cast<QwtPlot *>( w );
    QColor borderColor(themeGradient.selectedBorderColor);
    QColor bgColor(themeGradient.selectedBgColor);
    QPen customPen;
    //customPen.setColor(themeGradient.markerColor);
    customPen.setColor(Qt::black);
    customPen.setWidthF(2.5f);

    for(int j(0); j<list.count(); j++)
    {
        QString compLabel("l"+list.at(j)), compMarker("m"+list.at(j));
        for(int i(0); i<plot->itemList().count(); i++)
        {
            if(compLabel == plot->itemList().at(i)->title().text())
            {
                QwtPlotMarker *label= static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
                int factor(8);
                if(label->label().text().length()<6)
                    factor = 11;
                QwtSymbol *sym2=new QwtSymbol(QwtSymbol::Rect,QBrush(bgColor),QPen(borderColor),QSize(label->label().text().length()*factor,15));
                label->setSymbol(sym2);
                plot->itemList().at(i)->detach();
                label->setVisible(labelsTogg);
                label->attach(plot);
                compLabel = "NULL";
                if(compMarker == "NULL")
                    break;
                i = 0;
            }
            if(compMarker== plot->itemList().at(i)->title().text())
            {
                QwtPlotMarker *mark= static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
                QwtSymbol *sym=new QwtSymbol(QwtSymbol::XCross,QBrush(themeGradient.markerColor),customPen,QSize(25,25));
                plot->itemList().at(i)->detach();
                mark->setSymbol(sym);
                mark->attach(plot);
                compMarker= "NULL";
                if(compLabel== "NULL")
                    break;
                i = 0;
            }
        }
    }
    replot();
    selectedList = list;
}

void generateContourPlot::toggleMode(int mode)
{
    if(!plotExist) return;
    if(dragMode == mode )return;
    dragMode = mode;
    if(dragMode==1)
    {
        zoomer->setMousePattern(QwtEventPattern::MouseSelect1, Qt::LeftButton );
        pickerDrag->setEnabled(false);
    }
    else
    {
        pickerDrag->setEnabled(true);
        zoomer->setMousePattern(QwtEventPattern::MouseSelect1, Qt::NoButton );
    }
}

void generateContourPlot::selectPoint(QPointF point)
{
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();
    QwtPlot *plot = qobject_cast<QwtPlot *>( w );

    if(markerExist)
        for(int i(0); i<plot->itemList().count(); i++)
        {
            if(plot->itemList().at(i)->title().text() == "POINT")
            {
                plot->itemList().at(i)->detach();
                replot();
                markerExist = false;
                break;
            }
        }

    if(moveModeEnabled)
    {
        QPen customPen;
        customPen.setWidth(2);
        customPen.setColor(themeGradient.selectionPointerColor);
        QwtSymbol *sym=new QwtSymbol(QwtSymbol::XCross,QBrush(themeGradient.selectionPointerColor),customPen,QSize(25,25));
        if(!tempExist)
        {
            QwtPlotMarker *mark=new QwtPlotMarker;
            mark->setSymbol(sym);
            mark->setTitle("TEMP");
            mark->setValue(point);
            mark->attach(plot);
            tempExist=true;
        }
        else
        {
            for(int i(0); i<plot->itemList().count(); i++)
            {
                if(plot->itemList().at(i)->title().text() == "TEMP")
                {
                    QwtPlotMarker *item = static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
                    plot->itemList().at(i)->detach();
                    item->setValue(point);
                    item->attach(plot);
                    break;
                }
            }
        }
        moveToPoint = point;
        validMove = true;
        replot();
        return;
    }
    float offsetY((plot->axisInterval(0).minValue()-plot->axisInterval(0).maxValue())*1.0/100.0);
    float offsetX((plot->axisInterval(2).minValue()-plot->axisInterval(2).maxValue())*1.0/100.0);
    int weight(1);
    if(offsetX!=0 && offsetY!=0)
        weight=(int)(offsetY/offsetX);

    int closestPoint(-1);
    float dist(9e99);
    for(int i(0); i<plot->itemList().count(); i++)
    {
        if('l' == plot->itemList().at(i)->title().text()[0] || 'm' == plot->itemList().at(i)->title().text()[0])
        {
            QwtPlotMarker *item = static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
            float labelWeight(1);
            if('l' == plot->itemList().at(i)->title().text()[0])
                labelWeight = 2.5;
            if(item->value().x()>point.x()-offsetX*labelWeight && item->value().x()<point.x()+offsetX*labelWeight
                    && item->value().y()>point.y()-offsetY && item->value().y()<point.y()+offsetY)
            {
                if(dist > qSqrt(qPow(item->value().x()*weight,2)+qPow(item->value().y(),2)))
                {
                    dist = qSqrt(qPow(item->value().x(),2)+qPow(item->value().y(),2));
                    closestPoint = i;
                }
            }
        }
    }
    if(closestPoint == -1 && ctrlPressed)
        return;
    else if(closestPoint == -1 && !ctrlPressed)
    {
        emit highlight("DESELECT");
        selectedList.clear();
        QPen customPen;
        customPen.setWidth(2);
        customPen.setColor(themeGradient.selectionPointerColor);
        QwtSymbol *sym=new QwtSymbol(QwtSymbol::XCross,QBrush(themeGradient.selectionPointerColor),customPen,QSize(25,25));
        if(!markerExist)
        {
            QwtPlotMarker *mark=new QwtPlotMarker;
            mark->setSymbol(sym);
            mark->setTitle("POINT");
            mark->setValue(point);
            mark->attach(plot);
            markerExist=true;
        }
        replot();
    }
    else
    {
        QwtPlotMarker *item= static_cast<QwtPlotMarker *>( plot->itemList().at(closestPoint) );
        emit highlight(item->title().text().mid(1));
    }
}

void generateContourPlot::movePeakMode()
{
    if(moveModeEnabled)
    {
        if(validMove)
        {
            QWidget *w = canvas();
            if ( w )
                w = w->parentWidget();
            QwtPlot *plot = qobject_cast<QwtPlot *>( w );
            for(int i(0); i<plot->itemList().count(); i++)
                if(plot->itemList().at(i)->title().text() == "TEMP")
                {
                    plot->itemList().at(i)->detach();
                    break;
                }
            selectedList.clear();
            tempExist=false;
            moveModeEnabled=false;
            emit infoPeakMode("", true, 0);
            emit defaultMoveModeFrame();
            emit updatePeakList(movePoint, moveToPoint);
        }
        return;
    }
    if(selectedList.count()==1)
    {
        moveModeEnabled = true;
        validMove=false;
        emit moveModeFrame();
        emit infoPeakMode("Moving peaks: Select a data point and press SPACE to move the peak.\nPress ESC to cancel.", false, 0);
        QWidget *w = canvas();
        if ( w )
            w = w->parentWidget();
        QwtPlot *plot = qobject_cast<QwtPlot *>( w );
        QColor borderColor(themeGradient.moveBorderColor);
        QColor bgColor(themeGradient.moveBgColor);
        QPen customPen;
        customPen.setColor(themeGradient.markerColor);
        customPen.setWidth(2);

        QString compLabel("l"+selectedList.at(0));
        QString compMarker("m"+selectedList.at(0));
        for(int i(0); i<plot->itemList().count(); i++)
        {
            if(compLabel == plot->itemList().at(i)->title().text())
            {
                movePoint = plot->itemList().at(i)->title().text().mid(1);
                QwtPlotMarker *label= static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
                int factor(8);
                if(label->label().text().length()<6)
                    factor = 11;
                QwtSymbol *sym2=new QwtSymbol(QwtSymbol::Rect,QBrush(bgColor),QPen(borderColor),QSize(label->label().text().length()*factor,15));
                label->setSymbol(sym2);
                plot->itemList().at(i)->detach();
                label->setVisible(labelsTogg);
                label->attach(plot);
                compLabel = "NULL";
                if(compMarker == "NULL")
                    break;
                i = 0;
            }
            if(compMarker== plot->itemList().at(i)->title().text())
            {
                movePoint = plot->itemList().at(i)->title().text().mid(1);
                QwtPlotMarker *mark= static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
                QwtSymbol *sym=new QwtSymbol(QwtSymbol::XCross,QBrush(themeGradient.markerColor),customPen,QSize(15,15));
                plot->itemList().at(i)->detach();
                mark->setSymbol(sym);
                mark->attach(plot);
                compMarker= "NULL";
                if(compLabel== "NULL")
                    break;
                i = 0;
            }
        }
        replot();
    }
    else
    {
        emit infoPeakMode("Moving peaks:\nSelect a single peak and press SPACE", true, 0);
        return;
    }
}

void generateContourPlot::exitMoveMode()
{
    selectedList.clear();
    tempExist=false;
    moveModeEnabled=false;
    emit infoPeakMode("", true, 0);
    emit defaultMoveModeFrame();
}

void generateContourPlot::removeMarker()
{
    if(markerExist)
    {
        QWidget *w = canvas();
        if ( w )
            w = w->parentWidget();
        QwtPlot *plot = qobject_cast<QwtPlot *>( w );

        for(int i(0); i<plot->itemList().count(); i++)
        {
            if(plot->itemList().at(i)->title().text() == "POINT")
            {
                QwtPlotMarker *item = static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
                Q_UNUSED(item)
                plot->itemList().at(i)->detach();
                markerExist = false;
                break;
            }
        }
        replot();
    }
}

void generateContourPlot::selectRect(QRectF rect)
{
    if(dragMode==2)
    {
        double minF1(rect.y()), maxF1(rect.height()+minF1);
        double minF2(rect.x()), maxF2(rect.width()+minF2);
        emit contourPickPeaks(minF1, maxF1, minF2, maxF2);
    }
    else
    {
        double minF1(rect.y()), maxF1(rect.height()+minF1);
        double minF2(rect.x()), maxF2(rect.width()+minF2);
        QWidget *w = canvas();
        if ( w )
            w = w->parentWidget();
        QwtPlot *plot = qobject_cast<QwtPlot *>( w );
        QStringList list;
        for(int i(0); i<plot->itemList().count(); i++)
        {
            if(plot->itemList().at(i)->title().text()[0] == 'm')
            {
                QwtPlotMarker *marker= static_cast<QwtPlotMarker *>( plot->itemList().at(i) );
                if(marker->value().x()>minF2 && marker->value().x()<maxF2
                        && marker->value().y()>minF1 && marker->value().y()<maxF1)
                    list << marker->title().text().mid(1);
            }
        }
        if(list.count()==0)
            return;
        for(int i(0); i<plot->itemList().count(); i++)
        {
            if(plot->itemList().at(i)->title().text() == "POINT")
            {
                plot->itemList().at(i)->detach();
                replot();
                break;
            }
        }
        markerExist = false;

        emit highlight("DESELECT");
        selectingFromRect=true;
        for(int i(0); i<list.count(); i++)
            emit highlight(list.at(i));
        selectingFromRect=false;
    }
}

void generateContourPlot::updateContourColors()
{
    QPen pen2;
    pen2.setColor(posContourColor);
    d_spectrogram->setDefaultContourPen(pen2);
    neg_spectrogram->setAlpha(0);
    QPen pen;
    pen.setColor(negContourColor);
    neg_spectrogram->setDefaultContourPen(pen);
    neg_spectrogram->setAlpha(0);
    replot();
}

void generateContourPlot::toggleLabels(bool labelsToggled)
{
    labelsTogg = labelsToggled;
    QWidget *w = canvas();
    if ( w )
        w = w->parentWidget();
    QwtPlot *plot = qobject_cast<QwtPlot *>( w );
    if ( plot == NULL )
        return;
    if(labelsToggled)
    {
        for(int i(0); i<plot->itemList().count(); i++)
        {
            if('l' == plot->itemList().at(i)->title().text()[0])
            {
                plot->itemList()[i]->setVisible(labelsTogg);
            }
        }
    }
    else
    {
        for(int i(0); i<plot->itemList().count(); i++)
        {
            if('l' == plot->itemList().at(i)->title().text()[0])
            {
                plot->itemList()[i]->setVisible(labelsTogg);
            }
        }
    }
    replot();
}

void generateContourPlot::ctrlDepressed(bool pressed)
{
    ctrlPressed = pressed;
    if(pressed)
        picker->setMousePattern( QwtEventPattern::MouseSelect1, Qt::LeftButton, Qt::ControlModifier );
    else
        picker->setMousePattern( QwtEventPattern::MouseSelect1, Qt::LeftButton);
    emit ctrlPressedSync(pressed);
}
