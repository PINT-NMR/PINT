#ifndef INTEGRATIONTEMPLATESCLASS_H
#define INTEGRATIONTEMPLATESCLASS_H
#include <QStringList>
#include <QVector>
#include <QString>
#include <QObject>

class integrationTemplatesClass
{
public:
    integrationTemplatesClass();
    ~integrationTemplatesClass();
    QStringList list;
    QVector<QStringList> tmpltVec;
    int defaultTemplateCount;

private slots:
    bool fileExists(QString path);
};

#endif // INTEGRATIONTEMPLATESCLASS_H
