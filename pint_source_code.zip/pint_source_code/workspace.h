#ifndef WORKSPACE_H
#define WORKSPACE_H

#include <QMainWindow>
#include "projecttemplate.h"
#include <QtDataVisualization/Q3DSurface>
#include <stdlib.h>
#include "spectrumgraph.h"
#include "plotgraph.h"
#include "pipedatatemplate.h"
#include <QMenuBar>
#include <QRubberBand>
#include <QTimer>
#include "spectrumthemes.h"
#include <QComboBox>
#include "foldedclass.h"
#include "integration/plot.h"
#include "pintworker.h"
#include "nointworkerthread.h"
#include "peaklistclass.h"
#include "integrationstatusdialog.h"
#include "qcustomplot.h"
#include "generatecontourplot.h"
#include "completertextedit.h"
#include "customcompleter.h"
#include "readspectrumworker.h"
#include "plotfileworker.h"
#include <QQueue>

using namespace QtDataVisualization;
using namespace std;

namespace Ui {
class workspace;
}

class workspace : public QWidget
{
    Q_OBJECT

public:
    explicit workspace(QWidget *parent = 0, projectTemplate tmplate = projectTemplate(), bool newProject = false);
    QString previousDir;
    ~workspace();

public slots:
    void readFromTemplate(projectTemplate tmplate);
    void sendLabelTitle(QAbstract3DGraph::ElementType type);
    bool eventFilter(QObject *obj, QEvent *event);
    void disconnectObjects();
    void importDefaultParameterEdit();
    void saveProject();

private:
    int ctrlInt;
    customCompleter *completer;
    completerTextEdit *paramEdit;
    integrationStatusDialog *iDialog;
    projectTemplate pintTemplate;
    SpectrumGraph *spectrumView3D;
    plotGraph *plotView3D;
    float cutoffSliderMax;
    float cutoffSliderMin;
    float minF1;
    float minF2;
    float maxF1;
    float maxF2;
    QString errMsg;
    QString loadedSpectrum;
    int peakId;
    QStringList selectedTableList;
    QStringList selectedTableList2;
    QRubberBand *rubberBand;
    QPoint origin;
    QTimer *msgTimer;
    QVector< QVector< QVector<QString> > > stateVector;
    int currentState;
    QVector<int> statePeakId;
    bool ctrlPressed;
    QVector<spectrumThemes> themeVector;
    QComboBox *themeList;
    bool generateIntensities;
    int threadsCount;
    int threadsDone;
    QPushButton *colorFitGraph;
    QPushButton *colorExpGraph;
    QTextBrowser *fitInfoBrowser;
    QColor plotColor;
    QComboBox *themeListPlot;
    ParserType parser;
    vector<PeakFitType> peakFit;
    EsdType esd;
    OutputType output;
    SpectrumType spec;
    PeakListType peak;
    VecString error_msg;
    PlotType plot;
    QVector<pintWorker* > workerThreads;
    noIntWorkerThread* noIntWorker;
    QVector<plotFileWorker* > vecPFW;
    plotFileWorker* workerPlot;
    int threadID;
    int activeThreadID;
    bool integration;
    bool centeringPeak;
    int toggledMode;
    bool centerPeakMode;
    int autBase;
    int autIncrement;
    QString autPrefix;
    QString autSuffix;
    bool quitIntegration;
    QVector<QStringList> plot2DVec;
    QString plotStr;
    QColor dataColor;
    QColor errorColor;
    int dataPenSize;
    int errorPenSize;
    int currentPlotIndex;
    QCPPlotTitle *titleQCustomPlotFit;
    QCPPlotTitle *titleQCustomPlotPlot;
    QCPScatterStyle::ScatterShape fitStyle;
    QCPScatterStyle::ScatterShape plotStyle;
    QColor fitDataColor;
    QColor fitFitColor;
    QColor plotDataColor;
    bool abortFitSave;
    Int nDim;
    generateContourPlot *contourPlot;
    bool errorIntegration;
    QString priorSelection;
    QString priorSelection2D;
    QColor posContourColor;
    QColor negContourColor;
    QVector<QStringList> tmpltVec;
    bool parameterEditChanged;
    int defaultTemplateCount;
    double sdev;
    bool labelsToggled;
    int dataPointCount;
    bool renderPlot;
    int specmode;
    bool rendering;
    bool abortCP;
    bool restoringState;
    bool togglingStates;
    Ui::workspace *ui;
    float xMinZoom;
    float xMaxZoom;
    float yMinZoom;
    float yMaxZoom;
    float zMinZoom;
    float zMaxZoom;
    bool zoomSaved;
    QVector<int> peaklistFormat;
    double minY;
    double minX;
    double maxX;
    double maxY;
    double minYfit;
    double minXfit;
    double maxXfit;
    double maxYfit;
    int totalSec;
    QMovie *movie;
    QMovie *movie2;
    int nPlane;
    QSignalMapper *plotSignalMapperType;
    QSignalMapper *plotSignalMapperType2;
    QMenuBar *menuBar;
    bool rendering3Dplot;
    QQueue<int> plotQueue;

private slots:
    void readAutoOverlaps();
    void handleSaveType(int sender);
    void handleSaveType2(int sender);
    void editAutomaticLabelAppearance();
    QString getNextLabelName(int val);
    void toggleLMBMode();
    void threadInfo();
    void handleThreading();
    void setColor(int model);
    void moveModeFrame();
    void defaultMoveModeFrame();
    void makeConnections();
    void setupCosmeticChanges();
    void setTabFromShortcut(int tabNo);
    void setupSpectrumWidget();
    void setupPlotWidget();
    void on_spectrumButton_clicked();
    void on_peaklistButton_clicked();
    void on_otherButton_clicked();
    void removeFiles(int source);
    void on_removeSelectedButton_clicked();
    void on_removeSelectedButton_2_clicked();
    void on_removeSelectedButton_3_clicked();
    QStringList addFiles(QString str);
    int read3DSpectrum(bool adjustSW);
    pipeDataTemplate readPipeHeader();
    pipeDataTemplate readTopspinHeader();
    void displayError();
    void on_loadPeaklistButton_clicked();
    void createPeakLabels(int start);
    void updatePeakLabels(int row, int col);
    void highlightPeak();
    void deselectTable();
    void createUserPeak(QVector3D position, QString label);
    void deleteUserPeak();
    void deleteFromPeaklist();
    void changeActions(int activeTab);
    void toggleHints();
    void syncPeakTable(QString query, bool select);
    void changeTheme(int theme);
    void changePlotTheme(int theme);
    void selectAll();
    void displayInformation(QString msg, bool timerEnabled, int target);
    void disableInformation();
    void updatePeakPosition(QVector3D pos, QString objName);
    void undoEvent();
    void redoEvent();
    void storeState();
    void initStateVector();
    void restoreStateFromVec();
    void loadThemes();
    int setActiveTheme();
    void removeThemeIdx(int idx);
    bool fileExists(QString path);
    foldedClass isPeakFolded(QString f1, QString f2);
    void foldPeak();
    void centerPeaks();
    int runPint(string paramFile, string outDir, string plotDir, bool integrationMode);
    void updateIntBrowser(QString str);
    bool updatePlotFiles();
    void update2DPlotFiles();
    QStringList sortList(QStringList files);
    bool checkLegal(QString str);
    void setPlot(int increment);
    void clickToPlot();
    void clickToPlot2D();
    void viewPlot(int index);
    void viewPlot2D(int index);
    void centerPeakEvaluate();
    bool removeDir(const QString & dirName);
    void manualLMBToggle();
    void selectPeaksWithinBorder(float x1,float x2,float z1,float z2);
    void pressCtrl(bool pressed);
    void writeConnectedPeaklist();
    void readConnectedPeaklist(int idx);
    void abortIntegration();
    void abortIntegrationPrep();
    void writeIntegratePeaklist();
    void addSpectrumToParamBrowser();
    QChar checkLegalFileName(QString str);
    void on_planeToPlotBox_toggled(bool checked);
    void tabChanged(int tabNo);
    void clearDir( const QString path );
    void defineOverlapForPlots();
    void defineOverlap();
    void setup2DFitWidget();
    void setup2DPlotWidget();
    void updateParameterTable();
    void generatePeakNumbers();
    void preparePlotBoxes();
    void toggleParameters();
    void toggleParameters2();
    void toggleParameters3();
    void toggleParameters4();
    void plot2D();
    void on_plotManualButton_clicked();
    void on_titleEdit_textChanged(const QString &arg1);
    void on_scatterButton_toggled(bool checked);
    void on_xaxisTitleEdit_textChanged(const QString &arg1);
    void on_yaxisTitleEdit_textChanged(const QString &arg1);
    void setManualPlotRanges();
    void setManualPlotRangesFit();
    void on_titleSizeBox_valueChanged(int arg1);
    void on_xaxisSizeBox_valueChanged(int arg1);
    void on_yaxisSizeBox_valueChanged(int arg1);
    void on_xtickBox_Plot_valueChanged(double arg1);
    void on_ytickBox_Plot_valueChanged(double arg1);
    void on_xtickBox_Fit_valueChanged(double arg1);
    void on_ytickBox_Fit_valueChanged(double arg1);
    void on_subTickXFit_valueChanged(int arg1);
    void on_subTickYFit_valueChanged(int arg1);
    void on_xaxisTitleEditFit_textChanged(const QString &arg1);
    void on_yaxisTitleEditFit_textChanged(const QString &arg1);
    void on_xaxisSizeBoxFit_valueChanged(int arg1);
    void on_yaxisSizeBoxFit_valueChanged(int arg1);
    void on_fitLegendButton_toggled(bool checked);
    void on_titleEditFit_textChanged(const QString &arg1);
    void on_titleSizeBoxFit_valueChanged(int arg1);
    void on_fitDataColorButton_clicked();
    void on_fitFitColorButton_clicked();
    void on_saveFitButton_clicked();
    void stopFitSave();
    Int setNoDim();
    Int setNoDim_Topspin();
    void spectrumBox_update();
    void on_plotDataColorButton_clicked();
    void on_xsubTickBox_Plot_valueChanged(int arg1);
    void on_ySubTickBox_Plot_valueChanged(int arg1);
    void on_savePlotButton_clicked();
    void togglePlotMode(bool mode3D);
    void setupContourWidget(pipeDataTemplate pipe);
    void processSpectrumLoad();
    void on_valuePlotBox_currentIndexChanged(int index);
    void on_view3DButton_clicked();
    void on_contourButton_clicked();
    void on_contourMinIntensity_textChanged(const QString &arg1);
    void on_contourMinIntensityMin_textChanged(const QString &arg1);
    void updateContourLevels();
    void updateContourLevelsMin();
    void on_contourLevels_valueChanged(int arg1);
    void on_contourStep_textChanged(const QString &arg1);
    void on_spectrogramToggleButton_clicked();
    void on_contourLevelsMin_valueChanged(int arg1);
    void on_contourStepMin_textChanged(const QString &arg1);
    void updateContourPlotLabels(int row, int col);
    void readContourPeaklist(int rowNo);
    void updateContourZoom();
    void updateContourZoomManual(float minF1, float maxF1, float minF2, float maxF2);
    void update3DZoom(float minF1, float maxF1, float minF2, float maxF2);
    void highlightContour();
    void deselectContour();
    void highlightContourFromIdx(QString peakidx);
    void syncCtrl(bool pressed);
    void updatePeakListFromContour(QString peakidx, QPointF point);
    void setupContourLevels(double sDev, double minZ,double maxZ);
    void on_contourPosColorButton_clicked();
    void on_contourNegColorButton_clicked();
    void setupCompleter(bool startUp);
    bool errorCheckParamFile();
    void integrate();
    void checkIntegrationHelp();
    void integrationSyntaxHelp(int index);
    void readParamFile();
    void on_integrateButton_clicked();
    void loadIntegrationTemplates();
    void readIntegrationTemplate(QModelIndex item);
    void toggleParamBool();
    void on_saveTemplateButton_clicked();
    void on_removeTemplateButton_clicked();
    QVector<QString> moveToLocalMax(QVector3D shifts);
    void on_labelsToggleButton_clicked();
    QString addTopspinDirs(QString str);
    void readThreadedSpectrum(pipeDataTemplate tmpPipe, pipeDataTemplate moddedPipe, int skip);
    void processReadThreadedSpectrum(pipeDataTemplate pipe, float minf1, float maxf1, float minf2, float maxf2, float cutoffslidermin, float cutoffslidermax);
    void flipZAxis();
    void adjustZAxis();
    void autoAdjustZAxis();
    void viewRegionInSpectrum();
    void openFileViewer(QListWidgetItem* item);
    void on_peaklistFormatButton_clicked();
    void helpTriggered();
    void tutorialTriggered();
    void initializePeaklistFormat();
    void initializeAutomaticLabelFormat();
    void on_savePeaklistButton_clicked();
    void setupContourPlotWidget();
    void toggleInfoBrowser();
    void displayInfoBrowserText(int target, int index);
    void on_spectrumDefineBox_currentIndexChanged(int index);
    void on_peaklistDefineBox_currentIndexChanged(int index);
    void on_procparDefineBox_currentIndexChanged(int index);
    void on_viewPeaklistButton_clicked();
    void on_viewProcparButton_clicked();
    void viewFromBrowser(int target);
    void cleanUpThreadsCount();
    void on_loadPeaklistIntegrationButton_clicked();
    void lockUI(bool lock);
    void abortCenterPeaks();
    QString randomTip();
    QString getFitQuality(QString fname);
    void handleSpinBox();
    void on_defaultContentButton_clicked();
    void pickPeaks(double minF1, double maxF1, double minF2, double maxF2);
    void updatePlotFilesEval(QStringList strList);
    void handleThreadingPlotFile();
    void editPeaklistFormat();
    void on_peaklistFormatButton2_clicked();
    void on_centerPeakModeBox_currentIndexChanged(int index);
    void noIntegrationEvaluate();

signals:
    void goToMain();
    void goToLoad();
    void quitApp();
    void closeScreenDialog();
};

#endif // WORKSPACE_H
