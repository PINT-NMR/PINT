/********************************************************************************
** Form generated from reading UI file 'helpdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HELPDIALOG_H
#define UI_HELPDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_helpDialog
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *labelTemplates;
    QListWidget *topicList;
    QTextBrowser *infoBrowser;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *okButton;
    QSpacerItem *horizontalSpacer_8;
    QLabel *okLabel;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QDialog *helpDialog)
    {
        if (helpDialog->objectName().isEmpty())
            helpDialog->setObjectName(QStringLiteral("helpDialog"));
        helpDialog->resize(960, 699);
        helpDialog->setStyleSheet(QStringLiteral("QDialog#helpDialog {background-image: url(:/img/bgui.png);}"));
        gridLayout = new QGridLayout(helpDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        labelTemplates = new QLabel(helpDialog);
        labelTemplates->setObjectName(QStringLiteral("labelTemplates"));
        labelTemplates->setMinimumSize(QSize(0, 0));
        labelTemplates->setMaximumSize(QSize(200, 16777215));
        QFont font;
        font.setFamily(QStringLiteral("Myriad Pro"));
        font.setPointSize(16);
        font.setBold(true);
        font.setItalic(false);
        font.setUnderline(true);
        font.setWeight(75);
        labelTemplates->setFont(font);

        verticalLayout_2->addWidget(labelTemplates);

        topicList = new QListWidget(helpDialog);
        new QListWidgetItem(topicList);
        new QListWidgetItem(topicList);
        new QListWidgetItem(topicList);
        new QListWidgetItem(topicList);
        new QListWidgetItem(topicList);
        topicList->setObjectName(QStringLiteral("topicList"));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(topicList->sizePolicy().hasHeightForWidth());
        topicList->setSizePolicy(sizePolicy);
        topicList->setMaximumSize(QSize(150, 16777215));

        verticalLayout_2->addWidget(topicList);


        horizontalLayout->addLayout(verticalLayout_2);

        infoBrowser = new QTextBrowser(helpDialog);
        infoBrowser->setObjectName(QStringLiteral("infoBrowser"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(infoBrowser->sizePolicy().hasHeightForWidth());
        infoBrowser->setSizePolicy(sizePolicy1);
        infoBrowser->setMaximumSize(QSize(16777215, 16777215));
        infoBrowser->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        infoBrowser->setLineWrapMode(QTextEdit::WidgetWidth);
        infoBrowser->setTextInteractionFlags(Qt::TextBrowserInteraction);
        infoBrowser->setOpenLinks(false);

        horizontalLayout->addWidget(infoBrowser);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_7);

        okButton = new QPushButton(helpDialog);
        okButton->setObjectName(QStringLiteral("okButton"));
        okButton->setMinimumSize(QSize(40, 40));
        okButton->setMaximumSize(QSize(40, 40));
        okButton->setStyleSheet(QLatin1String("QPushButton#okButton {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(74, 118, 155, 255), stop:1 rgba(111, 137, 160, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}\n"
"QPushButton#okButton:pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(34, 55, 72, 255), stop:1 rgba(48, 60, 70, 255));\n"
" border-style: inset;\n"
"}\n"
"QPushButton#okButton:hover:!pressed {\n"
"background-color: qlineargradient(spread:pad, x1:0.506, y1:0.960318, x2:0.5, y2:0.335955, stop:0 rgba(102, 162, 213, 255), stop:1 rgba(136, 168, 196, 255));\n"
" border-style: outset;\n"
"border-radius: 10px;\n"
"border-width: 1px;\n"
"border-color: gray;\n"
"}"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/img/go.png"), QSize(), QIcon::Normal, QIcon::Off);
        okButton->setIcon(icon);
        okButton->setIconSize(QSize(35, 35));

        horizontalLayout_10->addWidget(okButton);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_8);


        verticalLayout_5->addLayout(horizontalLayout_10);

        okLabel = new QLabel(helpDialog);
        okLabel->setObjectName(QStringLiteral("okLabel"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(okLabel->sizePolicy().hasHeightForWidth());
        okLabel->setSizePolicy(sizePolicy2);
        okLabel->setMinimumSize(QSize(0, 0));
        okLabel->setMaximumSize(QSize(1000, 1000));
        QFont font1;
        font1.setFamily(QStringLiteral("Myriad Pro"));
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(50);
        okLabel->setFont(font1);

        verticalLayout_5->addWidget(okLabel);


        horizontalLayout_2->addLayout(verticalLayout_5);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        gridLayout->addLayout(horizontalLayout_2, 1, 0, 1, 1);


        retranslateUi(helpDialog);

        QMetaObject::connectSlotsByName(helpDialog);
    } // setupUi

    void retranslateUi(QDialog *helpDialog)
    {
        helpDialog->setWindowTitle(QApplication::translate("helpDialog", "Help", 0));
        labelTemplates->setText(QApplication::translate("helpDialog", "<html><head/><body><p><span style=\" color:#ffffff;\">Select a topic</span></p></body></html>", 0));

        const bool __sortingEnabled = topicList->isSortingEnabled();
        topicList->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = topicList->item(0);
        ___qlistwidgetitem->setText(QApplication::translate("helpDialog", "About PINT", 0));
        QListWidgetItem *___qlistwidgetitem1 = topicList->item(1);
        ___qlistwidgetitem1->setText(QApplication::translate("helpDialog", "Usage", 0));
        QListWidgetItem *___qlistwidgetitem2 = topicList->item(2);
        ___qlistwidgetitem2->setText(QApplication::translate("helpDialog", "Shortcuts", 0));
        QListWidgetItem *___qlistwidgetitem3 = topicList->item(3);
        ___qlistwidgetitem3->setText(QApplication::translate("helpDialog", "Citation", 0));
        QListWidgetItem *___qlistwidgetitem4 = topicList->item(4);
        ___qlistwidgetitem4->setText(QApplication::translate("helpDialog", "Changelog", 0));
        topicList->setSortingEnabled(__sortingEnabled);

        okButton->setText(QString());
        okLabel->setText(QApplication::translate("helpDialog", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Ok</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class helpDialog: public Ui_helpDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HELPDIALOG_H
