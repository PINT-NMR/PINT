#include "integrationtemplatesclass.h"
#include <QFile>
#include <QDir>
#include <QDirIterator>
#include <QApplication>

integrationTemplatesClass::integrationTemplatesClass() :
    defaultTemplateCount(0)
{
    //Load user created templates
    QString dirName(qApp->applicationDirPath() + "/templates/");
    QDir dir(dirName);
    if (dir.exists())
    {
        QStringList nameFilters;
        nameFilters << "*.tmplt";
        QDirIterator it(dirName, nameFilters, QDir::Files | QDir::NoSymLinks);
        while (it.hasNext())
        {
            QString fname(it.next());
            if(fileExists(fname))
            {
                QFile file(fname);
                if(file.open(QIODevice::ReadOnly | QIODevice::Text))
                {
                    int count(0);
                    QStringList lst;
                    while (!file.atEnd())
                    {
                        QByteArray line = file.readLine();
                        if(count==0)
                        {
                            list << line.trimmed();
                            lst << line.trimmed();
                            count++;
                        }
                        else
                            lst << line.trimmed();
                    }
                    file.close();
                    tmpltVec.push_back(lst);
                }
            }
        }
    }
}

integrationTemplatesClass::~integrationTemplatesClass()
{
}

bool integrationTemplatesClass::fileExists(QString path)
{
    QFileInfo check_file(path);
    return (check_file.exists() && check_file.isFile());
}
