// parser.cpp

#include "parser.h"
#include "peak.h"
#include "spectrum.h"
#include <deque>
#include "pint.h"
#ifndef PINTGUI
#include "verbose.h"
#endif

template<class T>
void printVec(T &t)
{
    for (auto _t : t)
        cout << _t << "\t";
    cout << "\n";
}

// Some boolean functions to test whether strings are valid doubles or integers
Bool is_Doub(const string& s)
{
// true if double;
    istringstream iss(s);
    Doub d;
    Char c;
    return (iss >> d) && !(iss >> c);
}

Bool is_Udoub(const string& s)
{
// true if positive double;
    istringstream iss(s);
    Doub d;
    Char c;
    Bool flag = (iss >> d) && !(iss >> c);
    return flag && d > 0.0;
}

Bool is_Uzdoub(const string& s)
{
// true if positive or zero double;
    istringstream iss(s);
    Doub d;
    Char c;
    Bool flag = (iss >> d) && !(iss >> c);
    return flag && d >= 0.0;
}

bool is_Int(const string& s)
{
// true if integer;
    istringstream iss(s);
    istringstream iss2(s);
    Int i;
    Doub d;
    Char c;
    Bool flag = (iss >> i) && !(iss >> c);
    iss2 >> d;
    return flag && (Doub)i == d;
}

bool is_Uint(const string& s)
{
// true if positive integer;
    istringstream iss(s);
    istringstream iss2(s);
    Int i;
    Doub d;
    Char c;
    Bool flag = (iss >> i) && !(iss >> c);
    iss2 >> d;
    return flag && (i > 0.0) && (Doub)i == d;
}

bool is_Uzint(const string& s)
{
// true if positive or zero integer;
    istringstream iss(s);
    istringstream iss2(s);
    Int i;
    Doub d;
    Char c;
    Bool flag = (iss >> i) && !(iss >> c);
    iss2 >> d;
    return flag && (i >= 0.0) && (Doub)i == d;
}

bool is_linewidth(const string &s)
{
    string temp = s;
    toUpper(temp);
    if (temp.length()>2)
        if (temp.find("HZ") == temp.length()-2)
            temp.erase(temp.end()-2, temp.end());
    istringstream iss(temp);
    Doub d;
    Char c;
    Bool flag = (iss >> d) && !(iss >> c);
    return flag && d > 0.0;
}


bool is_signedlinewidth(const string &s)
{
// for voigt linewidth contributions, one of which might be negative

    string temp = s;
    toUpper(temp);
    if (temp.length()>2)
    if (temp.find("HZ") == temp.length()-2)
        temp.erase(temp.end()-2, temp.end());
    istringstream iss(temp);
    Doub d;
    Char c;
    return ((iss >> d) && !(iss >> c));
}




// line widths <0 is a signal that they are entered in Hz. Here they are converted to ppm
void lw_hz2ppm(ParserType &p, const SpectrumType &spec)
{
        p.peak.lwF1_in /= (p.peak.lwF1_in < 0.) ? -spec.obsF1 : 1.0;
        p.peak.lwF2_in /= (p.peak.lwF2_in < 0.) ? -spec.obsF2 : 1.0;
        p.peak.maxlwF1 /= (p.peak.maxlwF1 < 0.) ? -spec.obsF1 : 1.0;
        p.peak.maxlwF2 /= (p.peak.maxlwF2 < 0.) ? -spec.obsF2 : 1.0;
        p.peak.minlwF1 /= (p.peak.minlwF1 < 0.) ? -spec.obsF1 : 1.0;
        p.peak.minlwF2 /= (p.peak.minlwF2 < 0.) ? -spec.obsF2 : 1.0;
        p.peak.voigtLorF1_in /= (p.peak.voigtLorF1_in < 0.) ? -spec.obsF1 : 1.0;
        p.peak.voigtLorF2_in /= (p.peak.voigtLorF2_in < 0.) ? -spec.obsF2 : 1.0;
        p.peak.voigtGaussF1_in /= (p.peak.voigtGaussF1_in < 0.) ? -spec.obsF1 : 1.0;
        p.peak.voigtGaussF2_in /= (p.peak.voigtGaussF2_in < 0.) ? -spec.obsF2 : 1.0;

        for (Uint i=0; i<p.OR.OlwVec.size(); ++i) {
            p.OR.OlwVec[i].d1 /= (p.OR.OlwVec[i].d1 < 0.) ? -spec.obsF1 : 1.0;
            p.OR.OlwVec[i].d2 /= (p.OR.OlwVec[i].d2 < 0.) ? -spec.obsF2 : 1.0;
        }
        for (Uint i=0; i<p.OR.OMaxlwVec.size(); ++i) {
            p.OR.OMaxlwVec[i].d1 /= (p.OR.OMaxlwVec[i].d1 < 0.) ? -spec.obsF1 : 1.0;
            p.OR.OMaxlwVec[i].d2 /= (p.OR.OMaxlwVec[i].d2 < 0.) ? -spec.obsF2 : 1.0;
        }
        for (Uint i=0; i<p.OR.OMinlwVec.size(); ++i) {
            p.OR.OMinlwVec[i].d1 /= (p.OR.OMinlwVec[i].d1 < 0.) ? -spec.obsF1 : 1.0;
            p.OR.OMinlwVec[i].d2 /= (p.OR.OMinlwVec[i].d2 < 0.) ? -spec.obsF2 : 1.0;
        }
        for (Uint i=0; i<p.OR.OvoigtLorlwVec.size(); ++i) {
            p.OR.OvoigtLorlwVec[i].d1 /= (p.OR.OvoigtLorlwVec[i].d1 < 0.) ? -spec.obsF1 : 1.0;
            p.OR.OvoigtLorlwVec[i].d2 /= (p.OR.OvoigtLorlwVec[i].d2 < 0.) ? -spec.obsF2 : 1.0;
        }
        for (Uint i=0; i<p.OR.OvoigtGausslwVec.size(); ++i) {
            p.OR.OvoigtGausslwVec[i].d1 /= (p.OR.OvoigtGausslwVec[i].d1 < 0.) ? -spec.obsF1 : 1.0;
            p.OR.OvoigtGausslwVec[i].d2 /= (p.OR.OvoigtGausslwVec[i].d2 < 0.) ? -spec.obsF2 : 1.0;
        }
}

void pushBackPeakToFitOnly(VecString_I &word, VecString_IO &vecstr)
{
    for (Uint i=1; i<word.size(); ++i)
            vecstr.push_back(word[i]);
}

void pushBackPeakToExclude(VecString_I &peakToFitOnly, VecString_I &word, VecString_IO &vecstr)
{
    for (Uint i=1; i<word.size(); ++i)
        if (std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[i]) == peakToFitOnly.end())
            vecstr.push_back(word[i]);
}

void pushBackWords(VecString_I &peakToFitOnly, VecString_I &word, VecString_IO &vecstr)
{
    for (Uint i=1; i<word.size(); ++i)
        if (peakToFitOnly.size() == 0 || std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[i]) != peakToFitOnly.end())
            vecstr.push_back(word[i]);
}

void pushBackOdouble(VecString_I &peakToFitOnly, VecString_I &word, vector<ODoubleType> &odouble)
{
    for (Uint i=1; i<word.size()-1; ++i) {
        if (peakToFitOnly.size() == 0 || std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[i]) != peakToFitOnly.end()) {
            ODoubleType od(word[i], word.back());
            odouble.push_back(od);
        }
    }
}

void pushBackOTwoDouble(VecString_I &peakToFitOnly, VecString_I &word, vector<OTwoDoubType> &oTwoDouble)
{
    for (Uint i=1; i<word.size()-2; ++i) {
        if (peakToFitOnly.size() == 0 || std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[i]) != peakToFitOnly.end()) {
            OTwoDoubType OLW(word[i], word[word.size()-2],  word.back());
            oTwoDouble.push_back(OLW);
        }
    }
}


void pushBackExcludedPlanes(VecString_I &peakToFitOnly, VecString_I &word, vector<OExcludeType> &OExclude, VecString_IO &error_msg)
{
    Int dummy, dummy2;
    OExcludeType oex;
    Bool is_okay = true;
    if (word.size() > 2) {
        oex.assi = word[1];
        if (word.size() == 5 && word[3] == "-" && is_Uint(word[2]) && is_Uint(word[4])) {
            from_string<Int>(dummy, word[2], std::dec);
            from_string<Int>(dummy2, word[4], std::dec);
            for (Int i=dummy; i<=dummy2; ++i)
                oex.planeToExclude.push_back(i);
        }
        if (word.size() == 5 && word[3] == "-" && !is_Uint(word[2])) {
            is_okay = false;
            error_msg.push_back("ERROR: Second argument (" + word[2] + ") in option '-DEFINEEXCLUDEPLANES' ('" + word[2] + "') is not a valid plane");
        }
        if (word.size() == 5 && word[3] == "-" && !is_Uint(word[4])) {
            is_okay = false;
            error_msg.push_back("ERROR: Last argument (" + word[4] + ") in option '-DEFINEEXCLUDEPLANES' ('" + word[4] + "') is not a valid plane");
        }
        if (word.size() != 5 || word[3] != "-")
            for (Uint i=2; i<word.size(); ++i) {
                from_string<Int>(dummy, word[i], std::dec);
                if (is_Uint(word[i]))
                    oex.planeToExclude.push_back(dummy);
                else {
                    is_okay = false;
                    error_msg.push_back("ERROR: Argument " + to_string(i) + " (" + word[i] + ") in option '-DEFINEEXCLUDEPLANES' ('" + word[2] + "') is not a valid plane");
                }
            }
        if (is_okay && (peakToFitOnly.size() == 0 || std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[1]) != peakToFitOnly.end())) {
            std::sort(oex.planeToExclude.begin(), oex.planeToExclude.end());
            OExclude.push_back(oex);
        }
    }
}

void pushBackLineShape(VecString_I &peakToFitOnly, VecString_I &word, vector<OIntModeType> &intModeVec, VecString_IO &error_msg)
{
    string temp = word.back();
    toUpper(temp);
    if (temp!="LORENTZIAN" && temp!="GAUSSIAN" && temp!="GALORE" && temp!="VOIGT")
        error_msg.push_back("ERROR: -DEFINELINESHAPE must be 'LORENTZIAN' or 'GAUSSIAN' or 'GALORE' or 'VOIGT'");
    else
        for (Uint i=1; i<word.size()-1; ++i) {
            if (peakToFitOnly.size() == 0 || std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[i]) != peakToFitOnly.end()) {
                OIntModeType imode(word[i], word.back());
                intModeVec.push_back(imode);
            }
        }
}


void pushBackLineWidth(VecString_I &peakToFitOnly, VecString_I &word, vector<OTwoDoubType> &OlwVec)
{
    string temp = word[word.size()-2];
    string temp2 = word.back();

    toUpper(temp);
    toUpper(temp2);

    // If line width val is followed with "Hz", remove "Hz" and
    // append "-" before. This is a signal that it is entered in Hz
    // and must be converted into ppm
    if (temp.length() > 1)
        if (temp.find("HZ") == temp.length()-2) {
            temp.erase(temp.end()-2, temp.end());
            temp = "-" + temp;
    }
    if (temp2.length() > 1)
        if (temp2.find("HZ") == temp2.length()-2) {
            temp2.erase(temp2.end()-2, temp2.end());
            temp2 = "-" + temp2;
    }
    for (Uint i=1; i<word.size()-2; ++i) {
        if (peakToFitOnly.size() == 0 || std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[i]) != peakToFitOnly.end()) {
            OTwoDoubType OLW(word[i], temp,  temp2);
            OlwVec.push_back(OLW);
        }
    }
}


void overlap(VecString_I peakToFitOnly, VecString &word, vector<PeakListType> &group, Bool &autoOverLap, VecString &error_msg)
{
    string s = word[1];
    toUpper(s);
    if (s == "AUTO")
        autoOverLap = true;
    else if (word.size() > 2) {
        Bool ok;
        if (peakToFitOnly.size()) {
            ok = false;
            for (Uint i=1; i<word.size(); ++i)
                if (std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[i]) != peakToFitOnly.end())
                    ok = true;
            if (ok)
                for (Uint i=1; i<word.size(); ++i)
                    if (peakToFitOnly.size() != 0 && std::find(peakToFitOnly.begin(), peakToFitOnly.end(), word[i]) == peakToFitOnly.end()) {
                        ok = false;
                        error_msg.push_back("ERROR: Peak " + word[i] + " is not fitted (-PEAKTOFITONLY is in effect) and cannot be overlapped with fitted peaks");
                    }
        }
        else
            ok = true;
        if (ok) {
            PeakListType p;
            group.push_back(p);
            readGroup(group.back(), word);
        }
    }
}


void excludePlanes(VecString_I &word, VecInt_IO &planeToExclude, VecString_IO &error_msg)
{
    Int dummy, dummy2;

    if (word.size() == 4 && word[2] == "-" && is_Uint(word[1]) && is_Uint(word[3])) {
        from_string<Int>(dummy, word[1], std::dec);
        from_string<Int>(dummy2, word[3], std::dec);
        for (Int i=dummy; i<=dummy2; ++i)
            planeToExclude.push_back(i);
    }
    if (word.size() == 4 && word[2] == "-" && !is_Uint(word[1])) {
        error_msg.push_back("ERROR: First argument (" + word[1] + ") in option '-EXCLUDEPLANES' ('" + word[1] + "') is not a valid plane");
    }
    if (word.size() == 4 && word[2] == "-" && !is_Uint(word[3])) {
        error_msg.push_back("ERROR: Last argument (" + word[3] + ") in option '-EXCLUDEPLANES' ('" + word[3] + "') is not a valid plane");
    }
    if (word.size() != 4 || word[2] != "-")
        for (Uint i=1; i<word.size(); ++i) {
            from_string<Int>(dummy, word[i], std::dec);
            if (is_Uint(word[i]))
                planeToExclude.push_back(dummy);
            else {
                error_msg.push_back("ERROR: Argument " + to_string(i) +  " (" + word[i] + ") in option '-EXCLUDEPLANES' is not a valid plane");
            }
        }
    std::sort(planeToExclude.begin(), planeToExclude.end());
}


void setLineShape(VecString_I &word, PeakType &peak)
{
// If error it is taken care of in peak.cpp

    VecString lineShape;
    lineShape.push_back("LORENTZIAN");
    lineShape.push_back("GAUSSIAN");
    lineShape.push_back("GALORE");
    lineShape.push_back("VOIGT");

    string temp = word[1];
    toUpper(temp);
    peak.intMode = -1;
    for (Uint i=0; i<4; ++i) {
        if (word[1] == lineShape[i])
            peak.intMode = i;
    }
}

void prepareLineWidth(VecString_I &word, Doub &lwF1, Doub &lwF2)
{
    string temp = word[1];
    string temp2 = word[2];
    toUpper(temp);
    toUpper(temp2);

    // If number is followed by 'Hz' (w/o space) the unit is taken to be
    // Hz. I deal with it by initially giving a negative number and calculating
    // corresponding value in ppm at thee end of this function. Whenever a line
    // width is read in the same applies.
    if (temp.length() > 1)
        if (temp.find("HZ") == temp.length()-2) {
            temp.erase(temp.end()-2, temp.end());
            from_string<Doub>(lwF1, temp, std::dec);
            lwF1 = -lwF1;
        }
        else
            from_string<Doub>(lwF1, temp, std::dec);
    else
        from_string<Doub>(lwF1, temp, std::dec);
    if (temp2.length() > 1)
        if (temp2.find("HZ") == temp2.length()-2) {
            temp2.erase(temp2.end()-2, temp2.end());
            from_string<Doub>(lwF2, temp2, std::dec);
            lwF2 = -lwF2;
        }
        else
            from_string<Doub>(lwF2, temp2, std::dec);
    else
        from_string<Doub>(lwF2, temp2, std::dec);
}

void setLineWidth(VecString_I &word, PeakType &peak)
{
    Doub lwF1, lwF2;
    prepareLineWidth(word, lwF1, lwF2);
    peak.setPeakLineWidth(lwF1, lwF2);
}

void setMaxLineWidth(VecString_I &word, PeakType &peak)
{
    Doub lwF1, lwF2;
    prepareLineWidth(word, lwF1, lwF2);
    peak.setPeakMaxLineWidth(lwF1, lwF2);
}

void setMinLineWidth(VecString_I &word, PeakType &peak)
{
    Doub lwF1, lwF2;
    prepareLineWidth(word, lwF1, lwF2);
    peak.setPeakMinLineWidth(lwF1, lwF2);
}

void setVoigtLorentzianLineWidth(VecString_I &word, PeakType &peak)
{
    Doub lwF1, lwF2;
    prepareLineWidth(word, lwF1, lwF2);
    peak.voigtLorF1_in = lwF1;
    peak.voigtLorF2_in = lwF2;  // Lorentzian line width for voigt
}

void setVoigtGaussianLineWidth(VecString_I &word, PeakType &peak)
{
    Doub lwF1, lwF2;
    prepareLineWidth(word, lwF1, lwF2);
    peak.voigtGaussF1_in = lwF1;
    peak.voigtGaussF2_in = lwF2;  // Gaussian line width for voigt
}

void setGaloreLorentzian(VecString_I &word, PeakType &peak)
{
    // Lorentzian contribution to line shape. Any number is accepted
    // Gaussian contribution is 1-'lorentzian contribution'

    Doub galoreLorF1, galoreLorF2;
    from_string<Doub>(galoreLorF1, word[1], std::dec);
    from_string<Doub>(galoreLorF2, word[2], std::dec);
    peak.galoreLorF1_in = galoreLorF1;
    peak.galoreLorF2_in = galoreLorF2;
}

void setPeakMaxMovement(VecString_I &word, PeakType &peak)
{
    Doub max1, max2;
    from_string<Doub>(max1, word[1], std::dec);
    from_string<Doub>(max2, word[2], std::dec);
    peak.setPeakMaxMovement(max1, max2);
}



ParserType::ParserType() { }

ParserType::ParserType(const string &parfile, const string &_outdir, const string &_progname) : parFile(parfile), outDir(_outdir), progname(_progname) {

    procparName = "";
    vdlistName = "";
    assiCol = 0;
    F1Col = 1;
    F2Col = 2;
    time_T2 = 0.;
    timeFactor = 1.;
    tanh = 1.;
    skipLines = 0;
    noIntegration = false;
    intMode = GAUSSIAN;
    eps = 1e-6;
    sort = 0;
    resno = false;
    invert = 0;
    nDim = -1;
    b1 = -9999.9;      // this value is a signal that parameter has not been specified
    db1 = 0.;
    r1rhoDim = 1;		// default to indirect dimension
    carrierPPM = -9999.9;  // this value is a signal that parameter has not been specified
    plotMode = 0;		// matlab plots would be 1 but this has now been disabled
    planeToPlot = -1;
    planeToFitFirst = 1;
    autoOverLap = false;
    trosy = false;   // only applies to R1rho experiments
    silent = false;
    lineShape.push_back("LORENTZIAN");
    lineShape.push_back("GAUSSIAN");
    lineShape.push_back("GALORE");
    lineShape.push_back("VOIGT");
    maxdata = MAX_DATA;
    nthreads = 100;
    fjack = 1;
    fboot = fmc = 0;
    pipeData = true;
}

Int ParserType::parse(VecString &error_msg) {

    Bool arrayFlag = false;
    string s, arrayPar;
    VecString word;
    Bool spectrumFlag = false;
    Bool peaklistFlag = false;


    // Parse parameter file
    // ---------------------
    ifstream myFile(parFile);

    if (!myFile.is_open()) {
        error_msg.push_back("ERROR: Cannot open parameter file '" + parFile + "'!");
        return 1;
    }


    // First check for peaks to fit only
    while (myFile.good()) {
        getline(myFile, s);

        line2words(s, word);

        if (EmptyLine(word))
            continue;

        toUpper(word[0]);

        if (word[0] == "-FITONLY") {
            if (word.size() > 1) {
                pushBackPeakToFitOnly(word, peakToFitOnly);
                //printVec(peakToFitOnly);
            }

            else
                error_msg.push_back("ERROR: Option '-FITONLY' requires at least one argument");
        }
    }

    // Parse everything else
    myFile.clear();
    myFile.seekg(0);
    while (myFile.good()) {
        getline(myFile, s);

        line2words(s, word);
        Uint wordsize = word.size();

        if (EmptyLine(word))
            continue;

        toUpper(word[0]);

        // spectrum
        if (word[0] == "-SPECTRUM") {
            spectrumFlag = true;
            if (word.size() > 1)
                specName.push_back(word[1]);
            else
                error_msg.push_back("ERROR: Missing argument for option '-SPECTRUM'");
        }

        else if (word[0] == "-SPECTRUMLIST") {
            spectrumFlag = true;
            if (word.size() > 1) {
                ifstream myfile(word[1].c_str());
                char mys[MAX_LINE];
                VecString mywd;
                for (;;) {
                    myfile.getline(mys, MAX_LINE);
                    if (myfile.fail())
                        break;
                    line2words(mys, mywd);
                    if (mywd.size() == 0)
                        continue;
                    if (mywd[0][0] != '#')
                        specName.push_back(mywd[0]);
                }
            }
            else
                error_msg.push_back("ERROR: Missing argument for option '-SPECTRUMLIST'");
        }

        else if (word[0] == "-TOPSPINDATA") {
            pipeData = false;
        }

        else if (word[0] == "-MAXDATA") {
            if (word.size() == 1) {
                error_msg.push_back("ERROR: Option '-MAXDATA' requires one argument");
            }
            else if (!is_Uint(word[1]))
                error_msg.push_back("ERROR: Argument for option '-MAXDATA' must be a positive integer");
            else
                from_string<Llong>(maxdata, word[1], std::dec);
        }

        // peaklist
        else if (word[0] == "-PEAKLIST") {
            peaklistFlag = true;
            if (word.size() > 1)
                peakListName = word[1];
            else
                error_msg.push_back("ERROR: Option '-PEAKLIST' requires one argument");
        }

        // custom ordering of columns
        else if (word[0] == "-PEAKLISTCOLUMNS") {
            if (word.size() >= 4) {
                from_string<Int>(assiCol, word[1], std::dec);
                from_string<Int>(F1Col, word[2], std::dec);
                from_string<Int>(F2Col, word[3], std::dec);
                if (!is_Uint(word[1]) || !is_Uint(word[2]) || !is_Uint(word[3]))
                    error_msg.push_back("ERROR: Specify legal integer numbers (>=1) for all columns in option '-PEAKLISTCOLUMNS'");
                else
                    --assiCol; --F1Col; --F2Col; // see why in file peak.cpp
                if (assiCol == F1Col || assiCol == F2Col || F1Col == F2Col)
                    error_msg.push_back("ERROR: All argument in option '-PEAKLISTCOLUMNS' must be unique");
            }
            else
                error_msg.push_back("ERROR: Option '-PEAKLISTCOLUMNS' requires three arguments");
        }

        else if (word[0] == "-SKIPLINES") {
            if (word.size() > 1)
                if (is_Uzint(word[1]))
                     from_string<Int>(skipLines, word[1], std::dec);
                else
             error_msg.push_back("ERROR: Argument for option '-SKIPLINES' must be an integer >= 0");
            else
                error_msg.push_back("ERROR: Missing argument for option '-SKIPLINES'");
        }

        // no integration - just downstream fitting of already integrated data
        else if (word[0] == "-NOINTEGRATION") {
            noIntegration = true;
        }

        // To not print disclaimer
        else if (word[0] == "-SILENT") {
            silent= true;
        }

        // lineshape fitting
        else if (word[0] == "-RADIUS") {
            if (word.size() > 2)
                if (is_Udoub(word[1]) && is_Udoub(word[2])) {
                    Doub radF1, radF2;
                    from_string<Doub>(radF1, word[1], std::dec);
                    from_string<Doub>(radF2, word[2], std::dec);
                    peak.setPeakRadius(radF1, radF2);
                }
                else
                    error_msg.push_back("ERROR: Both arguments for option '-RADIUS' must be positive real numbers");
            else
                error_msg.push_back("ERROR: Option '-RADIUS' requires two arguments");
        }

        else if (word[0] == "-LINEWIDTH") {
            if (word.size() > 2)
                if (is_linewidth(word[1]) && is_linewidth(word[2]))
                    setLineWidth(word, peak);
                else
                    error_msg.push_back("ERROR: Both arguments for option '-LINEWIDTH' must be positive real numbers (optionally immediately followed by 'Hz')");
                else
                    error_msg.push_back("ERROR: Option '-LINEWIDTH' requires two arguments");
        }

        else if (word[0] == "-MAXLINEWIDTH") {
            if (word.size() > 2)
                if (is_linewidth(word[1]) && is_linewidth(word[2]))
                    setMaxLineWidth(word, peak);
                else
                    error_msg.push_back("ERROR: Both arguments for option '-MAXLINEWIDTH' must be positive real numbers (optionally immediately followed by 'Hz')");
            else
                error_msg.push_back("ERROR: Option '-MAXLINEWIDTH' requires two arguments");
        }

        else if (word[0] == "-MINLINEWIDTH") {
            if (word.size() > 2)
                if (is_linewidth(word[1]) && is_linewidth(word[2]))
                    setMinLineWidth(word, peak);
                else
                    error_msg.push_back("ERROR: Both arguments for option '-MINLINEWIDTH' must be positive real numbers (optionally immediately followed by 'Hz')");
            else
                error_msg.push_back("ERROR: Option '-MINLINEWIDTH' requires two arguments");
        }

        // N.B. I will allow negative guesses because this might occur
        else if (word[0] == "-VOIGTLORENTZIANLINEWIDTH") {
            if (word.size() > 2)
                if (is_signedlinewidth(word[1]) && is_signedlinewidth(word[2]))
                    setVoigtLorentzianLineWidth(word, peak);
                else
                    error_msg.push_back("ERROR: Both arguments for option '-VOIGTLORENTZIANLINEWIDTH' must be real numbers");
            else
                error_msg.push_back("ERROR: Option '-VOIGTLORENTZIANLINEWIDTH' requires two arguments");
        }

        // N.B. I will allow negative guesses because this might occur
        else if (word[0] == "-VOIGTGAUSSIANLINEWIDTH") {
            if (word.size() > 2)
                if (is_signedlinewidth(word[1]) && is_signedlinewidth(word[2]))
                    setVoigtGaussianLineWidth(word, peak);
                else
            error_msg.push_back("ERROR: Both arguments for option '-VOIGTGAUSSIANLINEWIDTH' must be real numbers");
            else
                error_msg.push_back("ERROR: Missing argument(s) for option '-VOIGTGAUSSIANLINEWIDTH'");
        }

        // N.B. Positive, negative and zero are just fine
        else if (word[0] == "-GALORELORENTZIAN") {
            if (word.size() > 2)
                if (is_Doub(word[1]) && is_Doub(word[2]))
                    setGaloreLorentzian(word, peak);
            else
                error_msg.push_back("ERROR:  Both arguments for option '-GALORELORENTZIAN' must be real numbers");
            else
                error_msg.push_back("ERROR: Option '-GALORELORENTZIAN' requires two arguments");
        }

        else if (word[0] == "-MAXMOVEMENT") {
            if (word.size() > 2)
                if (is_Udoub(word[1]) && is_Udoub(word[2]))
                    setPeakMaxMovement(word, peak);
                else
                    error_msg.push_back("ERROR: Both arguments for '-MAXMOVEMENT' must be positive real numbers");
            else
                error_msg.push_back("ERROR: Option '-MAXMOVEMENT' requires two arguments");
        }

        else if (word[0] == "-CENTERWEIGHTED") {
            if (word.size() > 1)
                if (is_Udoub(word[1]))
                    from_string<Doub>(peak.centerWt, word[1], std::dec);
                else
                    error_msg.push_back("ERROR: Argument for option '-CENTERWEIGHTED' must be a positive real number");
            else
                error_msg.push_back("ERROR: Missing argument for option '-CENTERWEIGHTED'");
        }

        else if (word[0] == "-NOISEUNCERTAINTY") {
            peak.noiseUncertainty = true;
        }

        else if (word[0] == "-NTHREADS") {
            if (word.size() >1)
                if (is_Uint(word[1]))
                from_string<Int>(nthreads, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-NTHREADS' must be a positive integer");
            else
                error_msg.push_back("ERROR: Option '-NTHREADS' requires one argument");
        }

        // procpar file, vdlist and arrays
        else if (word[0] == "-PROCPAR") {
            if (word.size() >1)
                procparName = word[1];
            else
                error_msg.push_back("ERROR: Option '-PROCPAR' requires one argument");
        }

        else if (word[0] == "-VDLIST") {
            if (word.size() >1)
                vdlistName = word[1];
            else
                error_msg.push_back("ERROR: Option option '-VDLIST' requires one argument");
        }

        else if (word[0] == "-ARRAY") {
            if (word.size() >1)
                arrayPar = word[1];
            else
                error_msg.push_back("ERROR: Option '-ARRAY' requires one argument");
        }

        // N.B. left to enforce nature of arguments for
        else if (word[0] == "-ARRVAL") {
            if (word.size() >1) {
                arr = VecDoub(word.size()-1);
                for (Uint i=1; i<word.size(); ++i) {
                    from_string<Doub>(arr[i-1], word[i], std::dec);
                    if (!is_Doub(word[i]))
                        error_msg.push_back("ERROR: All arguments for option '-ARRVAL' must be numerical");
                }
                arrayFlag = true;
            }
            else
                error_msg.push_back("ERROR: Option '-ARRVAL' requires at least one argument");
        }

        // MODIFY TIME FACTOR
        else if (word[0] == "-TIMEFACTOR") {
            if (word.size() > 1)
                if (is_Doub(word[1]))
                from_string<Doub>(timeFactor, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-TIMEFACTOR' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-TIMEFACTOR' requires one argument");
        }

        // Error estimation in downstream fitting
        else if (word[0] == "-JACKKNIFE") {
            peak.fjack = 1;
            peak.fboot = peak.fmc = 0;
        }

        else if (word[0] == "-BOOTSTRAP") {
            peak.fboot = 1;
            peak.fjack = peak.fmc = 0;
        }

        else if (word[0] == "-MONTECARLO") {
            peak.fmc = 1;
            peak.fjack = peak.fboot = 0;
        }

        // CPMG
        else if (word[0] == "-FITCPMG") {
            peak.fitCPMG = 1;
        }

        else if (word[0] == "-CPMGTIME_T2") {
            if (word.size() == 1) {
                error_msg.push_back("ERROR: Option '-TIME_T2' requires one argument");
                continue;
            }
            else if (is_Udoub(word[1]))
                from_string<Doub>(time_T2, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-TIME_T2' must be a positive real number");
        }

        else if (word[0] == "-CPMGKEX") {
            if (word.size() > 1)
                if (is_Udoub(word[1]))
                from_string<Doub>(peak.kex, word[1], std::dec);
            else
                error_msg.push_back("ERROR: 'Argument for option -CPMGKEX' must be a positive real number");
            else
                error_msg.push_back("ERROR: Option '-CPMGKEX' requires one argument");
        }

        else if (word[0] == "-CPMGPB") {
            if (word.size() > 1) {
                from_string<Doub>(peak.pB, word[1], std::dec);
                if (!is_Doub(word[1]) || peak.pB < 0.0 || peak.pB > 1.0)
                    error_msg.push_back("ERROR: Argument for option '-CPMGPB' must be real number in the range 0.0-1.0");
            }
            else
                error_msg.push_back("ERROR: Option '-CPMGPB' requires one argument");
        }

        else if (word[0] == "-CPMGDELTAOMEGA") {
            if (word.size() > 1) {
                if (is_Doub(word[1]))
                    from_string<Doub>(peak.Dw, word[1], std::dec);
                else
                    error_msg.push_back("ERROR: Argument for option '-CPMGDELTAOMEGA' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-CPMGDELTAOMEGA' requires one argument");
        }

        else if (word[0] == "-CPMGR20") {
            if (word.size() > 1) {
                if (is_Doub(word[1]))
                    from_string<Doub>(peak.R20, word[1], std::dec);
                else
                    error_msg.push_back("ERROR: Argument for option '-CPMGR20' nust be a real number");
            }
            else
                error_msg.push_back("ERROR: Missing argument for option '-CPMGR20'");
        }

        else if (word[0] == "-CPMGFIXKEX") {
            peak.fixKex = true;
        }

        else if (word[0] == "-CPMGFIXPB") {
            peak.fixPb = true;
        }

        // NOE
        else if (word[0] == "-CALCNOE")
            peak.fitNOE = 1;

        else if (word[0] == "-NOEINVERT")
            invert = 1;

        // CONSTANT FUNCTION
        else if (word[0] == "-FITCONSTANT")
            peak.fitConstant = 1;

        else if (word[0] == "-CONSTANTINTERCEPT") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.constant, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-CONSTANTINTERCEPT' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-CONSTANTINTERCEPT' requires one argument");
        }

        // LINEAR FUNCTION
        else if (word[0] == "-FITLIN") {
            peak.fitLin = 1;
        }

        else if (word[0] == "-LINSLOPE") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.slope, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-LINSLOPE' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-LINSLOPE' requires one argument");
        }

        else if (word[0] == "-LININTERCEPT") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.intercept, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-LININTERCEPT' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-LININTERCEPT' requires one argument");
        }

        // EXPONENTIAL
        else if (word[0] == "-FITEXP") {
            peak.fitExp = 1;
        }

        else if (word[0] == "-EXPDECAYRATE") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.R12, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-EXPDECAYRATE' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-EXPDECAYRATE' requires one argument");
        }

        else if (word[0] == "-EXPINTERCEPT") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.A12, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-EXPINTERCEPT' must be real number");
            else
                error_msg.push_back("ERROR: Option '-EXPINTERCEPT' requires one argument");
        }

        // EXPONENTIAL WITH OFFSET
        else if (word[0] == "-FITEXPOFFSET") {
                peak.fitExpOffset = 1;
        }

        else if (word[0] == "-EXPOFFSETDECAYRATE") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.expoffsR12, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-EXPOFFSETDECAYRATE' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-EXPOFFSETDECAYRATE' requires one argument");
        }

        else if (word[0] == "-EXPOFFSETINTERCEPT") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.expoffsA12, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-EXPOFFSETINTERCEPT' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-EXPOFFSETINTERCEPT' requires one argument");
        }

        else if (word[0] == "-EXPOFFSETOFFSET") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.expoffsOffset, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-EXPOFFSETOFFSET' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-EXPOFFSETOFFSET' requires one argument");
        }

        // BIEXPONENTIAL
        else if (word[0] == "-FITBIEXP") {
            peak.fitBiExp = 1;
        }

        else if (word[0] == "-BIEXPDECAYRATE1") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.BExp1, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-BIEXPDECAYRATE1' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-BIEXPDECAYRATE1' requires one argument");
        }

        else if (word[0] == "-BIEXPDECAYRATE2") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.BExp2, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-BIEXPDECAYRATE2' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-BIEXPDECAYRATE2' requires one argument");
        }

        else if (word[0] == "-BIEXPINTERCEPT1") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.BExpA1, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-BIEXPINTERCEPT1' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-BIEXPINTERCEPT1' requires one argument");
        }

        else if (word[0] == "-BIEXPINTERCEPT2") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.BExpA2, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-BIEXPINTERCEPT2' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-BIEXPINTERCEPT2' requires one argument");
        }

        // INVERSION RECOVERY
        else if (word[0] == "-FITINVRECOVERY") {
            peak.fitInvRecovery = 1;
        }

        else if (word[0] == "-INVRECOVERYBUILDUPRATE") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.invrecR1, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-INVRECOVERYBUILDUPRATE' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-INVRECOVERYBUILDUPRATE' requires one argument");
        }

        else if (word[0] == "-INVRECOVERYOFFSET") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.invrecPlateau, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-INVRECOVERYOFFSET' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-INVRECOVERYOFFSET' requires one argument");
        }

        // SATURATION RECOVERY
        else if (word[0] == "-FITSATRECOVERY") {
            peak.fitSatRecovery = 1;
        }

        else if (word[0] == "-SATRECOVERYBUILDUPRATE") {
            if (word.size() > 1)
                             if (is_Doub(word[1]))
                from_string<Doub>(peak.satrecR1, word[1], std::dec);
                        else
                error_msg.push_back("ERROR: Argument for option '-SATRECOVERYBUILDUPRATE' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-SATRECOVERYBUILDUPRATE' requires one argument");
        }

        else if (word[0] == "-SATRECOVERYOFFSET") {
            if (word.size() > 1)
                        if (is_Doub(word[1]))
                from_string<Doub>(peak.satrecPlateau, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Argument for option '-SATRECOVERYOFFSET' must be a real number");
            else
                error_msg.push_back("ERROR: Option '-SATRECOVERYOFFSET' requires one argument");
        }

        // R2 from R1rho
        else if (word[0] == "-FITR2FROMR1RHO") {
            peak.fitR1rho = 1;
        }

        else if (word[0] == "-R2FROMR1RHOTROSY") {
            trosy = true;
        }

        else if (word[0] == "-R2FROMR1RHOR1LIST") {
            if (word.size() > 1)
                r1List = word[1];
            else
                error_msg.push_back("ERROR: Option '-R2FROMR1RHOR1LIST' requires one argument");
        }

        else if (word[0] == "-R2FROMR1RHOB1") {
            if (word.size() > 1) {
                             if (is_Udoub(word[1]))
                from_string<Doub>(b1, word[1], std::dec);
            else {
                error_msg.push_back("ERROR: First argument for option '-R2FROMR1RHOB1' must be a positive real number");
                b1 = -999.9; // signal that option has been specified in order to not get multiple error messages
            }
            }
            else
                error_msg.push_back("ERROR: Option '-R2FROMR1RHOB1' requires at least one argument");
            if (word.size() > 2) {
                             if (is_Udoub(word[2]))
                                 from_string<Doub>(db1, word[2], std::dec);
                  else
                error_msg.push_back("ERROR: Second argument for option '-R2FROMR1RHOB1' must be a positive real number");
                 }
        }

        // It would be exotic but carrier could in fact have negative chemical shift
        else if (word[0] == "-R2FROMR1RHOCARRIER") {
            if (word.size() > 1) {
                if (is_Doub(word[1]))
                    from_string<Doub>(carrierPPM, word[1], std::dec);
                else {
                    error_msg.push_back("ERROR: Argument for option '-R2FROMR1RHOCARRIER' must be a real number");
                    carrierPPM = -999.9; // this is a signal that option has been read but in order not to get multiple error codes
                }
            }
            else
                error_msg.push_back("ERROR: Option '-R2FROMR1RHOCARRIER' requires one argument");
        }

        // dimension that r1rho is measured in (F1 is default)
        else if (word[0] == "-R2FROMR1RHODIM") {
            if (word.size() > 1) {
                from_string<Int>(r1rhoDim, word[1], std::dec);
                if (r1rhoDim != 1 && r1rhoDim != 2)
                    error_msg.push_back("ERROR: Argument for option '-R2FROMR1RHODIM' must be either 1 (indirect dimension) or 2 (direct dimension)");
            }
            else
                error_msg.push_back("ERROR: Option '-R2FROMR1RHODIM' requires one argument");
        }

        // overlap
        else if (word[0] == "-OVERLAP") {
            if (word.size() > 1)
                overlap(peakToFitOnly, word, group, autoOverLap, error_msg);
            else
                error_msg.push_back("ERROR: Missing argument for option '-OVERLAP'");
        }

        // fit only these peak . THIS SHOULD INDEED BE EMPTY
        else if (word[0] == "-FITONLY") {
        }

        // exclude peaks from integration
        else if (word[0] == "-EXCLUDEPEAKS") {
            if (word.size() > 1)
                pushBackPeakToExclude(peakToFitOnly, word, peakToExclude);
            else
                error_msg.push_back("ERROR: Option '-EXCLUDEPEAKS' requires at least one argument");
        }

        // exclude planes
        else if (word[0] == "-EXCLUDEPLANES") {
            if (word.size() > 1)
                excludePlanes(word, planeToExclude, error_msg);
            else
                error_msg.push_back("ERROR: Option '-EXCLUDEPLANES' requires at least one argument");
        }

        // line shape
        else if (word[0] == "-LINESHAPE") {
            if (word.size() > 1)
                setLineShape(word, peak);
            else
                error_msg.push_back("ERROR: Option '-LINESHAPE' requires one argument");
        }

        // Change tolerance for convergance
        else if (word[0] == "-EPS") {
            if (word.size() > 1)
                if (is_Udoub(word[1]))
                    from_string<Doub>(eps, word[1], std::dec);
                else
             error_msg.push_back("ERROR: Argument for option '-EPS' must be a positive real number");
                else
                error_msg.push_back("ERROR: Option '-EPS' requires one argument");
        }

        // fix peak position
        else if (word[0] == "-FIXPOSITION") {
            peak.fixPos = true;
        }

        // fix line width
        else if (word[0] == "-FIXLINEWIDTH") {
            peak.fixLW = true;
        }

        // Select a special plane to add to plotfits.gnu (default is all planes)
        else if (word[0] == "-PLANE2PLOT") {
            if (word.size() > 1)
                from_string<Int>(planeToPlot, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Option '-PLANE2PLOT' requires one argument");
        }

        // Select a special plane to fit first (default is plane 1)
        else if (word[0] == "-PLANE2FITFIRST") {
            if (word.size() > 1)
                from_string<Int>(planeToFitFirst, word[1], std::dec);
            else
                error_msg.push_back("ERROR: Option '-PLANE2FITFIRST' requires one argument");
        }

        // output options
        else if (word[0] == "-SORT") {
            sort = 1;
        }

        else if (word[0] == "-RESNO") {
            resno = 1;
        }

        // do not report results for these peaks
        else if (word[0] == "-NOREPORT") {
            if (word.size() > 1)
                pushBackWords(peakToFitOnly, word, peakToNotReport);
            else
                error_msg.push_back("ERROR: Missing argument for option '-NOREPORT'");
        }


        // OVERRIDE DEFAULTS
        // -----------------

        // integration
        else if (word[0] == "-DEFINERADIUS") {
            if (word.size() > 3) {
                pushBackOTwoDouble(peakToFitOnly, word, OR.ORadVec);
                if (!is_Udoub(word[wordsize-2]) || !is_Udoub(word.back()))
                    error_msg.push_back("ERROR: Last two arguments for option '-DEFINERADIUS' must be positive real numbers");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINERADIUS' requires at least three arguments");
        }

        else if (word[0] =="-DEFINELINEWIDTH") {
            if (word.size() > 3) {
                pushBackLineWidth(peakToFitOnly, word, OR.OlwVec);
                if (!is_linewidth(word[wordsize-2]) || !is_linewidth(word.back()))
                    error_msg.push_back("ERROR: Last two arguments for option '-DEFINELINEWIDTH' must be positive real numbers");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINELINEWIDTH' requires at least three arguments");
        }

        else if (word[0] =="-DEFINEMAXLINEWIDTH") {
            if (word.size() > 3) {
                pushBackLineWidth(peakToFitOnly, word, OR.OMaxlwVec);
                if (!is_linewidth(word[wordsize-2]) || !is_linewidth(word.back()))
                    error_msg.push_back("ERROR: Last two arguments for option '-DEFINEMAXLINEWIDTH' must be positive real numbers");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEMAXLINEWIDTH' requires at least three arguments");
        }

        else if (word[0] =="-DEFINEMINLINEWIDTH") {
            if (word.size() > 3) {
                pushBackLineWidth(peakToFitOnly, word, OR.OMinlwVec);
                if (!is_linewidth(word[wordsize-2]) || !is_linewidth(word.back()))
                    error_msg.push_back("ERROR: Last two arguments for option '-DEFINEMINLINEWIDTH' must be positive real numbers");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEMINLINEWIDTH' requires at least three arguments");
        }

        else if (word[0] =="-DEFINEVOIGTLORENTZIANLINEWIDTH") {
            if (word.size() > 3) {
                pushBackLineWidth(peakToFitOnly, word, OR.OvoigtLorlwVec);
                if (!is_signedlinewidth(word[wordsize-2]) || !is_signedlinewidth(word.back()))
                    error_msg.push_back("ERROR: Last two arguments for option '-DEFINEVOIGTLORENTZIANLINEWIDTH' must be real numbers");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEVOIGTLORENTZIANLINEWIDTH' requires at least three arguments");
        }

        else if (word[0] =="-DEFINEVOIGTGAUSSIANLINEWIDTH") {
            if (word.size() > 3) {
                pushBackLineWidth(peakToFitOnly, word, OR.OvoigtGausslwVec);
                if (!is_signedlinewidth(word[wordsize-2]) || !is_signedlinewidth(word.back()))
                    error_msg.push_back("ERROR: Last two arguments for option '-DEFINEVOIGTGAUSSIANLINEWIDTH' must be real numbers");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEVOIGTGAUSSIANLINEWIDTH' requires at least three arguments");
        }

        else if (word[0] =="-DEFINEMAXMOVEMENT") {
            if (word.size() > 3) {
                pushBackOTwoDouble(peakToFitOnly, word, OR.OMaxMoveVec);
                if (!is_Udoub(word[wordsize-2]) || !is_Udoub(word.back()))
                    error_msg.push_back("ERROR: Last two arguments for option '-DEFINEMAXMOVEMENT' must be positive real numbers");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEMAXMOVEMENT' requires at least three arguments");
        }

        else if (word[0] == "-DEFINEEXCLUDEPLANES") {
            if (word.size() > 2)
                pushBackExcludedPlanes(peakToFitOnly, word, OR.OExclude, error_msg);
            else
                error_msg.push_back("ERROR: Option '-DEFINEEXCLUDEPLANES' requires at least two arguments");
        }

        else if (word[0] =="-DEFINELINESHAPE") {
            if (word.size() > 2)
                pushBackLineShape(peakToFitOnly, word, OR.intModeVec, error_msg);
            else
                error_msg.push_back("ERROR: Option '-DEFINELINESHAPE' requires at least two arguments");
        }

        else if (word[0] == "-DEFINEFIXPOSITION") {
            if (word.size() > 1)
                pushBackWords(peakToFitOnly, word, OR.OFixPosVec);
            else
                error_msg.push_back("ERROR: Option '-DEFINEFIXPOSITION' requires at least one argument");
        }

        else if (word[0] == "-DEFINEFIXLINEWIDTH") {
            if (word.size() > 1)
                pushBackWords(peakToFitOnly, word, OR.OFixLWVec);
            else
                error_msg.push_back("ERROR: Option '-DEFINEFIXLINEWIDTH' requires at least one argument");
        }
        else if (word[0] =="-DEFINEGALORELORENTZIAN") {
            if (word.size() > 3) {
                pushBackLineWidth(peakToFitOnly, word, OR.OgaloreLorVec);
                if (!is_Doub(word[wordsize-2]) || !is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last two arguments for option '-DEFINEGALORELORENTZIAN' must be real numbers");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEGALORELORENTZIAN' requires at least three arguments");
        }

        else if (word[0] == "-DEFINECENTERWEIGHTED") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OcenterWtVec);
                if (!is_Udoub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINECENTERWEIGHTED' must be a positive real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINECENTERWEIGHTED' requires at least two arguments");
        }


        // error estimation in downstream fitting
        else if (word[0] == "-DEFINEJACKKNIFE") {
            if (word.size() > 1)
                pushBackWords(peakToFitOnly, word, OR.OJack);
            else
                error_msg.push_back("ERROR: Option '-DEFINEJACKKNIFE' requires at least one argument");
        }

        else if (word[0] == "-DEFINEBOOTSTRAP") {
            if (word.size() > 1)
                pushBackWords(peakToFitOnly, word, OR.OBoot);
            else
                error_msg.push_back("ERROR: Option '-DEFINEBOOTSTRAP' requires at least one argument");
        }

        else if (word[0] == "-DEFINEMONTECARLO") {
            if (word.size() > 1)
                pushBackWords(peakToFitOnly, word, OR.OMonteCarlo);
            else
                error_msg.push_back("ERROR: Option '-DEFINEMONTECARLO' requires at least one argument");
        }

        /* constantFit Parameters */
        else if (word[0] == "-DEFINECONSTANTINTERCEPT") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OConstant);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINECONSTANTINTERCEPT' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINECONSTANTINTERCEPT' requires at least two arguments");
        }

        /* linfit parameters */
        else if (word[0] == "-DEFINELINSLOPE") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OSlope);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINELINSLOPE' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINELINSLOPE' requires at least two arguments");
        }

        else if (word[0] == "-DEFINELININTERCEPT") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OIntercept);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINELININTERCEPT' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINELININTERCEPT' requires at least two arguments");
        }

        /* expfit parameters */
        else if (word[0] == "-DEFINEEXPDECAYRATE") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OexpDecayRate);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEEXPDECAYRATE' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEEXPDECAYRATE' requires at least two arguments");
        }

        else if (word[0] == "-DEFINEEXPINTERCEPT") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OexpIntercept);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEEXPINTERCEPT' must be a positive number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEEXPINTERCEPT' requires at least two arguments");
        }

        /* expoffsetfit parameters */
        else if (word[0] == "-DEFINEEXPOFFSETDECAYRATE") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OexpoffsR12);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEEXPOFFSETDECAYRATE' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEEXPOFFSETDECAYRATE' requires at least two arguments");
        }

        else if (word[0] == "-DEFINEEXPOFFSETINTERCEPT") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OexpoffsA12);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEEXPOFFSETINTERCEPT' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEEXPOFFSETINTERCEPT' requires at least two arguments");
        }

        else if (word[0] == "-DEFINEEXPOFFSETOFFSET") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OexpoffsOffset);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEEXPOFFSETOFFSET' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEEXPOFFSETOFFSET' requires at least two arguments");
        }

        /* biExpfit parameters */
        else if (word[0] == "-DEFINEBIEXPDECAYRATE1") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OBExp1);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEBIEXPDECAYRATE1' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEBIEXPDECAYRATE1' requires at least two arguments");
        }

        else if (word[0] == "-DEFINEBIEXPDECAYRATE2") {
            if (word.size() > 2) {
                 pushBackOdouble(peakToFitOnly, word, OR.OBExp2);
                 if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEBIEXPDECAYRATE2' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEBIEXPDECAYRATE2' requires at least two arguments");
        }

        else if (word[0] == "-DEFINEBIEXPINTERCEPT1") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OBExpA1);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEBIEXPINTERCEPT1' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEBIEXPINTERCEPT1' requires at least two arguments");
        }

        else if (word[0] == "-DEFINEBIEXPINTERCEPT2") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OBExpA2);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEBIEXPINTERCEPT2' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEBIEXPINTERCEPT2' requires at least two arguments");
        }

        /* inversion recovery parameters */
        else if (word[0] == "-DEFINEINVRECOVERYBUILDUPRATE") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OinvrecR1);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEINVRECOVERYBUILDUPRATE' must be a positive real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEINVRECOVERYBUILDUPRATE' requires at least two arguments");
        }

        else if (word[0] == "-DEFINEINVRECOVERYOFFSET") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OinvrecPlateau);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINEINVRECOVERYOFFSET' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINEINVRECOVERYOFFSET' requires at least two arguments");
        }

        /* saturation recovery parameters */
        else if (word[0] == "-DEFINESATRECOVERYBUILDUPRATE") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OsatrecR1);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINESATRECOVERYBUILDUPRATE' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINESATRECOVERYBUILDUPRATE' requires at least two arguments");
        }

        else if (word[0] == "-DEFINESATRECOVERYOFFSET") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OsatrecPlateau);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Last argument for option '-DEFINESATRECOVERYOFFSET' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINESATRECOVERYOFFSET' requires at least two arguments");
        }

        /* CPMGfit parameters */
        else if (word[0] == "-DEFINECPMGKEX") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OKex);
                if (!is_Udoub(word.back()))
                    error_msg.push_back("ERROR: Argument for '-DEFINECPMGKEX' must be a positive real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINECPMGKEX' requires at least two arguments");
        }

        else if (word[0] == "-DEFINECPMGPB") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OPB);
                if (is_Doub(word.back())) {
                    Doub d;
                    from_string<Doub>(d, word.back(), std::dec);
                    if (d < 0.0 || d>1.0)
                        error_msg.push_back("ERROR: Argument for option '-DEFINECPMGPB' must be a real number in the range 0.0-1.0");
                }
                else
                    error_msg.push_back("ERROR: Argument for option '-DEFINECPMGPB' must be a real number in the range 0.0-1.0");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINECPMGPB' requires at least two arguments");
        }

        else if (word[0] == "-DEFINECPMGDELTAOMEGA") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.ODW);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: Argument for option '-DEFINECPMGDELTAOMEGA' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINECPMGDELTAOMEGA' requires at least two arguments");
        }

        else if (word[0] == "-DEFINECPMGR20") {
            if (word.size() > 2) {
                pushBackOdouble(peakToFitOnly, word, OR.OR20);
                if (!is_Doub(word.back()))
                    error_msg.push_back("ERROR: argument for option '-DEFINECPMGR20' must be a real number");
            }
            else
                error_msg.push_back("ERROR: Option '-DEFINECPMGR20' requires at least two arguments");
        }

        else if (word[0] == "-DEFINECPMGFIXKEX") {
            if (word.size() > 1)
                pushBackWords(peakToFitOnly, word, OR.OFixKex);
            else
                error_msg.push_back("ERROR: Option '-DEFINECPMGFIXKEX' requires at least one argument");
        }

        else if (word[0] == "-DEFINECPMGFIXPB") {
            if (word.size() > 1)
                pushBackWords(peakToFitOnly, word, OR.OFixPb);
            else
                error_msg.push_back("ERROR: Option '-DEFINECPMGFIXPB' requires at least one argument");
        }

        // unknown option. should be modified
        else {
            error_msg.push_back("ERROR: Unknown option: " + word[0]);
        }

    }

    if (peaklistFlag == false)
        error_msg.push_back("ERROR: No peaklist specified, include line '-PEAKLIST <name>'");

    if (peaklistFlag == true && peakListName != "") {
        ifstream myFile(peakListName);
        if (!myFile.is_open())
            error_msg.push_back("ERROR: Cannot open peak list '" + peakListName + "'");
    }

    // Make sure carrierposition and b1 field are specified for R1rho2R2
    if (carrierPPM == -9999.9 && peak.fitR1rho == 1)
            error_msg.push_back("ERROR: Option 'FITR2FROMR1RHO' requires option '-R2FROMR1RHOCARRIER <value>'");
    if (b1 == -9999.9 && peak.fitR1rho == 1)
            error_msg.push_back("ERROR: Option 'FITR2FROMR1RHO' requires option '-R2FROMR1RHOB1 <value> [<uncertainty>]'");



    // Look up values of array in procpar or vdlistfile if applicable
    Bool bad_array = false;
    if (arrayFlag == true && procparName != "" && arrayPar != "") {
        bad_array = true;
        error_msg.push_back("ERROR: You cannot use the option '-ARRVAL' simultaneously as options '-ARRAY' and '-PROCPAR'");
    }
    if (arrayFlag == true && vdlistName !="") {
        bad_array = true;
        error_msg.push_back("ERROR: You cannot use the option '-ARRVAL' simultaneously as options '-VDLIST'");
    }
    if (vdlistName != "" && procparName != "" && arrayPar != "") {
        bad_array = true;
        error_msg.push_back("ERROR: You cannot use the option '-VDLIST' simultaneously as options '-ARRAY' and '-PROCPAR'");
    }
    if (!bad_array && procparName != "" && arrayPar != "")
        getArray(procparName, arrayPar, arr, error_msg);
    if (!bad_array && vdlistName != "")
        get_vdlist(vdlistName, arr, error_msg);

    // fitR1rho automatically does fitExp so no need to to both
    if (peak.fitExp && peak.fitR1rho)
        peak.fitExp = 0;

    // check that time_T2 has been entered if required
    if (peak.fitCPMG == 1 && time_T2 == 0.0)
        error_msg.push_back("ERROR: Option '-FITCPMG' requires that option 'TIME_T2' is specified correctly");

    //////////////////////////////////////
    // Stuff below requires spectral info
    // ///////////////////////////////////
    if (spectrumFlag == false) {
        error_msg.push_back("ERROR: No spectrum specified, include line '-SPECTRUM <name>' or '-SPECTRUMLIST <file>'");
    }

    if (specName.size() == 0)
        return 1;

    SpectrumType spec(specName, 9000);
    if (spec.getCalib(error_msg, pipeData))
        return 1;

    // Written this way, we must always specify all array values even if some planes will be excluded
    if (!bad_array && (Int)arr.size() != spec.noPlanes() && arr.size() != 0) {
        error_msg.push_back("ERROR: Number of planes in pseudo 3D or number of 2D spectra (" +  \
                             std::to_string(spec.noPlanes()) + ") does not match number in array (" + \
                             std::to_string(arr.size()) + ")!");
    }

    if (planeToPlot!=-1 && planeToPlot>spec.noPlanes()) {
        error_msg.push_back("ERROR: Specify a plane in the range '1-" + to_string(spec.noPlanes()) + "' in option '-PLANE2PLOT'");
    }


    if (planeToFitFirst<1 || planeToFitFirst>spec.noPlanes()) {
        error_msg.push_back("ERROR: Specify a plane in the range '1-" + to_string(spec.noPlanes()) + "' in option '-PLANE2FITFIRST'");
    }

    // Set planes to exclude
    peak.setPlaneToExclude(planeToExclude, spec.nPlane, error_msg);


//*******************************  THESE LINES SHOULD NOT SHOW FOR PINT 2.0 (GUI version) ********************
    if (find(peak.excludePlane.begin(), peak.excludePlane.end(), planeToPlot) != peak.excludePlane.end()) {
        error_msg.push_back("ERROR: '-PLANE2PLOT " + to_string(planeToPlot) + "' is not allowed since that plane has been excluded ('-EXCLUDEPLANE')");
    }
    for (auto &_oex : OR.OExclude)
        if (std::find(_oex.planeToExclude.begin(), _oex.planeToExclude.end(), planeToPlot) != _oex.planeToExclude.end())
            error_msg.push_back("ERROR: '-PLANE2PLOT " + to_string(planeToPlot) + "' is not allowed since that plane has been excluded ('-DEFINEEXCLUDEPLANE')");
//*******************************  THESE LINES SHOULD NOT SHOW FOR PINT 2.0 (GUI version) ********************


    if (find(peak.excludePlane.begin(), peak.excludePlane.end(), planeToFitFirst) != peak.excludePlane.end()) {
        error_msg.push_back("ERROR: Plane '" + to_string(planeToFitFirst) + "' that is fitted first has been excluded ('-EXCLUDEPLANES'). Add/modify option '-PLANE2FITFIRST'");
    }
    for (auto &_oex : OR.OExclude)
        if (std::find(_oex.planeToExclude.begin(), _oex.planeToExclude.end(), planeToFitFirst) != _oex.planeToExclude.end())
            error_msg.push_back("ERROR: Plane '" + to_string(planeToFitFirst) + "' that is fitted first has been excluded ('-DEFINEEXCLUDEPLANES'). Add/modify option '-PLANE2FITFIRST'");

    // Convert line widths entered in Hz to ppm if needed
    lw_hz2ppm(*this, spec);

    // make coupled peaklist from decoupled one
    if (jcouplingF1.size()>0 || OR.OjcouplingF1.size()>0 || jcouplingF2.size()>0 || OR.OjcouplingF2.size()>0) {
        ifstream myFile(peakListName.c_str());
        if (!myFile.is_open()) {
            string s = "ERROR: Cannot open peaklist '" + peakListName + "'";
            error_msg.push_back(s);
            return 1;
        }


        // Make sure new peaklist with splittings is written to outDir
        int beginIdx = peakListName.rfind('/');
        string newPeakList = peakListName.substr(beginIdx+1) + ".coup";
        newPeakList = outDir + "/" + newPeakList;
        ofstream myFile2(newPeakList.c_str());
        if (!myFile2.is_open()) {
            string s = "ERROR: Cannot write peaklist with couplings '" + newPeakList + "'";
            error_msg.push_back(s);
            return 1;
        }

        string line;
        VecString word;

        // Read and print header
        for (Int i=0; i<skipLines; ++i) {
            getline (myFile,line);
            myFile2 << line << ENDL;
        }

        while (!myFile.eof()) {

            getline (myFile,line);
            line2words(line, word);

            // Ignore empty lines or lines starting with '#'
            if (EmptyLine(word)) {
                myFile2 << line << ENDL;
                continue;
            }

            // Verify that there are enough columns
            Uint max = std::max(assiCol, F1Col);
            max = std::max((Int)max, F2Col);
            if (max >= word.size())
                error_msg.push_back("ERROR: Line '" + line + "' in peak list does not contain the correct number of columns");

            vector<DoubIntType> jcF1 = jcouplingF1;
            vector<DoubIntType> jcF2 = jcouplingF2;


            for (Uint i=0; i<OR.OjcouplingF1.size(); ++i)
                if (OR.OjcouplingF1[i].assi == word[assiCol]) {
                    jcF1 = OR.OjcouplingF1[i].jcoup;
                    break;
                }

            for (Uint i=0; i<OR.OjcouplingF2.size(); ++i)
                if (OR.OjcouplingF2[i].assi == word[assiCol]) {
                    jcF2 = OR.OjcouplingF2[i].jcoup;
                    break;
            }

            if (!jcF1.size() && !jcF2.size()) {
                for (Uint i=0; i<word.size()-1; ++i)
                    myFile2 << word[i] << TAB;
                myFile2 << word.back() << ENDL;
                //myFile2 << line << ENDL;
            }

            else {

                deque<string> lines;
                lines.push_back(line);
                Int linesSize = 1;  //lines.size();


                for (Uint iii=0; iii<jcF1.size(); ++iii) {
                    for (Int ii=0; ii<linesSize; ++ii) {

                        line2words(lines[ii], word);


                        Char tag = 'a';
                        string temp(word[assiCol]);
                        Char tags[2];
                        tags[1] = '\0';

                        Doub _f1;
                        from_string<Doub>(_f1, word[F1Col], std::dec);

                        _f1 -= (jcF1[ii].integ-1)/2.*jcF1[ii].dbl/spec.obsF1;

                        for (Int i=0; i<jcF1[iii].integ; ++i, ++tag) {
                            tags[0] = tag;
                            word[assiCol] = temp + tags;
                            ostringstream strs;
                            strs << _f1;
                            word[F1Col] = strs.str();

                            ostringstream ss;
                            for (Uint j=0; j<word.size()-1; ++j)
                                ss << word[j] << TAB;
                            ss << word.back();

                            lines.push_back(ss.str());

                            _f1 += jcF1[iii].dbl/spec.obsF1;
                        }
                    }

                    for (Int j=0; j<linesSize; ++j)
                        lines.pop_front();
                    linesSize = lines.size();
                }

                for (Uint iii=0; iii<jcF2.size(); ++iii) {
                    for (Int ii=0; ii<linesSize; ++ii) {

                        line2words(lines[ii], word);

                        if (iii == 0) // underscore is to distinguish couplings in two dimensions
                            word[assiCol] += "_";

                        Char tag = 'a';
                        string temp(word[assiCol]);
                        Char tags[2];
                        tags[1] = '\0';

                        Doub _f2;
                        from_string<Doub>(_f2, word[F2Col], std::dec);

                        _f2 -= (jcF2[0].integ-1)/2.*jcF2[ii].dbl/spec.obsF2;

                        for (Int i=0; i<jcF2[iii].integ; ++i, ++tag) {
                            tags[0] = tag;
                            word[assiCol] = temp + tags;
                            ostringstream strs;
                            strs << _f2;
                            word[F2Col] = strs.str();

                            ostringstream ss;
                            for (Uint j=0; j<word.size()-1; ++j)
                                ss << word[j] << TAB;
                            ss << word.back();

                            lines.push_back(ss.str());

                            _f2 += jcF2[iii].dbl/spec.obsF2;
                        }
                    }

                    for (Int j=0; j<linesSize; ++j)
                        lines.pop_front();
                    linesSize = lines.size();
                }

                for (Uint j=0; j<lines.size(); ++j)
                    myFile2 << lines[j] << ENDL;
            }
        }

        // set peak list to the new peak list
        peakListName = newPeakList;
    }

#ifndef PINTGUI
    if (!silent) {
        Verbose verb;
        verb.disclaimer(progname);
    }
#endif

    return 0;
}

Int ParserType::get_vdlist(const string &vdlistName, VecDoub &arr, VecString &error_msg)
{
    ifstream myFile(vdlistName.c_str());
    if (!myFile) {
        error_msg.push_back("ERROR: Cannot open vdlist '" + vdlistName + "'");
        return 1;
    }
    Int i=0;
    string s;
    while (getline(myFile, s)) {
        cerr << s.length() << " " << ++i << endl;
        Doub val;
        from_string<Doub>(val, s, std::dec);
        if (!is_Doub(s))
            error_msg.push_back("ERROR: All entries of file '" + vdlistName + "' must be numerical");
        arr.push_back(val);
    }
    return 0;
}





Int ParserType::getArray(const string &procparName, const string &arrayPar, VecDoub &arr, VecString &error_msg)
{
    VecDoub myvector;

    if (arrayPar == "") {
        arr = VecDoub(1, 1.0);
        return 0;
    }

    ifstream myFile(procparName.c_str());
    if (!myFile) {
        error_msg.push_back("ERROR: Cannot open procpar file '" + procparName + "'");
        return 1;
    }

    while (!myFile.eof()) {

        string s;
        VecString word;

        getline(myFile, s);

        if (!s.size()) break;
        line2words(s, word);

        if (word[0] == arrayPar) {

            getline(myFile, s);
            line2words(s, word);

            arr = VecDoub(word.size()-1);
            for (Uint i=1; i<word.size(); ++i) {
                from_string<Doub>(arr[i-1], word[i], std::dec);
                if (!is_Doub(word[i]))
                    error_msg.push_back("ERROR: All arguments of option '-ARRAY " + arrayPar + "' must be numerical");
            }
            return 0;
        }
    }
    error_msg.push_back("ERROR: The parameter '" + arrayPar + "' is not present in procpar");
    return 1;
}


Bool ParserType::EmptyLine(VecString_I &word) { return (word.size() == 0 || word[0][0] == '#'); }
