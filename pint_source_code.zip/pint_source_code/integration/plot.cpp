#include "plot.h"



static const Char *lShape[NUMBER_OF_LINESHAPES] = {"LORENTZIAN", "GAUSSIAN", "GALORE", "VOIGT"};



PlotType::PlotType(const string &_outDir, Int _mode) : outDir(_outDir), mode(_mode)
{
    // wipe out contents of plotfits.gnu
    if (mode == GNUPLOT) {
        summaryName = outDir + "/" + "plotfits.gnu";
        summaryIndName = outDir + "/" + "plotfits_individual.gnu";
    }
    else {
        summaryName = outDir + "/" + "plotfits.m";
        summaryIndName = outDir + "/" + "plotfits_individual.m";
    }
    // wipe out contents of plotfits.gnu
    ofstream myFile(summaryName.c_str());
    ofstream myFile2(summaryIndName.c_str());
}


// For mtpint
void PlotType::plot(const PeakFitType &peak, VecString &error_msg)
{
    if (mode == GNUPLOT)
        gnuPlot(peak.swF1, peak.swF2, peak.obsF1, peak.obsF2, peak.peak, peak.f1, peak.f2, peak.f3, peak.y, peak.a, peak.BigJ, error_msg);
    else
        error_msg.push_back("ERROR: Plot modes other than GNUPLOT are not implemented.");
}
// For mtpint

// For pint
void PlotType::plot(const SpectrumType &spec, const vector<PeakType> &peak, VecDoub_I &f1, VecDoub_I &f2, VecInt_I &f3, \
                    VecDoub_I &y, VecDoub_I &a, Int BigJ, VecString &error_msg)
{
    if (mode == GNUPLOT)
        gnuPlot(spec.swF1, spec.swF2, spec.obsF1, spec.obsF2, peak, f1, f2, f3, y, a, BigJ, error_msg);
    else
        error_msg.push_back("ERROR: Plot modes other than GNUPLOT are not implemented.");
}
// For pint


void PlotType::gnuPlot(Doub swF1, Doub swF2, Doub obsF1, Doub obsF2, PeakListType_I &peak, VecDoub_I &f1, VecDoub_I &f2, \
                       VecInt_I &f3, VecDoub_I &y, VecDoub_I &a, Int BigJ, VecString &error_msg)
{
    plotPeakGnu(swF1, swF2, obsF1, obsF2, peak, f1, f2, f3, y, a, BigJ, error_msg);
    plotIndividualPeakGnu(swF1, swF2, obsF1, obsF2, peak, a, error_msg);
}



void PlotType::plotPeakGnu(Doub swF1, Doub swF2, Doub obsF1, Doub obsF2, PeakListType_I &peak, VecDoub_I &f1, VecDoub_I &f2, \
                           VecInt_I &f3, VecDoub_I &y, VecDoub_I &a, Int BigJ, VecString &error_msg)
{
// In output files:
// col1: F1 chemical shift
// col2: F2 chemical shift
// col3: spectral intensity
// col4: fitted intensity
// col5-n: fitted intesity for respective components in overlapped groups
//
// Note that there must be an equal number of lines for each value of F1.
// If there there are fewer than the number BigJ, the last one is repeated
// the necessary number of times.

    Uint i;
    Int ctr;
    Char fname[MAX_LINE];

    Int nArr = peak[0].arr.size() - peak[0].excludePlane.size();

    // generate a vector with all existing planes as elements
    VecInt actualPlanes(nArr);
    Int ii=0;
    for (Uint i=1; i<=peak[0].arr.size(); ++i)
        if (std::find(peak[0].excludePlane.begin(), peak[0].excludePlane.end(), i) == peak[0].excludePlane.end())
            actualPlanes[ii++] = i;

    for (Uint ii=0; ii<peak.size(); ++ii) {
        for (Int j=0; j<nArr; ++j) {

            sprintf(fname, "%s/%s_%03d.dat", outDir.c_str(), peak[ii].assi.c_str(), actualPlanes[j]);

            FILE *fp = fopen(fname, "w");
            if (!fp) {
                string s = fname;
                error_msg.push_back("ERROR: Can't open plot file '" + s + "'!");
                return;
            }
            Doub dummy=f1[j*f1.size()/nArr];
            for (i=0; (Uint)i<f1.size()/nArr;) {
                Uint idx = j*f1.size()/nArr+i;
                Doub yfit=0.;
                for (ctr=0; (Uint)i<f1.size()/nArr && dummy == f1[j*f1.size()/nArr+i]; ++i, ++ctr) {
                    idx = j*f1.size()/nArr+i;
                    yfit = peak[ii].funcscore(f1[idx], f2[idx], f3[idx], a, peak.size(), nArr);
                    fprintf(fp, "%f %f %f %f\n", f1[idx] + peak[ii].foldF1*swF1/obsF1, f2[idx] + peak[ii].foldF2*swF2/obsF2, y[idx],yfit);
                }
                for (; ctr < BigJ; ++ctr) {
                     fprintf(fp, "%f %f %f %f\n", f1[idx] + peak[ii].foldF1*swF1/obsF1, f2[idx] + peak[ii].foldF2*swF2/obsF2, y[idx],yfit);
                }
                if (i<f1.size())
                    fprintf(fp, "\n");
                dummy = f1[i];
            }
            fclose(fp);
        }
    }
}


void PlotType::plotIndividualPeakGnu(Doub swF1, Doub swF2, Doub obsF1, Doub obsF2, PeakListType_I &peak, VecDoub_I &a, VecString &error_msg)
{
// In output file:
// col1: F1 chemical shift
// col2: F2 chemical shift
// col3: fitted spectral intensity

    const Int NPLOTSTEPS = 21;

    Doub yfit;
    Char fname[MAX_LINE];
    VecDoub aIndividual = a;

    Int nfix = (peak[0].intMode == GALORE || peak[0].intMode == VOIGT)? 6 : 4;
    Int nArr = peak[0].arr.size() - peak[0].excludePlane.size();
    Int nPar = nfix + nArr;

    // generate a vector with all existing planes as elements
    VecInt actualPlanes(nArr);
    Int ii=0;
    for (Uint i=1; i<=peak[0].arr.size(); ++i)
        if (std::find(peak[0].excludePlane.begin(), peak[0].excludePlane.end(), i) == peak[0].excludePlane.end())
            actualPlanes[ii++] = i;

    // set all intensities of aIndividual to zero
    for (Uint i=0; i<peak.size(); ++i)
        for (Int j=0; j<nArr; ++j)
            aIndividual[nfix+j+i*nPar] = 0.;

    for (Uint k=0; k<peak.size(); ++k) {

        Doub F1ppm = a[k*nPar];
        Doub F2ppm = a[k*nPar+2];
        Doub radF1 = peak[k].radF1;
        Doub radF2 = peak[k].radF2;
        Doub f1min = F1ppm - radF1;
        Doub stepF1 = radF1 / ((NPLOTSTEPS-1)/2.); // use NPLOTSTEPS steps in total
        Doub f2max;

        for (Int i=0; i<nArr; ++i)
            aIndividual[nfix+i+k*nPar] = a[nfix+i+k*nPar];

        for (Int j=0; j<nArr; ++j) {

            sprintf(fname, "%s/%s_ind_%03d.dat", outDir.c_str(), peak[k].assi.c_str(), actualPlanes[j]);

            FILE *fp = fopen(fname, "w");
            if (!fp) {
                string s = fname;
                error_msg.push_back("ERROR: Can't open plot file '" + s + "'!");
                return;
            }

            for (Uint i=0; i<(Uint)NPLOTSTEPS; ++i) {
                Doub f1 = f1min + i*stepF1;

                Doub value = SQR((F1ppm-f1)/radF1);
                if (value >= 1.0) f2max = 0.;
                else f2max = radF2*sqrt(1. - SQR((F1ppm-f1)/radF1));

                Doub stepF2 = f2max / ((NPLOTSTEPS-1)/2.);
                for (Int h=0; h<NPLOTSTEPS; ++h) {
                    Doub f2 = F2ppm - f2max + h*stepF2;
                    yfit = peak[k].funcscore(f1, f2, j+1, aIndividual, peak.size(), nArr);
                    fprintf(fp, "%f\t%f\t%f\n", f1 + peak[k].foldF1*swF1/obsF1, f2 + peak[k].foldF2*swF2/obsF2, yfit);
                }
                fprintf(fp, "\n");
            }
            fclose(fp);
        }
        for (Int i=0; i<nArr; ++i)
            aIndividual[nfix+i+k*nPar] = 0.;
    }
}


// for pint
void PlotType::writePlotSummary(PeakType_I &peak, Int planeToPlot, VecString &error_msg)
{
    if (mode == GNUPLOT)
        writeGnuPlotSummary(peak, planeToPlot, error_msg);
    else if (mode == MATLAB)
        error_msg.push_back("ERROR: plot mode MATLAB is not implemented.");
}
// for pint

// for mtpint
void PlotType::writePlotSummary(PeakListType_I &peak, PeakFitListType_I &peakFit, Int planeToPlot, VecString &error_msg)
{
    for (Uint i=0; i<peak.size(); ++i)
        for (Uint j=0; j<peakFit.size(); ++j)
            for (Uint k=0; k<peakFit[j].peak.size(); ++k)
                if (peak[i].assi == peakFit[j].peak[k].assi) {
                    //writePlotSummary(peak[i], peakFit[j].peak, planeToPlot, error_msg);
                    writePlotSummary(peak[i], planeToPlot, error_msg);
                    break;
                }
}
// for mtpint


// for mtpint
void PlotType::writeIndividualPlotSummary(PeakListType_I &peak, PeakFitListType_I &peakFit, Int planeToPlot, VecString &error_msg)
{
    for (Uint i=0; i<peak.size(); ++i)
        for (Uint j=0; j<peakFit.size(); ++j)
            for (Uint k=0; k<peakFit[j].peak.size(); ++k)
                if (peak[i].assi == peakFit[j].peak[k].assi) {
                    writeIndividualPlotSummary(peak[i], peakFit[j].peak, planeToPlot, error_msg);
                    break;
                }
}
// for mtpint


// for pint
void PlotType::writeIndividualPlotSummary(PeakType_I &peak, PeakListType_I &group, Int planeToPlot, VecString &error_msg)
{
    if (mode == GNUPLOT) {
        writeIndividualGnuPlotSummary(peak, group, planeToPlot, error_msg);
    }
    else if (mode == MATLAB)
        error_msg.push_back("ERROR: plot mode MATLAB not implemented yet. Sorry!");
}
// for pint


void PlotType::writeGnuPlotSummary(PeakType_I &peak, Int planeToPlot, VecString &error_msg)
{
    Char legend[MAX_LINE], fname[MAX_LINE], dataName[MAX_LINE];
    ofstream sumFile, myFile;

    sumFile.open(summaryName.c_str(), ios_base::app);
    if (!sumFile) {
        error_msg.push_back("ERROR: Can't write to 'plotfits.gnu' file!");
        return;
    }

    sprintf(fname, "%s/%s.gnu", outDir.c_str(), peak.assi.c_str());
    myFile.open(fname);
    writeAxesGnuPlot(myFile);
    writeAxesGnuPlot(sumFile);

    Int nArr = peak.arr.size() - peak.excludePlane.size();

    // generate a vector with all existing planes as elements
    VecInt actualPlanes(nArr);
    Int ii=0;
    for (Uint i=1; i<=peak.arr.size(); ++i)
        if (std::find(peak.excludePlane.begin(), peak.excludePlane.end(), i) == peak.excludePlane.end())
            actualPlanes[ii++] = i;

    if (!peak.convFlag)
        sprintf(legend, "%s (%.1f; %.2f ppm)", peak.assi.c_str(), peak.f1, peak.f2);
    else
        sprintf(legend, "%s (%.1f; %.2f ppm) FAILED! (%d)", peak.assi.c_str(), peak.f1, peak.f2, peak.convFlag);

    if ((Uint)planeToPlot <= peak.arr.size() && planeToPlot > 0) {
        sprintf(dataName, "%s_%03d.dat", peak.assi.c_str(), planeToPlot);
        writeLineGnuPlot(sumFile, dataName, legend, lShape[peak.intMode]);
    }
    else {
        for (Int i=0; i<nArr; ++i) {
            sprintf(dataName, "%s_%03d.dat", peak.assi.c_str(), actualPlanes[i]);
            writeLineGnuPlot(sumFile, dataName, legend, lShape[peak.intMode]);
        }
    }

    for (Int i=0; i<nArr; ++i) {
        sprintf(dataName, "%s_%03d.dat", peak.assi.c_str(), actualPlanes[i]);
        writeLineGnuPlot(myFile, dataName, legend, lShape[peak.intMode]);
    }
}


void PlotType::writeIndividualGnuPlotSummary(PeakType_I &peak, PeakListType_I &group, Int planeToPlot, VecString &error_msg)
{
    Char legend[MAX_LINE], fname2[MAX_LINE], dataName[MAX_LINE];
    ofstream sumFileInd, myFileInd;

    sumFileInd.open(summaryIndName.c_str(), ios_base::app);
    if (!sumFileInd) {
        error_msg.push_back("ERROR: Can't write to 'plotfits_individual.gnu' file!");
        return;
    }

    sprintf(fname2, "%s/%s_individual.gnu", outDir.c_str(), peak.assi.c_str());
    myFileInd.open(fname2);
    writeAxesGnuPlot(myFileInd);
    writeAxesGnuPlot(sumFileInd);

    Int nArr = peak.arr.size() - peak.excludePlane.size();

    // generate a vector with all existing planes as elements
    VecInt actualPlanes(nArr);
    Int ii=0;
    for (Uint i=1; i<=peak.arr.size(); ++i)
        if (std::find(peak.excludePlane.begin(), peak.excludePlane.end(), i) == peak.excludePlane.end())
            actualPlanes[ii++] = i;

    if (!peak.convFlag)
        sprintf(legend, "%s (%.1f; %.2f ppm)", peak.assi.c_str(), peak.f1, peak.f2);
    else
        sprintf(legend, "%s (%.1f; %.2f ppm) FAILED! (%d)", peak.assi.c_str(), peak.f1, peak.f2, peak.convFlag);

    if ((Uint)planeToPlot <= peak.arr.size() && planeToPlot > 0) {
        sprintf(dataName, "%s_%03d.dat", group[0].assi.c_str(), planeToPlot);
        writeLineGnuPlotIndividual(sumFileInd, dataName, legend, planeToPlot, peak, group);
    }
    else {
        for (Int j=0; j<nArr; ++j) {
            sprintf(dataName, "%s_%03d.dat", group[0].assi.c_str(), actualPlanes[j]);
            writeLineGnuPlotIndividual(sumFileInd, dataName, legend, actualPlanes[j], peak, group);
        }
    }
    for (Int j=0; j<nArr; ++j) {
        sprintf(dataName, "%s_%03d.dat", group[0].assi.c_str(), actualPlanes[j]);
        writeLineGnuPlotIndividual(myFileInd, dataName, legend, actualPlanes[j], peak, group);
    }
}


void PlotType::writeAxesGnuPlot(ofstream &myFile)
{
    myFile << "set ticslevel 0\n";
    myFile << "set yrange [] reverse\n";  // to get ppm increasing from right to left
    myFile << "set xlabel \"F1 (ppm)\"\n";
    myFile << "set ylabel \"F2 (ppm)\"\n";
}


void PlotType::writeLineGnuPlot(ofstream &myFile, Char *dataName, Char *legend, const Char *lShape)
{
    myFile << "splot '" << dataName << "' u 1:2:3 w lines t '" <<  legend << "', '" \
           << dataName << "' u 1:2:4 w lines linetype 3 t '" << lShape << "'\n";
    myFile << "pause -1 'Press [ENTER] to continue'\n";
}


void PlotType::writeLineGnuPlotIndividual(ofstream &myFile, Char *dataName, Char *legend, Int planeToPlot, PeakType_I &peak, PeakListType_I &group)
{
// As of now only five different colors are plotted
// regardless of how many peaks ther are in a group.
// This can of course easily be changed.
//
// First the experimental data centered on the
// region for a particular peak. Then the fitted
// lineshape for this peak is plotted. Then other
// overlapped peaks of this group are plotted
// (in no particular order)

    static Int color[50] = {3,2,5,6,7, 8,2,5,6,7, 8,2,5,6,7, 8,2,5,6,7, 8,2,5,6,7, 8,2,5,6,7, 8,2,5,6,7, 8,2,5,6,7, 8,2,5,6,7, 8,2,5,6,7};

    Char dataNameInd[MAX_LINE];

    myFile << "splot";
    myFile << " '" << dataName << "' u 1:2:3 w lines t '" <<  legend << "'";
    sprintf(dataNameInd, "%s_ind_%03d.dat", peak.assi.c_str(), planeToPlot);

    myFile << ", '" << dataNameInd << "' u 1:2:3 w lines linetype " << color[0] << " t '" << peak.assi << SPACE << lShape[peak.intMode] << "'";
    Int j=0;
    for (Uint i=0; i<group.size(); ++i)
        if (peak.assi != group[i].assi) {
            sprintf(dataNameInd, "%s_ind_%03d.dat", group[i].assi.c_str(), planeToPlot);
            myFile << ", '" << dataNameInd << "' u 1:2:3 w lines linetype " << color[++j] << " t '" <<
                      group[i].assi << SPACE << lShape[group[i].intMode] << "'";
        }
    myFile << "\npause -1 'Press [ENTER] to continue'\n";
}
