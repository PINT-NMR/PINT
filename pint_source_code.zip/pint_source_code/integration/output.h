#ifndef _OUTPUT
#define _OUTPUT

#include "pint.h"
#include "peak.h"
#include "parser.h"
#include "fitmrq.h"
#include "spectrum.h"
#include "esd.h"


struct OutputType {

    string outDir;

    Int invert;
    Bool listByResNo;
    Int sort;

    Doub time_T2;

    Doub timeFactor;

    Doub b1, db1;
    Int  r1rhoDim;

    Bool calcJcoup;

    Doub obsF1, obsF2;

    Doub carrierPPM, carrierMHz;

    Doub noise;

    VecDoub x, y, sig;

    Bool biexpListFlag,
         constListFlag,
         cpmgListFlag,
         expListFlag,
         expOffsetListFlag,
         invRecoveryListFlag,
         linListFlag,
         NOElistFlag,
         r2ListFlag,
         satRecoveryListFlag,
         chi2ListFlag,
         linewidthListFlag,
         peakListFlag,
         trosy,
         initFail,
         noIntegration;

    VecString peakToNotReport;

    string outName,
           cpmgName,
           linName,
           constName,
           R12Name,
           biexpName,
           expOffsetName,
           noeName,
           invRecoveryName,
           satRecoveryName,
           peakListName,
           linewidthListName,
           linListName,
           constListName,
           expListName,
           biexpListName,
           expOffsetListName,
           r2ListName,
           NOElistName,
           cpmgListName,
           pbListName,
           kexListName,
           deltaOmegaListName,
           r20ListName,
           ftestListName,
           rmsdListName,
           invRecoveryListName,
           satRecoveryListName,
           failName,
           chi2ListName,
           jcoupListName,
           relVolListName,
           paramListName,
           sortKeyName;

    OutputType();

    OutputType(const string &_outDir, const ParserType &parser, const SpectrumType &spec);

    Int printResult(PeakListType &peak, VecString &error_msg);

    void setListNames();

    void setPeakFileNames(string assi);

    void printDownStreamFitting(PeakType &peak, VecString &error_msg);

    void printLists(PeakListType_I &peak, VecString &error_msg);

    void printFailedFits(Int convFlag, const string &assi, VecString &error_msg);

    void copyData(const PeakType &peak, VecDoub &x, VecDoub &y, VecDoub &sig);

    void FitConstant(PeakType &peak);

    void FitLin(PeakType &peak);

    void FitExp(PeakType &peak);

    void FitBiExp(PeakType &peak);

    void FitInvRecovery(PeakType &peak);

    void FitSatRecovery(PeakType &peak);

    void FitExpOffset(PeakType &peak);

    void CalcR2(PeakType &peak);

    void FitTanh(PeakType &peak);

    Int FitCR(PeakType &peak, VecDoub &x, VecDoub &y, VecDoub &sig, VecDoub &cpmgFit);

    void initializeCR(const PeakType &peak, VecDoub_I &y, VecDoub &a, VecBool &ia);

    void copyCRresults(PeakType &peak, const Fitmrq &fitmrq, const ErrorSim &errSim);

    void FtestCPMG(PeakType &peak, Doub chisq1, Int dof1, Doub chisq2, Int dof2);

    void plotFit(void (*func)(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda), VecDoub_I &x, VecDoub_I &a, VecDoub &y);

    void printOutputHdr(const PeakType &peak, ofstream &myFile);

    Int printVol(PeakType &peak, VecString &error_msg);

    void printVolumes(const PeakType &peak, VecDoub_I &outArr, VecDoub_I &outIntensity, VecDoub_I &outVol, ofstream &myFile, Int precision);

    void printVolHeading(ofstream &myFile);

    void printConstant(PeakType &peak, VecString &error_msg);

    Int printJCoup(const PeakListType &peak, VecString &error_msg);

    void printLin(PeakType &peak, VecString &error_msg);

    void printExp(PeakType &peak, VecString &error_msg);

    void printBiExp(PeakType &peak, VecString &error_msg);

    void calcFittedVal(const Doub x, Doub &fittedY, Doub a0, Doub a1, Doub a2, Doub a3, void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &d));

    void calcFittedVal(const Doub x, Doub &fittedY, Doub a0, Doub a1, Doub a2, void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &d));

    void calcFittedVal(const Doub x, Doub &fittedY, Doub a0, Doub a1, void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &d));

    void calcFittedVal(const Doub x, Doub &fittedY, Doub a0, void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &d));

    void printConstantFitParam(const PeakType &peak, ofstream &myFile);

    void printLinFitParam(const PeakType &peak, ofstream &myFile);

    void printExpFitParam(const PeakType &peak, ofstream &myFile);

    void printBiExpFitParam(const PeakType &peak, ofstream &myFile);

    void printFitHeader(ofstream &myFile);

    void printFitExpOffsetParam(const PeakType &peak, const string &name, ofstream &myFile);

    void printFitInvRecParam(const PeakType &peak, const string &name, ofstream &myFile);

    void printFitSatRecParam(const PeakType &peak, const string &name, ofstream &myFile);

    void printFittedVal(const PeakType &peak, Doub outArr, Doub outVol, Doub fittedY, ofstream &myFile, Int precision);

    void printFittedCpmgVal(const PeakType &peak, Doub nu_cpmg, Doub r2eff, Doub sig, Doub cpmgFit, ofstream &myFile, Int precision);

    void printSatRecovery(PeakType &peak, VecString &error_msg);

    void printInvRecovery(PeakType &peak, VecString &error_msg);

    void printExpOffset(PeakType &peak, VecString &error_msg);

    void printR1rho(PeakType &peak, VecString &error_msg);

    void printR1rhoParam(const PeakType &peak, ofstream &myFile);

    void printTanh(PeakType &peak, VecString &error_msg);

    void printTanhResults(const PeakType &peak, ofstream &myFile);

    void printNOE(PeakType &peak, VecString &error_msg);

    void printCpmg(PeakType &peak);

    void printCpmgParam(const PeakType &peak, VecDoub_I &nu_cpmg, ofstream &myFile);

    Int printPeakList(const PeakType &peak, VecString &error_msg);

    Int printLineWidthList(const PeakType &peak, VecString &error_msg);

    Int printChi2List(const PeakType &peak, VecString &error_msg);

    void printConstantFitList(const PeakType &peak, VecString &error_msg);

    void printLinFitList(const PeakType &peak, VecString &error_msg);

    void printExpFitList(const PeakType &peak, VecString &error_msg);

    void printBiExpFitList(const PeakType &peak, VecString &error_msg);

    void printSatRecoveryFitList(const PeakType &peak, VecString &error_msg);

    void printInvRecoveryFitList(const PeakType &peak, VecString &error_msg);

    void printExpOffsetFitList(const PeakType &peak, VecString &error_msg);

    void printR2FitList(const PeakType &peak, VecString &error_msg);

    void printTanhFitList(const PeakType &peak, VecString &error_msg);

    void printNOElist(const PeakType &peak, VecString &error_msg);

    void printCpmgList(const PeakType &peak);

    void printSortKeyList(const PeakType &peak, VecInt_I &key, VecString &error_msg);

    void OpenCpmgListFile(ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF, ofstream &dwF, ofstream &r20F,
                          ofstream &ftestF, ofstream &rmsdF);

    void CpmgListWriteHeader(ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF, ofstream &dwF, ofstream &r20F, ofstream &ftestF, ofstream &rmsdF);

    void CpmgListPrecision(ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF, ofstream &dwF, ofstream &r20F, ofstream &ftestF, ofstream &rmsdF);

    void CpmgListWriteData(const PeakType &peak, ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF,
                           ofstream &dwF, ofstream &r20F, ofstream &ftestF, ofstream &rmsdF);

    void CloseCpmgListFile(ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF, ofstream &dwF, ofstream &r20F, ofstream &ftestF, ofstream &rmsdF);

    void copyArrVol(VecDoub_I &a, VecDoub_I &a2, VecDoub_I &v, VecDoub &aa, VecDoub aa2, VecDoub &vv);

    void copyArrVol(PeakType &peak, VecDoub &outArr, VecDoub &outIntensity);

    void copyArrIntensityVol(PeakType &peak, VecDoub &outArr, VecDoub &outIntensity, VecDoub &outVol, VecInt &key);
};

#endif
