// plot.h

#ifndef _PLOT
#define _PLOT

#include "pint.h"
#include "peak.h"
#include "peakfit.h"
#include "spectrum.h"

#define GNUPLOT 0
#define MATLAB 1


// N.B.! Some of the features are not
// implemented for the matlab functions.

struct PlotType {

    string outDir;
    Int mode;
    string summaryName, summaryIndName;

    PlotType(const string &_outDir, Int _mode);

    void plot(const PeakFitType &peak, VecString &error_msg); // for mtpint
    void plot(const SpectrumType &spec, const vector<PeakType> &peak, VecDoub_I &f1, VecDoub_I &f2, VecInt_I &f3, VecDoub_I &y, VecDoub_I &a, \
              Int BigJ, VecString &error_msg); // for pint

    void gnuPlot(Doub swF1, Doub swF2, Doub obsF1, Doub obsF2, PeakListType_I &peak, VecDoub_I &f1, VecDoub_I &f2, VecInt_I &f3, \
                 VecDoub_I &y, VecDoub_I &a, Int BigJ, VecString &error_msg);

    void plotPeakGnu(Doub swF1, Doub swF2, Doub obsF1, Doub obsF2, PeakListType_I &peak, VecDoub_I &f1, VecDoub_I &f2, \
                     VecInt_I &f3, VecDoub_I &y, VecDoub_I &a, Int BigJ, VecString &error_msg);

    void plotIndividualPeakGnu(Doub swF1, Doub swF2, Doub obsF1, Doub obsF2, PeakListType_I &peak, VecDoub_I &a, VecString &error_msg);

    void writePlotSummary(PeakListType_I &peak, PeakFitListType_I &peakFit, Int planeToPlot, VecString &error_msg); // for mtpint
    void writePlotSummary(PeakType_I &peak, Int planeToPlot, VecString &error_msg); // for pint

    void writeIndividualPlotSummary(PeakListType_I &peak, PeakFitListType_I &peakFit, Int planeToPlot, VecString &error_msg); // for mtpint
    void writeIndividualPlotSummary(PeakType_I &peak, PeakListType_I &group, Int planeToPlot, VecString &error_msg); // for pint

    void writeGnuPlotSummary(PeakFitListType_I &peakFit, Int planeToPlot, VecString &error_msg); // for mtpint
    void writeGnuPlotSummary(PeakType_I &peak, Int planeToPlot, VecString &error_msg); //for pint

    void writeIndividualGnuPlotSummary(PeakType_I &peak, PeakListType_I &group, Int planeToPlot, VecString &error_msg);

    void writeAxesGnuPlot(ofstream &myFile);

    void writeLineGnuPlot(ofstream &myFile, Char *dataName, Char *legend, const Char *lShape);

    void writeLineGnuPlotIndividual(ofstream &myFile, Char *dataName, Char *legend, Int planeToPlot, PeakType_I &peak, PeakListType_I &group);
};

#endif
