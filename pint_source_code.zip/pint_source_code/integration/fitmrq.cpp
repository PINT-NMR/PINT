#include "fitmrq.h"
#include "gaussj.h"
#ifdef PINTGUI
#include "cancelvar.h"
#endif


Peakmrq::Peakmrq(VecDoub_I &xx1, VecDoub_I &xx2, VecInt_I &xx3, VecDoub_I &yy, VecDoub_I &ssig, VecDoub &aa,
                 VecBool &iia, Int nnol, Int nnarr, void funks(Doub, Doub, Int, VecDoub &, Doub &, VecDoub_O &, Int, Int),
         Doub &cchisq,	Doub ttol, Int nndone, Int iitmax) :

    ndata(xx1.size()), ma(aa.size()), x1(xx1), x2(xx2), x3(xx3), y(yy), sig(ssig),
    nol(nnol), narr(nnarr), ndone(nndone), itmax(iitmax), tol(ttol), funcs(funks), ia(iia),
    a(aa), covar(ma,ma), alpha(ma,ma), chisq(cchisq)
{
}


void Peakmrq::fix(const Int i) {
    ia[i]=false;
}

void Peakmrq::fix(const Int i, const Doub val) {
    ia[i]=false;
    a[i]=val;
}

void Peakmrq::free(const Int i) {
    ia[i]=true;
}


Int Peakmrq::fit()
{
    Int j,k,l,iter,done=0;
    Doub alamda=.001,ochisq;
    VecDoub atry(ma),beta(ma),da(ma);

    mfit=0;
    for (j=0; j<ma; ++j)
        if (ia[j])
            mfit++;
    MatDoub temp(mfit,mfit);
    VecDoub oneda(mfit);
    mrqcof(a,alpha,beta);
    for (j=0; j<ma; ++j)
        atry[j]=a[j];

    ochisq=chisq;
    for (iter=0; iter<itmax; ++iter) {
#ifdef PINTGUI
        extern bool cancelVar;
        if(cancelVar) return 1;
#endif
        if (done==ndone)
            alamda=0.;
        for (j=0; j<mfit; ++j) {
            for (k=0; k<mfit; ++k)
                covar[j][k]=alpha[j][k];

            // comment in either
            //covar[j][j]=alpha[j][j]*(1.0+alamda); // multiplicative
            covar[j][j]=alpha[j][j] + alamda; // additive - this seems superior
            for (k=0; k<mfit; ++k)
                temp[j][k]=covar[j][k];
            oneda[j]=beta[j];
        }

        if (gaussj(temp,oneda))
            return 1;
#ifdef PINTGUI
        if(cancelVar) return 1;
#endif
        for (j=0; j<mfit; ++j) {
            for (k=0; k<mfit; k++) covar[j][k]=temp[j][k];
            da[j]=oneda[j];

        }
        if (done==ndone) {
            covsrt(covar, alpha);
            return 0;
        }
        for (j=0,l=0; l<ma; ++l)
            if (ia[l]) atry[l]=a[l]+da[j++];
        mrqcof(atry,covar,da);
        if (abs(chisq-ochisq) < std::max(tol,tol*chisq))
            done++;
        if (chisq < ochisq) {
            alamda *= 0.1;
            ochisq=chisq;
            for (j=0; j<mfit; ++j) {
                for (k=0; k<mfit; ++k) alpha[j][k]=covar[j][k];
                beta[j]=da[j];
            }
            for (l=0; l<ma; ++l)
                a[l]=atry[l];
        }
        else {
            alamda *= 10.0;
            chisq=ochisq;
        }
    }
    return 1;
}

Int Peakmrq::fit_fast()
{
// Requires that all entries in sig have the same value

    Int j,k,l,iter,done=0;
    Doub alamda=.001,ochisq;
    VecDoub atry(ma),beta(ma),da(ma);

    mfit=0;
    for (j=0; j<ma; ++j)
        if (ia[j])
            mfit++;
    MatDoub temp(mfit,mfit);
    VecDoub oneda(mfit);
    mrqcof_fast(a,alpha,beta);
    for (j=0; j<ma; ++j)
        atry[j]=a[j];

    ochisq=chisq;
    for (iter=0; iter<itmax; ++iter) {
#ifdef PINTGUI
        extern bool cancelVar;
        if(cancelVar) return 1;
#endif
        if (done==ndone)
            alamda=0.;
        for (j=0; j<mfit; ++j) {
            for (k=0; k<mfit; ++k)
                covar[j][k]=alpha[j][k];

            // comment in either
            //covar[j][j]=alpha[j][j]*(1.0+alamda); // multiplicative
            covar[j][j]=alpha[j][j] + alamda; // additive - this seems superior
            for (k=0; k<mfit; ++k)
                temp[j][k]=covar[j][k];
            oneda[j]=beta[j];
        }


        if (gaussj(temp,oneda))
            return 1;
#ifdef PINTGUI
        if(cancelVar) return 1;
#endif

        for (j=0; j<mfit; ++j) {
            for (k=0; k<mfit; ++k) covar[j][k]=temp[j][k];
            da[j]=oneda[j];

        }
        if (done==ndone) {
            covsrt(covar, alpha);
            return 0;
        }
        for (j=0,l=0; l<ma; ++l)
            if (ia[l]) atry[l]=a[l]+da[j++];
        mrqcof_fast(atry,covar,da);
        if (abs(chisq-ochisq) < std::max(tol,tol*chisq))
            done++;
        if (chisq < ochisq) {
            alamda *= 0.1;
            ochisq=chisq;
            for (j=0; j<mfit; ++j) {
                for (k=0; k<mfit; ++k) alpha[j][k]=covar[j][k];
                beta[j]=da[j];
            }
            for (l=0; l<ma; ++l)
                a[l]=atry[l];
        }
        else {
            alamda *= 10.0;
            chisq=ochisq;
        }
    }
    return 1;
}


void Peakmrq::mrqcof(VecDoub &a, MatDoub_O &alpha, VecDoub_O &beta)
{

    Int i,j,k,l,m;
    Doub ymod,wt,sig2i,dy;
    VecDoub dyda(ma);
    for (j=0; j<mfit; ++j) {
        for (k=0; k<=j; ++k) alpha[j][k]=0.0;
        beta[j]=0.;
    }
    chisq=0.;
    for (i=0; i<ndata; ++i) {
        funcs(x1[i],x2[i],x3[i],a,ymod,dyda,nol,narr);
        sig2i=1.0/(sig[i]*sig[i]);
        dy=y[i]-ymod;
        for (j=0,l=0; l<ma; ++l) {
            if (ia[l]) {
                wt=dyda[l]*sig2i;
                for (k=0,m=0; m<l+1; ++m)
                    if (ia[m]) alpha[j][k++] += wt*dyda[m];
                beta[j++] += dy*wt;
            }
        }
        chisq += dy*dy*sig2i;
    }
    for (j=1; j<mfit; ++j)
        for (k=0; k<j; ++k) alpha[k][j]=alpha[j][k];
}


void Peakmrq::mrqcof_fast(VecDoub &a, MatDoub_O &alpha, VecDoub_O &beta)
{
// Requires that all entries in sig have the same value

    Int i,j,k,l,m;
    Doub ymod,wt,dy;
    VecDoub dyda(ma);
    for (j=0; j<mfit; ++j) {
        for (k=0; k<=j; ++k) alpha[j][k]=0.0;
        beta[j]=0.;
    }
    //Doub sig2i = 1./(sig[0]*sig[0]);
    chisq=0.;
    for (i=0; i<ndata; ++i) {
        funcs(x1[i],x2[i],x3[i],a,ymod,dyda,nol,narr);
        dy=y[i]-ymod;
        for (j=0,l=0; l<ma; ++l) {
            if (ia[l]) {
                //wt=dyda[l]*sig2i;
                wt=dyda[l];					// all weights are equal so no need to use
                for (k=0,m=0; m<l+1; ++m)
                    if (ia[m]) alpha[j][k++] += wt*dyda[m];
                beta[j++] += dy*wt;
            }
        }
        chisq += dy*dy;
    }
    for (j=1; j<mfit; ++j)
        for (k=0; k<j; ++k) alpha[k][j]=alpha[j][k];
    chisq *= 1./(sig[0]*sig[0]);
}


void Peakmrq::covsrt(MatDoub_IO &covar, MatDoub_IO &alpha) {
    Int i,j,k;
    for (i=mfit; i<ma; ++i)
        for (j=0; j<i+1; ++j) {
            covar[i][j]=covar[j][i]=0.0;
            alpha[i][j]=alpha[j][i]=0.0;
        }
    k=mfit-1;
    for (j=ma-1; j>=0; --j) {
        if (ia[j]) {
            for (i=0; i<ma; ++i) {
                swap(covar[i][k],covar[i][j]);
                swap(alpha[i][k],alpha[i][j]);
            }
            for (i=0; i<ma; ++i) {
                swap(covar[k][i],covar[j][i]);
                swap(alpha[k][i],alpha[j][i]);
            }
            k--;
        }
    }
}


Fitmrq::Fitmrq(VecDoub_I &xx, VecDoub_I &yy, VecDoub_I &ssig, VecDoub_I &aa,
               VecBool_I &iia, void funks(const Doub, VecDoub_I &, Doub &, VecDoub_O &), const Doub
               TOL, const Int NDONE, const Int ITMAX) : ndata(xx.size()), ma(aa.size()), x(xx), y(yy), sig(ssig),
    ndone(NDONE), itmax(ITMAX), tol(TOL), funcs(funks), ia(ma),
    a(aa), covar(ma,ma), alpha(ma,ma)
{
    for (Int i=0; i<ma; ++i) ia[i] = iia[i];
}

void Fitmrq::fix(const Int i, const Doub val) {
    ia[i]=false;
    a[i]=val;
}
void Fitmrq::free(const Int i) {
    ia[i]=true;
}

Int Fitmrq::fit() {
    Int j,k,l,iter,done=0;
    Doub alamda=.001,ochisq;
    VecDoub atry(ma),beta(ma),da(ma);
    mfit=0;

    for (j=0; j<ma; ++j)
        if (ia[j])
            mfit++;
    MatDoub temp(mfit,mfit);
    VecDoub oneda(mfit);
    mrqcof(a,alpha,beta);
    for (j=0; j<ma; ++j)
        atry[j]=a[j];
    ochisq=chisq;
    for (iter=0; iter<itmax; ++iter) {
#ifdef PINTGUI
        extern bool cancelVar;
        if(cancelVar) return 1;
#endif
        if (done==ndone) alamda=0.;
        for (j=0; j<mfit; ++j) {
            for (k=0; k<mfit; ++k) covar[j][k]=alpha[j][k];

            // Comment in either
            //covar[j][j]=alpha[j][j]*(1.0+alamda); //multiplicative
            covar[j][j]=alpha[j][j] + alamda; // additive

            for (k=0; k<mfit; ++k) temp[j][k]=covar[j][k];
            oneda[j]=beta[j];
        }
        gaussj(temp,oneda);
#ifdef PINTGUI
        if(cancelVar) return 1;
#endif
        for (j=0; j<mfit; ++j) {
            for (k=0; k<mfit; ++k) covar[j][k]=temp[j][k];
            da[j]=oneda[j];
        }
        if (done==ndone) {
            covsrt(covar, alpha);
            return 0;
        }
        for (j=0,l=0; l<ma; ++l)
            if (ia[l]) atry[l]=a[l]+da[j++];
        mrqcof(atry,covar,da);
        if (abs(chisq-ochisq) < std::max(tol,tol*chisq)) done++;
        if (chisq < ochisq) {
            alamda *= 0.1;
            ochisq=chisq;
            for (j=0; j<mfit; ++j) {
                for (k=0; k<mfit; ++k) alpha[j][k]=covar[j][k];
                beta[j]=da[j];
            }
            for (l=0; l<ma; ++l) a[l]=atry[l];
        } else {
            alamda *= 10.0;
            chisq=ochisq;
        }
    }
    return 1;
}


void Fitmrq::mrqcof(VecDoub_I &a, MatDoub_O &alpha, VecDoub_O &beta) {
    Int i,j,k,l,m;
    Doub ymod,wt,sig2i,dy;
    VecDoub dyda(ma);
    for (j=0; j<mfit; ++j) {
        for (k=0; k<=j; ++k)
            alpha[j][k]=0.0;
        beta[j]=0.;
    }
    chisq=0.;
    for (i=0; i<ndata; ++i) {
        funcs(x[i],a,ymod,dyda);
        sig2i=1.0/(sig[i]*sig[i]);
        dy=y[i]-ymod;
        for (j=0,l=0; l<ma; ++l) {
            if (ia[l]) {
                wt=dyda[l]*sig2i;
                for (k=0,m=0; m<l+1; ++m)
                    if (ia[m]) alpha[j][k++] += wt*dyda[m];
                beta[j++] += dy*wt;
            }
        }
        chisq += dy*dy*sig2i;
    }
    for (j=1; j<mfit; ++j)
        for (k=0; k<j; ++k) alpha[k][j]=alpha[j][k];
}

void Fitmrq::covsrt(MatDoub_IO &covar, MatDoub_IO &alpha) {
    Int i,j,k;
    for (i=mfit; i<ma; ++i)
        for (j=0; j<i+1; ++j) {
            covar[i][j] = covar[j][i]=0.0;
            alpha[i][j] = alpha[j][i]=0.0;
        }
    k=mfit-1;
    for (j=ma-1; j>=0; --j) {
        if (ia[j]) {
            for (i=0; i<ma; ++i) {
                swap(covar[i][k], covar[i][j]);
                swap(alpha[i][k], alpha[i][j]);
            }
            for (i=0; i<ma; ++i) {
                swap(covar[k][i], covar[j][i]);
                swap(alpha[k][i], alpha[j][i]);
            }
            k--;
        }
    }
}

// This is the public gridsearch
void Fitmrq::gridSearch(VecDoub_I &aLo, VecDoub_I &aHi, VecInt_I &aSteps, Bool fgrid) {
    if (fgrid) {
        VecDoub aAct(aLo);
        gridSearch(aLo, aHi, aSteps, aAct, 0);
    }
}

// Private gridSearch
void Fitmrq::gridSearch(VecDoub_I &aLo, VecDoub_I &aHi, VecInt_I &aSteps, VecDoub_IO &aAct, Uint index)
{
    static Doub chisqLo = -1.;
    static VecDoub dyda(ma);
    Doub chisqGrid, yGrid;

    for (Int i=0; i<aSteps[index]; ++i) {
        if (index == a.size()-1) {
            chisqGrid = 0.;
            for (Int j=0; j<ndata; ++j) {
                funcs(x[j], aAct, yGrid, dyda);
                chisqGrid += SQR(yGrid -y[j]/sig[j]);
            }
            if (chisqGrid < chisqLo || chisqLo == -1.) {
                chisqLo = chisqGrid;
                a = aAct;
            }
        }
        else {
            gridSearch(aLo, aHi, aSteps, aAct, index+1);
        }
        aAct[index] += (aHi[index]-aLo[index])/(Doub)(aSteps[index]-1);
    }
    aAct[index] = aLo[index];
}
