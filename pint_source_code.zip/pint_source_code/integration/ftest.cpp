// ftest.cpp
//
// Caclulates the probability that two models are
// equally valid by doing an f-test on their
// respective chisquares
//
// - The "full" chi2 NOT the reduced ones should be entered
// - df refers to degrees of freedom which is n-m, where
//   n is no. data points and m is the number of parameters
//   used to determine chi2
//
// Example 1: You are testing two variances with n1 and n2 points
// df1 = n1-1 and df2=n2-1
//
// Example 2: You are testing the fit of a 2-parameter and a
// 4-parameter model to your data of size n. df1 = n-2 df2=n-4
//
// coded by Patrik Lundstrom, 021024



#include "ftest.h"


void FTest::test(Doub chisq1, Doub _df1, Doub chisq2, Doub _df2)
{
    // Calculates f statistic and probability (prob) that two fits are
    // equally good. The fits have chisquares of chisq1 and chisq2 and
    // their degrees of freedom (fitted points minus number of fit
    // parameters) are df1, and df2.
    //
    // coded by Patrik Lundstrom, 021024

    if (chisq1 > chisq2) {
        f = chisq1/chisq2;
        df1 = _df1;
        df2 = _df2;
    }
    else {
        f = chisq2/chisq1;
        df1 = _df2;
        df2 = _df1;
    }

    // Calculate probability that fits are equally good
    // (one tailed F-test here)
    // ------------------------------------------------
    prob = betai(0.5*df2,0.5*df1,df2/(df2+df1*f));
    if (prob >  0.5)
        prob = 1. - prob;
}


Doub FTest::betai(Doub a, Doub b, Doub x)
{
    // Calculates the incomplete beta function
    //
    // coded by Patrik Lundstrom, 021024

    Doub bt;

    if (x < 0.0 || x > 1.0)
        return -1.0; // signal that something is wrong
    if (x == 0.0 || x == 1.0)
        bt=0.0;
    else
        bt=exp(lgamma(a+b)-lgamma(a)-lgamma(b)+a*log(x)+b*log(1.0-x));
    if (x < (a+1.0)/(a+b+2.0))
        return bt*betacf(a,b,x)/a;
    else
        return 1.0-bt*betacf(b,a,1.0-x)/b;
}

#define MAXIT 100
#define EPS 3.0e-7
#define FPMIN 1.0e-30

Doub FTest::betacf(Doub a, Doub b, Doub x)
{
    // Used by betai(). Evaluates continued fraction for
    // incomplete beta function
    //
    // coded by Patrik Lundstrom, 021024

    Int m,m2;
    Doub aa,c,d,del,h,qab,qam,qap;

    qab=a+b;
    qap=a+1.0;
    qam=a-1.0;
    c=1.0;
    d=1.0-qab*x/qap;
    if (fabs(d) < FPMIN) d=FPMIN;
    d=1.0/d;
    h=d;
    for (m=1; m<=MAXIT; ++m) {
        m2=2*m;
        aa=m*(b-m)*x/((qam+m2)*(a+m2));
        d=1.0+aa*d;
        if (fabs(d) < FPMIN) d=FPMIN;
        c=1.0+aa/c;
        if (fabs(c) < FPMIN) c=FPMIN;
        d=1.0/d;
        h *= d*c;
        aa = -(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
        d=1.0+aa*d;
        if (fabs(d) < FPMIN) d=FPMIN;
        c=1.0+aa/c;
        if (fabs(c) < FPMIN) c=FPMIN;
        d=1.0/d;
        del=d*c;
        h *= del;
        if (fabs(del-1.0) < EPS) break;
    }
    if (m > MAXIT)
        return -1.0; // sigfnal that something went wrong
    return h;
}
#undef MAXIT
#undef EPS
#undef FPMIN
