#ifndef _PINT
#define _PINT
#define PINTGUI

#define PINT_VERSION "1.18.0"


// system headers
#include <algorithm>
#include <cmath>
#include <complex>
#include <deque>
#include <dirent.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>


using namespace std;

// PINT SPECIFIC defines
#define MAX_PEAKS 5000
#define MAX_ASSI  50
#define MAX_LINE  10000
#define MAX_NAME  50
#define MAX_DATA 1000000  // to safeguard against insane alloation requests
#define MAX_PLANE 1024
#define MAX_OVERLAP 4
#define LORENTZIAN 0
#define GAUSSIAN   1
#define GALORE      2
#define VOIGT        3
#define NUMBER_OF_LINESHAPES 4

#define EPS_CONV 1e-6	// default criterion for convergence

#ifndef PI
#define PI 3.141592654
#endif

#define SPACE " "
#define TAB "\t"
#define ENDL "\n"



// inline functions
template<class T>
inline T SQR(const T a) { return a*a; }


template<class T>
inline T SIGN(const T &a, const T &b)
{
    return b >= 0 ? (a >= 0 ? a : -a) : (a >= 0 ? -a : a);
}


template <class T>
class PINTmatrix {
private:
    int nn;
    int mm;
    T **v;
public:
    PINTmatrix();
    PINTmatrix(int n, int m);
    PINTmatrix(int n, int m, const T &a);
    PINTmatrix(const PINTmatrix &rhs);
    PINTmatrix & operator=(const PINTmatrix &rhs);
    inline T* operator[](const int i);
    inline const T* operator[](const int i) const;
    inline int nrows() const;
    inline int ncols() const;
    ~PINTmatrix();
};


template <class T>
PINTmatrix<T>::PINTmatrix() : nn(0), mm(0), v(NULL) {}

template <class T>
PINTmatrix<T>::PINTmatrix(int n, int m) : nn(n), mm(m), v(n>0 ? new T*[n] : NULL)
{
    int i,nel=m*n;
    if (v) v[0] = nel>0 ? new T[nel] : NULL;
    for (i=1; i<n; i++) v[i] = v[i-1] + m;
}

template <class T>
PINTmatrix<T>::PINTmatrix(int n, int m, const T &a) : nn(n), mm(m), v(n>0 ? new T*[n] : NULL)
{
    int i,j,nel=m*n;
    if (v) v[0] = nel>0 ? new T[nel] : NULL;
    for (i=1; i< n; i++) v[i] = v[i-1] + m;
    for (i=0; i< n; i++) for (j=0; j<m; j++) v[i][j] = a;
}

template <class T>
PINTmatrix<T>::PINTmatrix(const PINTmatrix &rhs) : nn(rhs.nn), mm(rhs.mm), v(nn>0 ? new T*[nn] : NULL)
{
    int i,j,nel=mm*nn;
    if (v) v[0] = nel>0 ? new T[nel] : NULL;
    for (i=1; i< nn; i++)
        v[i] = v[i-1] + mm;
    for (i=0; i< nn; i++)
        for (j=0; j<mm; j++)
            v[i][j] = rhs[i][j];
}

template <class T>
PINTmatrix<T> & PINTmatrix<T>::operator=(const PINTmatrix<T> &rhs)
{
    if (this != &rhs) {
        int i,j;
        if (nn != rhs.nn || mm != rhs.mm)
           { std::cerr <<  "Matrices cannot be assigned to matrices of different size!" << ENDL; exit(1); }
        for (i=0; i< nn; i++) for (j=0; j<mm; j++)
            v[i][j] = rhs[i][j];
    }
    return *this;
}

template <class T>
inline T* PINTmatrix<T>::operator[](const int i)
{
    return v[i];
}

template <class T>
inline const T* PINTmatrix<T>::operator[](const int i) const
{
    return v[i];
}

template <class T>
inline int PINTmatrix<T>::nrows() const
{
    return nn;
}

template <class T>
inline int PINTmatrix<T>::ncols() const
{
    return mm;
}

template <class T>
PINTmatrix<T>::~PINTmatrix()
{
    if (v != NULL) {
        delete[] (v[0]);
        delete[] (v);
    }
}





// basic type names (redefine if your bit lengths don't match)

typedef int Int; // 32 bit integer
typedef unsigned int Uint;

typedef long long int Llong; // 64 bit integer
typedef unsigned long long int Ullong;

typedef char Char; // 8 bit integer
typedef unsigned char Uchar;

typedef double Doub; // default floating type
typedef long double Ldoub;

typedef complex<double> Complex; // default complex type

typedef bool Bool;

// NaN: uncomment one of the following 3 methods of defining a global NaN
// you can test by verifying that (NaN != NaN) is true

static const Doub NaN = numeric_limits<Doub>::quiet_NaN();


// vector types
#define PINTvector vector
typedef const PINTvector<Int> VecInt_I;
typedef PINTvector<Int> VecInt, VecInt_O, VecInt_IO;

typedef const PINTvector<Uint> VecUint_I;
typedef PINTvector<Uint> VecUint, VecUint_O, VecUint_IO;

typedef const PINTvector<Llong> VecLlong_I;
typedef PINTvector<Llong> VecLlong, VecLlong_O, VecLlong_IO;

typedef const PINTvector<Ullong> VecUllong_I;
typedef PINTvector<Ullong> VecUllong, VecUllong_O, VecUllong_IO;

typedef const PINTvector<Char> VecChar_I;
typedef PINTvector<Char> VecChar, VecChar_O, VecChar_IO;

typedef const PINTvector<Char*> VecCharp_I;
typedef PINTvector<Char*> VecCharp, VecCharp_O, VecCharp_IO;

typedef const PINTvector<Uchar> VecUchar_I;
typedef PINTvector<Uchar> VecUchar, VecUchar_O, VecUchar_IO;

typedef const PINTvector<Doub> VecDoub_I;
typedef PINTvector<Doub> VecDoub, VecDoub_O, VecDoub_IO;

typedef const PINTvector<Doub*> VecDoubp_I;
typedef PINTvector<Doub*> VecDoubp, VecDoubp_O, VecDoubp_IO;

typedef const PINTvector<Complex> VecComplex_I;
typedef PINTvector<Complex> VecComplex, VecComplex_O, VecComplex_IO;

typedef const PINTvector<Bool> VecBool_I;
typedef PINTvector<Bool> VecBool, VecBool_O, VecBool_IO;

typedef const PINTvector<string> VecString_I;
typedef PINTvector<string> VecString, VecString_O, VecString_IO;

// matrix types
typedef const PINTmatrix<Int> MatInt_I;
typedef PINTmatrix<Int> MatInt, MatInt_O, MatInt_IO;

typedef const PINTmatrix<Uint> MatUint_I;
typedef PINTmatrix<Uint> MatUint, MatUint_O, MatUint_IO;

typedef const PINTmatrix<Llong> MatLlong_I;
typedef PINTmatrix<Llong> MatLlong, MatLlong_O, MatLlong_IO;

typedef const PINTmatrix<Ullong> MatUllong_I;
typedef PINTmatrix<Ullong> MatUllong, MatUllong_O, MatUllong_IO;

typedef const PINTmatrix<Char> MatChar_I;
typedef PINTmatrix<Char> MatChar, MatChar_O, MatChar_IO;

typedef const PINTmatrix<Uchar> MatUchar_I;
typedef PINTmatrix<Uchar> MatUchar, MatUchar_O, MatUchar_IO;

typedef const PINTmatrix<Doub> MatDoub_I;
typedef PINTmatrix<Doub> MatDoub, MatDoub_O, MatDoub_IO;

typedef const PINTmatrix<Bool> MatBool_I;
typedef PINTmatrix<Bool> MatBool, MatBool_O, MatBool_IO;


// Some useful string functions
inline void toUpper(string &s) { for (Uint i=0; i<s.size(); i++) s[i] = toupper(s[i]); }

inline void toLower(string &s) { for (Uint i=0; i<s.size(); i++) s[i] = tolower(s[i]); }

template <class T>
inline Bool from_string(T& t, const std::string& s, std::ios_base& (*f)(std::ios_base&))
{
    std::istringstream iss(s);
    return !(iss >> f >> t).fail();
}


inline void line2words(string s, VecString_O &word)
{
// divides a string separated by white space into words.
// If several words are within
// double quotes they count as one word.

    istringstream iss(s);
    string sub;

    word.resize(0);
    string tmp("");
    while (iss >> sub)
    {
        if(sub[0]=='#')
            return;
        if(sub[0]=='\"' && tmp=="")
        {
            if(sub[sub.length()-1]=='\"')
                word.push_back(sub.substr(1,sub.length()-2));
            else
                tmp=sub.substr(1);
        }
        else if(tmp!="")
        {
            if(sub[sub.length()-1]=='\"' )
            {
                word.push_back(tmp+sub.substr(0,sub.size()-1));
                tmp ="";
            }
            else
                tmp+=sub;
        }
        else
            word.push_back(sub);
    }
}


#endif /* _PINT */

