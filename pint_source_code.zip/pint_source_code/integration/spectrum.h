// spectrum.h

#ifndef _SPECTRUM
#define _SPECTRUM

#include "pint.h"
#include "peak.h"

// codes for nmrPipe header
#define HEADER_SIZE 512
#define F2SIZE 99
#define F2SW   100
#define F2OBS  119
#define F2ORIG 101
#define F1OBS  218
#define F1SIZE 219
#define F1SW   229
#define F1ORIG 249
#define F1OBS_3D  10
#define F1SIZE_3D 219
#define F1SW_3D 11
#define F1ORIG_3D 12
#define NPLANE 15
#define NDIM 9


struct SpectrumType {
    VecString specName;
    Doub swF1, swF2;	   // Sweep width in F1 and F2 resp.
    Doub obsF1, obsF2;    // Freq. for 0 ppm
    Int   sizeF1, sizeF2;  // Size in points
    Doub origF1, origF2;  // Distance in Hz from 0 ppm to first point
    Int nPlane;              // No. planes in 3D or no. 2D spectra
    Int nDim;
    Doub noise;
    Doub deltaF1;
    Doub deltaF2;
    Doub firstF1;
    Doub firstF2;
    Bool calib_OK;

    // for topspin
    int xDimF1;
    int xDimF2;
    int xDimF3;
    int nc_proc;
    // for topspin

    SpectrumType();
    SpectrumType(VecString_I &specname);
    SpectrumType(VecString_I &specname, Doub _noise);

    Int setNoDim(VecString &error_msg);

    Int getCalib(VecString &error_msg, bool pipeData);

    Int noPlanes();

    Int readData(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                 VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg, bool pipeData);

    Int readData2D(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                   VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg);

    Int readData3D(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                   VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg);

    Int readData2DTopspin(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                                    VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg);

    Int readData3DTopspin(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                                    VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg);

    Int getNoPoints3D(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                   VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg);

    Int checkSpecData(PeakListType_I &peak, VecString &error_msg);

    void getRegion(const PeakType &peak, Int &imin, Int &imax, Int &jmin, Int &jmax);

    void getRegionOL(PeakListType_IO &peak, Int &imin, Int &imax, Int &jmin, Int &jmax, VecInt &iopt, VecInt &jopt);

    void trimRegion(Int &imin, Int &imax, Int &jmin, Int &jmax);

    Int readSpectralData3D(FILE *fp, PeakListType &peak, Int realCnt, Int imin, Int imax,
                                         Int jmin, Int jmax, VecInt &iopt, VecInt &jopt, VecDoub &f1vec, VecDoub &f2vec, VecInt &f3vec,
                                         VecDoub &sigvec, VecDoub &yvec, Int &sizecounter);

    Int getDataSize(PeakListType_I &peak, Int imin, Int imax, Int jmin, Int jmax, Int nArrReal);

    Int checkDataSize(PeakListType_IO &peak, Int sizecounter, Llong, VecString &error_msg);

    Bool skipPlane(const PeakListType &peak, Int cnt, Int &realCnt);

    void ReportMaxDataError(Int maxdata, Int sizecounter, const string &s1, const string &s2, VecString &error_msg);

    Bool exists(VecString &error_msg);

    Doub calcNoisePipe(VecString &error_msg);

    Int checkMaxData(PeakListType_IO &peak, Llong maxdata, VecString &error_msg);

#ifdef PINTGUI
    Int readData3DTopspinmmap(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                          VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg);
    Int readData2Dmmap(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                   VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg);
    Int readData3Dmmap(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                   VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg);
#endif
};

#endif
