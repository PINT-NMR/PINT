// esd.h


#ifndef _ESD
#define _ESD

#include "pint.h"
#include "peak.h"

struct EsdType {
// This class estimates uncertainties in peak volumes.
//
// Patrik Lundstrom, 2010

    string outDir;
    char errorList[1000];
    VecString dupAssi;
    VecDoub dupDup;
    VecString dupListAssi;
    VecDoub dupListArr;
    VecDoub dupListArr2;
    VecDoub dupListFirst;
    VecDoub dupListSec;
    VecDoub dupListDiff;


    EsdType();
    EsdType(const string &_outDir);

    void calcEsd(PeakListType &peak);

    void appendDuplicate(const PeakType &peak, Doub &sum, Doub &sumOfSquares, Int &nDup);

    void calcSdev(PeakListType &peak, Doub sum, Doub sumOfSquares, Uint nDup);

    void calcSdev(PeakType &peak, Doub sum, Doub sumOfSquares, Uint nDup);
};


struct ErrorSim
{
// This class can perform Monte Carlo, Jackknife and Bootstrap
// error estimation for functions of one variable
//
// Patrik Lundstrom, 2009

    VecDoub x, y, sig;
    Uint ndata;

    VecDoub guess;
    VecBool ia;
    Uint ma;

    void (*funcs)(const Doub, VecDoub_I &, Doub &, VecDoub_O &);

    VecDoub simerr;

    ErrorSim(VecDoub_I &xx, VecDoub_I &yy, VecDoub_I &ssig, VecDoub_I &gguess, VecBool_I &iia,
             void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &));

    void simerror(Bool fmc, Bool fjack, Bool fboot);

    void montecarlo(Bool fmc=true);

    void jackknife(Bool fjack=true);

    void bootstrap(Bool fboot=true);
};

#endif
