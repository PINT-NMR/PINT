// spectrum.cpp
#include "pint.h"
#include "spectrum.h"
#ifdef PINTGUI
#include <QString>
#include <QFile>
#include <QTextStream>
#else
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
//#define SPEC_HEAD_SIZE 2048

//#define MMAP   // comment in for memory mapping of files
#endif

SpectrumType::SpectrumType() : nDim(-1), noise(1.), calib_OK(false) {  }

SpectrumType::SpectrumType(VecString_I &specname) : specName(specname), nDim(-1), noise(1.0), calib_OK(false) { }

SpectrumType::SpectrumType(VecString_I &specname, Doub ns) : specName(specname), nDim(-1), noise(ns), calib_OK(false) { }

Bool SpectrumType::exists(VecString &error_msg)
{
    // determines dimensionality of spectrum from header

    Uint error_in = error_msg.size();

    FILE *fp;

    for (auto _specName : specName) {
        if (!(fp = fopen(_specName.c_str(), "rb"))) {
            error_msg.push_back("ERROR: Cannot open spectrum '" + _specName + "'!");
            continue;
        }
        fclose(fp);
    }
    return error_msg.size() == error_in;
}


Int SpectrumType::noPlanes() { return calib_OK? nPlane : -1; }

Int SpectrumType::setNoDim(VecString &error_msg)
{
    // determines dimensionality of spectrum from header

    Uint error_in = error_msg.size();

    FILE *fp;

    for (Uint i=0; i<specName.size(); ++i) {
        fp = fopen(specName[i].c_str(), "rb");
        float temp; // N.B. must be a 4 byte float
        fseek(fp, NDIM*4, SEEK_SET);
        fread(&temp, 4, 1, fp);
        if (i==0) {
            nDim = (Int)(temp+0.5);
            if (nDim < 2 || nDim > 3) {
                error_msg.push_back("ERROR: Only 2D or 3D spectra are allowed");
                return 1;
            }
        }
        else if (nDim == 3 || nDim != (Int)(temp+0.5) ) {
            error_msg.push_back("ERROR: If more than one spectrum is specified, all must be 2D");
            return 1;
        }
        fclose(fp);
    }
    return (error_msg.size() == error_in) ? 0 : 1;
}
#ifdef PINTGUI
Int SpectrumType::getCalib(VecString &error_msg, bool pipeData)
{
    // determines spectrometer frequencies, sweep widths etc from header
    if(pipeData)
    {
        if (specName.size() == 0)// there is already an error message for this case so no need to repeat
            return 1;

        if (!exists(error_msg))
            return 1;

        if (setNoDim(error_msg))
            return 1;

        float header[HEADER_SIZE]; // yes, float

        ifstream myFile(specName[0].c_str(), ios::binary);

        myFile.read((char *)header, sizeof(float)*HEADER_SIZE);

        myFile.close();

        sizeF2 = header[F2SIZE];
        swF2 = header[F2SW];
        obsF2 = header[F2OBS];
        origF2 = header[F2ORIG];

        if (nDim == 2) {
            sizeF1 = header[F1SIZE];
            swF1 = header[F1SW];
            obsF1 = header[F1OBS];
            origF1 = header[F1ORIG];
            nPlane = specName.size();
        }
        else if (nDim == 3) {
            sizeF1 = header[F1SIZE_3D];
            swF1 = header[F1SW_3D];
            obsF1 = header[F1OBS_3D];
            origF1 = header[F1ORIG_3D];
            nPlane = header[NPLANE];
        }
        deltaF1 = -swF1/(Doub)sizeF1;
        deltaF2 = -swF2/(Doub)sizeF2;
        firstF1 = origF1 - deltaF1*((Doub)sizeF1-1.);
        firstF2 = origF2 - deltaF2*((Doub)sizeF2-1.);

        calib_OK = true;
        return 0;
    }
    else
    {
        FILE *fp;
        nDim = 0;
        if((fp = fopen((specName[0]+"/2rr").c_str(), "rb")))
        {
            nDim = 2;
            fclose(fp);
        }
        if((fp = fopen((specName[0]+"/3rrr").c_str(), "rb")))
        {
            nDim = 3;
            fclose(fp);
        }
        if(nDim==0)
        {
            error_msg.push_back("Only 2D or 3D spectra are allowed");
            return 1;
        }
        if(nDim==2 || nDim==3)
        {
            QFile file((specName[0]+"/procs").c_str());
            if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                error_msg.push_back("Could not open "+specName[0]+"/procs");
                return 1;
            }

            QTextStream in(&file);
            QString line = in.readLine();
            while(!line.isNull())
            {
                istringstream iss(line.toStdString().c_str());
                string sub;
                int col(0);
                int type(-1);
                while(iss >> sub)
                {
                    if(col==0 && sub =="##$SI=")
                        type = 1;
                    else if(col==0 && sub =="##$SW_p=")
                        type = 2;
                    else if(col==0 && sub =="##$SF=")
                        type = 3;
                    else if(col==0 && sub =="##$OFFSET=")
                        type = 4;
                    else if(col==0 && sub =="##$XDIM=")
                        type = 5;
                    else if(col==0 && sub =="##$NC_proc=")
                        type = 6;

                    if(col==1)
                    {
                        switch(type)
                        {
                        case 1:
                        {
                            sizeF2 = (Int) atoi(sub.c_str());
                            break;
                        }
                        case 2:
                        {
                            swF2 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 3:
                        {
                            obsF2 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 4:
                        {
                            origF2 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 5:
                        {
                            xDimF2 = (int) atof(sub.c_str());
                            break;
                        }
                        case 6:
                        {
                            nc_proc = atoi(sub.c_str());
                            break;
                        }
                        default:
                            break;
                        }
                    }
                    col++;
                }
                line = in.readLine();
            }
            file.close();
            QFile file2((specName[0]+"/proc2s").c_str());
            if(!file2.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                error_msg.push_back("Could not open "+specName[0]+"/proc2s");
                return 1;
            }
            QTextStream in2(&file2);
            line = in2.readLine();
            while(!line.isNull())
            {
                istringstream iss(line.toStdString().c_str());
                string sub;
                int col(0);
                int type(-1);
                while(iss >> sub)
                {
                    if(col==0 && sub =="##$SI=")
                        type = 1;
                    else if(col==0 && sub =="##$SW_p=")
                        type = 2;
                    else if(col==0 && sub =="##$SF=")
                        type = 3;
                    else if(col==0 && sub =="##$OFFSET=")
                        type = 4;
                    else if(col==0 && sub =="##$XDIM=")
                        type = 5;
                    else if(col==0 && sub =="##$NC_proc=")
                        type = 6;


                    if(col==1)
                    {
                        switch(type)
                        {
                        case 1:
                        {
                            sizeF1 = (Int) atoi(sub.c_str());
                            break;
                        }
                        case 2:
                        {
                            swF1 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 3:
                        {
                            obsF1 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 4:
                        {
                            origF1 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 5:
                        {
                            xDimF1 = (int) atof(sub.c_str());
                            break;
                        }
                        case 6:
                        {
                            nc_proc = atoi(sub.c_str());
                            break;
                        }
                        default:
                            break;
                        }
                    }
                    col++;
                }
                line = in2.readLine();
            }
            file2.close();

            origF1 = origF1*obsF1-swF1;
            origF2 = origF2*obsF2-swF2;
            deltaF1 = -swF1/(Doub)sizeF1;
            deltaF2 = -swF2/(Doub)sizeF2;
            firstF1 = origF1 - deltaF1*((Doub)sizeF1-1.);
            firstF2 = origF2 - deltaF2*((Doub)sizeF2-1.);
            xDimF3 = 1;
            if(nDim==2)
            {
                calib_OK = true;
                nPlane = specName.size();
                return 0;
            }
            QFile file3((specName[0]+"/proc3s").c_str());
            if(!file3.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                error_msg.push_back("Could not open "+specName[0]+"/proc3s");
                return 1;
            }
            QTextStream in3(&file3);
            line = in3.readLine();
            while(!line.isNull())
            {
                istringstream iss(line.toStdString().c_str());
                string sub;
                int col(0);
                int type(-1);
                while(iss >> sub)
                {
                    if(col==0 && sub =="##$SI=")
                        type = 1;
                    else if(col==0 && sub =="##$XDIM=")
                        type = 2;

                    if(col==1)
                    {
                        switch(type)
                        {
                        case 1:
                        {
                            nPlane = atoi(sub.c_str());
                            break;
                        }
                        case 2:
                        {
                            xDimF3 = atof(sub.c_str());
                            break;
                        }
                        default:
                            break;
                        }
                    }
                    col++;
                }
                line = in3.readLine();
            }
            file3.close();
            calib_OK = true;
            return 0;
        }
        else
            return 1;
    }
}
#else
Int SpectrumType::getCalib(VecString &error_msg, bool pipeData)
{
    // determines spectrometer frequencies, sweep widths etc from header
    if(pipeData)
    {
        if (specName.size() == 0)// there is already an error message for this case so no need to repeat
            return 1;

        if (!exists(error_msg))
            return 1;

        if (setNoDim(error_msg))
            return 1;

        float header[HEADER_SIZE]; // yes, float

        ifstream myFile(specName[0].c_str(), ios::binary);

        myFile.read((char *)header, sizeof(float)*HEADER_SIZE);

        sizeF2 = header[F2SIZE];
        swF2 = header[F2SW];
        obsF2 = header[F2OBS];
        origF2 = header[F2ORIG];

        if (nDim == 2) {
            sizeF1 = header[F1SIZE];
            swF1 = header[F1SW];
            obsF1 = header[F1OBS];
            origF1 = header[F1ORIG];
            nPlane = specName.size();
        }
        else if (nDim == 3) {
            sizeF1 = header[F1SIZE_3D];
            swF1 = header[F1SW_3D];
            obsF1 = header[F1OBS_3D];
            origF1 = header[F1ORIG_3D];
            nPlane = header[NPLANE];
        }
        deltaF1 = -swF1/(Doub)sizeF1;
        deltaF2 = -swF2/(Doub)sizeF2;
        firstF1 = origF1 - deltaF1*((Doub)sizeF1-1.);
        firstF2 = origF2 - deltaF2*((Doub)sizeF2-1.);

        calib_OK = true;
        return 0;
    }
    else
    {
        FILE *fp;
        nDim = 0;
        if((fp = fopen((specName[0]+"/2rr").c_str(), "rb")))
        {
            nDim = 2;
            fclose(fp);
        }
        if((fp = fopen((specName[0]+"/3rrr").c_str(), "rb")))
        {
            nDim = 3;
            fclose(fp);
        }
        if(nDim==0)
        {
            error_msg.push_back("ERROR: Only 2D or 3D spectra are allowed");
            return 1;
        }
        if(nDim==2 || nDim==3)
        {
            //QFile file((specName[0]+"/procs").c_str());
            ifstream file((specName[0]+"/procs").c_str());

            //if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
            if (!file.is_open())
            {
                error_msg.push_back("ERROR: Could not open "+specName[0]+"/procs");
                return 1;
            }
            //QTextStream in(&file);
            //QString line = in.readLine();

            //while(!line.isNull())
            while(file.good())
            {
                string line;
                getline(file, line);

                istringstream iss(line.c_str());
                string sub;
                int col(0);
                int type(-1);
                while(iss >> sub)
                {
                    if(col==0 && sub =="##$SI=")
                        type = 1;
                    else if(col==0 && sub =="##$SW_p=")
                        type = 2;
                    else if(col==0 && sub =="##$SF=")
                        type = 3;
                    else if(col==0 && sub =="##$OFFSET=")
                        type = 4;
                    else if(col==0 && sub =="##$XDIM=")
                        type = 5;
                    else if(col==0 && sub =="##$NC_proc=")
                        type = 6;

                    if(col==1)
                    {
                        switch(type)
                        {
                        case 1:
                        {
                            sizeF2 = (Int) atoi(sub.c_str());
                            break;
                        }
                        case 2:
                        {
                            swF2 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 3:
                        {
                            obsF2 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 4:
                        {
                            origF2 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 5:
                        {
                            xDimF2 = (int) atof(sub.c_str());
                            break;
                        }
                        case 6:
                        {
                            nc_proc = atoi(sub.c_str());
                            break;
                        }
                        default:
                            break;
                        }
                    }
                    col++;
                }
                //line = in.readLine();
            }
            file.close();
            //QFile file2((specName[0]+"/proc2s").c_str());
            ifstream file2((specName[0]+"/proc2s").c_str());

            //if(!file2.open(QIODevice::ReadOnly | QIODevice::Text))
            if(!file2.is_open())
            {
                error_msg.push_back("ERROR: Could not open "+specName[0]+"/proc2s");
                return 1;
            }
            //QTextStream in2(&file2);
            //line = in2.readLine();
            //while(!line.isNull())
            while (file2.good())
            {
                string line;
                getline(file2, line);

                istringstream iss(line.c_str());
                string sub;
                int col(0);
                int type(-1);
                while(iss >> sub)
                {
                    if(col==0 && sub =="##$SI=")
                        type = 1;
                    else if(col==0 && sub =="##$SW_p=")
                        type = 2;
                    else if(col==0 && sub =="##$SF=")
                        type = 3;
                    else if(col==0 && sub =="##$OFFSET=")
                        type = 4;
                    else if(col==0 && sub =="##$XDIM=")
                        type = 5;
                    else if(col==0 && sub =="##$NC_proc=")
                        type = 6;


                    if(col==1)
                    {
                        switch(type)
                        {
                        case 1:
                        {
                            sizeF1 = (Int) atoi(sub.c_str());
                            break;
                        }
                        case 2:
                        {
                            swF1 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 3:
                        {
                            obsF1 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 4:
                        {
                            origF1 = (Doub) atof(sub.c_str());
                            break;
                        }
                        case 5:
                        {
                            xDimF1 = (int) atof(sub.c_str());
                            break;
                        }
                        case 6:
                        {
                            nc_proc = atoi(sub.c_str());
                            break;
                        }
                        default:
                            break;
                        }
                    }
                    col++;
                }
                //line = in2.readLine();
            }
            file2.close();

            origF1 = origF1*obsF1-swF1;
            origF2 = origF2*obsF2-swF2;
            deltaF1 = -swF1/(Doub)sizeF1;
            deltaF2 = -swF2/(Doub)sizeF2;
            firstF1 = origF1 - deltaF1*((Doub)sizeF1-1.);
            firstF2 = origF2 - deltaF2*((Doub)sizeF2-1.);
            if(nDim==2)
            {
                calib_OK = true;
                nPlane = 1;
                return 0;
            }
            //QFile file3((specName[0]+"/proc3s").c_str());
            ifstream file3((specName[0]+"/proc3s").c_str());
            //if(!file3.open(QIODevice::ReadOnly | QIODevice::Text))
            if(!file3.is_open())
            {
                error_msg.push_back("ERROR: Could not open "+specName[0]+"/proc3s");
                return 1;
            }
            //QTextStream in3(&file3);
            //line = in3.readLine();
            //while(!line.isNull())
            while(file3.good())
            {
                string line;
                getline(file3, line);

                istringstream iss(line.c_str());
                string sub;
                int col(0);
                int type(-1);
                while(iss >> sub)
                {
                    if(col==0 && sub =="##$SI=")
                        type = 1;
                    else if(col==0 && sub =="##$XDIM=")
                        type = 2;

                    if(col==1)
                    {
                        switch(type)
                        {
                        case 1:
                        {
                            nPlane = atoi(sub.c_str());
                            break;
                        }
                        case 2:
                        {
                            xDimF3 = atof(sub.c_str());
                            break;
                        }
                        default:
                            break;
                        }
                    }
                    col++;
                }
                //line = in3.readLine();
            }
            file3.close();
            calib_OK = true;
            return 0;
        }
        else
            return 1;
    }
}
#endif


Doub SpectrumType::calcNoisePipe(VecString &error_msg)
{
// calculate standard deviation of noise and trim
// away (iteratively) values outside of CUTOFF std
// deviations in the calculation.

    const Doub CUTOFF = 3.0;

    FILE *fp;
    if (!(fp = fopen(specName[0].c_str(), "rb"))) {
         error_msg.push_back("ERROR: Cannot open spectrum '" + specName[0] + "'");
         return -1.0;
    }

    PINTmatrix<float> yVec(sizeF1, sizeF2);  // must be float (or 4 byte word)

    fseek(fp, sizeof(float)*HEADER_SIZE, SEEK_SET);
    for (Int i=0; i<sizeF1; ++i)
        fread(yVec[i], 4, sizeF2, fp);
    fclose(fp);

    Doub mean, ndata=0., sum=0., sqSum=0., ndataPrev = sizeF1*sizeF2;
    for (Int i=0; i<sizeF1; ++i)
        for (Int j=0; j<sizeF2; ++j) {
                sum+= yVec[i][j];
                sqSum+= yVec[i][j]*yVec[i][j];
                ++ndata;
        }
    mean = sum/ndata;
    noise =  sqrt(1.0/(ndata-1.0)*(sqSum-sum*sum/ndata));
    for(;;) {
        ndata=0.; sum=0.; sqSum=0.;
        for (Int i=0; i<sizeF1; ++i)
            for (Int j=0; j<sizeF2; ++j)
                if (fabs(yVec[i][j]) < mean + CUTOFF*noise) {
                    sum+= yVec[i][j];
                    sqSum+= yVec[i][j]*yVec[i][j];
                    ++ndata;
                }
        mean = sum/ndata;
        noise =  sqrt(1.0/(ndata-1.0)*(sqSum-sum*sum/ndata));

        if (ndata == ndataPrev)
            return noise;

        ndataPrev = ndata;
    }
}


#ifdef PINTGUI
Int SpectrumType::readData(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                           VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg, bool pipeData)
{
    // read data for a group of peaks. pseudo-3D and (a set of) 2D spectra
    // are handled differently
    if(pipeData)
    {
        calcNoisePipe(error_msg);
        if (nDim == 3) {
            return readData3Dmmap(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
            //return readData3D(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        }
        else if (nDim == 2)
            return readData2Dmmap(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
            //return readData2D(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        else
            return 1;
    }
    else
    {
        if (nDim == 3) {
            return readData3DTopspinmmap(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
            //return readData3DTopspin(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        }
        else if (nDim == 2)
            //return readData2DTopspinmmap(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        return readData2DTopspin(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        else
            return 1;
    }
}
#else
Int SpectrumType::readData(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                           VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg, bool pipeData)
{
    // read data for a group of peaks. pseudo-3D and (a set of) 2D spectra
    // are handled differently
    if(pipeData)
    {
        calcNoisePipe(error_msg);
        if (nDim == 3) {
            return readData3D(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        }
        else if (nDim == 2)
            return readData2D(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        else
            return 1;
    }
    else
    {
        if (nDim == 3) {
            return readData3DTopspin(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        }
        else if (nDim == 2)
            return readData2DTopspin(peak, f1, f2, f3, y, sig, yopt, BigJ, maxdata, error_msg);
        else
            return 1;
    }
}
#endif
void allocateVectors(VecDoub &yopt, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, Int npar, Int sizecounter)
{
    yopt = VecDoub(npar);
    f1 = VecDoub(sizecounter);
    f2 = VecDoub(sizecounter);
    f3 = VecInt(sizecounter);
    y = VecDoub(sizecounter);
    sig = VecDoub(sizecounter);
}

Bool skipExcludedPlane(const PeakListType_IO &peak, Int cnt, Int &realCnt)
{
    for (Uint i=0; i<peak[0].excludePlane.size(); ++i)
        if (cnt == (Int)peak[0].excludePlane[i]) {
            --realCnt;
            return true;
        }
    return false;
}


Int SpectrumType::readData2D(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                             VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg)
{
// read data for a group of peaks in (a set of) 2D spectra

    Int imin, jmin, imax, jmax;
    VecInt iopt(peak.size()), jopt(peak.size());
    FILE *fp;
    Int nArrReal = peak[0].arr.size() - peak[0].excludePlane.size();

    // Determine data size and allocate space. Return if too big
    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg)) return 1; // must return if datasize too big
    allocateVectors(yopt, f1,f2,f3,y,sig, peak.size()*nArrReal, sizecounter);

    Int realCnt = 1;
    sizecounter = 0;
    for (Uint cnt=1; cnt <= specName.size(); ++cnt, ++realCnt) {

        if (skipExcludedPlane(peak, cnt, realCnt))
            continue;

        if (!(fp = fopen(specName[cnt-1].c_str(), "rb"))) {
             error_msg.push_back("ERROR: Cannot open spectrum '" + specName[cnt-1] + "'");
             return 1;
        }

        for (Int i=imin; i<imax; ++i) {

            Int j;
            for (j=jmin, fseek(fp, sizeof(float)*HEADER_SIZE+0*(cnt-1)*sizeF1*sizeF2*4 + i*sizeF2*4+j*4, SEEK_SET); j<jmax; ++j) {
                float _y;
                fread(&_y, 4, 1, fp);
                Doub _F1 = (firstF1 + (i)*deltaF1)/obsF1;
                Doub _F2 = (firstF2 + (j)*deltaF2)/obsF2;
                for (Uint k=0; k<peak.size(); ++k)
                    if (i == iopt[k] && j == jopt[k])
                        yopt[k*peak[0].arr.size()+realCnt-1] = _y;
                for (Uint k=0; k<peak.size(); ++k) {
                    Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                    if (radius <= 1.0) {
                        f1[sizecounter] = _F1;
                        f2[sizecounter] = _F2;
                        f3[sizecounter] = realCnt;
                        y[sizecounter] = _y;
                        sig[sizecounter] = ((peak[k].centerWt - 1.)*radius + 1.)*noise;
                        ++sizecounter;
                        break;
                    }
                }
            }
        }
        fclose(fp);
    }
    BigJ = jmax - jmin + 1;
    return 0;
}
#ifdef PINTGUI

Int SpectrumType::readData2DTopspin(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                                    VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg)
{
    // read data for a group of peaks in (a set of) 2D spectra
    Int imin, jmin, imax, jmax;
    VecInt iopt(peak.size()), jopt(peak.size());
    Doub _F1, _F2;  // N.B. Size of these must be exactly 4 bytes since that is the nmrPipe format
    FILE *fp;
    Uint nArrReal = peak[0].arr.size() - peak[0].excludePlane.size();

    // Determine data size and allocate space. Return if too big
    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg)) return 1; // must return if datasize too big
    //allocateVectors(yopt, f1,f2,f3,y,sig, peak.size()*nArrReal, sizecounter);
    yopt = VecDoub(peak.size()*nArrReal);

    Int realCnt = 1;
    //sizecounter = 0;
    for (Int cnt=1; cnt <= (Int) specName.size(); cnt++, realCnt++)
    {
        if (skipExcludedPlane(peak, cnt, realCnt))
            continue;

        if(!nc_proc)
           nc_proc=1;

        if (!(fp = fopen((specName[cnt-1]+"/2rr").c_str(), "rb"))) {
            error_msg.push_back("Cannot open spectrum '" + specName[cnt-1] + "'");
            return 1;
        }

        int a;
        int submatrixF2 = sizeF2/xDimF2;
        int countingF2(0);
        int f2Max(0);
        int f1Max(0);
        for (int i=f2Max+f1Max*((int)sizeF2); i < sizeF1*sizeF2; ++i)
        {
            int v = i - xDimF2 * (int)((floor)((double)((double)i/(double)xDimF2))) + xDimF1 * xDimF2 * (int)((floor)((double)((double)i/(double)xDimF2)))
                    - xDimF2 * (xDimF1 * submatrixF2-1) * (int)((floor)((double)((double)i/(double)(xDimF2 * submatrixF2))))
                    + xDimF2 * xDimF1 * (submatrixF2-1) * (int)((floor)((double)((double)i/(double)(xDimF2 * xDimF1 * submatrixF2))));
            Int ii(((Int)(floor)((Int)v/sizeF2)));
            Int jj((Int)v - sizeF2*ii);
            if(ii<imin || ii>=imax || jj<jmin || jj>=jmax)
            {
                countingF2++;
                if(countingF2==sizeF2)
                {
                    i+=(sizeF2-1)-(countingF2+f2Max);
                    countingF2=0;
                }
                continue;
            }
            _F1 = (firstF1 + (ii)*deltaF1)/obsF1;
            _F2 = (firstF2 + (jj)*deltaF2)/obsF2;
            fseek(fp, v*4, 0);
            fread(&a, sizeof(int), 1, fp);
            Doub b = (Doub)((Doub) a * (Doub)pow(2.0,(Doub)nc_proc)+0.5); //Compensate for the 2^N Bruker scaling factor
            for (Uint k=0; k<peak.size(); ++k)
                if ((Int) ii == iopt[k] && (Int) jj == jopt[k])
                    yopt[k*peak[0].arr.size()+realCnt-1] = b;
            for (Uint k=0; k<peak.size(); ++k)
            {
                Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                if (radius <= 1.0)
                {
                    f1.push_back(_F1);
                    f2.push_back(_F2);
                    f3.push_back(realCnt);
                    y.push_back(b);
                    sig.push_back(((peak[k].centerWt - 1.)*radius + 1.)*noise);
                    break;
                }
            }
            countingF2++;
            if(countingF2==sizeF2)
            {
                i+=(sizeF2-1)-(countingF2+f2Max);
                countingF2=0;
            }
        }
        fclose(fp);
    }
    BigJ = jmax - jmin + 1;
    return 0;
}
#else
Int SpectrumType::readData2DTopspin(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                                    VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg)
{
    // read data for a group of peaks in (a set of) 2D spectra
    Int imin, jmin, imax, jmax, iopt[peak.size()], jopt[peak.size()];
    Uint nArrReal = peak[0].arr.size() - peak[0].excludePlane.size();

    // Determine data size and allocate space. Return if too big
    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg)) return 1; // must return if datasize too big

    allocateVectors(yopt, f1,f2,f3,y,sig, peak.size()*nArrReal, sizecounter);
    yopt = VecDoub(peak.size()*nArrReal);

    Uint realCnt = 1;
    sizecounter = 0;
    for (Uint cnt=1; cnt <= specName.size(); cnt++, realCnt++)
    {

        Bool flag = false;
        for (Uint kk=0; kk<peak[0].excludePlane.size() && !flag; kk++)
            if (cnt == (Uint)peak[0].excludePlane[kk]) {
                flag = true;
            }
        if (flag) {
            --realCnt;
            continue;
        }

        if(!nc_proc)
           nc_proc=1;

#ifndef MMAP
        FILE *fp;
        if (!(fp = fopen((specName[cnt-1]+"/2rr").c_str(), "rb"))) {
            error_msg.push_back("ERROR: Cannot open spectrum '" + specName[cnt-1] + "/2rr'");
            return 1;
        }
#else
        int fd;
        int *map;
        struct stat sb;

        fd = open((specName[cnt-1]+"/2rr").c_str(), O_RDONLY);
        if (fd == -1) {
            error_msg.push_back("ERROR: opening file to be mapped for reading");
            return 1;
        }

        fstat (fd, &sb);
        map = (int *)mmap(0, sb.st_size, PROT_READ, MAP_SHARED, fd, 0);
        if (map == MAP_FAILED) {
            close(fd);
            error_msg.push_back("ERROR: mmapping the file");
        return 1;
        }
#endif

        int a;
        int submatrixF2 = sizeF2/xDimF2;
        int countingF2(0);
        int f2Max(0);
        int f1Max(0);
        for (int i=f2Max+f1Max*((int)sizeF2); i < sizeF1*sizeF2; ++i)
        {
            int v = i - xDimF2 * (int)((floor)((double)((double)i/(double)xDimF2))) + xDimF1 * xDimF2 * (int)((floor)((double)((double)i/(double)xDimF2)))
                    - xDimF2 * (xDimF1 * submatrixF2-1) * (int)((floor)((double)((double)i/(double)(xDimF2 * submatrixF2))))
                    + xDimF2 * xDimF1 * (submatrixF2-1) * (int)((floor)((double)((double)i/(double)(xDimF2 * xDimF1 * submatrixF2))));
            int ii(((int)(floor)(v/sizeF2)));
            int jj((v - sizeF2*(int)(floor)(v/sizeF2)));
            if(ii<imin || ii>=imax || jj<jmin || jj>=jmax)
            {
                countingF2++;
                if(countingF2==sizeF2)
                {
                    i+=(sizeF2-1)-(countingF2+f2Max);
                    countingF2=0;
                }
                continue;
            }
            Doub _F1 = (Doub)((firstF1 + ((Doub)ii)*deltaF1)/obsF1);
            Doub _F2 = (Doub)(firstF2 + ((Doub)jj)*deltaF2)/obsF2;

#ifndef MMAP
            fseek(fp, v*4, 0);
            fread(&a, sizeof(int), 1, fp);
#else
            a = map[v];
#endif

            Doub b = (Doub)((Doub) a * (Doub)pow(2.0,(Doub)nc_proc)+0.5); //Compensate for the 2^N Bruker scaling factor
            for (Uint k=0; k<peak.size(); k++)
                if ((Int) ii == iopt[k] && (Int) jj == jopt[k])
                    yopt[k*peak[0].arr.size()+realCnt-1] = b;
            for (Uint k=0; k<peak.size(); k++)
            {
                Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                if (radius <= 1.0)
                {
                    f1[sizecounter] = _F1;
                    f2[sizecounter] = _F2;
                    f3[sizecounter] = realCnt;
                    y[sizecounter] = b;
                    sig[sizecounter] = ((peak[k].centerWt - 1.)*radius + 1.)*noise;
                    ++sizecounter;
                    break;
                }
            }
            countingF2++;
            if(countingF2==sizeF2)
            {
                i+=(sizeF2-1)-(countingF2+f2Max);
                countingF2=0;
            }
        }
#ifndef MMAP
        fclose(fp);
#else
        if (munmap(map, sb.st_size) == -1) {
        error_msg.push_back("ERROR: unmmapping file");
        }
        close(fd);
#endif
    }
    BigJ = jmax - jmin + 1;
    return 0;
}

#endif

Int SpectrumType::getDataSize(PeakListType_I &peak, Int imin, Int imax, Int jmin, Int jmax, Int nArrReal)
{
    Int sizecounter = 0;
    for (Int i=imin; i<imax; ++i)
        for (Int j=jmin; j<jmax; ++j) {
            Doub _F1 = (firstF1 + (i)*deltaF1)/obsF1;
            Doub _F2 = (firstF2 + (j)*deltaF2)/obsF2;
            for (Uint k=0; k<peak.size(); ++k) {
                Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                if (radius <= 1.0) {
                   sizecounter += nArrReal;
                   break;
                }
            }
         }
    return sizecounter;
}


Int SpectrumType::checkDataSize(PeakListType_IO &peak, Int sizecounter, Llong maxdata, VecString &error_msg)
{
    if (sizecounter > maxdata) {
        string s = "ERROR: Increase '-MAXDATA' to at least ";
        string t;
        ostringstream convert;
        convert << sizecounter;
        s += convert.str() + " to integrate peak(s)";
        for (Uint ii=0; ii<peak.size(); ++ii) {
            s += " ";
            s += peak[ii].assi;
        }
        error_msg.push_back(s);
        return 1;
    }
    return 0;

}

Int SpectrumType::readData3D(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                             VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg)
{
// read data for a group of peaks in a pseudo-3D spectrum


    Int imin, jmin, imax, jmax;
    VecInt iopt(peak.size()), jopt(peak.size());
    Int nArr = peak[0].arr.size();
    Int nArrReal = peak[0].arr.size() - peak[0].excludePlane.size();

    // Determine data size and allocate space. Return if too big request
    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg)) return 1; // must return if datasize too big
    allocateVectors(yopt, f1,f2,f3,y,sig, peak.size()*nArrReal, sizecounter);

    FILE *fp = fopen(specName[0].c_str(), "rb");
    char *buf = NULL;
    setvbuf(fp, buf, _IONBF, 0);

    Int realCnt = 1;
    sizecounter = 0;
    for (Int cnt=1; cnt <= nArr; ++cnt, ++realCnt) {

        if (skipExcludedPlane(peak, cnt, realCnt))
            continue;

        for (Int i=imin; i<imax; ++i)
        {
            float _yvec[jmax-jmin]; // yes, float (or rather size must be 4 bytes).
            fseek(fp, sizeof(float)*HEADER_SIZE+(cnt-1)*sizeF1*sizeF2*4 + i*sizeF2*4 + jmin*4, SEEK_SET);
            fread(_yvec, 4, jmax-jmin, fp);

            for (Int j=jmin; j<jmax; ++j) {
                Doub _F1 = (firstF1 + (i)*deltaF1)/obsF1;
                Doub _F2 = (firstF2 + (j)*deltaF2)/obsF2;
                for (Uint k=0; k<peak.size(); ++k)
                    if (i == iopt[k] && j == jopt[k])
                        yopt[k*nArrReal+realCnt-1] = _yvec[j-jmin];
                for (Uint k=0; k<peak.size(); ++k) {
                    Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                    if (radius <= 1.0) {
                        f1[sizecounter] = _F1;
                        f2[sizecounter] = _F2;
                        f3[sizecounter] = realCnt;
                        y[sizecounter] = _yvec[j-jmin];
                        sig[sizecounter] = ((peak[k].centerWt - 1.)*radius + 1.)*noise;
                        ++sizecounter;
                        break;
                    }
                }
            }
        }
    }
    fclose(fp);

    BigJ = jmax - jmin + 1;
    return 0;
}


Int SpectrumType::readData3DTopspin(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                                    VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg)
{
    // read data for a group of peaks in a pseudo-3D spectrum

    Int imin, jmin, imax, jmax;
    VecInt iopt(peak.size()), jopt(peak.size());
    //Uint nArr = peak[0].arr.size();
    Uint nArrReal = peak[0].arr.size() - peak[0].excludePlane.size();

    // Determine data size and allocate space. Return if too big request
    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg)) return 1; // must return if datasize too big
    allocateVectors(yopt, f1,f2,f3,y,sig, peak.size()*nArrReal, sizecounter);
    yopt = VecDoub(peak.size()*nArrReal);

    // Read data - failure to open file should of course not happen at this stage
    FILE *fp;
    if (!(fp = fopen((specName[0]+"/3rrr").c_str(), "rb"))) {
        error_msg.push_back("ERROR: Cannot open spectrum '" + specName[0] + "/3rrr'");
        return 1;
    }
    char *buf = NULL;
    setvbuf(fp, buf, _IONBF, 0);
    int submatrixF1 = sizeF1/xDimF1;
    int submatrixF2 = sizeF2/xDimF2;
    Uint realCnt = 1;
    sizecounter = 0;
    for (Uint cnt=1; cnt <= (Uint)nPlane; cnt++, realCnt++) {
        int countingF2(0);

        // Skip planes that should be excluded
        Bool flag = false;
        for (Uint kk=0; kk<peak[0].excludePlane.size() && !flag; kk++)
            if (cnt == (Uint)peak[0].excludePlane[kk]) {
                flag = true;
            }
        if (flag) {
            --realCnt;
            continue;
        }
        // Skip planes that should be excluded
        int a;
        int planeSkip  = (cnt-1)*xDimF2*xDimF1 + (int)((floor)((double)((double)(cnt-1)/(double)xDimF3)))
                * (-xDimF3*xDimF2*xDimF1 + xDimF1*xDimF2*xDimF3*submatrixF2*submatrixF1);
        int b((xDimF1*xDimF2*xDimF3-xDimF2));
        int c(xDimF2 - xDimF2*xDimF1*xDimF3*submatrixF2);
        int d(sizeF2*xDimF1);
        int e((xDimF1*xDimF2*xDimF3*submatrixF2 - xDimF1*xDimF2));
        int ii(0);
        int jj(0);
        for (int i=0; i < sizeF1*sizeF2; ++i)
        {
            int v = planeSkip + i + (int)((floor)((double)((double)i/(double)xDimF2))) * b
                    + (int)((floor)((double)((double)i/(double)sizeF2))) * c
                    + (int)((floor)((double)((double)i/(double)d))) * e;
            if(jj==sizeF2)
                jj=0;
            else
                ++jj;
            if(jj==sizeF2)
                ++ii;
            //int ii(((int)(floor)(v/sizeF2)));
            //int jj((v - sizeF2*(int)(floor)(v/sizeF2)));
            if(ii<imin || ii>=imax || jj<jmin || jj>=jmax)
            {
                countingF2++;
                if(countingF2==sizeF2)
                {
                    i+=(sizeF2-1)-(countingF2);
                    countingF2=0;
                }
                continue;
            }
            fseek(fp, v*4, 0);
            fread(&a, sizeof(int), 1, fp);
            Doub _F1 = (firstF1 + ((Int)ii)*deltaF1)/obsF1;
            Doub _F2 = (firstF2 + ((Int)jj)*deltaF2)/obsF2;
            Doub b = (float)((float) a * (float)pow(2.0f,(float)nc_proc)+0.5f); //Compensate for the 2^N Bruker scaling factor
            for (Uint k=0; k<peak.size(); k++)
                if (ii == iopt[k] && jj == jopt[k])
                    yopt[k*nArrReal+realCnt-1] = b;
            for (Uint k=0; k<peak.size(); k++)
            {
                Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                if (radius <= 1.0)
                {
                    f1[sizecounter] = _F1;
                    f2[sizecounter] = _F2;
                    f3[sizecounter] = realCnt;
                    y[sizecounter] = b;
                    sig[sizecounter] = ((peak[k].centerWt - 1.)*radius + 1.)*noise;
                    ++sizecounter;
                    break;
                }
            }
            countingF2++;
            if(countingF2==sizeF2)
            {
                i+=(sizeF2-1)-(countingF2);
                countingF2=0;
            }
        }
    }
    fclose(fp);

    BigJ = jmax - jmin + 1;
    return 0;
}

Int SpectrumType::checkSpecData(PeakListType_I &peak, VecString &error_msg) \
{
// check that the peak comprises a contiguous region in spectrum.

    Int imin, jmin, imax, jmax;
    Int flag = 0;

    for (Uint i=0; i<peak.size() && calib_OK; ++i) {
        getRegion(peak[i], imin, imax, jmin, jmax);
        trimRegion(imin, imax, jmin, jmax);

        if (imin < 0 || imax>=sizeF1 || jmin <0 || jmax>=sizeF2) {
            error_msg.push_back("ERROR: Peak " + peak[i].assi + " is partly outside spectrum");
            calib_OK = false;
            flag = 1;
        }
    }
    return flag;
}


void SpectrumType::getRegion(const PeakType &peak, Int &imin, Int &imax, Int &jmin, Int &jmax)
{
    imin = (Int)(((peak.f1+peak.radF1)*obsF1 - firstF1)/deltaF1 + 0.5); // Points from 0 to N-1
    imax = (Int)(((peak.f1-peak.radF1)*obsF1 - firstF1)/deltaF1 + 0.5);
    jmin = (Int)(((peak.f2+peak.radF2)*obsF2 - firstF2)/deltaF2 + 0.5);
    jmax = (Int)(((peak.f2-peak.radF2)*obsF2 - firstF2)/deltaF2 + 0.5);
}

void SpectrumType::getRegionOL(PeakListType_IO &peak, Int &imin, Int &imax, Int &jmin, Int &jmax, VecInt &iopt, VecInt &jopt)
{
// Used in readData functions
// * Gets a rectangular region in a spectrum a group of peaks are located
// * Gets points of maximum intensity.
// * Folds peaks if necessary

    Int _imin, _imax, _jmin, _jmax;

    getRegion(peak[0], imin, imax, jmin, jmax);
    for (Uint k=0; k<peak.size(); ++k) {
        getRegion(peak[k], _imin, _imax, _jmin, _jmax);
        imin = std::min(_imin, imin);
        imax = std::max(_imax, imax);
        jmin = std::min(_jmin, jmin);
        jmax = std::max(_jmax, jmax);
        iopt[k] = (Int)((peak[k].f1*obsF1 - firstF1)/deltaF1 + 0.5);
        jopt[k] = (Int)((peak[k].f2*obsF2 - firstF2)/deltaF2 + 0.5);
        peak[k].fold(sizeF1, sizeF2, swF1, swF2, obsF1, obsF2, iopt[k], jopt[k]);
    }
    trimRegion(imin, imax, jmin, jmax);
}


void SpectrumType::trimRegion(Int &imin, Int &imax, Int &jmin, Int &jmax)
{
    while (imax < 0 || imax >=  sizeF1)
        imax += sizeF1 * ((imax < 0)? 1 : -1);
    while (imin < 0 || imin >=  sizeF1)
        imin += sizeF1 * ((imin < 0)? 1 : -1);
    while (jmax < 0 || jmax >=  sizeF2)
        jmax += sizeF2 * ((jmax < 0)? 1 : -1);
    while (jmin < 0 || jmin >=  sizeF2)
        jmin += sizeF2 * ((jmin < 0)? 1 : -1);

    if (imax < imin)
        imin -= sizeF1;
    if (jmax < jmin)
        jmin -= sizeF2;
}


Int SpectrumType::checkMaxData(PeakListType_IO &peak, Llong maxdata, VecString &error_msg)
{
    // read data for a group of peaks. pseudo-3D and (a set of) 2D spectra
    // are handled differently
    Int imin, imax, jmin, jmax;
    VecInt iopt(peak.size()), jopt(peak.size());
    Int nArrReal = peak[0].arr.size() - peak[0].excludePlane.size();

    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg))

        return 1; // must return if datasize too big
    return 0;
}

#ifdef PINTGUI
Int SpectrumType::readData2Dmmap(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                             VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg)
{
    // read data for a group of peaks in (a set of) 2D spectra
    Int imin, jmin, imax, jmax;
    VecInt iopt(peak.size()), jopt(peak.size());
    Uint nArrReal = peak[0].arr.size() - peak[0].excludePlane.size();
    // Determine data size and allocate space. Return if too big
    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg)) return 1; // must return if datasize too big
    allocateVectors(yopt, f1,f2,f3,y,sig, peak.size()*nArrReal, sizecounter);

    Int realCnt = 1;
    sizecounter = 0;
    bool isBigEndian(true);
    union
    {
        uint32_t i;
        char c[4];
    } bigint = {0x01020304};

    if(bigint.c[0] != 1)
        isBigEndian=false;
    int endian(-1);
    int endianStart(3);
    if(isBigEndian) // Big endian byte ordering
    {
        endian = 1;
        endianStart = 0;
    }
    for (Int cnt=1; cnt <= (Int)specName.size(); cnt++, realCnt++) {

        if (skipExcludedPlane(peak, cnt, realCnt))
            continue;

        QFile fp(QString::fromStdString(specName[cnt-1].c_str()));
        if (!fp.open(QIODevice::ReadOnly)) {
            error_msg.push_back("Cannot open spectrum '" + specName[cnt-1] + "'");
            return 1;
        }
        const int page_size = sizeF1*sizeF2*sizeof(float);
        long off(0);
        off=2048; //skip header
        uchar *memory = fp.map(off,page_size);
        if(memory)
        {
            for (Int i=imin; i<imax; i++)
            {
                for (Int j=jmin; j<jmax; j++)
                {
                    int u((i*sizeF2+j)*sizeof(float));
                    union fConv
                    {
                        unsigned char buf[4];
                        float number;
                    }tt;
                    tt.buf[endianStart]= memory[u+3];
                    tt.buf[endianStart+endian]= memory[u+2];
                    tt.buf[endianStart+2*endian]= memory[u+1];
                    tt.buf[endianStart+3*endian]= memory[u];
                    float _y = tt.number;
                    Doub _F1 = (firstF1 + (i)*deltaF1)/obsF1;
                    Doub _F2 = (firstF2 + (j)*deltaF2)/obsF2;
                    for (Uint k=0; k<peak.size(); k++)
                        if (i == iopt[k] && j == jopt[k])
                            yopt[k*peak[0].arr.size()+realCnt-1] = _y;
                    for (Uint k=0; k<peak.size(); k++) {
                        Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                        if (radius <= 1.0) {
                            f1[sizecounter] = _F1;
                            f2[sizecounter] = _F2;
                            f3[sizecounter] = realCnt;
                            y[sizecounter] = (Doub) _y;
                            sig[sizecounter] = ((peak[k].centerWt - 1.)*radius + 1.)*noise;
                            sizecounter++;
                            break;
                        }
                    }
                }
            }
            fp.unmap(memory);
        }
        fp.close();
    }
    BigJ = jmax - jmin + 1;
    return 0;
}

Int SpectrumType::readData3Dmmap(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                             VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg)
{
    // read data for a group of peaks in a pseudo-3D spectrum
    Int imin, jmin, imax, jmax;
    VecInt iopt(peak.size()), jopt(peak.size());
    Uint nArr = peak[0].arr.size();
    Uint nArrReal = peak[0].arr.size() - peak[0].excludePlane.size();

    // Determine data size and allocate space. Return if too big request
    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg)) return 1; // must return if datasize too big
    allocateVectors(yopt, f1,f2,f3,y,sig, peak.size()*nArrReal, sizecounter);

    if(imin<0 || jmin<0)
    {
        error_msg.push_back("Peak "+peak[0].assi+" is outside of spectrum.");
        return 1;
    }
    // Read data - failure to open file should of course not happen at this stage
    QFile fp(QString::fromStdString(specName[0].c_str()));
    if (!fp.open(QIODevice::ReadOnly)) {
        error_msg.push_back("Cannot open spectrum '" + specName[0] + "'");
        return 1;
    }

    Uint realCnt = 1;
    sizecounter = 0;
    bool isBigEndian(true);
    union
    {
        uint32_t i;
        char c[4];
    } bigint = {0x01020304};

    if(bigint.c[0] != 1)
        isBigEndian=false;
    int endian(-1);
    int endianStart(3);
    if(isBigEndian) // Big endian byte ordering
    {
        endian = 1;
        endianStart = 0;
    }
    for (Uint cnt=1; cnt <= nArr; cnt++, realCnt++)
    {
        // Skip planes that should be excluded
        Bool flag = false;
        for (Uint kk=0; kk<peak[0].excludePlane.size() && !flag; kk++)
            if (cnt == (Uint)peak[0].excludePlane[kk]) {
                flag = true;
            }
        if (flag) {
            --realCnt;
            continue;
        }
        // Skip planes that should be excluded

        const int page_size = sizeF1*sizeF2*sizeof(float);
        long off(0);
        off=2048; //skip header
        off+= page_size*(cnt-1); //Skip planes if needed
        uchar *memory = fp.map(off,page_size);
        if(memory)
        {
            for (int i(imin); i<imax; ++i)
            {
                float _yvec[jmax-jmin];
                for(int v(0); v<jmax-jmin; ++v)
                {
                    union fConv
                    {
                        unsigned char buf[4];
                        float number;
                    }tt;
                    int u((i*sizeF2+jmin+v)*sizeof(float));
                    tt.buf[endianStart]= memory[u+3];
                    tt.buf[endianStart+endian]= memory[u+2];
                    tt.buf[endianStart+2*endian]= memory[u+1];
                    tt.buf[endianStart+3*endian]= memory[u];
                    _yvec[v] = tt.number;
                }
                for (int j=jmin; j<jmax; ++j)
                {
                    Doub _F1 = (firstF1 + (i)*deltaF1)/obsF1; // I am not exactly sure if these need be float
                    Doub _F2 = (firstF2 + (j)*deltaF2)/obsF2;
                    for (Uint k=0; k<peak.size(); k++)
                        if (i == iopt[k] && j == jopt[k])
                            yopt[k*nArrReal+realCnt-1] = _yvec[j-jmin];
                    for (Uint k=0; k<peak.size(); k++)
                    {
                        Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                        if (radius <= 1.0)
                        {
                            f1[sizecounter] = _F1;
                            f2[sizecounter] = _F2;
                            f3[sizecounter] = realCnt;
                            y[sizecounter] = (Doub) _yvec[j-jmin];
                            sig[sizecounter] = ((peak[k].centerWt - 1.)*radius + 1.)*noise;
                            sizecounter++ ;
                            break;
                        }
                    }
                }
            }
            fp.unmap(memory);
        }
    }
    fp.close();
    BigJ = jmax - jmin + 1;
    return 0;
}

Int SpectrumType::readData3DTopspinmmap(PeakListType_IO &peak, VecDoub &f1, VecDoub &f2, VecInt &f3, VecDoub &y, VecDoub &sig, \
                                    VecDoub &yopt, Int &BigJ, Llong maxdata, VecString &error_msg)
{
    // read data for a group of peaks in a pseudo-3D spectrum

    Int imin, jmin, imax, jmax;
    VecInt iopt(peak.size()), jopt(peak.size());
    //Uint nArr = peak[0].arr.size();
    Uint nArrReal = peak[0].arr.size()- peak[0].excludePlane.size();

    // Determine data size and allocate space. Return if too big request
    getRegionOL(peak, imin, imax, jmin, jmax, iopt, jopt);
    Int sizecounter = getDataSize(peak, imin, imax, jmin, jmax, nArrReal);
    if (checkDataSize(peak, sizecounter, maxdata, error_msg)) return 1; // must return if datasize too big
    allocateVectors(yopt, f1,f2,f3,y,sig, peak.size()*nArrReal, sizecounter);
    yopt = VecDoub(peak.size()*nArrReal);

    // Read data - failure to open file should of course not happen at this stage
    FILE *fp;
    if (!(fp = fopen((specName[0]+"/3rrr").c_str(), "rb"))) {
        error_msg.push_back("Cannot open spectrum '" + specName[0] + "/3rrr'");
        return 1;
    }
    char *buf = NULL;
    setvbuf(fp, buf, _IONBF, 0);
    int submatrixF1 = sizeF1/xDimF1;
    int submatrixF2 = sizeF2/xDimF2;
    Uint realCnt = 1;
    sizecounter = 0;
    for (int cnt=1; cnt <= (int) nPlane; cnt++, realCnt++) {
        int countingF2(0);

        // Skip planes that should be excluded
        Bool flag = false;
        for (Uint kk=0; kk<peak[0].excludePlane.size() && !flag; kk++)
            if (cnt == (int)peak[0].excludePlane[kk]) {
                flag = true;
            }
        if (flag) {
            --realCnt;
            continue;
        }
        // Skip planes that should be excluded
        int a;
        int planeSkip  = (cnt-1)*xDimF2*xDimF1 + (int)((floor)((double)((double)(cnt-1)/(double)xDimF3)))
                * (-xDimF3*xDimF2*xDimF1 + xDimF1*xDimF2*xDimF3*submatrixF2*submatrixF1);
        int b((xDimF1*xDimF2*xDimF3-xDimF2));
        int c(xDimF2 - xDimF2*xDimF1*xDimF3*submatrixF2);
        int d(sizeF2*xDimF1);
        int e((xDimF1*xDimF2*xDimF3*submatrixF2 - xDimF1*xDimF2));
        int ii(0);
        int jj(0);
        for (int i=0; i < sizeF1*sizeF2; ++i)
        {
            int v = planeSkip + i + (int)((floor)((double)((double)i/(double)xDimF2))) * b
                    + (int)((floor)((double)((double)i/(double)sizeF2))) * c
                    + (int)((floor)((double)((double)i/(double)d))) * e;
            if(jj==sizeF2)
                jj=0;
            else
                ++jj;
            if(jj==sizeF2)
                ++ii;
            if(ii<imin || ii>=imax || jj<jmin || jj>=jmax)
            {
                countingF2++;
                if(countingF2==sizeF2)
                {
                    i+=(sizeF2-1)-(countingF2);
                    countingF2=0;
                }
                continue;
            }
            fseek(fp, v*4, 0);
            fread(&a, sizeof(int), 1, fp);
            Doub _F1 = (firstF1 + ((Int)ii)*deltaF1)/obsF1;
            Doub _F2 = (firstF2 + ((Int)jj)*deltaF2)/obsF2;
            Doub b = (Doub)((Doub) a * (Doub)pow(2.0,(Doub)nc_proc)+0.5); //Compensate for the 2^N Bruker scaling factor
            for (Uint k=0; k<peak.size(); k++)
                if (ii == iopt[k] && jj == jopt[k])
                    yopt[k*nArrReal+realCnt-1] = b;
            for (Uint k=0; k<peak.size(); k++)
            {
                Doub radius = sqrt(SQR((_F1-peak[k].appF1)/peak[k].radF1) + SQR((_F2-peak[k].appF2)/peak[k].radF2));
                if (radius <= 1.0)
                {
                    f1[sizecounter]=_F1;
                    f2[sizecounter]=_F2;
                    f3[sizecounter]=realCnt;
                    y[sizecounter]=b;
                    sig[sizecounter]=((peak[k].centerWt - 1.)*radius + 1.)*noise;
                    sizecounter++;
                    break;
                }
            }
            countingF2++;
            if(countingF2==sizeF2)
            {
                i+=(sizeF2-1)-(countingF2);
                countingF2=0;
            }
        }
    }
    fclose(fp);

    BigJ = jmax - jmin + 1;
    return 0;
}
#endif
