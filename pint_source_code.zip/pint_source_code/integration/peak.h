#ifndef _PEAK
#define _PEAK

#include "pint.h"

struct ParserType;
struct SpectrumType;

struct InitialGuess {
    Doub lwF1, lwF2;
    Doub radF1, radF2;

    InitialGuess();
    InitialGuess(Doub _lwF1, Doub _lwF2, Doub _radF1, Doub _radF2);
};


// Override default two doubles
struct OTwoDoubType {
    string assi;
    Doub d1;
    Doub d2;

    OTwoDoubType();
    OTwoDoubType(string wd1, string wd2, string wd3);
};

// Override default one double and one int
struct ODoubIntType {
    string assi;
    Doub d;
    Int i;

    ODoubIntType();
    ODoubIntType(string wd1, string wd2, string wd3);
};

struct DoubIntType {
    Doub dbl;
    Int integ;

    DoubIntType();
    DoubIntType(Doub _d, Int _i);
    DoubIntType(string _d, string _i);

};

struct OjcoupType {
    string assi;
    vector<DoubIntType> jcoup;

    OjcoupType();
    OjcoupType(string _assi);
};



// Override default lineshape
struct OIntModeType {
    string assi;
    Int intMode;
    void   (*funcs)(const Doub f1, const Doub f2, const Int f3, VecDoub &a, Doub &y, \
                    VecDoub_O &dyda, const Int nOL, const Int nArr); /*  lineshape derivatives */
    Doub (*funcscore)(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr);  /* lineshape w/o derivatives */

    OIntModeType();
    OIntModeType(string wd1, string wd2);

    Int setIntMode(string wd1, string wd2, VecString &error_msg);
};

// Override default plane to exclude
struct OExcludeType {
    string assi;
    VecInt planeToExclude;

    OExcludeType();
};

// Override some double setting
struct ODoubleType {
    string assi;
    Doub val;

    ODoubleType();
    ODoubleType(string wd1, string wd2);
};



struct OverRideType {
    vector<OTwoDoubType> ORadVec;
    vector<OTwoDoubType> OlwVec;
    vector<OTwoDoubType> OMaxlwVec;
    vector<OTwoDoubType> OMinlwVec;
    vector<OTwoDoubType> OMaxMoveVec;
    vector<OIntModeType> intModeVec;
    vector<ODoubleType>  OcenterWtVec;
    vector<OExcludeType> OExclude;
    vector<OjcoupType> OjcouplingF1;
    vector<OjcoupType> OjcouplingF2;
    vector<ODoubleType> OexpDecayRate;
    vector<ODoubleType> OexpIntercept;
    vector<ODoubleType> OIntercept;
    vector<ODoubleType> OSlope;
    vector<ODoubleType> OConstant;
    vector<ODoubleType> OexpoffsR12;
    vector<ODoubleType> OexpoffsA12;
    vector<ODoubleType> OexpoffsOffset;
    vector<ODoubleType> OsatrecR1;
    vector<ODoubleType> OsatrecPlateau;
    vector<ODoubleType> OinvrecR1;
    vector<ODoubleType> OinvrecPlateau;
    vector<ODoubleType> OBExp1;
    vector<ODoubleType> OBExp2;
    vector<ODoubleType> OBExpA1;
    vector<ODoubleType> OBExpA2;
    vector<ODoubleType> OOffset;
    vector<ODoubleType> OKex;
    vector<ODoubleType> OPB;
    vector<ODoubleType> ODW;
    vector<ODoubleType> OR20;
    vector<ODoubleType> OTanh;
    VecString OFixPosVec;
    VecString OFixLWVec;
    VecString OFixKex;
    VecString OFixPb;
    VecString OJack;
    VecString OBoot;
    VecString OMonteCarlo;
    vector<OTwoDoubType> OvoigtLorlwVec;
    vector<OTwoDoubType> OvoigtGausslwVec;
    vector<OTwoDoubType> OgaloreLorVec;
};

typedef const OverRideType OverRideType_I;
typedef OverRideType OverRideType_IO, OverRideType_O;


// peak type
struct PeakType {

// input
    string assi;            // assignment (column 1 from peak list)
    Doub f1, f2;			// input freq. (ppm) [ columns 2 and 3 in peak list ]
    Doub appF1, appF2;	    // input freq. corrected for folding (ppm) [ where peaks appear in spectrum ]
    Int   foldF1, foldF2;   // number of times peak has been folded
    VecDoub arr;            // number of planes in 3rd dimension

// lineshape fit parameters
    Doub lwF1_in, lwF2_in;  // input linewidths (ppm)
    Doub radF1, radF2;		// integration area (ppm)
    Int  intMode;
    Int  nData;
    Int  nOL;
    Bool OLmarker;           // true if peak is overlapped. Only used for for '-overlap auto' option
    Bool fixPos; // fix peak position during, or first fix and fit, then free and refit (latter not implemented)
    Bool  fixLW;   // fix peak line width during, or first fix and fit, then free and refit (neither implemented)
    VecInt excludePlane;
    Doub maxlwF1, maxlwF2;      // Max allowed linewidth to acceptfit
    Doub minlwF1, minlwF2;      // Min allowed linewidth to acceptfit
    Doub maxMoveF1, maxMoveF2;  // Max allowed peak momvement to accept fit
    Doub centerWt;              // Set different from one to emphasize center of peak more in fitting
    Doub galoreLorF1_in, galoreLorF2_in;  // Lorentzian and gaussian line width for galore
    Doub voigtLorF1_in, voigtLorF2_in;  // Lorentzian line width for voigt
    Doub voigtGaussF1_in, voigtGaussF2_in;  // Gaussian line width for voigt
    Bool noiseUncertainty;

// output
    Doub ppmF1, ppmF2;      // output frequencies (ppm)
    Doub lwF1, lwF2;		// output linewidths (Hz)
    Doub galoreLorF1, galoreLorF2;  // Lorentzian and gaussian line width for galore
    Doub voigtLorF1, voigtLorF2;  // Lorentzian and gaussian line width for voigt
    Doub voigtGaussF1, voigtGaussF2;  // Lorentzian and gaussian line width for voigt
    VecDoub intensity;            // vector with all intensities
    VecDoub vol;            // vector with all volumes
    Doub esd;               // uncertainty in peak intensity
    Doub dvol;               // uncertainty in peak volumes
    Doub chi2;              // chi2 in fitting
    Int  dof;               // degrees of freedom in fit
    Bool  readFlag;          // peak intensities have been read
    Bool  fitFlag;           // peak has been fitted
    Int  convFlag;          // fitting converged, this cannot be Bool because there are several possibilities
    string resNo;           // residue number if we can construct it from assi

// downstream fitting
    Int  fitConstant;
    Int  fitLin;
    Int  fitExp;
    Int  fitBiExp;
    Int  fitExpOffset;
    Int  fitR1rho;
    Int  fitNOE;
    Int  fitTanh;
    Int  fitCPMG;
    Int  fitInvRecovery;
    Int  fitSatRecovery;
    Doub  R1, dR1;                              // R1 read from a file, defaulted to zero
    Doub  R12, dR12;                            // fitted exponential decay rate
    Doub  A12, dA12;                            // fitted intercept for fitted exponential decay
    Doub  expoffsR12, dexpoffsR12;              // fitted exponential decay rate
    Doub  expoffsA12, dexpoffsA12;              // fitted intercept for fitted exponential decay
    Doub  expoffsOffset, dexpoffsOffset;        // fitted intercept for fitted exponential decay
    Doub  invrecR1, dinvrecR1;                  // fitted R1 for inversion recovery
    Doub  invrecPlateau, dinvrecPlateau;        // fitted plateau for inversion recovery
    Doub  satrecR1, dsatrecR1;                  // fitted R1 for saturation recovery
    Doub  satrecPlateau, dsatrecPlateau;        // fitted plateau for saturation recovery
    Doub  offs, dOffs;                          // fitted offset for exponential decay w/ offset
    Doub  BExp1, dBExp1;                        // fitted rate constant for first exponential in biexponetial fit
    Doub  BExp2, dBExp2;                        // fitted rate constant for second exponential in biexponetial fit
    Doub  BExpA1, dBExpA1;                      // fitted prefaactor for first term in bioesponetial fit
    Doub  BExpA2, dBExpA2;                      // fitted prefaactor for second term in bioesponetial fit
    Doub  R2, dR2;                              // calculated R2 from R1rho and R1
    Doub  intercept, dintercept;                // fitted intercept for linear fit
    Doub  slope, dslope;                        // fitted slope for linear fit
    Doub  constant, dconstant;                  // fitted intercept for constant function
    Doub  NOE, dNOE;                            // calculated heteronuclear NOE
    Doub  R20, dR20;                            // fitted R2,0 (CPMG)
    Doub  kex, dkex;                            // fitted kex (CPMG)
    Doub  pB, dpB;                              // fitted pB (CPMG)
    Doub  R2noex, dR2noex;                      // fitted R2 for a model w/o exchange (CPMG)
    Doub  Dw, dDw;                              // fitted delta omega (CPMG)
    Doub  rmsdCpmg;                             // rmsd from straight line in cpmg fit
    Bool  fixKex;								// fix kex and pb to guessed value
    Bool  fixPb;								// fix kex and pb to guessed value
    Doub  fstat, pval;                          // for CPMG
    Doub  chi2Constant, chi2Lin, chi2Exp, chi2BiExp, chi2ExpOffs, chi2Tanh, chi2Const, chi2Cpmg, chi2InvRecovery, chi2SatRecovery;
    Int   fjack, fboot, fmc;
    void   (*funcs)(const Doub f1, const Doub f2, const Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr); /* lineshape w/ derivatives */
    Doub (*funcscore)(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr);  /* lineshape w/o derivatives */

    PeakType();

    Int setFromParser(const PeakType &p, VecDoub_I arr, Int nPlane, Bool spectrumOK, OverRideType_I &OR, VecString &error_msg);

    void setFromParser(const PeakType &p, OverRideType_I &OR, VecString &error_msg);

    Int setIntMode(Int _intMode, VecString &error_msg);

    void setPeakRadius(Doub _radF1, Doub _radF2);

    void setPeakRadius(const PeakType &p, const vector<OTwoDoubType> &ORad);

    void setPeakLineWidth(Doub f1, Doub f2);

    void setPeakLineWidth(const PeakType &p, const vector<OTwoDoubType> &OLW);

    void setPeakNoiseUncertainty(const PeakType &p);

    void setPeakMaxLineWidth(Doub _maxlwF1, Doub _maxlwF2);

    void setPeakMinLineWidth(Doub _minlwF1, Doub _minlwF2);

    void setPeakMaxLineWidth(const PeakType &p, const vector<OTwoDoubType> &OLW);

    void setPeakMinLineWidth(const PeakType &p, const vector<OTwoDoubType> &OLW);

    void setPeakVoigtLorentzianLineWidth(const PeakType &p, const vector<OTwoDoubType> &OLW);

    void setPeakVoigtGaussianLineWidth(const PeakType &p, const vector<OTwoDoubType> &OLW);

    void setPeakGaloreLorentzian(const PeakType &p, const vector<OTwoDoubType> &OgaloreLor);

    void setPeakMaxMovement(Doub _maxMoveF1, Doub _maxMoveF2);

    void setPeakMaxMovement(const PeakType &p, const vector<OTwoDoubType> &OLW);

    void setCenterWt(const PeakType &p, const vector<ODoubleType> &OCW);

    Int setPlaneToExclude(const PeakType &peak, const vector<OExcludeType> &oex, const Int nPlane, VecString &error_msg); // -define

    Int setPlaneToExclude(VecInt_I &planeToExclude, const Int nPlane, VecString &error_msg); //global

    void constructResNo();

    void setPeakFixPos(const PeakType &p, VecString_I &fixvec);

    void setPeakFixLW(const PeakType &p, VecString_I &fixvec);

    void setPeakEsd(const PeakType &p, VecString_I &OJack,  VecString_I &OBoot,  VecString_I &OMonteCarlo);

    void setPeakIntMode(const Int defaulty, const vector<OIntModeType> &iMode, VecString &error_msg);

    void setFitConstant(Int _fitConstant, Doub _intercept, const vector<ODoubleType> &ointercept) ;

    void setFitLin(Int _fitLin, Doub _intercept, Doub _slope, const vector<ODoubleType> &ointercept, const vector<ODoubleType> &oslope) ;

    void setFitExp(Int _fitExp, Doub _r12, Doub _a, const vector<ODoubleType> &odr, const vector<ODoubleType> &oa) ;

    void setFitBiExp(Int _fitBiExp, Doub _exp1, Doub _exp2, Doub _icept1, Doub _icept2, const vector<ODoubleType> &oexp1, \
                     const vector<ODoubleType> &oexp2, const vector<ODoubleType> &oicept1, const vector<ODoubleType> &oicept2) ;

    void setFitInvRecovery(Int _fitInvRec, Doub _r12, Doub _offs, const vector<ODoubleType> &odr, const vector<ODoubleType> &ooffs) ;

    void setFitSatRecovery(Int _fitSatRec, Doub _r12, Doub _offs, const vector<ODoubleType> &odr, const vector<ODoubleType> &ooffs) ;

    void setFitExpOffset(Int _fitExpOffset, Doub _r12,  Doub _a, Doub _offs, const vector<ODoubleType> &odr,
                         const vector<ODoubleType> &oa, const vector<ODoubleType> &oo);

    void setFitR1rho(Int _fitR1rho, Doub _r12, Doub _a, const vector<ODoubleType> &odr, const vector<ODoubleType> &oa) ;

    void setFitCPMG(const PeakType &p, const vector<ODoubleType> &okex,
                    const vector<ODoubleType> &opb, const vector<ODoubleType> &odw,
                    const vector<ODoubleType> &or20, VecString_I &ofixkex, VecString_I &ofixpb);

    void fold(Int sizeF1, Int sizeF2, Doub swF1, Doub swF2, Doub obsF1, Doub obsF2, Int &iopt, Int &jopt) ;

    inline Int checkIllegalName(VecString &error_msg);

    inline Int setArray(VecDoub_I &_arr, Uint nPlane, Bool spectrum_OK);

    Int readR1(const string &r1ListName, VecString &error_msg, VecString &info_msg);

    inline void setEsd(Doub _esd);

    inline void setFitNOE(Int _fitNOE);

    Bool IgnoreLines(VecString_I &word);

    ~PeakType();
};

typedef const PeakType PeakType_I;
typedef PeakType PeakType_IO, PeakType_O;

typedef const vector<PeakType> PeakListType_I;
typedef vector<PeakType> PeakListType, PeakListType_IO, PeakListType_O;

typedef const vector<PeakListType> ListofPeakListType_I;
typedef vector<PeakListType> ListofPeakListType, ListofPeakListType_IO, ListofPeakListType_O;


Int readPeaks(PeakListType &peak, const ParserType &parser, const SpectrumType &spectrum, VecString &error_msg);

void listPeaks(PeakListType &peak, string outDir, VecString_IO &error_msg);

Int readPeak(PeakType &peak, const string &fname) ;

Int readR1List(const string &r1ListName, PeakListType &peak, VecString &error_msg);
#ifdef PINTGUI
Int autoOverLapPeaks(PeakListType &peak, ListofPeakListType &group,
                      const string &outDir, VecString &error_msg, bool &overlapOverload);
#else
Int autoOverLapPeaks(PeakListType &peak, ListofPeakListType &group,
                      const string &outDir, VecString &error_msg);
#endif
void overlapLoop(PeakListType &peak, Uint i, Uint j, PeakListType &group);

Doub checkOverlap(PeakListType_I &peak, Int i, Int j);

Doub overlapfunc(Doub x1, Doub a1, Doub x2, Doub a2, Doub y1, Doub b1, Doub y2, Doub b2, Doub theta);

Doub zbrentOverlap(Doub (*func)(Doub, Doub, Doub, Doub, Doub, Doub, Doub, Doub, Doub), const Doub x1,
                   const Doub x2, const Doub F1ppm1, const Doub F1rad1, const Doub F1ppm2,
                   const Doub F1rad2, const Doub F2ppm1, const Doub F2rad1, const Doub F2ppm2,
                   const Doub F2rad2);

void readGroup(PeakListType &group, VecString &word) ;

Int fillInGroups(PeakListType_I &peak, ListofPeakListType &group, VecString &error_msg);

Int getPeaksToFit(PeakType_I &peak, ListofPeakListType &group, PeakListType &peakToFit);

Int checkPeaks(PeakListType &peak, ListofPeakListType &group, VecString &error_msg);

Bool IgnoreLines(VecString_I &word);

Bool isPlaneExcluded(PeakType_I &peak, const Int &plane);


#endif
