// output.cpp


#include "peak.h"
#include "parser.h"
#include "spectrum.h"
#include "fitfunctions.h"
#include "fitmrq.h"
#include "sort.h"
#include "ftest.h"
#include "output.h"
#ifdef PINTGUI
#include "cancelvar.h"
#endif

#define PRECISION 6

OutputType::OutputType() {}

OutputType::OutputType(const string &_outDir, const ParserType &parser, const SpectrumType &spec) :
    outDir(_outDir),

    invert(parser.invert),
    listByResNo(parser.resno),
    sort(parser.sort),

    time_T2(parser.time_T2),

    timeFactor(parser.timeFactor),

    b1(parser.b1),
    db1(parser.db1),
    r1rhoDim(parser.r1rhoDim),

    obsF1(spec.obsF1),
    obsF2(spec.obsF2),
    carrierPPM(parser.carrierPPM),
    carrierMHz(parser.r1rhoDim == 1? spec.obsF1 : spec.obsF2),
    noise(spec.noise),

    biexpListFlag(false),
    constListFlag(false),
    cpmgListFlag(false),
    expListFlag(false),
    expOffsetListFlag(false),
    invRecoveryListFlag(false),
    linListFlag(false),
    NOElistFlag(false),
    r2ListFlag(false),
    satRecoveryListFlag(false),

    chi2ListFlag(false),
    linewidthListFlag(false),
    peakListFlag(false),
    trosy(parser.trosy),
    initFail(true),
    noIntegration(parser.noIntegration),

    peakToNotReport(parser.peakToNotReport)
{
}

Int OutputType::printResult(PeakListType &peak, VecString &error_msg)
{
    setListNames();

    for (auto &_peak : peak) {
#ifdef PINTGUI
        extern bool cancelVar;
        if(cancelVar)
            return 1;
#endif

        if (_peak.convFlag)
            printFailedFits(_peak.convFlag, _peak.assi, error_msg);
        else if (std::find(peakToNotReport.begin(), peakToNotReport.end(), _peak.assi) == peakToNotReport.end())  {
            setPeakFileNames(_peak.assi);
            if (!noIntegration)
                printVol(_peak, error_msg);
            printDownStreamFitting(_peak, error_msg);
        }
    }
    return 0;
}

void OutputType::setListNames() {
    peakListName =  outDir + "/peaklist.txt";
    linewidthListName =  outDir + "/linewidth.txt";
    failName =  outDir + "/error.txt";
    linListName = outDir + "/linfit.txt";
    constListName = outDir + "/constfit.txt";
    expListName = outDir + "/expfit.txt";
    biexpListName = outDir + "/biexpfit.txt";
    expOffsetListName = outDir + "/expoffsetfit.txt";
    r2ListName = outDir + "/R2.txt";
    NOElistName = outDir + "/noe.txt";
    invRecoveryListName = outDir + "/invrecovery.txt";
    satRecoveryListName = outDir + "/satrecovery.txt";
    cpmgListName = outDir + "/cpmg.txt";
    pbListName = outDir + "/pb.txt";
    kexListName = outDir + "/kex.txt";
    deltaOmegaListName = outDir + "/deltaomega.txt";
    r20ListName = outDir + "/R2infinity.txt";
    ftestListName = outDir + "/ftest.txt";
    rmsdListName = outDir + "/rmsd.txt";
    chi2ListName = outDir + "/chi2.txt";
    jcoupListName = outDir + "/jcoup.txt";
    relVolListName = outDir + "/fracvol.txt";
    paramListName = outDir + "/parameters.txt";
    sortKeyName = outDir + "/sortkey.txt";
}

void OutputType::setPeakFileNames(string assi)
{
    string dummy = outDir + "/" + assi;
    outName = dummy + ".out";
    cpmgName = dummy + ".cpmg";
    R12Name = dummy + ".exp";
    constName = dummy + ".const";
    linName = dummy + ".lin";
    biexpName = dummy + ".biexp";
    expOffsetName = dummy + ".expoffs";
    noeName = dummy + ".noe";
    invRecoveryName = dummy + ".invrec";
    satRecoveryName = dummy + ".satrec";
}


void OutputType::printDownStreamFitting(PeakType &peak, VecString &error_msg)
{
    if (peak.fitCPMG) printCpmg(peak);
    if (peak.fitConstant) printConstant(peak, error_msg);
    if (peak.fitLin) printLin(peak, error_msg);
    if (peak.fitExp) printExp(peak, error_msg);
    if (peak.fitBiExp) printBiExp(peak, error_msg);
    if (peak.fitExpOffset) printExpOffset(peak, error_msg);
    if (peak.fitR1rho) printR1rho(peak, error_msg);
    if (peak.fitNOE) printNOE(peak, error_msg);
    if (peak.fitSatRecovery) printSatRecovery(peak, error_msg);
    if (peak.fitInvRecovery) printInvRecovery(peak, error_msg);
}

void OutputType::printLists(PeakListType_I &peak, VecString &error_msg)
{
    OutputType::setListNames();

    Bool flag;

    for (auto &_peak : peak)
    {
#ifdef PINTGUI
        extern bool cancelVar;
        if(cancelVar)
            return;
#endif
        if (!_peak.convFlag) {
            flag = false;
            for (auto _peakToNotReport : peakToNotReport)
                if (_peak.assi == _peakToNotReport)
                    flag = true;
            if (flag)
                continue;
            if (_peak.fitCPMG) printCpmgList(_peak);
            if (_peak.fitConstant) printConstantFitList(_peak, error_msg);
            if (_peak.fitLin) printLinFitList(_peak, error_msg);
            if (_peak.fitExp) printExpFitList(_peak, error_msg);
            if (_peak.fitBiExp) printBiExpFitList(_peak, error_msg);
            if (_peak.fitExpOffset) printExpOffsetFitList(_peak, error_msg);
            if (_peak.fitR1rho) printR2FitList(_peak, error_msg);
            if (_peak.fitNOE) printNOElist(_peak, error_msg);
            if (_peak.fitSatRecovery) printSatRecoveryFitList(_peak, error_msg);
            if (_peak.fitInvRecovery) printInvRecoveryFitList(_peak, error_msg);

            printPeakList(_peak, error_msg);
            printLineWidthList(_peak, error_msg);
            printChi2List(_peak, error_msg);
        }
        else
            OutputType::printFailedFits(_peak.convFlag, _peak.assi, error_msg);
    }
}


void OutputType::printFailedFits(Int convFlag, const string &assi, VecString &error_msg)
{
    ofstream failFile;
    if (initFail) {
        failFile.open(failName.c_str());
        if (!failFile) {
            string s = "ERROR: Cannot write to file '" + failName + "'";
            error_msg.push_back(s);
        }
        failFile << "#Failed fits for the following peaks\n";
        failFile << "#-----------------------------------\n";
        initFail = false;
    }
    else
        failFile.open(failName.c_str(), ios::app);
    if (convFlag == 1) failFile <<  assi << "\tError code 1: No convergence\n";
    if (convFlag == 3) failFile <<  assi << "\tError code 2: Too much peak movement in F1\n";
    if (convFlag == 4) failFile <<  assi << "\tError code 3: Too much peak movement in F2\n";
    if (convFlag == 5) failFile <<  assi << "\tError code 4: Too large line width in F1\n";
    if (convFlag == 6) failFile <<  assi << "\tError code 5: Too large line width in F2\n";
    if (convFlag == 7) failFile <<  assi << "\tError code 6: Too small line width in F1\n";
    if (convFlag == 8) failFile <<  assi << "\tError code 7: Too small line width in F2\n";
}


void OutputType::copyData(const PeakType &peak, VecDoub &x, VecDoub &y, VecDoub &sig)
{
    x.resize(peak.arr.size()-peak.excludePlane.size());
    y.resize(peak.arr.size()-peak.excludePlane.size());
    sig.resize(peak.arr.size()-peak.excludePlane.size());
    Int j=0;
    for (Uint i=0; i<peak.arr.size(); ++i, ++j) {
        Bool flag = false;
        for (Uint k=0; k<peak.excludePlane.size() && !flag; ++k)
            flag = (Uint)peak.excludePlane[k] == i+1;
        if (flag)
            --j;
        else {
            x[j] = peak.arr[i];
            y[j] = peak.intensity[i];
            sig[j] = peak.esd>0.? peak.esd : noise;
        }
    }
}

void multiplyWithTimeFactorAndSort(VecDoub &x, VecDoub &y, VecDoub &sig, Doub timeFactor)
{
    for (auto &_x : x)
        _x *= timeFactor;
    sort3(x, y, sig);
}



void OutputType::FitConstant(PeakType &peak)
{
    if (peak.fitConstant) {

        copyData(peak, x, y, sig);
        multiplyWithTimeFactorAndSort(x, y, sig, timeFactor);

        VecDoub a(1);
        VecBool ia(1, true);
        a[0] = peak.constant;
        Fitmrq fitmrq(x, y, sig, a, ia, constant);
        fitmrq.fit();
        peak.constant = fitmrq.a[0];
        peak.chi2Constant = fitmrq.chisq;

        ErrorSim errSim(x, y, sig, fitmrq.a, ia, constant);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);
        peak.dconstant = errSim.simerr[0];
    }
}

void OutputType::FitLin(PeakType &peak)
{
    if (peak.fitLin) {

        copyData(peak, x, y, sig);
        multiplyWithTimeFactorAndSort(x, y, sig, timeFactor);

        VecDoub a(2);
        VecBool ia(2, true);
        a[0] = peak.intercept;
        a[1] = peak.slope;
        Fitmrq fitmrq(x, y, sig, a, ia, linear);
        fitmrq.fit();
        peak.intercept = fitmrq.a[0];
        peak.slope = fitmrq.a[1];
        peak.chi2Lin = fitmrq.chisq;

        ErrorSim errSim(x, y, sig, fitmrq.a, ia, linear);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);
        peak.dintercept = errSim.simerr[0];
        peak.dslope = errSim.simerr[1];
    }
}

void OutputType::FitExp(PeakType &peak)
{
    if ((peak.fitExp || peak.fitR1rho)) {

        copyData(peak, x, y, sig);
        multiplyWithTimeFactorAndSort(x, y, sig, timeFactor);

        VecDoub a(2);
        VecBool ia(2, true);
        a[0] = y[0];
        if (y[0]*y.back() > 0.)
            a[1] = log(y[0]/y.back())/(x.back()-x[0]);
        else
            a[1] = -peak.R12;
        Fitmrq fitmrq(x, y, sig, a, ia, exponential);
        fitmrq.fit();
        a = fitmrq.a;
        ErrorSim errSim(x, y, sig, fitmrq.a, ia, exponential);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);

        peak.A12 = a[0];
        peak.R12 = -a[1];
        peak.chi2Exp = fitmrq.chisq;
        peak.dA12 = errSim.simerr[0];
        peak.dR12 = errSim.simerr[1];
    }
}

void OutputType::FitBiExp(PeakType &peak)
{
    if (peak.fitBiExp) {

        copyData(peak, x, y, sig);
        multiplyWithTimeFactorAndSort(x, y, sig, timeFactor);

        VecDoub a(4);
        VecBool ia(4, true);
        a[0] = peak.BExpA1;
        a[1] = peak.BExp1;
        a[2] = peak.BExpA2;
        a[3] = peak.BExp2;

        Fitmrq fitmrq(x, y, sig, a, ia, biexponential);
        fitmrq.fit();
        peak.BExpA1 = fitmrq.a[0];
        peak.BExp1 = fitmrq.a[1];
        peak.BExpA2 = fitmrq.a[2];
        peak.BExp2 = fitmrq.a[3];
        peak.chi2BiExp = fitmrq.chisq;

        ErrorSim errSim(x, y, sig, fitmrq.a, ia, biexponential);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);
        peak.dBExpA1 = errSim.simerr[0];
        peak.dBExp1 = errSim.simerr[1];
        peak.dBExpA2 = errSim.simerr[2];
        peak.dBExp2 = errSim.simerr[3];
    }
}

void OutputType::FitInvRecovery(PeakType &peak)
{
    if (peak.fitInvRecovery) {

        copyData(peak, x, y, sig);
        multiplyWithTimeFactorAndSort(x, y, sig, timeFactor);

        VecDoub a(2);
        VecBool ia(2, true);
        if (peak.invrecPlateau != 0.)
            a[0] = peak.invrecPlateau;
        else
            a[0] = y.back();
        if (peak.invrecR1 != 0.)
            a[1] = -peak.invrecR1;
        else
            a[1] = -1.;
        Fitmrq fitmrq(x, y, sig, a, ia, invrecover);
        fitmrq.fit();
        peak.invrecPlateau = fitmrq.a[0];
        peak.invrecR1 = -fitmrq.a[1];
        peak.chi2InvRecovery = fitmrq.chisq;

        ErrorSim errSim(x, y, sig, fitmrq.a, ia, invrecover);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);
        peak.dinvrecPlateau = errSim.simerr[0];
        peak.dinvrecR1 = errSim.simerr[1];
    }
}

void OutputType::FitSatRecovery(PeakType &peak)
{
    if (peak.fitSatRecovery) {

        copyData(peak, x, y, sig);
        multiplyWithTimeFactorAndSort(x, y, sig, timeFactor);

        VecDoub a(2);
        VecBool ia(2, true);
        if (peak.satrecPlateau != 0.)
            a[0] = peak.satrecPlateau;
        else
            a[0] = y.back();
        if (peak.satrecR1 != 0.)
            a[1] = -peak.satrecR1;
        else
            a[1] = -1.;
        Fitmrq fitmrq(x, y, sig, a, ia, satrecover);
        fitmrq.fit();
        peak.satrecPlateau = fitmrq.a[0];
        peak.satrecR1 = -fitmrq.a[1];
        peak.chi2SatRecovery = fitmrq.chisq;

        ErrorSim errSim(x, y, sig, fitmrq.a, ia, satrecover);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);
        peak.dsatrecPlateau = errSim.simerr[0];
        peak.dsatrecR1 = errSim.simerr[1];
    }
}

void OutputType::FitExpOffset(PeakType &peak)
{
    if (peak.fitExpOffset) {

        copyData(peak, x, y, sig);
        multiplyWithTimeFactorAndSort(x, y, sig, timeFactor);

        VecDoub a(3);
        VecBool ia(3, true);
        a[0] = y[0];
        a[1] = -peak.expoffsR12;
        a[2] = y.back();
        Fitmrq fitmrq(x, y, sig, a, ia, expoffset);
        fitmrq.fit();
        peak.expoffsA12 = fitmrq.a[0];
        peak.expoffsR12 = -fitmrq.a[1];
        peak.expoffsOffset = fitmrq.a[2];
        peak.chi2ExpOffs = fitmrq.chisq;

        ErrorSim errSim(x, y, sig, fitmrq.a, ia, expoffset);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);
        peak.dexpoffsA12 = errSim.simerr[0];
        peak.dexpoffsR12 = errSim.simerr[1];
        peak.dexpoffsOffset = errSim.simerr[2];
    }
}


void OutputType::CalcR2(PeakType &peak)
{
    // includes trosy correction if specified. In general it should
    // not matter much but it is better to be as accurate as possible.
    // a J-coupling of JCOUP Hz is supposed

    const Doub JCOUP = 92.0;

    Doub beff2, offs, sin2theta, tan2theta;
    if (r1rhoDim == 1) {
        if (!trosy)
            offs = (peak.ppmF1-carrierPPM)*carrierMHz;
        else
            offs = (peak.ppmF1-JCOUP/2./carrierMHz-carrierPPM)*carrierMHz;
    }
    else {
        if (!trosy)
            offs = (peak.ppmF2-carrierPPM)*carrierMHz;
        else
            offs = (peak.ppmF2+JCOUP/2./carrierMHz-carrierPPM)*carrierMHz;
    }
    beff2 = SQR(offs) + SQR(b1);
    sin2theta = SQR(b1)/beff2;
    tan2theta = SQR(b1)/SQR(offs);
    peak.R2 = peak.R12/sin2theta - peak.R1/tan2theta;
    peak.dR2 = sqrt(SQR(peak.dR12/sin2theta) + SQR(peak.dR1/tan2theta));
}


Int OutputType::FitCR(PeakType &peak, VecDoub &nu_cpmg, VecDoub &y, VecDoub &sig, VecDoub &cpmgFit)
{
    VecDoub _x, _y, _sig;
    Int j=0;
    Doub y_naught; // intensity w/ time_T2=0 if that point exists, otherwise largest intensity

    copyData(peak, _x, _y, _sig);
    sort3(_x, _y, _sig);

    y_naught = _y[0];
    if (_x[0] != 0.)
        for (Uint i=0; i<_y.size(); ++i)
            if (_y[i] > y_naught)
                y_naught = _y[i];

    for (Uint i=0; i<_x.size(); ++i)
        if (_x[i] > 0.)
            ++j;
    nu_cpmg = y = sig = cpmgFit = VecDoub(j);
    for (Uint i=0, j=0; i<_x.size(); ++i) {
        if (_x[i] > 0.) {
            nu_cpmg[j] = _x[i]/time_T2;
            if (_y[i]*y_naught <= 0.)
                return 1;
            y[j] = -log(_y[i]/y_naught)/time_T2;
            sig[j] = 1./time_T2 * sqrt(SQR(1./_y[i]*_sig[i]) + SQR(1./y_naught*_sig[0]));
            ++j;
        }
    }
    VecDoub a(1);
    VecBool ia(1, true);

    Fitmrq fitconst(nu_cpmg, y, sig, a, ia, constant);
    fitconst.a[0] = -log(_y.back()/y_naught)/time_T2;
    fitconst.fit();
    ErrorSim errSimConst(nu_cpmg, y, sig, fitconst.a, fitconst.ia, constant);
    errSimConst.simerror(peak.fjack, peak.fboot, peak.fmc);
    peak.R2noex = fitconst.a[0];
    peak.chi2Const = fitconst.chisq;
    peak.dR2noex = errSimConst.simerr[0];

    // Calculate rmsd from straight line
    for (Uint ii=0; ii<y.size(); ++ii)
        peak.rmsdCpmg+= SQR(y[ii] - fitconst.a[0]);
    peak.rmsdCpmg = sqrt(peak.rmsdCpmg/y.size());

    a.resize(5);
    ia.resize(5);
    initializeCR(peak, y, a, ia);
    Fitmrq fitmrq(nu_cpmg, y, sig, a, ia, carverrichards);

    // Fit of dispersion ok
    Int dof_constant = nu_cpmg.size()-1;
    Int dof_cpmg = nu_cpmg.size()-4;
    if (peak.fixKex) ++dof_cpmg;
    if (peak.fixPb) ++dof_cpmg;

    if (!fitmrq.fit()) {
        ErrorSim errSim(nu_cpmg, y, sig, fitmrq.a, fitmrq.ia, carverrichards);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);

        copyCRresults(peak, fitmrq, errSim);

        plotFit(carverrichards, nu_cpmg, fitmrq.a, cpmgFit);
        FtestCPMG(peak, fitmrq.chisq, dof_cpmg, fitconst.chisq, dof_constant);
        peak.chi2Cpmg = fitmrq.chisq;

    }
    else {
        ErrorSim errSim(nu_cpmg, y, sig, fitconst.a, fitconst.ia, constant);
        errSim.simerror(peak.fjack, peak.fboot, peak.fmc);
        peak.R20 = fitconst.a[0];
        peak.dR20 = errSim.simerr[0];
        peak.kex = peak.dkex = peak.pB = peak.dpB = peak.Dw = peak.dDw = 0.;

        plotFit(constant, nu_cpmg, fitconst.a, cpmgFit);
        FtestCPMG(peak, 1., dof_cpmg, 1., dof_constant);
    }
    return 0;
}

void OutputType::initializeCR(const PeakType &peak, VecDoub_I &y, VecDoub &a, VecBool &ia)
{
    a[0] = peak.R20 == 0.? y.back() : peak.R20;
    a[1] = peak.kex == 0.? 1000.: peak.kex;
    a[2] = peak.pB == 0.? 0.02 : peak.pB;
    a[3] = peak.Dw == 0.? 200. : peak.Dw;
    a[4] = time_T2;
    for (Int i=0; i<4; ++i)
        ia[i] = true;
    if (peak.fixKex) ia[1] = false;
    if (peak.fixPb) ia[2] = false;
    ia[4] = false; // this represents time_T2 and should of course NEVER  be fitted
}

void OutputType::copyCRresults(PeakType &peak, const Fitmrq &fitmrq, const ErrorSim &errSim)
{
    Doub R20 = fitmrq.a[0];
    peak.R20 = fitmrq.a[0];
    peak.dR20 = errSim.simerr[0];
    peak.kex = fitmrq.a[1];
    peak.dkex = errSim.simerr[1];
    peak.pB = ((fitmrq.a[2] < 0.5)? fitmrq.a[2] : 1.-fitmrq.a[2]);
    peak.dpB = errSim.simerr[2];
    peak.Dw = fabs(fitmrq.a[3]);
    peak.dDw = errSim.simerr[3];
    peak.R20 = RexCR(R20, fitmrq.a[3], fitmrq.a[2], fitmrq.a[1], time_T2, 1.0e6);
}


void OutputType::FtestCPMG(PeakType &peak, Doub chisq1, Int dof1, Doub chisq2, Int dof2)
{
    FTest ftest;
    ftest.test(chisq1, dof1, chisq2, dof2);
    peak.fstat = ftest.f;
    peak.pval = ftest.prob;
}

void OutputType::plotFit(void (*func)(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda), VecDoub_I &x, VecDoub_I &a, VecDoub &y)
{
    VecDoub dyda(a.size());
    y = VecDoub(x.size());
    for (Uint i=0; i<x.size(); ++i)
        func(x[i], a, y[i], dyda);
}


void OutputType::printOutputHdr(const PeakType &peak, ofstream &myFile)
{
    static const Char *lineShape[NUMBER_OF_LINESHAPES] = {"LORENTZIAN", "GAUSSIAN", "GALORE", "VOIGT"};
    Int dof =  (peak.nData - 1) * peak.arr.size();

    if (peak.intMode == GAUSSIAN || peak.intMode == LORENTZIAN)
        dof -= 4;
    else if (peak.intMode == GALORE || peak.intMode == VOIGT)
        dof -= 6;

    myFile << "################################\n";
    myFile << "# Peak Name: " << peak.assi << ENDL;;
    myFile << "# No. peaks in group: " << peak.nOL << ENDL;
    myFile << "# Input F1 (ppm): " << peak.f1 << ENDL;
    myFile << "# Input F2 (ppm): " << peak.f2 << ENDL;
    myFile << "# Input LW1 (Hz): " << peak.lwF1_in << ENDL;
    myFile << "# Input LW2 (Hz): " << peak.lwF2_in << ENDL;
    myFile << "# Lineshape: \t" << lineShape[peak.intMode] << ENDL;
    myFile << "# ------- Results of Fit -------\n";
    if (!peak.fixPos) {
        myFile << "# F1 (ppm): \t" << peak.ppmF1 << ENDL;
        myFile << "# F2 (ppm): \t" << peak.ppmF2 << ENDL;
    }
    else {
        myFile << "# F1 (ppm): \t" << peak.ppmF1 << " (fixed)\n";
        myFile << "# F2 (ppm): \t" << peak.ppmF2 << " (fixed)\n";
    }
    if (!peak.fixLW) {
        myFile << "# LW1 (Hz): \t" << peak.lwF1 << ENDL;
        myFile << "# LW2 (Hz): \t" << peak.lwF2 << ENDL;
    }
    else {
        myFile << "# LW1 (Hz): \t" << peak.lwF1 << " (fixed)\n";
        myFile << "# LW2 (Hz): \t" << peak.lwF2 << " (fixed)\n";
    }
    myFile << "# Chi2: \t" << peak.chi2 << ENDL;
    myFile << "# dof: \t" << peak.dof << ENDL;
}



Int OutputType::printVol(PeakType &peak, VecString &error_msg)
{
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()),
            outIntensity(peak.arr.size()-peak.excludePlane.size()),
            outVol(peak.arr.size()-peak.excludePlane.size());
    VecInt  key;
    ofstream myFile(outName.c_str());

    copyArrIntensityVol(peak, outArr, outIntensity, outVol, key);

    printOutputHdr(peak, myFile);
    printVolHeading(myFile);
    printVolumes(peak, outArr, outIntensity, outVol, myFile, PRECISION);

    printPeakList(peak, error_msg);
    printLineWidthList(peak, error_msg);
    printChi2List(peak, error_msg);
    printSortKeyList(peak, key, error_msg);
    return 0;
}

void OutputType::printVolumes(const PeakType &peak, VecDoub_I &outArr, VecDoub_I &outIntensity, VecDoub_I &outVol, ofstream &myFile, Int precision)
{
    myFile.precision(precision);
    for (Uint j=0; j<outArr.size(); ++j)
        myFile << scientific << outArr[j] << "\t" << outIntensity[j] << "\t" << peak.esd << "\t" << outVol[j] << "\t" << peak.dvol << ENDL;
}

void OutputType::printVolHeading(ofstream &myFile)
{
    myFile << "################################\n";
    myFile << "#ArrVal     \tIntensity     \tdIntensity\t     Volume\t    dVolume\n";
}



void OutputType::printConstant(PeakType &peak, VecString &error_msg)
{
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()), outVol(peak.arr.size()-peak.excludePlane.size());
    ofstream myFile(constName.c_str());
    Doub fittedY=0.;

    FitConstant(peak);

    copyArrVol(peak, outArr, outVol);

    printOutputHdr(peak, myFile);
    printConstantFitParam(peak, myFile);

    for (Uint i=0; i<outArr.size(); ++i) {
        calcFittedVal(outArr[i]*timeFactor, fittedY, peak.constant, constant);
        printFittedVal(peak, outArr[i]*timeFactor, outVol[i], fittedY, myFile, PRECISION);
    }

    printConstantFitList(peak, error_msg);
}


void OutputType::printLin(PeakType &peak, VecString &error_msg)
{
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()), outVol(peak.arr.size()-peak.excludePlane.size());
    ofstream myFile(linName.c_str());
    Doub fittedY=0.;

    FitLin(peak);

    copyArrVol(peak, outArr, outVol);

    printOutputHdr(peak, myFile);
    printLinFitParam(peak, myFile);

    for (Uint i=0; i<outArr.size(); ++i) {
        calcFittedVal(outArr[i]*timeFactor, fittedY, peak.intercept, peak.slope, linear);
        printFittedVal(peak, outArr[i]*timeFactor, outVol[i], fittedY, myFile, PRECISION);
    }

    printLinFitList(peak, error_msg);
}

void OutputType::printExp(PeakType &peak, VecString &error_msg)
{
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()), outVol(peak.arr.size()-peak.excludePlane.size());
    ofstream myFile(R12Name.c_str());
    Doub fittedY=0.;

    FitExp(peak);

    copyArrVol(peak, outArr, outVol);

    printOutputHdr(peak, myFile);
    printExpFitParam(peak, myFile);

    for (Uint i=0; i<outArr.size(); ++i) {
        calcFittedVal(outArr[i]*timeFactor, fittedY, peak.A12, -peak.R12, exponential);
        printFittedVal(peak, outArr[i]*timeFactor, outVol[i], fittedY, myFile, PRECISION);
    }

    printExpFitList(peak, error_msg);
}


void OutputType::printBiExp(PeakType &peak, VecString &error_msg)
{
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()), outVol(peak.arr.size()-peak.excludePlane.size());
    ofstream myFile(biexpName.c_str());
    Doub fittedY=0.;

    FitBiExp(peak);

    copyArrVol(peak, outArr, outVol);

    printOutputHdr(peak, myFile);
    printBiExpFitParam(peak, myFile);

    for (Uint i=0; i<outArr.size(); ++i) {
        calcFittedVal(outArr[i]*timeFactor, fittedY, peak.BExpA1, peak.BExp1, peak.BExpA2, peak.BExp2, biexponential);
        printFittedVal(peak, outArr[i]*timeFactor, outVol[i], fittedY, myFile, PRECISION);
    }
    printBiExpFitList(peak, error_msg);
}



void OutputType::calcFittedVal(const Doub x, Doub &fittedY, Doub a0, Doub a1, Doub a2, Doub a3, void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &d))
{
    VecDoub a(4);
    a[0]=a0;
    a[1]=a1, a[2]=a2, a[3]=a3;
    VecDoub dyda(4);
    funks(x, a, fittedY, dyda);
}

void OutputType::calcFittedVal(const Doub x, Doub &fittedY, Doub a0, Doub a1, Doub a2, void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &d))
{
    VecDoub a(3);
    a[0]=a0;
    a[1]=a1, a[2]=a2;
    VecDoub dyda(3);
    funks(x, a, fittedY, dyda);
}

void OutputType::calcFittedVal(const Doub x, Doub &fittedY, Doub a0, Doub a1, void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &d))
{
    VecDoub a(2);
    a[0]=a0;
    a[1]=a1;
    VecDoub dyda(2);
    funks(x, a, fittedY, dyda);
}

void OutputType::calcFittedVal(const Doub x, Doub &fittedY, Doub a0, void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &d))
{
    VecDoub a(1);
    a[0]=a0;
    VecDoub dyda(1);
    funks(x, a, fittedY, dyda);
}

void OutputType::printConstantFitParam(const PeakType &peak, ofstream &myFile)
{
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    else if (peak.fboot) errMethod = "Bootstrap";
    else if (peak.fmc) errMethod = "Monte Carlo";

    myFile << "#\n";
    myFile << "# Constant fit:\n";
    myFile << "#       Intercept: " << peak.constant << " +/- " << peak.dconstant << ENDL;
    myFile << "#       Chi2: " << peak.chi2Constant << ENDL
           << "#       dof: " << peak.arr.size()-peak.excludePlane.size()-2 << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    printFitHeader(myFile);
}

void OutputType::printLinFitParam(const PeakType &peak, ofstream &myFile)
{
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    else if (peak.fboot) errMethod = "Bootstrap";
    else if (peak.fmc) errMethod = "Monte Carlo";

    myFile << "#\n";
    myFile << "# Linear fit:\n";
    myFile << "#       Intercept: " << peak.intercept << " +/- " << peak.dintercept << ENDL;
    myFile << "#       Slope: " << peak.slope << " +/- " << peak.dslope << ENDL;
    myFile << "#       Chi2: " << peak.chi2Lin << ENDL
           << "#       dof: " << peak.arr.size()-peak.excludePlane.size()-2 << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    printFitHeader(myFile);
}

void OutputType::printExpFitParam(const PeakType &peak, ofstream &myFile)
{
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    else if (peak.fboot) errMethod = "Bootstrap";
    else if (peak.fmc) errMethod = "Monte Carlo";

    myFile << "#\n";
    myFile << "# Exponential fit:\n";
    myFile << "#       Intercept: " << peak.A12 << " +/- " << peak.dA12 << ENDL;
    myFile << "#       DecayRate: " << peak.R12 << " +/- " << peak.dR12 << ENDL;
    myFile << "#       Chi2: " << peak.chi2Exp << ENDL
           << "#       dof: " << peak.arr.size()-peak.excludePlane.size()-2 << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    printFitHeader(myFile);
}

void OutputType::printBiExpFitParam(const PeakType &peak, ofstream &myFile)
{
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    else if (peak.fboot) errMethod = "Bootstrap";
    else if (peak.fmc) errMethod = "Monte Carlo";

    myFile << "#\n";
    myFile << "# Exponential fit:\n";
    myFile << "#       Intercept1: " << peak.BExpA1 << " +/- " << peak.dBExpA1 << ENDL;
    myFile << "#       DecayRate1: " << peak.BExp1 << " +/- " << peak.dBExp1 << ENDL;
    myFile << "#       Intercept2: " << peak.BExpA2 << " +/- " << peak.dBExpA2 << ENDL;
    myFile << "#       DecayRate2: " << peak.BExp2 << " +/- " << peak.dBExp2 << ENDL;
    myFile << "#       Chi2: " << peak.chi2BiExp << ENDL
           << "#       dof: " << peak.arr.size()-peak.excludePlane.size()-2 << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    printFitHeader(myFile);
}

void OutputType::printFitHeader(ofstream &myFile)
{
    myFile << "#Time      \tIntensity      \tdIntensity    \tIntensity(fit)\n";
}

void OutputType::printFitExpOffsetParam(const PeakType &peak, const string &name, ofstream &myFile)
{
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    else if (peak.fboot) errMethod = "Bootstrap";
    else if (peak.fmc) errMethod = "Monte Carlo";

    myFile << "#\n";
    myFile << "# " << name << ENDL;
    myFile << "#       Intercept: " << peak.expoffsA12 << " +/- " << peak.dexpoffsA12 << ENDL;
    myFile << "#       DecayRate: " << peak.expoffsR12 << " +/- " << peak.dexpoffsR12 << ENDL;
    myFile << "#       Offset: " << peak.expoffsOffset << " +/- " << peak.dexpoffsOffset << ENDL;
    myFile << "#       Chi2: " << peak.chi2SatRecovery << ENDL
           << "#       dof: " << peak.arr.size()-peak.excludePlane.size()-2 << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    printFitHeader(myFile);
}

void OutputType::printFitInvRecParam(const PeakType &peak, const string &name, ofstream &myFile)
{
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    else if (peak.fboot) errMethod = "Bootstrap";
    else if (peak.fmc) errMethod = "Monte Carlo";

    myFile << "#\n";
    myFile << "# " << name << ENDL;
    myFile << "#       Plateau: " << peak.invrecPlateau << " +/- " << peak.dinvrecPlateau << ENDL;
    myFile << "#       BuildupRate: " << peak.invrecR1 << " +/- " << peak.dinvrecR1 << ENDL;
    myFile << "#       Chi2: " << peak.chi2InvRecovery << ENDL
           << "#       dof: " << peak.arr.size()-peak.excludePlane.size()-2 << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    printFitHeader(myFile);
}

void OutputType::printFitSatRecParam(const PeakType &peak, const string &name, ofstream &myFile)
{
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    else if (peak.fboot) errMethod = "Bootstrap";
    else if (peak.fmc) errMethod = "Monte Carlo";

    myFile << "#\n";
    myFile << "# " << name << ENDL;
    myFile << "#       Plateau: " << peak.satrecPlateau << " +/- " << peak.dsatrecPlateau << ENDL;
    myFile << "#       BuildupRate: " << peak.satrecR1 << " +/- " << peak.dsatrecR1 << ENDL;
    myFile << "#       Chi2: " << peak.chi2SatRecovery << ENDL
           << "#       dof: " << peak.arr.size()-peak.excludePlane.size()-2 << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    printFitHeader(myFile);
}


void OutputType::printFittedVal(const PeakType &peak, Doub outArr, Doub outVol, Doub fittedY, ofstream &myFile, Int precision)
{
    myFile.precision(precision);
    if (peak.esd > 0.)
        myFile << scientific << outArr << "\t" << outVol << "\t" << peak.esd << "\t" << fittedY << ENDL;
    else
        myFile << scientific << outArr << "\t" << outVol << "\t" << noise << "\t" << fittedY << ENDL;
}


void OutputType::printFittedCpmgVal(const PeakType &peak, Doub nu_cpmg, Doub r2eff, Doub sig, Doub cpmgFit, ofstream &myFile, Int precision)
{
    myFile.precision(precision);
    myFile << scientific << nu_cpmg <<"\t"<< r2eff << "\t" << sig << "\t" << cpmgFit << "\t" << peak.R2noex << ENDL;
}

void OutputType::printSatRecovery(PeakType &peak, VecString &error_msg)
{
    Doub fittedY=0.;
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()), outVol(peak.arr.size()-peak.excludePlane.size());
    ofstream myFile(satRecoveryName.c_str());

    FitSatRecovery(peak);

    copyArrVol(peak, outArr, outVol);

    printOutputHdr(peak, myFile);
    printFitSatRecParam(peak, "Saturation recovery:", myFile);

    for (Uint i=0; i<outArr.size(); ++i) {
        calcFittedVal(outArr[i]*timeFactor, fittedY, peak.satrecPlateau, -peak.satrecR1, satrecover);
        printFittedVal(peak, outArr[i]*timeFactor, outVol[i], fittedY, myFile, PRECISION);
    }

    printSatRecoveryFitList(peak, error_msg);
}


void OutputType::printInvRecovery(PeakType &peak, VecString &error_msg)
{
    Doub fittedY=0.;
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()), outVol(peak.arr.size()-peak.excludePlane.size());
    ofstream myFile(invRecoveryName.c_str());

    FitInvRecovery(peak);

    copyArrVol(peak, outArr, outVol);

    printOutputHdr(peak, myFile);
    printFitInvRecParam(peak, "Inversion recovery:", myFile);

    for (Uint i=0; i<outArr.size(); ++i) {
        calcFittedVal(outArr[i]*timeFactor, fittedY, peak.invrecPlateau, -peak.invrecR1, invrecover);
        printFittedVal(peak, outArr[i]*timeFactor, outVol[i], fittedY, myFile, PRECISION);
    }
    printInvRecoveryFitList(peak, error_msg);
}


void OutputType::printExpOffset(PeakType &peak, VecString &error_msg)
{
    Doub fittedY=0.;
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()), outVol(peak.arr.size()-peak.excludePlane.size());
    ofstream myFile(expOffsetName.c_str());

    FitExpOffset(peak);

    copyArrVol(peak, outArr, outVol);

    printOutputHdr(peak, myFile);
    printFitExpOffsetParam(peak, "Exponential with offset: ", myFile);

    for (Uint i=0; i<outArr.size(); ++i) {
        calcFittedVal(outArr[i]*timeFactor, fittedY, peak.expoffsA12, -peak.expoffsR12, peak.expoffsOffset, expoffset);
        printFittedVal(peak, outArr[i]*timeFactor, outVol[i], fittedY, myFile, PRECISION);
    }

    printExpOffsetFitList(peak, error_msg);
}


void OutputType::printR1rho(PeakType &peak, VecString &error_msg)
{
    Doub fittedY=0.;
    VecDoub outArr(peak.arr.size()-peak.excludePlane.size()), outVol(peak.arr.size()-peak.excludePlane.size());
    ofstream myFile(R12Name.c_str());

    FitExp(peak);
    CalcR2(peak);

    copyArrVol(peak, outArr, outVol);

    printOutputHdr(peak, myFile);
    printR1rhoParam(peak, myFile);

    for (Uint i=0; i<outArr.size(); ++i) {
        calcFittedVal(outArr[i]*timeFactor, fittedY, peak.A12, -peak.R12, exponential);
        printFittedVal(peak, outArr[i]*timeFactor, outVol[i], fittedY, myFile, PRECISION);
    }

    printR2FitList(peak, error_msg);
}

void OutputType::printR1rhoParam(const PeakType &peak, ofstream &myFile)
{
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    if (peak.fboot) errMethod = "Bootstrap";
    if (peak.fmc) errMethod = "Monte Carlo";

    myFile << "#\n";
    myFile << "# Exponential fit (R1rho) and calculation of R2:\n";
    myFile << "#       Intensity(0): " << peak.A12 << " +/- " << peak.dA12 << ENDL;
    myFile << "#       Decay: " << peak.R12 << " +/- " << peak.dR12 << ENDL;
    myFile << "#       Calculated R2: " << peak.R2 << " +/- " << peak.dR2 << ENDL;
    myFile << "#       Chi2: " << peak.chi2Exp << ENDL
           << "#       dof: " << peak.arr.size()-peak.excludePlane.size() - 2 << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    printFitHeader(myFile);
}


void OutputType::printNOE(PeakType &peak, VecString &error_msg)
{
    // invert == 0  =>  NOE = intensity(i)/intensity(i+1)
    // invert == 1  =>  NOE = intensity(i+1)/intensity(i)
    // the uncertainty is estimated by calculating
    // the standard error of all permutations of
    // ratios of duplicate cross and reference
    // experiments.

    ofstream myFile(noeName.c_str());
    Doub sum=0., sum2=0.;
    VecDoub noe;
    Doub dnoe = 0.;

    for (Uint i=0; i<peak.intensity.size()-1; i+=2)
        for (Uint j=1; j<peak.intensity.size(); j+=2) {
            Doub temp = !invert? peak.intensity[i]/peak.intensity[j] : peak.intensity[j]/peak.intensity[i];
            noe.push_back(temp);
            sum += temp;
            sum2 += SQR(temp);
        }

    printOutputHdr(peak, myFile);
    if (noe.size() > 1 && (sum2 - SQR(sum)/noe.size()) > 0.0) {
        dnoe = sqrt((sum2 - SQR(sum)/noe.size())/noe.size())/sqrt(noe.size());
        myFile << "# NOE = " <<  scientific << sum/noe.size() << " +/- " << dnoe << ENDL;
        myFile << "################################\n";
        myFile << "# NOE\tdNOE\n";
    }
    else {
        myFile << "# NOE = " <<  scientific << sum/noe.size() << ENDL;
        myFile << "################################\n";
        myFile << "# NOE\n";
    }

    for (Uint i=0; i<noe.size(); ++i)
        if (noe.size() > 1)
            myFile << scientific << noe[i] << "\t" << dnoe << ENDL;
        else
            myFile << scientific << noe[i] << ENDL;
    peak.NOE = sum/noe.size();
    peak.dNOE = dnoe;

    printNOElist(peak, error_msg);
}


void OutputType::printCpmg(PeakType &peak)
{
    VecDoub nu_cpmg, r2eff, sig, cpmgFit;

    if (!FitCR(peak, nu_cpmg, r2eff, sig, cpmgFit)) {
        ofstream myFile(cpmgName.c_str());

        printCpmgParam(peak, nu_cpmg, myFile);
        for (Uint i=0; i<nu_cpmg.size(); ++i)
            printFittedCpmgVal(peak, nu_cpmg[i], r2eff[i], sig[i], cpmgFit[i], myFile, PRECISION);

        printCpmgList(peak);
    }
    else {
        peak.fitCPMG = false;
        ofstream failFile;
        failFile.open(failName.c_str(), ios::app);
        failFile << "CPMG fit failed for peak " << peak.assi << ENDL;
    }
}


void OutputType::printCpmgParam(const PeakType &peak, VecDoub_I &nu_cpmg, ofstream &myFile)
{
    // An asterisk is printed before F-stat and p-value if chi2Const (erronously) is
    // less than chi2Cpmg.
    string errMethod;
    if (peak.fjack) errMethod = "Jackknife";
    if (peak.fboot) errMethod = "Bootstrap";
    if (peak.fmc) errMethod = "Monte Carlo";

    Int dof = nu_cpmg.size()-4;
    if (peak.fixKex) ++dof;
    if (peak.fixPb) ++dof;

    printOutputHdr(peak, myFile);
    myFile << scientific;
    myFile << "#\n";
    myFile << "# Fit of CPMG dispersion and constant function:\n";
    myFile << "#       R2,0: " << peak.R20 << " +/- " << peak.dR20 << ENDL;
    myFile << "#       kex: " << peak.kex << " +/- " << peak.dkex << ENDL;
    myFile << "#       pB: " << peak.pB << " +/- " << peak.dpB << ENDL;
    myFile << "#       |DeltaOmega|: " << peak.Dw << " +/- " << peak.dDw << ENDL;
    myFile << "#       Chi2: " << peak.chi2Cpmg << ENDL
           << "#       dof: " << dof << ENDL;
    myFile << "#       R2,0 (no exchange): " << peak.R2noex << " +/- " << peak.dR2noex << ENDL;
    myFile << "#       Chi2(constant): " << peak.chi2Const << ENDL
           << "#       dof(constant): " << nu_cpmg.size()-1 << ENDL;
    myFile << "#       F-stat:" << " " << peak.fstat << ENDL;
    myFile << "#       p-value:" << " " << peak.pval << ENDL;
    myFile << "#       RMSD from straight line: " << peak.rmsdCpmg << ENDL;
    myFile << "#       Errors estimated by: " << errMethod << ENDL;
    myFile << "################################\n";
    myFile << "# nuCPMG\tR2eff(exp)\tdR2eff(exp)\tR2eff(fit)\tR2noex(fit)\n";
}

Int OutputType::printPeakList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream myFile;
    if (!peakListFlag) {
        myFile.open(peakListName.c_str(), ios::trunc);
        myFile << "# Assignment\tF1 (ppm)\tF2 (ppm)\n";
        peakListFlag = true;
    }
    else
        myFile.open(peakListName.c_str(), ios::app);
    if (!myFile) {
        string s = "ERROR: Cannot write to '" + peakListName + "'";
        error_msg.push_back(s);
        return 1;
    }
    myFile.precision(6);
    myFile << scientific << assi << "\t" << peak.ppmF1 << "\t" << peak.ppmF2 << ENDL;
    return 0;
}


Int OutputType::printLineWidthList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream myFile;
    if (!linewidthListFlag) {
        myFile.open(linewidthListName.c_str(), ios::trunc);
        myFile << "# Assignment\tLW(F1) (Hz)\tLW(F2) (Hz)\n";
        linewidthListFlag = true;
    }
    else
        myFile.open(linewidthListName.c_str(), ios::app);
    if (!myFile) {
        string s = "ERROR: Cannot write to '" + linewidthListName + "'";
        error_msg.push_back(s);
        return 1;
    }
    myFile.precision(6);
    myFile << scientific << assi << "\t" << peak.lwF1 << "\t" << peak.lwF2 << ENDL;
    return 0;
}

Int OutputType::printChi2List(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream myFile;
    if (!chi2ListFlag) {
        myFile.open(chi2ListName.c_str(), ios::trunc);
        myFile << "#assi\tChi2\tNo.points\tChi2,red\n";
        chi2ListFlag = true;
    }
    else
        myFile.open(chi2ListName.c_str(), ios::app);
    if (!myFile) {
        string s = "ERROR: Cannot write to '" + chi2ListName + "'";
        error_msg.push_back(s);
        return 1;
    }
    myFile.precision(6);
    myFile << scientific << assi << "\t" << peak.chi2 << "\t" << peak.nData << "\t" << peak.chi2/peak.nData << ENDL;
    return 0;
}

void OutputType::printSortKeyList(const PeakType &peak, VecInt_I &key, VecString &error_msg)
{
    ofstream myFile(sortKeyName, ios::app);
    //myFile.open(chi2ListName.c_str(), ios::app);
    if (!myFile)
        error_msg.push_back("ERROR: Cannot write to '" + sortKeyName + "'");
    else  {
        myFile << peak.assi;
        for (auto _key : key)
            myFile << "\t" << _key;
        myFile << "\n";
    }
}

void OutputType::printConstantFitList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream myFile, paramFile;
    if (!constListFlag) {
        myFile.open(constListName.c_str(), ios::trunc);
        paramFile.open(paramListName.c_str(), ios::trunc);
        myFile << "#assi\tIntercept\tdIntercept\n";
        paramFile << "#assi\tIntercept\tdIntercept\n";
        constListFlag = true;
    }
    else {
        myFile.open(constListName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!myFile) {
        string s = "ERROR: Cannot write to file '" + constListName + "'";
        error_msg.push_back(s);
    }
    myFile.precision(6);
    paramFile.precision(6);
    myFile << scientific << assi << "\t" << peak.constant << "\t" << peak.dconstant << ENDL;
    paramFile << scientific << assi << "\t" << peak.constant << "\t" << peak.dconstant << ENDL;
}

void OutputType::printLinFitList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream paramFile, myFile;
    if (!linListFlag) {
        myFile.open(linListName.c_str(), ios::trunc);
        paramFile.open(paramListName.c_str(), ios::trunc);
        myFile << "#assi\tSlope\tdSlope\tIntercept\tdIntercept\n";
        paramFile << "#assi\tSlope\tdSlope\tIntercept\tdIntercept\n";
        linListFlag = true;
    }
    else {
        myFile.open(linListName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!myFile) {
        string s = "ERROR: Cannot write to file '" + linListName + "'";
        error_msg.push_back(s);
    }
    myFile.precision(6);
    paramFile.precision(6);
    myFile << scientific << assi << "\t" << peak.slope << "\t" << peak.dslope << "\t" << peak.intercept << "\t" << peak.dintercept << ENDL;
    paramFile << scientific << assi << "\t" << peak.slope << "\t" << peak.dslope << "\t" << peak.intercept << "\t" << peak.dintercept << ENDL;
}

void OutputType::printExpFitList(const PeakType &peak, VecString &error_msg)
{
    // Third argument is a flag that is defaulted to false (see output.h)
    // Set it to true if you do not wish to write to the files parameters here.
    // This is the case in the case of R1rho data where the correct file is created
    // in function printR2FitList. -PL

    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream expFile;
    ofstream paramFile;
    if (!expListFlag) {
        expFile.open(expListName.c_str(), ios::trunc);
        expFile << "#assi\tDecayRate\tdDecayRate\n";
        paramFile.open(paramListName.c_str(), ios::trunc);
        paramFile << "#assi\tDecayRate\tdDecayRate\tIntercept\tdIntercept\n";
        expListFlag = true;
    }
    else {
        expFile.open(expListName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!expFile) {
        string s = "ERROR: Cannot write to file '" + expListName + "'";
        error_msg.push_back(s);
    }
    expFile.precision(6);
    expFile << scientific << assi << "\t" << peak.R12 << "\t" << peak.dR12 << ENDL;
    paramFile.precision(6);
    paramFile << scientific << assi << "\t" << peak.R12 << "\t" << peak.dR12 << "\t" << peak.A12 << "\t" << peak.dA12 << ENDL;
}

void OutputType::printBiExpFitList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream paramFile, myFile;
    if (!biexpListFlag) {
        myFile.open(biexpListName.c_str(), ios::trunc);
        paramFile.open(paramListName.c_str(), ios::trunc);
        myFile << "#assi\tDecayRate1\tdDecayRate2\tIntercept1\tdIntercept1\tDecayRate2\tdDecayRate2\tIntercept2\tdIntercept2\n";
        paramFile << "#assi\tDecayRate1\tdDecayRate1\tIntercept1\tdIntercept1\tDecayRate2\tdDecayRate2\tIntercept2\tdIntercept2\n";
        biexpListFlag = true;
    }
    else {
        myFile.open(biexpListName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!myFile) {
        string s = "ERROR: Cannot write to file '" + biexpListName + "'";
        error_msg.push_back(s);
    }
    myFile.precision(6);
    paramFile.precision(6);
    myFile << scientific << assi << "\t" << peak.BExpA1 << "\t" << peak.dBExpA1 << "\t" << peak.BExp1 \
           << "\t" << peak.dBExp1 << "\t" << peak.BExpA2 << "\t" << peak.dBExpA2 << "\t" << peak.BExp2 \
           << "\t" << peak.dBExp2 << ENDL;
    paramFile << scientific << assi << "\t" << peak.BExp1 << "\t" << peak.dBExp1 << "\t" << peak.BExpA1 \
              << "\t" << peak.dBExpA1 << "\t" << peak.BExp2 << "\t" << peak.dBExp2 << "\t" << peak.BExpA2 \
              << "\t" << peak.dBExpA2 << ENDL;
    paramFile << biexpListFlag << " DAMMIT ";
}

void OutputType::printSatRecoveryFitList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream paramFile, myFile;
    if (!satRecoveryListFlag) {
        myFile.open(satRecoveryListName.c_str(), ios::trunc);
        paramFile.open(paramListName.c_str(), ios::trunc);
        myFile << "#sassie\tBuildupRate\tdBuildupRate" << ENDL;
        paramFile << "#assi\tBuildupRate\tdBuildupRate\tOffset\tdOffset" << ENDL;
        satRecoveryListFlag = true;
    }
    else {
        myFile.open(satRecoveryListName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!myFile) {
        string s = "ERROR: Cannot write to '" + satRecoveryListName + "'";
        error_msg.push_back(s);
    }
    myFile.precision(6);
    paramFile.precision(6);
    myFile << scientific << assi << "\t" << peak.satrecR1 << "\t" << peak.dsatrecR1 << ENDL;
    paramFile << scientific << assi << "\t" << peak.satrecR1 << "\t" << peak.dsatrecR1 << "\t" << peak.satrecPlateau << "\t" << peak.dsatrecPlateau <<ENDL;
}

void OutputType::printInvRecoveryFitList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream paramFile, myFile;
    if (!invRecoveryListFlag) {
        myFile.open(invRecoveryListName.c_str(), ios::trunc);
        paramFile.open(paramListName.c_str(), ios::trunc);
        paramFile << "#assi\tBuildupRate\tdBuildupRate\tOffset\tdOffset\n";
        invRecoveryListFlag = true;
    }
    else {
        myFile.open(invRecoveryListName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!myFile) {
        string s = "ERROR: Cannot write to '" + invRecoveryListName + "'";
        error_msg.push_back(s);
    }
    myFile.precision(6);
    paramFile.precision(6);
    myFile << scientific << assi << "\t" << peak.invrecR1 << "\t" << peak.dinvrecR1 << ENDL;
    paramFile << scientific << assi << "\t" << peak.invrecR1 << "\t" << peak.dinvrecR1 << "\t" << peak.invrecPlateau << "\t" << peak.dinvrecPlateau <<ENDL;
}

void OutputType::printExpOffsetFitList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream paramFile, myFile;
    if (!expOffsetListFlag) {
        myFile.open(expOffsetListName.c_str(), ios::trunc);
        paramFile.open(paramListName.c_str(), ios::trunc);
        myFile << "#assi\tDecayRate\tdDecayRate\n";
        paramFile << "#assi\tDecayRate\tdDecayRate\n";
        expOffsetListFlag = true;
    }
    else {
        myFile.open(expOffsetListName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!myFile) {
        string s = "ERROR: Cannot write output data to file '" + expOffsetListName + "'";
        error_msg.push_back(s);
    }
    myFile.precision(6);
    paramFile.precision(6);
    myFile << scientific << assi << "\t" << peak.expoffsR12 << "\t" << peak.dexpoffsR12 << ENDL;
    paramFile << scientific << assi << "\t" << peak.expoffsR12 << "\t" << peak.dexpoffsR12 <<  "\t"
              << peak.expoffsA12 << "\t" << peak.dexpoffsA12 << "\t" << peak.expoffsR12 << "\t"
              << peak.dexpoffsR12 << ENDL;
}


void OutputType::printR2FitList(const PeakType &peak, VecString &error_msg)
{
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    ofstream paramFile, myFile, myFile2;
    if (!r2ListFlag) {
        myFile.open(r2ListName.c_str(), ios::trunc);
        myFile2.open(expListName.c_str(), ios::trunc);
        paramFile.open(paramListName.c_str(), ios::trunc);
        myFile << "#assi\tR2\tdR2\n";
        myFile2 << "#assi\tDecayRate\tdDecayRate\n";
        paramFile << "#assi\tR2\tdR2\tR1rho\tdR1rho\tOffset\tdOffset\n";
        r2ListFlag = true;
    }
    else {
        myFile.open(r2ListName.c_str(), ios::app);
        myFile2.open(expListName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!myFile) {
        string s = "ERROR: Cannot write output data to file '" + r2ListName + "'";
        error_msg.push_back(s);
    }
    if (!myFile2) {
        string s = "ERROR: Cannot write output data to file '" + expListName + "'";
        error_msg.push_back(s);
    }

    myFile.precision(6);
    paramFile.precision(6);
    myFile << scientific << assi << "\t" << peak.R2 << "\t" << peak.dR2 << ENDL;
    myFile2 << scientific << assi << "\t" << peak.R12 << "\t" << peak.dR12 << ENDL;
    paramFile << scientific << assi << "\t" << peak.R2 << "\t" << peak.dR2 << "\t" << peak.R12
              << "\t" << peak.dR12 << "\t" << peak.A12 << "\t" << peak.dA12 << ENDL;
}


void OutputType::printNOElist(const PeakType &peak, VecString &error_msg)
{
    ofstream paramFile, myFile;
    string assi = peak.assi;
    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;
    if (!NOElistFlag) {
        myFile.open(NOElistName.c_str(), ios::trunc);
        paramFile.open(paramListName.c_str(), ios::trunc);
        if (peak.dNOE > 0.) {
            myFile << "#assi\tNOE\tdNOE\n";
            paramFile << "#assi\tNOE\tdNOE\n";
        }
        else {
            myFile << "#assi\tNOE\n";
            paramFile << "#assi\tNOE\n";
        }
        NOElistFlag = true;
    }
    else {
        myFile.open(NOElistName.c_str(), ios::app);
        paramFile.open(paramListName.c_str(), ios::app);
    }
    if (!myFile)
        error_msg.push_back("ERROR: Cannot write output data to file '" + NOElistName + "'");
    myFile.precision(6);
    if (peak.dNOE > 0.) {
        myFile << scientific << assi << "\t" << peak.NOE << "\t" << peak.dNOE << ENDL;
        paramFile << scientific << assi << "\t" << peak.NOE << "\t" << peak.dNOE << ENDL;
    }
    else {
        myFile << scientific << assi << "\t" << peak.NOE << "\t" << ENDL;
        paramFile << scientific << assi << "\t" << peak.NOE << "\t" << ENDL;
    }
}


void OutputType::printCpmgList(const PeakType &peak)
{
    ofstream paramF, cpmgF, pbF, kexF, dwF, r20F, ftestF, rmsdF;
    OpenCpmgListFile(paramF, cpmgF, pbF, kexF, dwF, r20F, ftestF, rmsdF);

    CpmgListWriteData(peak, paramF, cpmgF, pbF, kexF, dwF, r20F, ftestF, rmsdF) ;
}

void OutputType::OpenCpmgListFile(ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF, ofstream &dwF, ofstream &r20F,
                                  ofstream &ftestF, ofstream &rmsdF)
{
    if (!cpmgListFlag) {
        paramF.open(paramListName.c_str());
        cpmgF.open(cpmgListName.c_str());
        pbF.open(pbListName.c_str());
        kexF.open(kexListName.c_str());
        dwF.open(deltaOmegaListName.c_str());
        r20F.open(r20ListName.c_str());
        ftestF.open(ftestListName.c_str());
        rmsdF.open(rmsdListName.c_str());
        CpmgListWriteHeader(paramF, cpmgF, pbF, kexF, dwF, r20F, ftestF, rmsdF) ;

        cpmgListFlag = true;
    }
    else {
        paramF.open(paramListName.c_str(), ios::app);
        cpmgF.open(cpmgListName.c_str(), ios::app);
        pbF.open(pbListName.c_str(), ios::app);
        kexF.open(kexListName.c_str(), ios::app);
        dwF.open(deltaOmegaListName.c_str(), ios::app);
        r20F.open(r20ListName.c_str(), ios::app);
        ftestF.open(ftestListName.c_str(), ios::app);
        rmsdF.open(rmsdListName.c_str(), ios::app);
    }
    CpmgListPrecision(paramF, cpmgF, pbF, kexF, dwF, r20F, ftestF, rmsdF) ;
}

void OutputType::CpmgListWriteHeader(ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF, ofstream &dwF, ofstream &r20F, ofstream &ftestF, ofstream &rmsdF)
{
    paramF << "#assi\tR2,0\t\tdR2,0\tkex\tdkex\tpB\tdpb\t|Dw|\td|Dw|\tF-stat\tp-value\tRMSD\n";
    cpmgF << "#assi\tR2,0\tkex\tpB\t|Dw|\tF-stat\tp-value\tRMSD\n";
    pbF << "#assi\tpB\tdpB\n";
    kexF << "#assi\tkex\tdkex\n";
    dwF << "#assi\t|DeltaOmega|\tdDeltaOmega\n";
    r20F << "#assi\tR2,0\tdR2,0\n";
    ftestF << "#assi\tF-stat\tp-value\n";
    rmsdF << "#assi\tRMSD\n";
}

void OutputType::CpmgListPrecision(ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF, ofstream &dwF, ofstream &r20F, ofstream &ftestF, ofstream &rmsdF)
{
    paramF.precision(6);
    cpmgF.precision(6);
    pbF.precision(6);
    kexF.precision(6);
    dwF.precision(6);
    r20F.precision(6);
    ftestF.precision(6);
    rmsdF.precision(6);
}


void OutputType::CpmgListWriteData(const PeakType &peak, ofstream &paramF, ofstream &cpmgF, ofstream &pbF, ofstream &kexF,
                                   ofstream &dwF, ofstream &r20F, ofstream &ftestF, ofstream &rmsdF)
{
    // If chi2 for fit to constant function is less than for fit to exchanging model
    // an asterisk is printed before the f-stat and p-val to signify that these values
    // (erronously) are the probability that the simpler model is correct. In this case
    // the fitting of CPMG dispersions cannot be trusted and other starting parameters
    // should be used

    string assi = peak.assi;

    if (listByResNo && peak.resNo!="")
        assi = peak.resNo;

    paramF << scientific << assi << "\t" << peak.R20 << "\t" << peak.dR20 << "\t" << peak.kex << "\t" << peak.dkex <<
              "\t" << peak.pB << "\t" << peak.dpB << "\t" << peak.Dw << "\t" << peak.dDw << "\t" << peak.fstat << "\t" << peak.pval << "\t" << peak.rmsdCpmg << ENDL;
    cpmgF << scientific << assi << "\t" << peak.R20 << " +/- " << peak.dR20 << "\t" << peak.kex << " +/- " << peak.dkex <<
             "\t" << peak.pB << " +/- " << peak.dpB << "\t" <<
             peak.Dw << " +/- " << peak.dDw << "\t" << peak.fstat << "\t" << peak.pval << "\t" << peak.rmsdCpmg << ENDL;
    pbF << scientific << assi << "\t" << peak.pB << "\t" << peak.dpB << ENDL;
    kexF << scientific << assi << "\t" << peak.kex << "\t" << peak.dkex << ENDL;
    dwF << scientific << assi << "\t" << peak.Dw << "\t" << peak.dDw << ENDL;
    r20F << scientific << assi << "\t" << peak.R20 << "\t" << peak.dR20 << ENDL;
    ftestF << scientific << assi << "\t" << peak.fstat << "\t" << peak.pval << ENDL;
    rmsdF << scientific << assi << "\t" << peak.rmsdCpmg << ENDL;
}


void OutputType::copyArrVol(VecDoub_I &a, VecDoub_I &a2, VecDoub_I &v, VecDoub &aa, VecDoub aa2, VecDoub &vv)
{
    aa = a;
    aa2 = a2;
    vv = v;
}


void OutputType::copyArrVol(PeakType &peak, VecDoub &outArr, VecDoub &outIntensity)
{
    Int i=0;
    for (Uint j=0; j<peak.arr.size(); ++j) {
        if (!isPlaneExcluded(peak, j+1)) {
            outArr[i]= peak.arr[j];
            outIntensity[i] = peak.intensity[j];
            ++i;
        }
    }
    if (sort)
        sort2(outArr, outIntensity);
}


void OutputType::copyArrIntensityVol(PeakType &peak, VecDoub &outArr, VecDoub &outIntensity, VecDoub &outVol, VecInt &key)
{
    Int i=0;
    for (Uint j=0; j<peak.arr.size(); ++j) {
        if (!isPlaneExcluded(peak, j+1)) {
            outArr[i]= peak.arr[j];
            outIntensity[i] = peak.intensity[j];
            outVol[i] = peak.vol[j];
            ++i;
            key.push_back(j+1);
        }
    }
    if (sort)
        sort4(outArr, outIntensity, outVol, key);
}
