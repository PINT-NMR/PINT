// fitfunctions.h

#ifndef _FITFUNCTIONS
#define _FITFUNCTIONS

#include "pint.h"
#include "peak.h"

//#ifndef PI
//  #define PI 3.141592654
//#endif

//#define NPAR_GAUSSIAN (4+nArr)
//#define NPAR_LORENTZIAN (4+nArr)
//#define NPAR_GALORE (6+nArr)

//#define c2  2.772588722	 // needed to get correctly defined linewidth


Doub gaussiancore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr) ;

void gaussian(const Doub f1, const Doub f2, const Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr) ;

Doub lorentziancore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr) ;

void lorentzian(const Doub f1, const Doub f2, const Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr) ;

Doub galorecore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr) ;

void galore(const Doub f1, const Doub f2, const Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr) ;

Doub generalShapeCore(const PeakListType &peak, Doub f1, Doub f2, Int f3, VecDoub_I &a, const Int nOL, const Int nArr);

void generalShape(const PeakListType &peak, Doub f1, Doub f2, Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, Int nOL, Int nArr);

Doub gausslorecore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr) ;

void gausslore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr) ;

Doub loregausscore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr) ;

void loregauss(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr) ;

Doub gaussian3Dcore(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, const Int nOL, const Int nArr) ;

void gaussian3D(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr) ;

Doub lorentzian3Dcore(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, const Int nOL, const Int nArr) ;

void lorentzian3D(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr) ;

Doub galore3Dcore(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, const Int nOL, const Int nArr) ;

void galore3D(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr) ;

void exponential(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

void linear(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

void expoffset(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

void biexponential(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

void invrecover(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

void satrecover(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

void tanhyp(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

void constant(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

inline complex<Doub> acosh_complex(complex<Doub> z);

Doub RexCR(Doub R20, Doub DW, Doub PA, Doub KEX, Doub time_T2, Doub nuCP) ;

void carverrichards(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda) ;

Doub galoreLWfunc(Doub a, Doub b, Doub x) ;


#endif
