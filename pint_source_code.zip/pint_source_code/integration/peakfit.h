#ifndef _PEAKFIT
#define _PEAKFIT

#include "pint.h"
#include "peak.h"
#include "spectrum.h"
#include "parser.h"
#include "fitmrq.h"


struct PeakFitType {

    PeakListType peak; // This is the group of peaks to fit
    VecDoub f1, f2;
    VecInt f3;
    VecDoub y, sig;
    VecDoub yopt;		// intensities at peak center according to peaklist
    VecDoub a;
    VecBool ia;
    Doub chi2;
    Int convFlag;
    Doub eps;
    Int BigJ;
    Int planeToPlot;
    Int swF1;
    Int swF2;
    Int obsF1;
    Int obsF2;
    string outDir;
    string plotDir;
    Int plotMode;
    const SpectrumType &spectrum;
    const ParserType &parser;
    VecString error_msg;
    Int nArr;
    Uint nOL;
    Int nPar;
    Int nfix;
    Int nparred;
    Bool centerWt;
    Doub noise;

    PeakFitType(PeakListType_IO &_peak, VecDoub _f1, VecDoub _f2, VecInt _f3, VecDoub _y, VecDoub _sig,
                VecDoub _yopt, Int _BigJ, string _outDir, string _plotDir, const SpectrumType &_spectrum,
                const ParserType &_parser, VecString &_error_msg);

    void initFitPar(VecDoub_I &yopt);

    void fit(VecDoub f1, VecDoub f2, VecInt f3, VecDoub y, VecDoub sig, VecDoub &a,
             VecBool ia, Int &convFlag);

    void fit(Int plane);

    void peakCenter(VecDoub_I &yopt);

    void setFittedParameters(PeakType &peak1, PeakType &peak2, const Int i, const Int nParRes);

    void setFittedVolumes(PeakType &peak1, PeakType &peak2, Int i, Int nParRes);

    void setFittedIntensities(PeakType &peak1, PeakType &peak2, Int i, Int nParRes);

    void calcConvFlag(const PeakType &peak, Int &convFlag);

    void setConvFlag(PeakListType_IO &peakList, const Int convFlag);

    Int makeFinalParam(PeakListType_IO &peakList);

    Int fit_stage_zero(Peakmrq &mrqmin, Peakmrq &mrqminred, Int plane);

    Int fit_stage_one(Peakmrq &mrqmin, Peakmrq &mrqminred, Int plane);

    Int fit_stage_two(Peakmrq &mrqminred);

    Int fit_stage_three(Peakmrq &mrqmin, Peakmrq &mrqminred, Int plane);

    Int fit_stage_four(Peakmrq &mrqmin, Peakmrq &mrqminred);

    void setVolumeEsd();
};

typedef vector<PeakFitType> PeakFitListType;
typedef PeakFitListType PeakFitListType_O;
typedef PeakFitListType PeakFitListType_IO;
typedef const PeakFitListType PeakFitListType_I;

void copyPeakFitListToPeakList(PeakListType_IO &peak,  PeakFitListType_I &peakFit);

#endif
