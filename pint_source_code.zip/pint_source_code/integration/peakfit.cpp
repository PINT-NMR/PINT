#include "pint.h"
#include "fitmrq.h"
#include "peak.h"
#include "peakfit.h"
#include "fitfunctions.h"
#include "faddeeva.h"

#define NDONE 1

#define NPAR_GAUSSIAN 4
#define NPAR_LORENTZIAN 4
#define NPAR_GALORE 6
#define NPAR_VOIGT 6


void printVector(VecDoub_I &a)
{
    for(auto _a : a)
        cerr << _a << "\t";
    cerr << endl;
}

void calc_nfix(PeakType_I &peak, Int &nfix)
{
    if (peak.intMode == GAUSSIAN)
        nfix = NPAR_GAUSSIAN;
    else if (peak.intMode == LORENTZIAN)
        nfix = NPAR_LORENTZIAN;
    else if (peak.intMode == GALORE)
        nfix = NPAR_GALORE;
    else if (peak.intMode == VOIGT)
        nfix = NPAR_VOIGT;
}

void calc_planeToFitFirst(VecInt_I &excludePlane, Int &plane)
{
// needed since the plane to fit first is modified if
// planes before it are excluded. -PL

    for (auto _excludePlane : excludePlane)
        if (_excludePlane < plane)
            --plane;
}

PeakFitType::PeakFitType(PeakListType_IO &_peak, VecDoub _f1, VecDoub _f2, VecInt _f3, VecDoub _y,
                         VecDoub _sig, VecDoub _yopt, Int _BigJ, string _outDir, string _plotDir,
                         const SpectrumType &_spectrum, const ParserType &_parser, VecString &_error_msg) :
    peak(_peak), f1(_f1), f2(_f2), f3(_f3), y(_y), sig(_sig), yopt(_yopt), BigJ(_BigJ), outDir(_outDir),
    plotDir(_plotDir), spectrum(_spectrum), parser(_parser), error_msg(_error_msg), centerWt(false)
{
    eps = parser.eps;
    planeToPlot = parser.planeToPlot;
    plotMode = parser.plotMode;
    swF1 = spectrum.swF1;
    swF2 = spectrum.swF2;
    obsF1 = spectrum.obsF1;
    obsF2 = spectrum.obsF2;
    noise = spectrum.noise;

    nArr = peak[0].arr.size() - peak[0].excludePlane.size();
    nOL = peak.size();
    calc_nfix(peak[0], nfix);
    nparred = nfix + 1;
    nPar = nfix + nArr;
    for (Uint i=0; i<nOL && !centerWt; ++i)
        centerWt = peak[i].centerWt != 1.0;
}


void PeakFitType::initFitPar(VecDoub_I &yopt)
{
    a = VecDoub(peak.size()*nPar);
    ia = VecBool(peak.size()*nPar, true);

    for (Uint i=0; i<nOL; ++i) {
        a[0+i*nPar] = peak[i].appF1;
        a[1+i*nPar] = peak[i].lwF1_in;
        a[2+i*nPar] = peak[i].appF2;
        a[3+i*nPar] = peak[i].lwF2_in;
        if (peak[i].intMode == GALORE) {
            a[4+i*nPar]= peak[i].galoreLorF1_in;
            a[5+i*nPar]= peak[i].galoreLorF2_in;
        }
        if (peak[i].intMode == VOIGT) {
            a[1+i*nPar] = peak[i].voigtLorF1_in;
            a[3+i*nPar] = peak[i].voigtLorF2_in;
            a[4+i*nPar] = peak[i].voigtGaussF1_in;
            a[5+i*nPar] = peak[i].voigtGaussF2_in;

        }
        for (Int j=0; j<nArr; ++j)
            if (peak[i].intMode == LORENTZIAN)
                a[4+j+i*nPar] = yopt[i*nArr+j];
            else if (peak[i].intMode == GAUSSIAN)
                a[4+j+i*nPar] = yopt[i*nArr+j];
            else if (peak[i].intMode == GALORE)
                a[6+j+i*nPar] = yopt[i*nArr+j];
            else if (peak[i].intMode == VOIGT)
                a[6+j+i*nPar] = yopt[i*nArr+j]/voigtcore(a[4+i*nPar], a[5+i*nPar], a[1+i*nPar], a[3+i*nPar]);
    }
}


Int fit_lineshape(Peakmrq &mrqmin, Bool centerWt)
{
        mrqmin.ndone = NDONE;
        if (centerWt)
            return mrqmin.fit();
        else
            return mrqmin.fit_fast();
}


Int PeakFitType::fit_stage_zero(Peakmrq &mrqmin, Peakmrq &mrqminred, Int plane)
{
    for (Uint i=0; i<peak.size(); ++i) {
        mrqminred.a[0+i*nparred] = mrqmin.a[0+i*nPar]; // positions
        mrqminred.a[2+i*nparred] = mrqmin.a[2+i*nPar]; // positions
        mrqminred.a[1+i*nparred] = mrqmin.a[1+i*nPar]; // line widths
        mrqminred.a[3+i*nparred] = mrqmin.a[3+i*nPar]; // line widths
        mrqminred.a[4+i*nparred] = mrqmin.a[4+i*nPar]; // gaussian-lorentzian weighting
        mrqminred.a[5+i*nparred] = mrqmin.a[5+i*nPar]; // gaussian-lorentzian weighting
        mrqminred.a[nfix+i*nparred] = mrqmin.a[nfix+i*nPar+(plane-1)]; // intensity
        mrqminred.ia[0+i*nparred] = mrqminred.ia[2+i*nparred] = false; // positions
        mrqminred.ia[1+i*nparred] = mrqminred.ia[3+i*nparred] = false; // line widths
        mrqminred.ia[4+i*nparred] = mrqminred.ia[5+i*nparred] = false; // lorentzian voigt line widths
    }
    return fit_lineshape(mrqminred, centerWt);
}


Int PeakFitType::fit_stage_one(Peakmrq &mrqmin, Peakmrq &mrqminred, Int plane)
{
    for (Uint i=0; i<peak.size(); ++i) {
        mrqminred.a[0+i*nparred] = mrqmin.a[0+i*nPar]; // positions
        mrqminred.a[2+i*nparred] = mrqmin.a[2+i*nPar]; // positions
        mrqminred.a[1+i*nparred] = mrqmin.a[1+i*nPar]; // line widths
        mrqminred.a[3+i*nparred] = mrqmin.a[3+i*nPar]; // line widths
        if (peak[i].intMode == GALORE || peak[i].intMode == VOIGT) {
            mrqminred.a[4+i*nparred] = mrqmin.a[4+i*nPar]; // gaussian-lorentzian weighting or voigt line widths
            mrqminred.a[5+i*nparred] = mrqmin.a[5+i*nPar]; // gaussian-lorentzian weighting or voigt line widths
        }
        mrqminred.a[nfix+i*nparred] = mrqmin.a[nfix+i*nPar+(plane-1)]; // intensity
        mrqminred.ia[0+i*nparred] = mrqminred.ia[2+i*nparred] = false; // positions
        mrqminred.ia[1+i*nparred] = mrqminred.ia[3+i*nparred] = !peak[i].fixLW; // line widths
        if (peak[i].intMode == VOIGT) {
            mrqminred.ia[4+i*nparred] = mrqminred.ia[5+i*nparred] = !peak[i].fixLW; // lorentzian voigt line widths
        }
    }
    return fit_lineshape(mrqminred, centerWt);
}


Int PeakFitType::fit_stage_two(Peakmrq &mrqminred)
{
    Int flag = 0;
    for (Uint i=0; i<nOL; ++i)
        if (!peak[i].fixPos) {
            mrqminred.ia[0+i*nparred] = mrqminred.ia[2+i*nparred] = true;
            flag = true;
        }
    if (flag)
        return fit_lineshape(mrqminred, centerWt);
    return 0;
}


Int PeakFitType::fit_stage_three(Peakmrq &mrqmin, Peakmrq &mrqminred, Int plane)
{
    for (Uint i=0; i<nOL; ++i) {
        if (!peak[i].fixPos) {
            mrqmin.a[0+i*nPar] = mrqminred.a[0+i*nparred];
            mrqmin.a[2+i*nPar] = mrqminred.a[2+i*nparred];
        }
        if (!peak[i].fixLW) {
            mrqmin.a[1+i*nPar] = mrqminred.a[1+i*nparred];
            mrqmin.a[3+i*nPar] = mrqminred.a[3+i*nparred];
        }
        if (peak[i].intMode == GALORE || peak[i].intMode == VOIGT) {
            mrqmin.a[4+i*nPar] = mrqminred.a[4+i*nparred];
            mrqmin.a[5+i*nPar] = mrqminred.a[5+i*nparred];
        }
        mrqmin.a[nfix+i*nPar+(plane-1)] = mrqminred.a[nfix+i*nparred];
        mrqmin.ia[0+i*nPar] = mrqmin.ia[2+i*nPar] = false;
        mrqmin.ia[1+i*nPar] = mrqmin.ia[3+i*nPar] = false;
        if (peak[i].intMode == GALORE || peak[i].intMode == VOIGT)
            mrqmin.ia[1+i*nPar] = mrqmin.ia[3+i*nPar] = false;

    }
    return fit_lineshape(mrqmin, centerWt);
}

Int PeakFitType::fit_stage_four(Peakmrq &mrqmin, Peakmrq &mrqminred)
{
    for (Uint i=0; i<nOL; ++i) {
        if (!peak[i].fixPos) {
            mrqmin.a[0+i*nPar] = mrqminred.a[0+i*nparred];
            mrqmin.a[2+i*nPar] = mrqminred.a[2+i*nparred];
        }
        if (!peak[i].fixLW) {
            mrqmin.a[1+i*nPar] = mrqminred.a[1+i*nparred];
            mrqmin.a[3+i*nPar] = mrqminred.a[3+i*nparred];
        }
        mrqmin.ia[0+i*nPar] = mrqmin.ia[2+i*nPar] = !peak[i].fixPos;
        mrqmin.ia[1+i*nPar] = mrqmin.ia[3+i*nPar] = !peak[i].fixLW;
        if (peak[0].intMode == GALORE)
            mrqmin.ia[4+i*nPar] = mrqmin.ia[5+i*nPar] = true;
        if (peak[0].intMode == VOIGT)
            mrqmin.ia[4+i*nPar] = mrqmin.ia[5+i*nPar] = !peak[i].fixLW;
    }
    return fit_lineshape(mrqmin, centerWt);
}

void PeakFitType::fit(Int plane)
{
// Normal way of fitting. First only plane k (range 1-nPlane)
// is fitted to quickly get good estimates of line widths and positions
// then everything is fitted



    Int vecsize = f1.size()/nArr;

    VecDoub f1red(vecsize);
    VecDoub f2red(vecsize);
    VecDoub yred(vecsize);
    VecDoub sigred(vecsize);
    VecInt  f3red(vecsize);
    VecDoub ared(nparred*nOL);
    VecBool iared(nparred*nOL, true);

    calc_planeToFitFirst(peak[0].excludePlane, plane);
    Int j=0;
    for (Int i=(plane-1)*vecsize; i<plane*vecsize; ++i,++j) {
         f1red[j] = f1[i];
         f2red[j] = f2[i];
         f3red[j] = 1;
         yred[j] = y[i];
         sigred[j] = sig[i];
    }

    Peakmrq mrqminred(f1red, f2red, f3red, yred, sigred, ared, iared, nOL, 1, peak[0].funcs, chi2, eps);
    Peakmrq mrqmin(f1, f2, f3, y, sig, a, ia, nOL, nArr, peak[0].funcs, chi2, eps);

    // 0. fitting w/ fixed peak position and line width for selected plane (only voigt)
    if (peak[0].intMode == VOIGT) {
        convFlag = fit_stage_one(mrqmin, mrqminred, plane);
    }

    // 1. First do fitting w/ fixed peak position for only selected plane
    convFlag = fit_stage_one(mrqmin, mrqminred, plane);

    // 2. Then let all parameters float for selected plane
    // unless flags require them to be fixed.
    convFlag = fit_stage_two(mrqminred);

    if (nArr == 1) {
        a = mrqminred.a; // must do this since mrqminred does not hold proper a vector
        chi2 = mrqminred.chisq;
        return;
    }

    // 3. Redo fitting for all planes with all intensities floating
    // but fix positions and line widths to values obtained from
    // the optimized parameters from step 2.
    convFlag = fit_stage_three(mrqmin, mrqminred, plane);

    // 4. Redo fitting for all planes with all parameters floating
    // unless fixPos and/or flag is specified. It is allowed to fix
    // some peak positions in an overlapped group. Use the optimized
    // parameters from step 3.
    convFlag = fit_stage_four(mrqmin, mrqminred);
    chi2 = mrqmin.chisq;
}



void PeakFitType::peakCenter(VecDoub_I &yopt)
{
// 1. Only do for a 2D spectrum
// 2. Always use Gaussian function
// 3. Since peaks may be far from true position it is stupid to
//    first try to fit with fixed peak position, so don't

    a = VecDoub(nOL*NPAR_GAUSSIAN);
    ia = VecBool(nOL*NPAR_GAUSSIAN, true);

    for (Uint i=0; i<nOL; ++i) {
        a[0+i*NPAR_GAUSSIAN] = peak[i].appF1;
        a[1+i*NPAR_GAUSSIAN] = peak[i].lwF1_in;
        a[2+i*NPAR_GAUSSIAN] = peak[i].appF2;
        a[3+i*NPAR_GAUSSIAN] = peak[i].lwF2_in;
        a[4+i*nPar] = yopt[i];
    }
    Peakmrq mrqmin(f1, f2, f3, y, sig, a, ia, nOL, nArr, gaussian, chi2, eps);
    convFlag = fit_lineshape(mrqmin, centerWt);
}


void PeakFitType::setFittedParameters(PeakType &peak1, PeakType &peak2, const Int i, const Int nParRes)
{
    peak1.ppmF1 = peak2.ppmF1 = a[i*nParRes] + peak2.foldF1*swF1/obsF1;
    peak1.ppmF2 = peak2.ppmF2 = a[2+i*nParRes] + peak2.foldF2*swF2/obsF2;

    if (peak2.intMode == LORENTZIAN || peak2.intMode == GAUSSIAN || peak2.intMode == GALORE) {
        peak1.lwF1 = peak2.lwF1 = fabs(a[1+i*nParRes]*obsF1);
        peak1.lwF2 = peak2.lwF2 = fabs(a[3+i*nParRes]*obsF2);
        peak1.lwF1_in = peak2.lwF1_in *=obsF1;
        peak1.lwF2_in = peak2.lwF2_in *=obsF2;
    }
    else if (peak2.intMode == VOIGT) {
        Doub lw_gF1 = a[4+i*nParRes];
        Doub lw_gF2 = a[5+i*nParRes];
        Doub lw_lF1 = a[1+i*nParRes];
        Doub lw_lF2 = a[3+i*nParRes];

        Doub lw_gF1_in = peak2.voigtGaussF1_in;
        Doub lw_gF2_in = peak2.voigtGaussF2_in;
        Doub lw_lF1_in = peak2.voigtLorF1_in;
        Doub lw_lF2_in = peak2.voigtLorF2_in;

        peak1.lwF1 = peak2.lwF1 = fabs(0.53446*lw_lF1 + sqrt(0.2166*lw_lF1*lw_lF1 + lw_gF1*lw_gF1))*obsF1;
        peak1.lwF2 = peak2.lwF2 = fabs(0.53446*lw_lF2 + sqrt(0.2166*lw_lF2*lw_lF2 + lw_gF2*lw_gF2))*obsF2;

        peak1.lwF1_in = peak2.lwF1_in = fabs(0.53446*lw_lF1_in + sqrt(0.2166*lw_lF1_in*lw_lF1_in + lw_gF1_in*lw_gF1_in))*obsF1;
        peak1.lwF2_in = peak2.lwF2_in = fabs(0.53446*lw_lF2_in + sqrt(0.2166*lw_lF2_in*lw_lF2_in + lw_gF2_in*lw_gF2_in))*obsF2;
    }

    peak1.nData = peak2.nData = f1.size();
    peak1.chi2 = peak2.chi2 = chi2;
    peak1.nOL = peak2.nOL = nOL;
    peak1.dof =  peak2.dof = (peak2.nData - 1)*peak2.arr.size();
    peak1.dof =  peak2.dof -= (peak2.intMode == GAUSSIAN || peak2.intMode == LORENTZIAN) ? 4 : 6;
}

void PeakFitType::setFittedIntensities(PeakType &peak1, PeakType &peak2, Int i, Int nParRes)
{
    Int j=0;
    for (Uint k=0; k<peak2.arr.size(); ++j, ++k) {

        Bool flag = false;
        for (Uint l=0; l<peak2.excludePlane.size() && !flag; ++l)
            if ((Uint)peak2.excludePlane[l] == k+1) {
                --j;
                flag = true;
        }
        if (flag)
            continue;

        switch (peak2.intMode) {
            case LORENTZIAN: peak1.intensity[k] = peak2.intensity[k] = lorentziancore(a[i*nParRes], a[2+i*nParRes], j+1, a, nOL, nArr); break;
            case GAUSSIAN: peak1.intensity[k] = peak2.intensity[k] =  gaussiancore(a[i*nParRes], a[2+i*nParRes], j+1, a, nOL, nArr); break;
            case GALORE: peak1.intensity[k] = peak2.intensity[k] = galorecore(a[i*nParRes], a[2+i*nParRes], j+1, a, nOL, nArr); break;
            case VOIGT: peak1.intensity[k] = peak2.intensity[k] = voigtcore(a[i*nParRes], a[2+i*nParRes], j+1, a, nOL, nArr); break;
        }
    }
}

void PeakFitType::setFittedVolumes(PeakType &peak1, PeakType &peak2, const Int i, const Int nParRes)
{
    Int j=0;
    for (Uint k=0; k<peak2.arr.size(); ++j, ++k) {

        Bool flag = false;
        for (Uint l=0; l<peak2.excludePlane.size() && !flag; ++l)
            if ((Uint)peak2.excludePlane[l] == k+1) {
                --j;
                flag = true;
            }
        if (flag)
            continue;

        switch (peak2.intMode) {
            case LORENTZIAN: peak1.vol[k] = peak2.vol[k] = a[4+j+i*nParRes]*a[1+i*nParRes]*a[3+i*nParRes]*SQR(PI)/4.; break;
            case GAUSSIAN: peak1.vol[k] = peak2.vol[k] = PI/(4.*log(2.))*fabs(a[1+i*nParRes]*a[3+i*nParRes])*a[4+j+i*nParRes]; break;
            case GALORE: peak1.vol[k] = peak2.vol[k] = a[6+j+i*nParRes] * fabs(a[1+i*nParRes]*a[3+i*nParRes]) * (

                                    a[4+i*nParRes]*a[5+i*nParRes]*SQR(PI)/4. +

                                    (1.-a[4+i*nParRes])*(1.-a[5+i*nParRes])*PI/(4*log(2.)) +

                                    a[4+i*nParRes]*PI/2.*(1.-a[5+i*nParRes])*sqrt(PI/(4*log(2.))) +

                                    a[5+i*nParRes]*PI/2.*(1.-a[4+i*nParRes])*sqrt(PI/(4*log(2.)))); break;

            // This is not correct
            case VOIGT: peak1.vol[k] = peak2.vol[k] = a[6+j+i*nParRes]/voigtcore(a[4+i*nPar], a[5+i*nPar], a[1+i*nPar], a[3+i*nPar]);
        }
    }
}

void PeakFitType::calcConvFlag(const PeakType &peak, Int &convFlag)
{
    if (fabs(peak.f1 - peak.ppmF1) > peak.maxMoveF1 && peak.maxMoveF1 > 0)
        convFlag = 2;

    if (fabs(peak.f2 - peak.ppmF2) > peak.maxMoveF2 && peak.maxMoveF2 > 0.)
        convFlag = 3;

    if (peak.lwF1/obsF1 > peak.maxlwF1 && peak.maxlwF1 > 0.)
        convFlag = 4;

    if (peak.lwF2/obsF2 > peak.maxlwF2 && peak.maxlwF2 > 0.)
        convFlag = 5;

    if (peak.lwF1/obsF1 < peak.minlwF1 && peak.minlwF1 > 0.)
        convFlag = 6;

    if (peak.lwF2/obsF2 < peak.minlwF2 && peak.minlwF2 > 0.)
        convFlag = 7;
}

void PeakFitType::setConvFlag(PeakListType_IO &peakList, const Int convFlag)
{
    for (Uint h=0; h<peakList.size(); ++h)
        for (Uint i=0; i<peak.size(); ++i)
            if (peakList[h].assi == peak[i].assi)
                 peakList[h].convFlag = peak[i].convFlag = convFlag;
}



Int PeakFitType::makeFinalParam(PeakListType_IO &peakList)
{
    // Calculates intensities and volumes from fitted parameters
    // and converts linewidth from ppm to Hz.
    // Also may classify the peak as non-converged
    // Even if it did converge in fitting. Codes:
    // 0: converged
    // 1: did not converge in fitting
    // 2: Too much peak movement in F1
    // 3: Too much peak movement in F2
    // 4: Too large line width in F1
    // 5: Too large line width in F2
    // 6: Too small line width in F1
    // 7: Too small line width in F2
    //
    // There will be an additional possible error code that is
    // set in a function in esd.h. It will be set if the computed
    // uncertainty in peak iintensity is too outrageous.
    //
    // N.B.! More than one thing may have gone wrong but only one error is reported

    for (Uint h=0; h<peakList.size(); ++h) {
        for (Uint i=0; i<peak.size(); ++i) {
            if (peakList[h].assi == peak[i].assi) {
                peakList[h].fitFlag = peak[i].fitFlag = 1;
                if (convFlag) continue;

                setFittedParameters(peakList[h], peak[i], i, nPar);
                calcConvFlag(peakList[h], convFlag);
                setFittedIntensities(peakList[h], peak[i], i, nPar);
                setFittedVolumes(peakList[h], peak[i], i, nPar);
            }
        }
    }
    setConvFlag(peakList, convFlag);
    return 0;
}


void copyPeakFitListToPeakList(PeakListType_IO &peak,  PeakFitListType_I &peakFit)
{
    for (Uint i=0; i<peak.size(); ++i)
        for (Uint j=0; j<peakFit.size(); ++j)
            for (Uint k=0; k<peakFit[j].peak.size(); ++k)
                if (peak[i].assi == peakFit[j].peak[k].assi)
                    peak[i] = peakFit[j].peak[k];
}

void PeakFitType::setVolumeEsd()
{
//  N.B. This must be done after esd (to calculate errors in intensities) has been called.
//  N.B. (2) Error in intensity is set to noise if it has not been calculated from duplicates.

        for (Uint i=0; i<peak.size(); ++i) {

            if (peak[i].esd == 0.0)
                peak[i].esd = noise;

            switch (peak[i].intMode) {
                case LORENTZIAN: peak[i].dvol = peak[i].esd*a[1+i*nPar]*a[3+i*nPar]*SQR(PI)/4.; break;
                case GAUSSIAN: peak[i].dvol = PI/(4.*log(2.))*fabs(a[1+i*nPar]*a[3+i*nPar])*peak[i].esd; break;
                case GALORE: peak[i].dvol =  peak[i].esd * fabs(a[1+i*nPar]*a[3+i*nPar]) * (

                                    a[4+i*nPar]*a[5+i*nPar]*SQR(PI)/4. +

                                    (1.-a[4+i*nPar])*(1.-a[5+i*nPar])*PI/(4*log(2.)) +

                                    a[4+i*nPar]*PI/2.*(1.-a[5+i*nPar])*sqrt(PI/(4*log(2.))) +

                                    a[5+i*nPar]*PI/2.*(1.-a[4+i*nPar])*sqrt(PI/(4*log(2.)))); break;

                // This is not correct
                case VOIGT: peak[i].dvol = peak[i].esd;
            }
        }
}

