// esd.cpp
//


#include "peak.h"
#include "sort.h"
#include "fitmrq.h"
#include "esd.h"


EsdType::EsdType() : outDir("") {}
EsdType::EsdType(const string &_outDir) : outDir(_outDir)
{
    sprintf(errorList, "%s/duplicates.txt", outDir.c_str());
}

void EsdType::calcEsd(PeakListType &peak)
{
    Int nDupInd = 0;
    Doub sumInd = 0., sumOfSquaresInd = 0.;
    ofstream myFile;

    for (auto &_peak : peak) {
        if (_peak.noiseUncertainty)
            continue;
        appendDuplicate(_peak, sumInd, sumOfSquaresInd, nDupInd);
        calcSdev(_peak, sumInd, sumOfSquaresInd, nDupInd);
        sumInd = sumOfSquaresInd = nDupInd = 0;
    }
}

void EsdType::appendDuplicate(const PeakType &peak, Doub &sum, Doub &sumOfSquares, Int &nDup)
{
    Uint i;
    Doub memory, memoryVol;
    VecDoub arr, intensity;

    if (peak.convFlag)
        return;

    for (Uint i=0; i<peak.arr.size(); ++i)
        if (!isPlaneExcluded(peak, i+1)) {
            arr.push_back(peak.arr[i]);
            intensity.push_back(peak.intensity[i]);
        }

    sort2(arr, intensity);

    for (i=1, memory=arr[0], memoryVol=intensity[0]; i<peak.arr.size(); ++i) {
        if (arr[i] == memory) {
            ++nDup;
            sum +=  intensity[i] - memoryVol;
            sumOfSquares += (intensity[i] - memoryVol)*(intensity[i] - memoryVol);
            dupDup.push_back(intensity[i] - memoryVol);
            dupAssi.push_back(peak.assi);
            dupListAssi.push_back(peak.assi);
            dupListArr.push_back(memory);
            dupListFirst.push_back(memoryVol);
            dupListSec.push_back(intensity[i]);
            dupListDiff.push_back(fabs(memoryVol-intensity[i]));
        }
        memory = arr[i];
        memoryVol = intensity[i];
    }
}


void EsdType::calcSdev(PeakType &peak, Doub sum, Doub sumOfSquares, Uint nDup)
{
    // The "2." in the expression is beacause this is pairwise data.
    // This version is for peaks with individual errors
    if ((sumOfSquares - sum*sum/(Doub)nDup) && nDup > 1)
        peak.esd = sqrt((sumOfSquares - sum*sum/(Doub)nDup)/ (2.*((Doub)nDup - 1.)));
}


struct Ran {
    Ullong u,v,w;
    Ran(Ullong j) : v(4101842887655102017LL), w(1) {
        u = j ^ v;
        int64();
        v = u;
        int64();
        w = v;
        int64();
    }
    inline Ullong int64() {
        u = u * 2862933555777941757LL + 7046029254386353087LL;
        v ^= v >> 17;
        v ^= v << 31;
        v ^= v >> 8;
        w = 4294957665U*(w & 0xffffffff) + (w >> 32);
        Ullong x = u ^ (u << 21);
        x ^= x >> 35;
        x ^= x << 4;
        return (x + v) ^ w;
    }
    inline Doub doub() {
        return 5.42101086242752217E-20 * int64();
    }
    inline Int int32() {
        return (Int)int64();
    }
};


struct Normaldev : Ran {
    Doub mu,sig;
    Normaldev(Doub mmu, Doub ssig, Ullong i)
        : Ran(i), mu(mmu), sig(ssig) {}
    Doub dev() {
        Doub u,v,x,y,q;
        do {
            u = doub();
            v = 1.7156*(doub()-0.5);
            x = u - 0.449871;
            y = abs(v) + 0.386595;
            q = SQR(x) + y*(0.19600*y-0.25472*x);
        } while (q > 0.27597
                 && (q > 0.27846 || SQR(v) > -4.*log(u)*SQR(u)));
        return mu + sig*v/u;
    }
};

#define N_MC 500
#define N_BOOTSTRAP 100

ErrorSim::ErrorSim(VecDoub_I &xx, VecDoub_I &yy, VecDoub_I &ssig, VecDoub_I &gguess, VecBool_I &iia,
                   void (*funks)(const Doub, VecDoub_I &, Doub &, VecDoub_O &)) :
    x(xx), y(yy), sig(ssig), ndata(x.size()), guess(gguess), ia(iia), ma(guess.size()), funcs(funks) { }


void ErrorSim::simerror(Bool fjack, Bool fboot, Bool fmc)
{
    montecarlo(fmc);
    jackknife(fjack);
    bootstrap(fboot);
}

void ErrorSim::montecarlo(Bool fmc)
{
    if (!fmc)
        return;

    VecDoub chisqmc(N_MC);
    VecDoub dyda(ma);
    VecDoub s(ma, 0.);
    VecDoub s2(ma, 0.);
    VecDoub yfit(ndata);
    VecDoub ymc(ndata);

    Normaldev gasdev(0., 0., 42);

    for (Uint i=0; i<ndata; ++i)
        funcs(x[i], guess, yfit[i], dyda);

    for (Uint i=0; i<N_MC; ++i) {
        for (Uint j=0; j<ndata; ++j) {
            gasdev.sig = sig[j];
            ymc[j] = yfit[j] + gasdev.dev();
        }
        Fitmrq mrqfit(x, ymc, sig, guess, ia, funcs);
        mrqfit.fit();
        for (Uint j=0; j<ma; ++j) {
            s[j] += mrqfit.a[j];
            s2[j] += SQR(mrqfit.a[j]);
        }
    }

    simerr.resize(ma);
    for (Uint i=0; i<ma; ++i)
        simerr[i] = sqrt((s2[i] - SQR(s[i])/(Doub)N_MC)/(Doub)(N_MC-1));
}

void ErrorSim::jackknife(Bool fjack)
{

    if (!fjack)
        return;

    Doub pseudoa;
    Doub xspare, yspare, sigspare;
    VecDoub chisqjack(ndata);
    VecDoub s(ma, 0.);
    VecDoub s2(ma, 0.);
    VecDoub xjack(ndata-1);
    VecDoub yjack(ndata-1);
    VecDoub sigjack(ndata-1);

    for (Uint i=0; i<ndata-1; ++i) {
        xjack[i] = x[i];
        yjack[i] = y[i];
        sigjack[i] = sig[i];
    }
    xspare = x[ndata-1];
    yspare = y[ndata-1];
    sigspare = sig[ndata-1];

    for (Uint i=0; i<ndata; ++i) {
        Fitmrq mrqfit(xjack, yjack, sigjack, guess, ia, funcs);
        mrqfit.fit();

        for (Uint j=0; j<ma; ++j) {
            pseudoa = ndata*guess[j] - (ndata-1)*mrqfit.a[j];
            s[j] += pseudoa;
            s2[j] += SQR(pseudoa);
        }
        if (i<ndata-1) {
            swap(xjack[i],xspare);
            swap(yjack[i],yspare);
            swap(sigjack[i],sigspare);
        }
    }

    simerr.resize(ma);
    for (Uint j=0; j<ma; ++j)
        simerr[j] = sqrt((s2[j] - s[j]*s[j]/(Doub)ndata)/(Doub)(ndata*(ndata-1)));
}

void ErrorSim::bootstrap(Bool fboot)
{
    //////////////////////////////////
    // Bootstrap estimation of errors some data points are replaced
    // with duplicates of other data points in each round. The
    // standard error of the fitted values are used as a
    // measure of the uncertainty of the fitted parameters.
    //
    // BOOTSTRAP IS NO GOOD WHEN TO FEW DATA POINTS ARE FITTED
    // SINCE HIGHLY IRREGULAR DATA SETS MAY RESULT. A WORST
    // CASE SCENARIO IS THAT THE SAME DATA POINT IS DRAWN FOR
    // THE ENTIRE SET MEANING THAT THE PROGRAM EVEN CRASHES.
    // USE WITH CAUTION!!
    //
    // coded by Patrik Lundstrom
    //////////////////////////////////
    if (!fboot)
        return;

    VecDoub aboot(ma);
    VecDoub chisq(N_BOOTSTRAP);
    VecDoub s(ma, 0.);
    VecDoub s2(ma, 0.);
    VecDoub sigboot(ndata);
    VecDoub xboot(ndata);
    VecDoub yboot(ndata);

    int boot;
    Ran randNum(42);

    for (Uint i=0; i<N_BOOTSTRAP; ++i) {

        for (Uint j=0; j<ndata; ++j) {
            boot = (int)(randNum.doub()*(ndata-1) + 0.5);
            xboot[j] = x[boot];
            yboot[j] = y[boot];
            sigboot[j] = sig[boot];
        }

        Fitmrq mrqfit(xboot, yboot, sigboot, guess, ia, funcs);
        mrqfit.fit();

        for (Uint j=0; j<ma; ++j) {
            s[j] += mrqfit.a[j];
            s2[j] += SQR(mrqfit.a[j]);
        }
    }

    simerr.resize(ma);
    for (Uint j=0; j<ma; ++j)
        simerr[j] = sqrt((s2[j] - SQR(s[j])/(Doub)N_BOOTSTRAP)/(Doub)(N_BOOTSTRAP-1));
}
