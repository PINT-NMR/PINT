// gaussj.h
//
// Gauss-Jordan inversion of matrices and simultaneous
// solution of a set of linear equations. The routine is
// similar to the one in Numerical Recipes but instead of
// capabiliteis for solving several systems (using a
// matrix 'b') only one can be solved here ('b' is a
// column vector). Another difference is to test for
// singularity before routine crashes.
//
// Patrik Lundstrom, 140511
// /////////////////////////////////////////////////////////

#ifndef _GAUSSJ
#define _GAUSSJ

#include "pint.h"

Int gaussj(MatDoub_IO &a, VecDoub_IO &b);

Int gaussj(MatDoub_IO &a, MatDoub_IO &b);

#endif
