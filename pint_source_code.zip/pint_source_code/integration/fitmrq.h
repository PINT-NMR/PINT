#ifndef _FITMRQ
#define _FITMRQ

#include "pint.h"
#include "gaussj.h"

struct Peakmrq
{
// This class fits peak shapes

    Int ndata, ma, mfit;
    VecDoub_I x1, x2;      // data in indirect and direct dimension
    VecInt_I x3;           // index of which 2D or plane in 3D
    VecDoub_I y, sig;      // intensity and uncertainty
    Int nol, narr;
    Int ndone, itmax;
    Doub tol;
    void (*funcs)(const Doub, const Doub, const Int, VecDoub &, Doub &, VecDoub_O &,const Int,const Int);
    VecBool &ia;  // Beware that this is a reference;
    VecDoub &a;   // Beware that this is a reference;
    MatDoub covar;
    MatDoub alpha;
    Doub chisq;

    Peakmrq(VecDoub_I &xx1, VecDoub_I &xx2, VecInt_I &xx3, VecDoub_I &yy, VecDoub_I &ssig, VecDoub &aa,
            VecBool &iia, Int nnol, Int nnarr, void funks(Doub, Doub, Int, VecDoub &, Doub &, VecDoub_O &,Int,Int),
            Doub &cchisq, Doub ttol=1.e-6, Int nndone=100, Int iitmax=100000);

    void fix(const Int i);

    void fix(const Int i, const Doub val);

    void free(const Int i);

    Int choleskyinvert(MatDoub &temp, VecDoub &b);

    Int fit();

    Int fit_fast();

    void mrqcof(VecDoub &a, MatDoub_O &alpha, VecDoub_O &beta);

    void mrqcof_fast(VecDoub &a, MatDoub_O &alpha, VecDoub_O &beta);

    void covsrt(MatDoub_IO &covar, MatDoub_IO &alpha);
};


struct Fitmrq
{
// This class fits 1D functions like expoentials, tanh and CPMG

    Int ndata, ma, mfit;
    VecDoub_I &x,&y,&sig;
    Int ndone, itmax;
    Doub tol;
    void (*funcs)(const Doub, VecDoub_I &, Doub &, VecDoub_O &);
    VecBool ia;
    VecDoub a;
    MatDoub covar;
    MatDoub alpha;
    Doub chisq;

    Fitmrq(VecDoub_I &xx, VecDoub_I &yy, VecDoub_I &ssig, VecDoub_I &aa,
           VecBool_I &iia, void funks(const Doub, VecDoub_I &, Doub &, VecDoub_O &), const Doub
           TOL=1.e-3, const Int NDONE=4, const Int ITMAX=1000);

    void fix(const Int i, const Doub val);

    void free(const Int i);

    Int fit();

    void mrqcof(VecDoub_I &a, MatDoub_O &alpha, VecDoub_O &beta);

    void covsrt(MatDoub_IO &covar, MatDoub_IO &alpha);

    // This is the public gridsearch
    void gridSearch(VecDoub_I &aLo, VecDoub_I &aHi, VecInt_I &aSteps, Bool fgrid);

private:
    void gridSearch(VecDoub_I &aLo, VecDoub_I &aHi, VecInt_I &aSteps, VecDoub_IO &aAct, Uint index);
};

#endif
