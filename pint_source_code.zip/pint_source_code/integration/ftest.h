#ifndef _FTEST
#define _FTEST



// ftestchisq.h
//
// Caclulates the probability that two models are
// equally valid by doing an f-test on their
// respective chisquares
//
// - The "full" chi2 NOT the reduced ones should be entered
// - df refers to degrees of freedom which is n-m, where
//   n is no. data points and m is the number of parameters
//   used to determine chi2
//
// Example 1: You are testing two variances with n1 and n2 points
// df1 = n1-1 and df2=n2-1
//
// Example 2: You are testing the fit of a 2-parameter and a
// 4-parameter model to your data of size n. df1 = n-2 df2=n-4
//
// coded by Patrik Lundstrom, 021024



#include "pint.h"


struct FTest
{
    Doub chisq2,		// chisq for second model
         f,		    // f statistic
         prob,		// probability that models are equally good
         df1,		// degrees of freedom first model
         df2;		// degrees of freedom second model

    void test(Doub chisq1, Doub _df1, Doub chisq2, Doub _df2);

    //Doub gammln(Doub xx);

    Doub betai(Doub a,Doub b, Doub x);

    Doub betacf(Doub a, Doub b, Doub x);
};

#endif
