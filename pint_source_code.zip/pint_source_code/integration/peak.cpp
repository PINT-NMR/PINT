#include "peak.h"
#include "parser.h"
#include "spectrum.h"
#include "faddeeva.h"
#include "fitfunctions.h"
#ifdef PINTGUI
#include <QString>
#endif

// Guessed values for position, linewidth and peak radius
InitialGuess::InitialGuess() {}
InitialGuess::InitialGuess(Doub _lwF1, Doub _lwF2, Doub _radF1, Doub _radF2) : lwF1(_lwF1), lwF2(_lwF2), radF1(_radF1), radF2(_radF2) {}

// Override default plane to exclude
OExcludeType::OExcludeType() {}

// Override some double setting
ODoubleType::ODoubleType() {}
ODoubleType::ODoubleType(string wd1, string wd2) { assi=wd1; val=atof(wd2.c_str()); }


// Override default two doubles
OTwoDoubType::OTwoDoubType() {}
OTwoDoubType::OTwoDoubType(string wd1, string wd2, string wd3) : assi(wd1), d1(atof(wd2.c_str())), d2(atof(wd3.c_str())) {}

// Override default one double and one int
ODoubIntType::ODoubIntType() {}
ODoubIntType::ODoubIntType(string wd1, string wd2, string wd3) : assi(wd1), d(atof(wd2.c_str())), i(atoi(wd3.c_str())) {}

// A double and one int to be used by OjcoupType
DoubIntType::DoubIntType() {}
DoubIntType::DoubIntType(Doub _d, Int _i) : dbl(_d), integ(_i) {}
DoubIntType::DoubIntType(string _d, string _i) : dbl(atof(_d.c_str())), integ(atoi(_i.c_str())) {}


// Override J-couplings
OjcoupType::OjcoupType() {}
OjcoupType::OjcoupType(string _assi) : assi(_assi) {}


// Override default lineshape
OIntModeType::OIntModeType() {}
OIntModeType::OIntModeType(string wd1, string wd2) : assi(wd1), intMode(atoi(wd2.c_str()))
{
    if (wd2 == "LORENTZIAN") {
        intMode = LORENTZIAN;
        funcs = lorentzian;
        funcscore = lorentziancore;
    }
    else if (wd2 == "GAUSSIAN") {
        intMode = GAUSSIAN;
        funcs = gaussian;
        funcscore = gaussiancore;
    }
    else if (wd2 == "GALORE") {
        intMode = GALORE;
        funcs = galore;
        funcscore = galorecore;
    }
    else if (wd2 == "VOIGT") {
        intMode = VOIGT;
        funcs = voigt;
        funcscore = voigtcore;
    }
}


Int OIntModeType::setIntMode(string wd1, string wd2, VecString &error_msg)
{
    assi = wd1;
    if (wd2 == "LORENTZIAN") {
        intMode = LORENTZIAN;
        funcs = lorentzian;
        funcscore = lorentziancore;
    }
    else if (wd2 == "GAUSSIAN") {
        intMode = GAUSSIAN;
        funcs = gaussian;
        funcscore = gaussiancore;
    }
    else if (wd2 == "GALORE") {
        intMode = GALORE;
        funcs = galore;
        funcscore = galorecore;
    }
    else if (wd2 == "VOIGT") {
        intMode = VOIGT;
        funcs = voigt;
        funcscore = voigtcore;
    }
    else {
        error_msg.push_back("ERROR: Illegal lineshape in option '-DEFINELINESHAPE' for peak " + assi);
        return 1;
    }
    return 0;
}


// peak type
PeakType::PeakType() :
    f1(0.), f2(0.),
    appF1(0.), appF2(0.),
    foldF1(0), foldF2(0),
    arr(1),

    lwF1_in(0.3), lwF2_in(0.03),
    radF1(0.6), radF2(0.06),
    intMode(1),
    nData(0),
    nOL(1),
    OLmarker(false),
    fixPos(false),
    fixLW(false),
    maxlwF1(0.), maxlwF2(0.),
    minlwF1(0.), minlwF2(0.),
    maxMoveF1(-1.), maxMoveF2(-1.),
    centerWt(1.),
    galoreLorF1_in(0.1), galoreLorF2_in(0.1),
    voigtLorF1_in(lwF1_in), voigtLorF2_in(lwF2_in),
    voigtGaussF1_in(lwF1_in), voigtGaussF2_in(lwF2_in),
    noiseUncertainty(false),

    ppmF1(0.), ppmF2(0.),
    lwF1(0.), lwF2(0.),
    galoreLorF1(0.), galoreLorF2(0.),
    voigtLorF1(0.), voigtLorF2(0.),
    voigtGaussF1(0.), voigtGaussF2(0.),
    intensity(1),
    vol(1),
    esd(0.),
    dvol(0.),
    chi2(0.),
    dof(0),
    readFlag(false),fitFlag(false), convFlag(1),
    resNo(""),

    fitConstant(0), fitLin(0), fitExp(0), fitBiExp(0), fitExpOffset(0), fitR1rho(0), fitNOE(0), fitTanh(0),
    fitCPMG(0), fitInvRecovery(0), fitSatRecovery(0),

    R1(0.), dR1(0.),
    R12(1.0), dR12(0.), A12(1000.), dA12(0.),
    expoffsR12(0.), dexpoffsR12(0.), expoffsA12(1000.), dexpoffsA12(0.), expoffsOffset(1000.), dexpoffsOffset(0.),
    invrecR1(0.), dinvrecR1(0.), invrecPlateau(1000.), dinvrecPlateau(0.),
    satrecR1(0.), dsatrecR1(0.), satrecPlateau(1000.), dsatrecPlateau(0.),
    offs(0.), dOffs(0.),
    BExp1(1.), dBExp1(0.), BExp2(10.), dBExp2(0.), BExpA1(1000.), dBExpA1(0.), BExpA2(100.), dBExpA2(0.),
    intercept(1000.), dintercept(0.), slope(1.), dslope(0.),
    constant(1000.), dconstant(0.),
    R20(0.), dR20(0.), kex(0.), dkex(0.), pB(0.), dpB(0.), Dw(0.), dDw(0.), rmsdCpmg(0.), fixKex(false), fixPb(false),
    chi2Constant(0.0), chi2Lin(0.), chi2Exp(0.), chi2ExpOffs(0.), chi2Tanh(0.), chi2Const(0.), chi2Cpmg(0.),
    fjack(1), fboot(0), fmc(0) {}


Int PeakType::setFromParser(PeakType_I &p, VecDoub_I arr, Int nPlane, Bool spectrumOK, OverRideType_I &OR, VecString &error_msg)
{
    setPeakRadius(p, OR.ORadVec);
    setPeakLineWidth(p, OR.OlwVec);
    setPeakMaxLineWidth(p, OR.OMaxlwVec);
    setPeakMinLineWidth(p, OR.OMinlwVec);
    setPeakVoigtLorentzianLineWidth(p, OR.OvoigtLorlwVec);
    setPeakVoigtGaussianLineWidth(p, OR.OvoigtGausslwVec);
    setPeakGaloreLorentzian(p, OR.OgaloreLorVec);
    setPeakNoiseUncertainty(p);
    setPeakMaxMovement(p, OR.OMaxMoveVec);
    setPeakIntMode(p.intMode, OR.intModeVec, error_msg);
    setPlaneToExclude(p, OR.OExclude, nPlane, error_msg);
    setPeakFixPos(p, OR.OFixPosVec);
    setPeakFixLW(p, OR.OFixLWVec);
    setPeakEsd(p, OR.OJack, OR.OBoot, OR.OMonteCarlo);
    setCenterWt(p, OR.OcenterWtVec);
    setArray(arr, nPlane, spectrumOK);
    setFitLin(p.fitLin, p.intercept, p.slope, OR.OIntercept, OR.OSlope);
    setFitConstant(p.fitConstant, p.constant, OR.OConstant);
    setFitExp(p.fitExp, p.R12, p.A12, OR.OexpDecayRate, OR.OIntercept);
    setFitBiExp(p.fitBiExp, p.BExp1, p.BExp2, p.BExpA1, p.BExpA2, OR.OBExp1, OR.OBExp2, OR.OBExpA1, OR.OBExpA2);
    setFitExpOffset(p.fitExpOffset, p.expoffsR12, p.expoffsA12, p.expoffsOffset, OR.OexpoffsR12, OR.OexpoffsA12, OR.OexpoffsOffset);
    setFitR1rho(p.fitR1rho, p.R12, p.A12, OR.OexpDecayRate, OR.OIntercept);
    setFitNOE(p.fitNOE);
    setFitCPMG(p, OR.OKex, OR.OPB, OR.ODW, OR.OR20,  OR.OFixKex,  OR.OFixPb);
    setFitInvRecovery(p.fitInvRecovery, p.invrecR1, p.invrecPlateau, OR.OinvrecR1, OR.OinvrecPlateau);
    setFitSatRecovery(p.fitSatRecovery, p.satrecR1, p.satrecPlateau, OR.OsatrecR1, OR.OsatrecPlateau);

    return 0;
}

void checkDefineName(PeakListType_I &peak, VecString_I &excludedPeaks, VecString_I &validExcludedPeaks, OverRideType_I &OR, VecString &error_msg)
{
// Checks that excluded peaks really are in the loaded peak list and that '-defineXXX- refers
// to peaks in peaks list and that have not been excluded. -PL


    // Check that excluded peaks really are in the peak list that was loaded.
    // validExcludedPeaks vector contain peaks that already have been removed from the vector peak.
    for (auto assiExclude : excludedPeaks)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == assiExclude); }) == peak.end() &&
               std::find(validExcludedPeaks.begin(),  validExcludedPeaks.end(), assiExclude) == validExcludedPeaks.end())
            error_msg.push_back("ERROR: You cannot use '-EXCLUDEPEAKS' for peak '" + assiExclude + "' that is not in the peak list");

    for (auto temp : OR.ORadVec)  // radius
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINERADIUS' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OlwVec)  // line width
        if(std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINELINEWIDTH' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OMaxlwVec)  //max lw
        if(std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEMAXLINEWIDTH' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OMinlwVec)  // min lw
        if(std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEMINLINEWIDTH' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OvoigtLorlwVec)  // voigt lorentzian lw
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEVOIGTLORENTZIANLINEWIDTH' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OvoigtGausslwVec)  // voigt gauss lw
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEVOIGTGAUSSIANLINEWIDTH' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OgaloreLorVec)  // galore lorentzian contribution
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-GALORELORENTZIAN' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OMaxMoveVec)  // max movement
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEMAXMOVEMENT' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.intModeVec)  // lineshape
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINELINESHAPE' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OExclude)  // exclude plane
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEEXCLUDEPLANES' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto assi : OR.OFixPosVec)  // fixpos
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEFIXPOSITION' for peak '" + assi + "' that is not in the peak list");

    for (auto assi : OR.OFixLWVec)  // fixlw
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEFIXLINEWIDTH' for peak '" + assi + "' that is not in the peak list");

    for (auto assi : OR.OJack)  //jackknife
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEJACKKNIFE' for peak '" + assi + "' that is not in the peak list");

    for (auto assi : OR.OBoot)  //bootstrap
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEBOOTSTRAP' for peak '" + assi + "' that is not in the peak list");

    for (auto assi : OR.OMonteCarlo)  // montecarlo
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEMONTECARLO' for peak '" + assi + "' that is not in the peak list");

    for (auto temp : OR.OcenterWtVec)  // centerweight
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINECENTERWEIGHTED' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OIntercept)  // linfit
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINELININTERCEPT' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OSlope)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINELINSLOPE' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OConstant)  // constfit
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINECONSTANTINTERCEPT' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OexpDecayRate)  // expfit
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEEXPDECAYRATE' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OexpIntercept)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEEXPINTERCEPT' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OBExp1)  // biexpfit
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEBIEXPDECAYRATE1' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OBExp2)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEBIEXPDECAYRATE2' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OBExpA1)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEBIEXPINTERCEPT1' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OBExpA2)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEBIEXPINTERCEPT2' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OexpoffsR12)  // expoffsetfit
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEEXPOFFSETDECAYRATE' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OexpoffsA12)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEEXPOFFSETINTERCEPT' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OexpoffsOffset)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEEXPOFFSETOFFSET' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OKex)  // cpmgfit
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINECPMGKEX' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OPB)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINECPMGPB' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.ODW)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINECPMGDELTAOMEGA' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OR20)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINECPMGR20' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto assi : OR.OFixKex)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINECPMGFIXKEX' for peak '" + assi + "' that is not in the peak list");

    for (auto assi : OR.OFixPb)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINECPMGFIXPB' for peak '" + assi + "' that is not in the peak list");

    for (auto temp : OR.OinvrecR1)  // invrecoveryfit
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEINVRECOVERYBUILDUPRATE' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OinvrecPlateau)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINEINVRECOVERYOFFSET' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OsatrecR1)  // satrecoveryfit
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINESATRECOVERYBUILDUPRATE' for peak '" + temp.assi + "' that is not in the peak list");

    for (auto temp : OR.OsatrecPlateau)
        if (std::find_if(peak.begin(), peak.end(), [=] (PeakType_I &p) { return (p.assi == temp.assi); }) == peak.end())
            error_msg.push_back("ERROR: You cannot use '-DEFINESATRECOVERYOFFSET' for peak '" + temp.assi + "' that is not in the peak list");

}



void PeakType::setFromParser(PeakType_I &p, OverRideType_I &OR, VecString &error_msg)
{
// This function is only used for 'noIntegration'
    setPeakRadius(p, OR.ORadVec);
    setPeakLineWidth(p, OR.OlwVec);
    setPeakMaxLineWidth(p, OR.OMaxlwVec);
    setPeakMinLineWidth(p, OR.OMinlwVec);
    setPeakVoigtLorentzianLineWidth(p, OR.OvoigtLorlwVec);
    setPeakVoigtGaussianLineWidth(p, OR.OvoigtGausslwVec);
    setPeakGaloreLorentzian(p, OR.OgaloreLorVec);
    setPeakNoiseUncertainty(p);
    setPeakMaxMovement(p, OR.OMaxMoveVec);
    setPeakIntMode(p.intMode, OR.intModeVec, error_msg);
    setPeakFixPos(p, OR.OFixPosVec);
    setPeakFixLW(p, OR.OFixLWVec);
    setPeakEsd(p, OR.OJack, OR.OBoot, OR.OMonteCarlo);
    setFitLin(p.fitLin, p.intercept, p.slope, OR.OIntercept, OR.OSlope);
    setFitConstant(p.fitConstant, p.constant, OR.OConstant);
    setFitExp(p.fitExp, p.R12, p.A12, OR.OexpDecayRate, OR.OexpIntercept);
    setFitBiExp(p.fitBiExp, p.BExp1, p.BExp2, p.BExpA1, p.BExpA2, OR.OBExp1, OR.OBExp2, OR.OBExpA1, OR.OBExpA2);
    setFitExpOffset(p.fitExpOffset, p.expoffsR12, p.expoffsA12, p.expoffsOffset, OR.OexpoffsR12, OR.OexpoffsA12, OR.OexpoffsOffset);
    setFitR1rho(p.fitR1rho, p.R12, p.A12, OR.OexpDecayRate, OR.OexpIntercept);
    setFitNOE(p.fitNOE);
    setFitCPMG(p, OR.OKex, OR.OPB, OR.ODW, OR.OR20, OR.OFixKex,  OR.OFixPb);
    setFitInvRecovery(p.fitInvRecovery, p.invrecR1, p.invrecPlateau, OR.OinvrecR1, OR.OinvrecPlateau);
    setFitSatRecovery(p.fitSatRecovery, p.satrecR1, p.satrecPlateau, OR.OsatrecR1, OR.OsatrecPlateau);
}

Int PeakType::setIntMode(Int _intMode, VecString &error_msg)
{
    intMode = _intMode;
    if (intMode == LORENTZIAN) {
        funcs = lorentzian;
        funcscore = lorentziancore;
    }
    else if (intMode == GAUSSIAN) {
        funcs = gaussian;
        funcscore = gaussiancore;
    }
    else if (intMode == GALORE) {
        funcs = galore;
        funcscore = galorecore;
    }
    else if (intMode == VOIGT) {
        funcs = voigt;
        funcscore = voigtcore;
    }
    else {
        error_msg.push_back("ERROR: -LINESHAPE must be 'LORENTZIAN' or 'GAUSSIAN' or 'GALORE' or 'VOIGT'");
        return 1;
    }
    return 0;
}

void PeakType::setPeakRadius(Doub _radF1, Doub _radF2)
{
    radF1 = _radF1;
    radF2 = _radF2;
}

void PeakType::setPeakRadius(PeakType_I &p, const vector<OTwoDoubType> &ORad)
{
    auto it = std::find_if(ORad.begin(), ORad.end(), [=] (const OTwoDoubType &otd) { return (otd.assi == assi); });
    radF1 = (it != ORad.end()) ? it->d1 : p.radF1;
    radF2 = (it != ORad.end()) ? it->d2 : p.radF2;
}

void PeakType::setPeakLineWidth(Doub _lw1_in, Doub _lw2_in)
{
    lwF1_in = _lw1_in;
    lwF2_in = _lw2_in;
}

void PeakType::setPeakLineWidth(PeakType_I &p, const vector<OTwoDoubType> &OLW)
{
    auto it = std::find_if(OLW.begin(), OLW.end(), [=] (const OTwoDoubType &otd) { return (otd.assi == assi); });
    lwF1_in = (it != OLW.end()) ? it->d1 : p.lwF1_in;
    lwF2_in = (it != OLW.end()) ? it->d2 : p.lwF2_in;
}

void PeakType::setPeakMaxLineWidth(Doub _maxlwF1, Doub _maxlwF2)
{
    maxlwF1 = _maxlwF1;
    maxlwF2 = _maxlwF2;
}

void PeakType::setPeakNoiseUncertainty(PeakType_I &p) {
    noiseUncertainty = p.noiseUncertainty;
}


void PeakType::setPeakMinLineWidth(Doub _minlwF1, Doub _minlwF2)
{
    minlwF1 = _minlwF1;
    minlwF2 = _minlwF2;
}

void PeakType::setPeakMaxLineWidth(PeakType_I &p, const vector<OTwoDoubType> &OLW)
{
    auto it = std::find_if(OLW.begin(), OLW.end(), [=] (const OTwoDoubType &otd) { return (otd.assi == assi); });
    maxlwF1 = (it != OLW.end()) ? it->d1 : p.maxlwF1;
    maxlwF2 = (it != OLW.end()) ? it->d2 : p.maxlwF2;
}

void PeakType::setPeakMinLineWidth(PeakType_I &p, const vector<OTwoDoubType> &OLW)
{
    auto it = std::find_if(OLW.begin(), OLW.end(), [=] (const OTwoDoubType &otd) { return (otd.assi == assi); });
    minlwF1 = (it != OLW.end()) ? it->d1 : p.minlwF1;
    minlwF2 = (it != OLW.end()) ? it->d2 : p.minlwF2;
}

void PeakType::setPeakVoigtLorentzianLineWidth(PeakType_I &p, const vector<OTwoDoubType> &OLW)
{
    auto it = std::find_if(OLW.begin(), OLW.end(), [=] (const OTwoDoubType &otd) { return (otd.assi == assi); });
    voigtLorF1_in = (it != OLW.end()) ? it->d1 : p.voigtLorF1_in;
    voigtLorF2_in = (it != OLW.end()) ? it->d2 : p.voigtLorF2_in;
}

void PeakType::setPeakVoigtGaussianLineWidth(PeakType_I &p, const vector<OTwoDoubType> &OLW)
{
    auto it = std::find_if(OLW.begin(), OLW.end(), [=] (const OTwoDoubType &otd) { return (otd.assi == assi); });
    voigtGaussF1_in = (it != OLW.end()) ? it->d1 : p.voigtGaussF1_in;
    voigtGaussF2_in = (it != OLW.end()) ? it->d2 : p.voigtGaussF2_in;
}

void PeakType::setPeakGaloreLorentzian(PeakType_I &p, const vector<OTwoDoubType> &OGaloreLor)
{
    auto it = std::find_if(OGaloreLor.begin(), OGaloreLor.end(), [=] (const OTwoDoubType &otd) { return (otd.assi == assi); });
    galoreLorF1_in = (it != OGaloreLor.end()) ? it->d1 : p.galoreLorF1_in;
    galoreLorF2_in = (it != OGaloreLor.end()) ? it->d2 : p.galoreLorF2_in;
}


void PeakType::setPeakMaxMovement(Doub _maxMoveF1, Doub _maxMoveF2)
{
    maxMoveF1 = _maxMoveF1;
    maxMoveF2 = _maxMoveF2;
}


void PeakType::setPeakMaxMovement(PeakType_I &p, const vector<OTwoDoubType> &OLW)
{
    auto it = std::find_if(OLW.begin(), OLW.end(), [=] (const OTwoDoubType &otd) { return (otd.assi == assi); });
    maxMoveF1 =  (it != OLW.end()) ?  it->d1 :  p.maxMoveF1;
    maxMoveF2 =  (it != OLW.end()) ?  it->d2 :  p.maxMoveF2;
}

void PeakType::setCenterWt(PeakType_I &p, const vector<ODoubleType> &OCW)
{
    auto it = std::find_if(OCW.begin(), OCW.end(), [=] (const ODoubleType &ocw) { return (ocw.assi == assi); });
    centerWt = (it != OCW.end()) ?  it->val : p.centerWt;
}



Int PeakType::setPlaneToExclude(PeakType_I &p, const vector<OExcludeType> &oex, const Int nPlane, VecString &error_msg)
{
// This function is used when peaks are pushed into peaklist

    Uint in_error = error_msg.size();

    int flag = 0;
    for (auto _oex : oex)
        if (assi == _oex.assi) {
            excludePlane.resize(0);
            flag = 1;
            break;
        }

    // -defineExcludePlanes is not set for this peak
    if (!flag) {
        excludePlane = p.excludePlane;
        return 0;
    }

    for (auto &_oex : oex)
        if (assi == _oex.assi) {
            for (Uint i=0; i<_oex.planeToExclude.size(); ++i) {
                if (_oex.planeToExclude[i]<1 || _oex.planeToExclude[i] > nPlane) {
                    error_msg.push_back("ERROR: You cannot exclude plane '" + to_string(_oex.planeToExclude[i]) + "' that does not exist in option -DEFINEEXCLUDEPLANES'");
                    continue;
                }
                if (std::find_if(excludePlane.begin(), excludePlane.end(), [&](Int plane){ return plane==_oex.planeToExclude[i];}) != excludePlane.end())
                    error_msg.push_back("ERROR: You cannot exclude plane '" + to_string(_oex.planeToExclude[i]) + "' twice in option -DEFINEEXCLUDEPLANES'");
                else
                    excludePlane.push_back(_oex.planeToExclude[i]);
            }
        }
    return (in_error == error_msg.size()) ? 0 : 1;
}

Int PeakType::setPlaneToExclude(VecInt_I &planeToExclude, const Int nPlane, VecString &error_msg)
{
// This function is only used by parser.cpp. Consider moving it there. /Patrik

    Uint in_error = error_msg.size();
    for (Uint i=0; i<planeToExclude.size(); ++i) {
        if (planeToExclude[i]<1 || planeToExclude[i] > nPlane) {
            error_msg.push_back("ERROR: '-EXCLUDEPLANES', you cannot exclude a plane (" + to_string(planeToExclude[i]) + ") that does not exist!");
            continue;
        }
        if (std::find_if(excludePlane.begin(), excludePlane.end(), [&](Int plane){ return plane==planeToExclude[i];}) != excludePlane.end()) {
                error_msg.push_back("ERROR: '-EXCLUDEPLANES', you cannot exclude the same plane (" + to_string(planeToExclude[i]) + ") twice!");
        }
        else
            excludePlane.push_back(planeToExclude[i]);
    }
    return (in_error == error_msg.size()) ? 0 : 1;
}

void PeakType::constructResNo()
{
    Bool ok = false;
    Bool started = false;
    Char s[MAX_LINE];
    Int j = 0;
    for (Uint i=0; i<MAX_LINE; ++i)
        s[i] = '\0';
    for (Uint i=0; !ok; ++i) {
        if (i == assi.length())
            ok = true;
        else if (assi[i] >= '0' && assi[i] <= '9') {
            s[j++] = assi[i];
            started = true;
        }
        else if (started)
            ok = true;
    }
    resNo = s;
}


void PeakType::setPeakFixPos(PeakType_I &p, VecString_I &fixvec)
{
    fixPos = (std::find(fixvec.begin(), fixvec.end(), assi) != fixvec.end()) ? true : p.fixPos;
}


void PeakType::setPeakFixLW(PeakType_I &p, VecString_I &fixvec)
{
    fixLW = (std::find(fixvec.begin(), fixvec.end(), assi) != fixvec.end()) ? true : p.fixLW;
}


void PeakType::setPeakEsd(PeakType_I &p, VecString_I &OJack,  VecString_I &OBoot,  VecString_I &OMonteCarlo)
{
    fjack = p.fjack;
    fboot = p.fboot;
    fmc = p.fmc;

    if ((std::find(OJack.begin(), OJack.end(), assi) != OJack.end())) {
        fjack = 1; fboot = fmc = 0;
    }

    if ((std::find(OBoot.begin(), OBoot.end(), assi) != OBoot.end())) {
        fboot = 1; fjack = fmc = 0;
    }

    if ((std::find(OMonteCarlo.begin(), OMonteCarlo.end(), assi) != OMonteCarlo.end())) {
        fjack = fboot = 0; fmc = 1;
    }
}


void PeakType::setPeakIntMode(const Int defaulty, const vector<OIntModeType> &iMode, VecString &error_msg)
{
    setIntMode(defaulty, error_msg);
    for (auto _iMode : iMode)
        if (_iMode.assi == assi) {
            intMode = _iMode.intMode;
            funcs = _iMode.funcs;
            funcscore = _iMode.funcscore;
        }
}

void PeakType::setFitConstant(Int _fitConstant, Doub _constant, const vector<ODoubleType> &oconstant)
{
    fitConstant = _fitConstant;
    constant = _constant;
    for (auto _oconstant : oconstant)
        if (_oconstant.assi == assi)
            constant = _oconstant.val;
}

void PeakType::setFitLin(Int _fitLin, Doub _intercept, Doub _slope, const vector<ODoubleType> &ointercept, const vector<ODoubleType> &oslope)
{
    fitLin = _fitLin;
    intercept = _intercept;
    slope = _slope;
    for (auto _ointercept : ointercept)
        if (assi == _ointercept.assi)
            intercept = _ointercept.val;
    for (auto _oslope : oslope)
        if (assi == _oslope.assi)
            slope = _oslope.val;
}

void PeakType::setFitExp(Int _fitExp, Doub _r12, Doub _a, const vector<ODoubleType> &odr, const vector<ODoubleType> &oa)
{
    fitExp = _fitExp;
    A12 = _a;
    R12 = _r12;
    for (auto _odr : odr)
        if (assi == _odr.assi)
            R12 = _odr.val;
    for (auto _oa : oa)
        if (assi == _oa.assi)
            A12 = _oa.val;
}

void PeakType::setFitBiExp(Int _fitBiExp, Doub _exp1, Doub _exp2, Doub _icept1, Doub _icept2, const vector<ODoubleType> &oexp1, \
                           const vector<ODoubleType> &oexp2, const vector<ODoubleType> &oicept1, const vector<ODoubleType> &oicept2)
{
    fitBiExp = _fitBiExp;
    BExp1 = _exp1;
    BExp2 = _exp2;
    BExpA1 = _icept1;
    BExpA2 = _icept2;
    for (auto _oexp1 : oexp1)
        if (assi == _oexp1.assi)
            BExp1 = _oexp1.val;
    for (auto _oexp2 : oexp2)
        if (assi == _oexp2.assi)
            BExp2 = _oexp2.val;
    for (auto _oicept1 : oicept1)
        if (assi == _oicept1.assi)
            BExpA1 = _oicept1.val;
    for (auto _oicept2 : oicept2)
        if (assi == _oicept2.assi)
            BExpA2 = _oicept2.val;
}

void PeakType::setFitInvRecovery(Int _fitInvRec, Doub _r1, Doub _plateau, const vector<ODoubleType> &or1, const vector<ODoubleType> &oplateau)
{
    fitInvRecovery = _fitInvRec;
    invrecPlateau = _plateau;
    invrecR1 = _r1;
    for (auto _or1 : or1)
        if (assi == _or1.assi)
            invrecR1 = _or1.val;
    for (auto _oplateau : oplateau)
        if (assi == _oplateau.assi)
            invrecPlateau = _oplateau.val;
}

void PeakType::setFitSatRecovery(Int _fitSatRec, Doub _r1, Doub _plateau, const vector<ODoubleType> &or1, const vector<ODoubleType> &oplateau)
{
    fitSatRecovery = _fitSatRec;
    satrecPlateau = _plateau;
    satrecR1 = _r1;
    for (auto _or1 : or1)
        if (assi == _or1.assi)
            satrecR1 = _or1.val;
    for (auto _oplateau : oplateau)
        if (assi == _oplateau.assi)
            satrecPlateau = _oplateau.val;
}

void PeakType::setFitExpOffset(Int _fitExpOffset, Doub _r12,  Doub _a, Doub _offs, const vector<ODoubleType> &odr,
                               const vector<ODoubleType> &oa, const vector<ODoubleType> &oo)
{
    fitExpOffset = _fitExpOffset;
    expoffsA12 = _a;
    expoffsR12 = _r12;
    expoffsOffset = _offs;
    for (auto _odr : odr)
        if (assi == _odr.assi)
            expoffsR12 = _odr.val;
    for (auto _oa : oa)
        if (assi == _oa.assi)
            expoffsA12 = _oa.val;
    for (auto _oo : oo)
        if (assi == _oo.assi)
            expoffsOffset = _oo.val;
}

void PeakType::setFitR1rho(Int _fitR1rho, Doub _r12, Doub _a, const vector<ODoubleType> &odr, const vector<ODoubleType> &oa)
{
    fitR1rho = _fitR1rho;
    A12 = _a;
    R12 = _r12;
    for (auto _odr : odr)
        if (assi == _odr.assi)
            R12 = _odr.val;
    for (auto _oa : oa)
        if (assi == _oa.assi)
            A12 = _oa.val;
}

void PeakType::setFitCPMG(PeakType_I &p, const vector<ODoubleType> &okex,
                          const vector<ODoubleType> &opb, const vector<ODoubleType> &odw,
                          const vector<ODoubleType> &or20, VecString_I &ofixkex, VecString_I &ofixpb) {
    fitCPMG = p.fitCPMG;
    kex = p.kex;
    pB = p.pB;
    Dw = p.Dw;
    R20 = p.R20;
    fixKex = p.fixKex;
    fixPb = p.fixPb;
    for (auto _okex : okex)
        if (assi == _okex.assi)
            kex = _okex.val;
    for (auto _opb : opb)
        if (assi == _opb.assi)
            pB = _opb.val;
    for (auto _odw : odw)
        if (assi == _odw.assi)
            Dw = _odw.val;
    for (auto _or20 : or20)
        if (assi == _or20.assi)
            R20 = _or20.val;
    for (auto _ofixkex : ofixkex)
        if (assi == _ofixkex)
            fixKex = true;
    for (auto _ofixpb : ofixpb)
        if (assi == _ofixpb)
            fixPb = true;
}


void PeakType::fold(Int sizeF1, Int sizeF2, Doub swF1, Doub swF2, Doub obsF1, Doub obsF2, Int &iopt, Int &jopt)
{
    while (iopt < 1 || iopt > sizeF1) {
        Int sign = (iopt<1)? 1 : -1;
        iopt += sizeF1*sign;
        appF1 -= swF1/obsF1*sign;
        foldF1 += sign;
    }
    while (jopt < 1 || jopt > sizeF2) {
        Int sign = (jopt<1)? 1 : -1;
        jopt += sizeF2*sign;
        appF2 -= swF2/obsF2*sign;
        foldF2 += sign;
    }
}

inline Int PeakType::checkIllegalName(VecString &error_msg)
{
    if (assi.find('/') < assi.size()) {
        error_msg.push_back("ERROR: Check peak " + assi +  ". Illegal character '/' in assignment");
        return 1;
    }
    return 0;
}

inline Int PeakType::setArray(VecDoub_I &_arr, Uint nPlane, Bool spectrumOK)
{
    if (!spectrumOK)
        return 1;
    if (_arr.size())
        arr = _arr;
    else {
        arr = VecDoub(nPlane);
        for (Uint i=0; i<nPlane; ++i)
            arr[i] = i+1;
    }
    intensity = VecDoub(arr.size());
    vol = VecDoub(arr.size());
    return 0;
}

Int PeakType::readR1(const string &r1ListName, VecString &error_msg, VecString &info_msg)
{

    Uint in_errors = error_msg.size();

    if (r1ListName == "")
        info_msg.push_back("INFO: No list with R1 values available. R1*cos^2(theta) approximated with 0.0");

    ifstream myFile(r1ListName.c_str());


    if (!myFile.is_open()) {
        error_msg.push_back("ERROR: Unable to open file '" + r1ListName + "' with R1-rates needed for conversion of R1rho to R2!");
        return 1;
    }

    while (! myFile.eof()) {

        string line;
        VecString word;
        getline (myFile,line);
        line2words(line, word);

        if (IgnoreLines(word))
            continue;

        Char s[MAX_LINE];
        Doub _r1, _dr1;
        if (sscanf (line.c_str(), "%s %lf %lf", s, &_r1, &_dr1) != 3)
            error_msg.push_back("ERROR: Line '" + line + "' in R1 list has the wrong format");

        if (s == assi) {
            R1 = _r1;
            dR1 = _dr1;
            break;
        }
    }
    return (error_msg.size() == in_errors) ? 0 : 1;
}

inline void PeakType::setEsd(Doub _esd) { esd = _esd; }


inline void PeakType::setFitNOE(Int _fitNOE) { fitNOE = _fitNOE; }


Bool PeakType::IgnoreLines(VecString_I &word)
{
    if (word.size() == 0) // Exclude empty lines
        return true;
    else if (word[0][0] == '#') // Exclude lines starting with '#' (possibly after white space)
        return true;
    return false;
}


PeakType::~PeakType() { }



Int readPeaks(PeakListType &peak, const ParserType &parser, const SpectrumType &spectrum, VecString &error_msg)
{
    Uint in_error = error_msg.size();

    ifstream myFile(parser.peakListName.c_str());

    if (myFile.is_open())
    {
        string line;

        for(Int i=0; i<parser.skipLines; ++i)
            getline (myFile,line);

        VecString validExcludedPeaks; // a vector with peaks that have been excluded

        while (getline(myFile,line)) {

            PeakType p;
            VecString word;
            Uint max;

            //getline (myFile,line);
            line2words(line, word);

            if (IgnoreLines(word))
                continue;

            max = std::max(parser.assiCol, parser.F1Col);
            max = std::max((Int)max, parser.F2Col);
            if (max >= word.size()) {
                error_msg.push_back("ERROR: Line '" + line + "' in peak list does not contain the correct number of columns");
                continue;
            }
            if (strstr(word[parser.assiCol].c_str(), "/")) {
                error_msg.push_back("ERROR: Peak '" + word[parser.assiCol] + "' contains illegal character '/'");
                continue;
            }

            // Disregard for peaks that should be excluded
            if (std::find_if(parser.peakToExclude.begin(), parser.peakToExclude.end(), [&](string s) {return s == word[parser.assiCol];}) == parser.peakToExclude.end()) {

                p.assi = word[parser.assiCol];

                p.f1 = p.appF1 = atof(word[parser.F1Col].c_str());
                p.f2 = p.appF2 = atof(word[parser.F2Col].c_str());
                p.foldF1 = p.foldF2 = 0;

                p.readFlag = false;
                p.fitFlag = false;
                p.convFlag = 1;
                p.constructResNo();
                p.OLmarker = false;

                // add peak if appropriate
                if (!parser.peakToFitOnly.size() || std::find_if(parser.peakToFitOnly.begin(), parser.peakToFitOnly.end(), [&](string s) {return s == p.assi; }) != parser.peakToFitOnly.end())
                    peak.push_back(p);

                    if (peak.size() == MAX_DATA)
                        error_msg.push_back("ERROR: Too many peaks in peak list");
               }
               else
                   validExcludedPeaks.push_back(word[parser.assiCol]);
        }

        for (auto &p : peak)
            p.setFromParser(parser.peak, parser.arr, spectrum.nPlane, spectrum.calib_OK, parser.OR, error_msg);
        checkDefineName(peak, parser.peakToExclude, validExcludedPeaks, parser.OR, error_msg);

        if (peak.size() == 0)
            error_msg.push_back("ERROR: Empty peak list!");
    }
    else {
        error_msg.push_back("ERROR: Unable to open peaklist file '" + parser.peakListName + "'");
    }
    return (in_error == error_msg.size()) ? 0 : 1;
}


void listPeaks(PeakListType &peak, string outDir, VecString_IO &error_msg)
{
    Int readPeak(PeakType &peak, const string &fname, VecString_IO &error_msg);

    DIR *dp;
    dirent *d;
    string ass;
    PeakType p;

    if ((dp = opendir(outDir.c_str())) == NULL)
        return;

    while((d = readdir(dp)) != NULL) {

        if(!strstr(d->d_name,".out"))
            continue;

        ass = d->d_name;
        p.assi = ass.substr(0, ass.length()-4);
        p.convFlag = 0;

        ass = outDir + "/" + ass;
        readPeak(p, ass, error_msg);
        peak.push_back(p);
    }
}


Int readPeak(PeakType &peak, const string &fname, VecString_IO &error_msg)
{
    string line;
    Doub a, inty, volume;
    VecDoub arr, intensity, vol;
    VecString word;

    ifstream myFile(fname.c_str());
    if (!myFile.is_open()) {
        error_msg.push_back("ERROR: Cannot open peak list '" + fname + "'");
        return 1;
    }

    peak.arr = VecDoub(0);
    peak.intensity = VecDoub(0);
    peak.vol = VecDoub(0);

    while (getline(myFile,line)) {

        line2words(line, word);
        //cerr << line << ENDL;

        if (strstr(line.c_str(), "# No. peaks in group:"))
            from_string<Int>(peak.nOL, word[5], std::dec);
        if (strstr(line.c_str(), "# Input F1 (ppm):"))
            from_string<Doub>(peak.f1, word[4], std::dec);
        if (strstr(line.c_str(), "# Input F2 (ppm):"))
            from_string<Doub>(peak.f2, word[4], std::dec);
        if (strstr(line.c_str(), "# F1 (ppm):"))
            from_string<Doub>(peak.ppmF1, word[3], std::dec);
        if (strstr(line.c_str(), "# F2 (ppm):"))
            from_string<Doub>(peak.ppmF2, word[3], std::dec);
        if (strstr(line.c_str(), "# LW1 (Hz):"))
            from_string<Doub>(peak.lwF1, word[3], std::dec);
        if (strstr(line.c_str(), "# LW2 (Hz):"))
            from_string<Doub>(peak.lwF2, word[3], std::dec);
        if (strstr(line.c_str(), "# Chi2:"))
            from_string<Doub>(peak.chi2, word[2], std::dec);
        if (strstr(line.c_str(), "# dof:"))
            from_string<Int>(peak.dof, word[2], std::dec);

        if (word.size() >= 2 && line[0]!='#') {
            from_string<Doub>(a, word[0], std::dec);
            from_string<Doub>(inty, word[1], std::dec);
            from_string<Doub>(peak.esd, word[2], std::dec);
            from_string<Doub>(volume, word[3], std::dec);
            from_string<Doub>(peak.dvol, word[4], std::dec);
            peak.arr.push_back(a);
            peak.intensity.push_back(inty);
            peak.vol.push_back(volume);
        }
    }
    //cerr << fname << SPACE << peak.assi << SPACE << peak.intensity.size() << ENDL;
    return 0;
}



Int readR1List(const string &r1ListName, PeakListType &peak, VecString &error_msg)
{
    Char s[MAX_LINE];
    double _r1, _dr1;
    string line;
    ifstream myFile(r1ListName.c_str());

    VecString word;

    if (!myFile.is_open()) {
        error_msg.push_back("ERROR: Unable to open file with R1 values for conversion of R1rho to R2, as defined by -R2fromR1rhoR1List.");
        return 1;
    }
    while (getline (myFile,line)) {
        line2words(line, word);

        if (IgnoreLines(word))
            continue;

        if (sscanf (line.c_str(), "%s %lf %lf", s, &_r1, &_dr1) != 3)
            error_msg.push_back("ERROR: Line '" + line + "' in R1 list has the wrong format!");

        auto it = std::find_if(peak.begin(), peak.end(), [s](PeakType &p){return s==p.assi;});
            if (it != peak.end()) {
                it->R1 =  _r1;
                it->dR1 = _dr1;
            }
    }
    return 0;
}
#ifdef PINTGUI
Int autoOverLapPeaks(PeakListType &peak, ListofPeakListType &group,
                      const string &outDir, VecString &error_msg, bool &overlapOverload)
{
// Determine automatically which peaks that are overlapped
// based on their peak position and radii.

    Uint errorsize = error_msg.size();

    string olFile(outDir + "/overlap.txt");
    ofstream myFile(olFile.c_str());
    group.resize(0);


    for (Uint i=0; i<peak.size(); i++) {
        if (peak[i].OLmarker)
            continue;
        PeakListType tempgroup;
        peak[i].OLmarker = true;
        tempgroup.push_back(peak[i]);
        overlapLoop(peak, i, i+1, tempgroup);
        if (tempgroup.size()>1) {
            group.push_back(tempgroup);
            peak[i].OLmarker = true;
            myFile << "-overlap";
            for (auto _tempgroup : tempgroup) {
                myFile << " " << _tempgroup.assi;
            }
            if(tempgroup.size()>10)
            {
                overlapOverload =true;
                error_msg.push_back("WARNING: Overlap auto generated an overlap with "+QString::number(tempgroup.size()).toStdString()+" peaks. This group can take a long time to integrate. Please verify or modify the overlaps and re-integrate.");
            }
            myFile << ENDL;
        }
        else {
            peak[i].OLmarker = false;
        }
    }
    myFile.close();

    for (Uint j=0; j<group.size(); ++j)
        for (Uint k=0; k<group[j].size(); ++k)
            if (group[j][k].intMode != group[j][0].intMode)
                error_msg.push_back("ERROR: Peaks " + group[j][0].assi + " and " + group[j][k].assi + " are in the same group and must have the same lineshape!");

    for (Uint j=0; j<group.size(); ++j)
        for (Uint k=0; k<group[j].size(); ++k) {
            Bool is_equal = group[j][k].excludePlane.size() == group[j][0].excludePlane.size();
            for (Uint ii=0; ii<group[j][k].excludePlane.size() && is_equal; ++ii)
                is_equal = group[j][k].excludePlane[ii] == group[j][0].excludePlane[ii];
            if (!is_equal)
                error_msg.push_back("ERROR: Peaks " + group[j][0].assi + " and " + group[j][k].assi + " are in the same group and must have the same planes excluded!");
        }
    return (error_msg.size() != errorsize);
}
#else
Int autoOverLapPeaks(PeakListType &peak, ListofPeakListType &group,
                      const string &outDir, VecString &error_msg)
{
// Determine automatically which peaks that are overlapped
// based on their peak position and radii.

    Uint errorsize = error_msg.size();

    string olFile(outDir + "/overlap.txt");
    ofstream myFile(olFile.c_str());
    group.resize(0);


    for (Uint i=0; i<peak.size(); i++) {
        if (peak[i].OLmarker)
            continue;
        PeakListType tempgroup;
        peak[i].OLmarker = true;
        tempgroup.push_back(peak[i]);
        overlapLoop(peak, i, i+1, tempgroup);
        if (tempgroup.size()>1) {
            group.push_back(tempgroup);
            peak[i].OLmarker = true;
            myFile << "-overlap";
            for (auto _tempgroup : tempgroup) {
                myFile << " " << _tempgroup.assi;
            }
            myFile << ENDL;
        }
        else {
            peak[i].OLmarker = false;
        }
    }

    for (Uint j=0; j<group.size(); ++j)
        for (Uint k=0; k<group[j].size(); ++k)
            if (group[j][k].intMode != group[j][0].intMode)
                error_msg.push_back("ERROR: Peaks " + group[j][0].assi + " and " + group[j][k].assi + " are in the same group and must have the same lineshape!");

    for (Uint j=0; j<group.size(); ++j)
        for (Uint k=0; k<group[j].size(); ++k) {
            Bool is_equal = group[j][k].excludePlane.size() == group[j][0].excludePlane.size();
            for (Uint ii=0; ii<group[j][k].excludePlane.size() && is_equal; ++ii)
                is_equal = group[j][k].excludePlane[ii] == group[j][0].excludePlane[ii];
            if (!is_equal)
                error_msg.push_back("ERROR: Peaks " + group[j][0].assi + " and " + group[j][k].assi + " are in the same group and must have the same planes excluded!");
        }
    return (error_msg.size() != errorsize);
}
#endif

void overlapLoop(PeakListType &peak, Uint i, Uint j, PeakListType &group)
{
    Doub checkOverlap(PeakListType_I &peak, Int i, Int j);

    while (peak[j].OLmarker && j<peak.size()-1)
        ++j;
    if (i==j)
        return;
    if (checkOverlap(peak, i, j) && j<peak.size()) {
        peak[j].OLmarker = true;

        // check if group contains peak[j] already. otherwise add it
        if (std::find_if(group.begin(), group.end(), [&](PeakType &p){return p.assi==peak[j].assi;}) == group.end())
            group.push_back(peak[j]);

        overlapLoop(peak, j, 0, group);
    }
    if (i<peak.size() && j<peak.size())
        overlapLoop(peak, i, j+1, group);
}


Doub checkOverlap(PeakListType_I &peak, Int i, Int j)
{
    Doub brentOverlap(Doub (*func)(Doub, Doub, Doub, Doub, Doub, Doub, Doub, Doub, Doub), const Doub x1,
                       const Doub x2, const Doub F1ppm1, const Doub F1rad1, const Doub F1ppm2,
                       const Doub F1rad2, const Doub F2ppm1, const Doub F2rad1, const Doub F2ppm2,
                       const Doub F2rad2);

    Doub overlapfunc(Doub x1, Doub a1, Doub x2, Doub a2, Doub y1, Doub b1, Doub y2, Doub b2, Doub theta);

    Doub theta = -2;
    for (Doub ii=1; ii<=10 && theta <= -1; ++ii)
        theta = brentOverlap(overlapfunc, 0.0, PI/ii, peak[i].f1, peak[i].radF1, peak[j].f1, \
                              peak[j].radF1, peak[i].f2, peak[i].radF2, peak[j].f2, peak[j].radF2);
    for (Doub ii=1; ii<=10 && theta <= -1; ++ii)
        theta = brentOverlap(overlapfunc, PI, PI+PI/ii, peak[i].f1, peak[i].radF1, peak[j].f1, \
                              peak[j].radF1, peak[i].f2, peak[i].radF2, peak[j].f2, peak[j].radF2);
    if (theta > -1)
        return true;
    else
        return false;
}





Doub overlapfunc(Doub x1, Doub a1, Doub x2, Doub a2, Doub y1, Doub b1, Doub y2, Doub b2, Doub theta)
// Function used for calculating when two ellipses intersect
{
    Doub f;
    if (a2 >= b2) {
        f = sqrt(SQR(a2)-SQR(b2)); // distance to focus from center
        return sqrt( SQR(x1+a1*cos(theta) - (x2-f)) + SQR (y1 + b1*sin(theta) - y2)) +
               sqrt( SQR(x1+a1*cos(theta) - (x2+f)) + SQR(y1 + b1*sin(theta) - y2) )  - 2.*a2;
    }
    else {
        f = sqrt(SQR(b2)-SQR(a2)); // distance to focus from center
        return sqrt( SQR(x1+a1*cos(theta) - x2)) + SQR (y1 + b1*sin(theta) - (y2-f)) +
               sqrt( SQR(x1+a1*cos(theta) - x2) + SQR(y1 + b1*sin(theta) - (y2+f)) )  - 2.*b2;
    }
}


Doub brentOverlap(Doub (*func)(Doub, Doub, Doub, Doub, Doub, Doub, Doub, Doub, Doub), const Doub x1,
                   const Doub x2, const Doub F1ppm1, const Doub F1rad1, const Doub F1ppm2,
                   const Doub F1rad2, const Doub F2ppm1, const Doub F2rad1, const Doub F2ppm2,
                   const Doub F2rad2)
{
    // The parameters for the function to minimize should be
    // 1. Chem.shift in F1 for peak 1
    // 2. Radius in F1 for peak 1
    // 3. Chem. shift in F1 (or F2) for peak 2
    // 4. Radius in F1 (or F2) for peak 2
    // 5. Chem.shift in F2 for peak 1
    // 6. Radius in F2 for peak 1
    // 7. Chem. shift in F2 (F1) for peak 2
    // 8. Azimuthal angle (independent parameter)

    const Int ITMAX=100;
    const Doub EPS=numeric_limits<Doub>::epsilon();
    const Doub tol = 1.e-9;
    Doub a=x1,b=x2,c=x2,d=0,e=0,fa=func(F1ppm1, F1rad1, F1ppm2, F1rad2, F2ppm1, F2rad1, F2ppm2, F2rad2, a);
    Doub fb=func(F1ppm1, F1rad1, F1ppm2, F1rad2, F2ppm1, F2rad1, F2ppm2, F2rad2, b),fc,p,q,r,s,tol1,xm;

    if ((fa > 0.0 && fb > 0.0) || (fa < 0.0 && fb < 0.0))
        return -2.; // signal that root is not bracketed
    fc=fb;
    for (Int iter=0; iter<ITMAX; ++iter) {
        if ((fb > 0.0 && fc > 0.0) || (fb < 0.0 && fc < 0.0)) {
            c=a;
            fc=fa;
            e=d=b-a;
        }
        if (abs(fc) < abs(fb)) {
            a=b;
            b=c;
            c=a;
            fa=fb;
            fb=fc;
            fc=fa;
        }
        tol1=2.0*EPS*abs(b)+0.5*tol;
        xm=0.5*(c-b);
        if (abs(xm) <= tol1 || fb == 0.0) return fabs(b);
        if (abs(e) >= tol1 && abs(fa) > abs(fb)) {
            s=fb/fa;
            if (a == c) {
                p=2.0*xm*s;
                q=1.0-s;
            }
            else {
                q=fa/fc;
                r=fb/fc;
                p=s*(2.0*xm*q*(q-r)-(b-a)*(r-1.0));
                q=(q-1.0)*(r-1.0)*(s-1.0);
            }
            if (p > 0.0) q = -q;
            p=abs(p);
            Doub min1=3.0*xm*q-abs(tol1*q);
            Doub min2=abs(e*q);
            if (2.0*p < (min1 < min2 ? min1 : min2)) {
                e=d;
                d=p/q;
            }
            else {
                d=xm;
                e=d;
            }
        }
        else {
            d=xm;
            e=d;
        }
        a=b;
        fa=fb;
        if (abs(d) > tol1)
            b += d;
        else
            b += SIGN(tol1,xm);
        fb=func(F1ppm1, F1rad1, F1ppm2, F1rad2, F2ppm1, F2rad1, F2ppm2, F2rad2, b);
    }
    return -1.; // Maximum number of iterations exceeded
}


void readGroup(PeakListType &group, VecString &word)
{
    PeakType peak;

    // N.B. first index = 1 --> cannot use range based loop
    for (Uint i=1; i<word.size(); ++i) {
        peak.assi = word[i];
        group.push_back(peak);
    }
}


Int fillInGroups(PeakListType_I &peak, ListofPeakListType &group, VecString &error_msg)
{
// Fills in correct information for all
// peaks in overlapped groups. Note that
// intMode and integration function are
// set to the value of the first member
// of the group, i.e. it is not allowed
// to use different lineshapes for members
// of the same group.
//
// REMEMBER THAT LAST PART OF FUNCTION MUST BE IDENTICAL TO LAST PART OF autoOverlap!!!

    Uint in_error = error_msg.size();
    for (Uint i=0; i<peak.size(); ++i)
        for (Uint j=0; j<group.size(); ++j)
            for (Uint k=0; k<group[j].size(); ++k)
                if (group[j][k].assi == peak[i].assi)
                    group[j][k] = peak[i];

    for (Uint j=0; j<group.size(); ++j)
        for (Uint k=0; k<group[j].size(); ++k)
            if (group[j][k].intMode != group[j][0].intMode)
                error_msg.push_back("ERROR: Peaks " + group[j][0].assi + " and " + group[j][k].assi + " are in the same group and must have the same lineshape");

    for (Uint j=0; j<group.size(); ++j)
        for (Uint k=0; k<group[j].size(); ++k) {
            Bool is_equal = group[j][k].excludePlane.size() == group[j][0].excludePlane.size();
            for (Uint ii=0; ii<group[j][k].excludePlane.size() && is_equal; ++ii)
                is_equal = group[j][k].excludePlane[ii] == group[j][0].excludePlane[ii];
            if (!is_equal)
                error_msg.push_back("ERROR: Peaks " + group[j][0].assi + " and " + group[j][k].assi + " are in the same group and must have the same planes excluded!");
        }

    return (in_error != error_msg.size());
}


Int getPeaksToFit(PeakType_I &peak, ListofPeakListType &group, PeakListType &peakToFit)
{
    peakToFit.resize(0);
    peakToFit.push_back(peak);

    for (Uint j=0; j<group.size(); ++j)
        if (std::find_if(group[j].begin(), group[j].end(), [&](PeakType &p){return p.assi==peak.assi;}) != group[j].end()) {
            peakToFit = group[j];
            break;
        }
    return 0;
}


Int checkPeaks(PeakListType &peak, ListofPeakListType &group, VecString &error_msg)
{
// Checks that overlapped peaks can be found in peaklist
// and that peaks are not overlapped with themselves or
// belong to several overlapped groups.

    // First determine whether there exists a valid peaklist or not
    // ------------------------------------------------------------
    Bool peakFlag = true;
    for (auto _error_msg : error_msg)
        if (_error_msg.find("peaklist") != std::string::npos)
            peakFlag = false;

    for (auto &_peak : peak)
        _peak.checkIllegalName(error_msg);

    for (Uint i=0; i<group.size(); ++i)
        for (Uint j=0; j<group[i].size(); ++j) {

            if (std::find_if(peak.begin(), peak.end(), [&](PeakType &p){return p.assi==group[i][j].assi;}) == peak.end() && peakFlag)
                error_msg.push_back("ERROR: Check overlapped peak " + group[i][j].assi + "! It cannot be found in peaklist or is in list of excluded peaks");

            if (std::find_if(group[i].begin()+j+1, group[i].end(), [&](PeakType &p){return p.assi==group[i][j].assi;}) != group[i].end())
                    error_msg.push_back("ERROR: Check overlapped peak " +  group[i][j].assi + "! Peaks cannot be overlapped with themselves");

            for (Uint k=i+1; k<group.size(); ++k)
               if (std::find_if(group[k].begin(), group[k].end(), [&](PeakType &p){return p.assi==group[i][j].assi;}) != group[k].end())
                        error_msg.push_back("ERROR: Check overlapped peak " + group[i][j].assi + "! Peaks cannot belong to more than one overlapped group");
        }
    return 0;
}

Bool IgnoreLines(VecString_I &word)
{
    if (word.size() == 0) // Exclude empty lines
        return true;
    else if (word[0][0] == '#') // Exclude lines starting with '#' (possibly after white space)
        return true;
    return false;
}


Bool isPlaneExcluded(PeakType_I &peak, const Int &plane)
{
// N.B.!! Planes are numbered 1 - n so the first plane (arr[0]) has number 1.

    for (Uint i=0; i<peak.excludePlane.size(); ++i)
        if (plane == peak.excludePlane[i])
            return true;
    return false;
}
