// fitfunctions.h

#include "fitfunctions.h"
#include "peakfit.h"

#define NPAR_GAUSSIAN (4+nArr)
#define NPAR_LORENTZIAN (4+nArr)
#define NPAR_GALORE (6+nArr)


Doub gaussiancore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr)
{
    Int i;
    Doub y;
    const Doub c2 = 2.772588722;	 // needed to get correctly defined linewidth

    for (y=0, i=0; i<nOL; ++i) {
        Doub sqr0 = SQR((a[0+i*NPAR_GAUSSIAN]-f1)/a[1+i*NPAR_GAUSSIAN]);
        Doub sqr1 = SQR((a[2+i*NPAR_GAUSSIAN]-f2)/a[3+i*NPAR_GAUSSIAN]);
        y += a[3+f3+i*NPAR_GAUSSIAN]*exp(-c2*(sqr0 + sqr1));
    }
    return y;
}

void gaussian(const Doub f1, const Doub f2, const Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr)
{
    Doub STEP;

    y = gaussiancore(f1, f2, f3, a, nOL, nArr);

    for (Int i=0; i<nOL*NPAR_GAUSSIAN; ++i)
        dyda[i] = 0.;

    for (Int i=0; i<nOL*NPAR_GAUSSIAN; i+=NPAR_GAUSSIAN) {

        STEP = 1.0e-6*a[i];
        a[i] += STEP;
        dyda[i] = ( gaussiancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i] -= STEP;

        STEP = 1.0e-6*a[i+1];
        a[i+1] += STEP;
        dyda[i+1] = ( gaussiancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+1] -= STEP;

        STEP = 1.0e-6*a[i+2];
        a[i+2] += STEP;
        dyda[i+2] = ( gaussiancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+2] -= STEP;

        STEP = 1.0e-6*a[i+3];
        a[i+3] += STEP;
        dyda[i+3] = ( gaussiancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+3] -= STEP;

        STEP = 1.0e-6*a[i+3+f3];
        a[i+3+f3] += STEP;
        dyda[i+3+f3] = ( gaussiancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+3+f3] -= STEP;
    }
}


Doub lorentziancore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr)
{
    Int i;
    Doub y;
    Doub sqra0, sqra1, sqra2, sqra3;

    for (y=0, i=0; i<nOL; ++i) {
        sqra0 = SQR (a[0+i*NPAR_LORENTZIAN]-f1);
        sqra1 =  SQR (a[1+i*NPAR_LORENTZIAN]);
        sqra2 = SQR (a[2+i*NPAR_LORENTZIAN]-f2);
        sqra3 =  SQR (a[3+i*NPAR_LORENTZIAN]);

        y += a[3+f3+i*NPAR_LORENTZIAN]*sqra1*sqra3/16. / (sqra0 + (sqra1/4.0)) / (sqra2 + (sqra3/4.0));
    }
    return y;
}


void lorentzian(const Doub f1, const Doub f2, const Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr)
{
    Doub STEP;

    y = lorentziancore(f1, f2, f3, a, nOL, nArr);

    for (Int i=0; i<nOL*NPAR_LORENTZIAN; ++i)
        dyda[i] = 0.;

    for (Int i=0; i<nOL*NPAR_LORENTZIAN; i+=NPAR_LORENTZIAN) {
        STEP = 1.0e-6*a[i];
        a[i] += STEP;
        dyda[i] = ( lorentziancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i] -= STEP;

        STEP = 1.0e-6*a[i+1];
        a[i+1] += STEP;
        dyda[i+1] = ( lorentziancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+1] -= STEP;

        STEP = 1.0e-6*a[i+2];
        a[i+2] += STEP;
        dyda[i+2] = ( lorentziancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+2] -= STEP;

        STEP = 1.0e-6*a[i+3];
        a[i+3] += STEP;
        dyda[i+3] = ( lorentziancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+3] -= STEP;

        STEP = 1.0e-6*a[i+3+f3];
        a[i+3+f3] += STEP;
        dyda[i+3+f3] = ( lorentziancore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+3+f3] -= STEP;
    }
}


Doub galorecore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr)
{
    Int i;
    const Doub c2 = 2.772588722;	 // needed to get correctly defined linewidth
    Doub sqra0, sqra1, sqra2, sqra3;
    Doub y, Lf1, Lf2, Gf1, Gf2;

    for (y=0,i=0; i<nOL; ++i) {
        sqra0 = SQR(a[0+i*NPAR_GALORE]-f1);
        sqra1 =  SQR(a[1+i*NPAR_GALORE]);
        sqra2 = SQR(a[2+i*NPAR_GALORE]-f2);
        sqra3 =  SQR(a[3+i*NPAR_GALORE]);

        Lf1 = a[4+i*NPAR_GALORE]*sqra1/4. / (sqra0 + (sqra1/4.0));
        Lf2 = a[5+i*NPAR_GALORE]*sqra3/4. / (sqra2 + (sqra3/4.0));
        Gf1 = (1.-a[4+i*NPAR_GALORE])*exp(-c2*sqra0/sqra1);
        Gf2 = (1.-a[5+i*NPAR_GALORE])*exp(-c2*sqra2/sqra3);
        y += a[5+f3+i*NPAR_GALORE]*(Lf1*Lf2 + Lf1*Gf2 + Gf1*Lf2 + Gf1*Gf2);
    }
    return y;
}

void galore(const Doub f1, const Doub f2, const Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr)
{
    Doub STEP;

    y = galorecore(f1, f2, f3, a, nOL, nArr);


    for (Int i=0; i<nOL*NPAR_GALORE; ++i)
        dyda[i] = 0.;


    for (Int i=0; i<nOL*NPAR_GALORE; i+=NPAR_GALORE) {
        STEP = 1.0e-6*a[i];
        a[i] += STEP;
        dyda[i] = ( galorecore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i] -= STEP;

        STEP = 1.0e-6*a[i+1];
        a[i+1] += STEP;
        dyda[i+1] = ( galorecore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+1] -= STEP;

        STEP = 1.0e-6*a[i+2];
        a[i+2] += STEP;
        dyda[i+2] = ( galorecore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+2] -= STEP;

        STEP = 1.0e-6*a[i+3];
        a[i+3] += STEP;
        dyda[i+3] = ( galorecore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+3] -= STEP;

        STEP = 1.0e-6*a[i+4];
        a[i+4] += STEP;
        dyda[i+4] = ( galorecore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+4] -= STEP;

        STEP = 1.0e-6*a[i+5];
        a[i+5] += STEP;
        dyda[i+5] = ( galorecore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+5] -= STEP;

        STEP = 1.0e-6*a[i+5+f3];
        a[i+5+f3] += STEP;
        dyda[i+5+f3] = ( galorecore(f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+5+f3] -= STEP;
    }
}

Doub generalShapeCore(const PeakListType &peak, Doub f1, Doub f2, Int f3, VecDoub_I &a, const Int nOL, const Int nArr)
{
    Doub y=0;
    for (Int i=0; i<nOL; ++i)
        y += peak[i].funcscore(f1, f2, f3, a, 1, nArr);
    return y;
}

void generalShape(const PeakListType &peak, Doub f1, Doub f2, Int f3, VecDoub &a, Doub &y, VecDoub_O &dyda, Int nOL, Int nArr)
{
    Doub STEP;

    y = generalShapeCore(peak, f1, f2, f3, a, nOL, nArr);

    VecInt npar;
    for (Int i=0; i<nOL; ++i)
        npar[i] = (peak[i].intMode == GALORE)? 6+nArr : 4+nArr;
    for (Uint i=0; i<dyda.size(); ++i)
        dyda[i] = 0.;

    for (Uint i=0; i<a.size(); i+=npar[i]) {

        STEP = 1.0e-6*a[i];
        a[i] += STEP;
        dyda[i] = (generalShapeCore(peak, f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i] -= STEP;

        STEP = 1.0e-6*a[i+1];
        a[i+1] += STEP;
        dyda[i+1] = (generalShapeCore(peak, f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+1] -= STEP;

        STEP = 1.0e-6*a[i+2];
        a[i+2] += STEP;
        dyda[i+2] = (generalShapeCore(peak, f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+2] -= STEP;

        STEP = 1.0e-6*a[i+3];
        a[i+3] += STEP;
        dyda[i+3] = (generalShapeCore(peak, f1, f2, f3, a, nOL, nArr) - y) / (STEP);
        a[i+3] -= STEP;

        if (peak[i].intMode != GALORE) {
            STEP = 1.0e-6*a[i+3+f3];
            a[i+3+f3] += STEP;
            dyda[i+3+f3] = (generalShapeCore(peak, f1, f2, f3, a, nOL, nArr) - y) / (STEP);
            a[i+3+f3] -= STEP;
        }
        else {
            STEP = 1.0e-6*a[i+4];
            a[i+4] += STEP;
            dyda[i+4] = (generalShapeCore(peak, f1, f2, f3, a, nOL, nArr) - y) / (STEP);
            a[i+4] -= STEP;

            STEP = 1.0e-6*a[i+5];
            a[i+5] += STEP;
            dyda[i+5] = (generalShapeCore(peak, f1, f2, f3, a, nOL, nArr) - y) / (STEP);
            a[i+5] -= STEP;

            STEP = 1.0e-6*a[i+5+f3];
            a[i+5+f3] += STEP;
            dyda[i+5+f3] = (generalShapeCore(peak, f1, f2, f3, a, nOL, nArr) - y) / (STEP);
            a[i+5+f3] -= STEP;
        }
    }
}


/*
#define NPAR (4+nArr)
Doub gausslorecore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr)
{
    Int i;
    const Doub c2 = 2.772588722;	 // needed to get correctly defined linewidth
    Doub y, a0, a1, a2, a3, a4;
    Doub sqra0, sqra1, sqra2, sqra3;

    for (y=0, i=0; i<nOL; i++) {
        a0 = a[0+i*NPAR]-f1;
        a1 = a[1+i*NPAR];
        a2 = a[2+i*NPAR]-f2;
        a3 = a[3+i*NPAR];
        a4 = a[3+f3+i*NPAR];
        sqra0 = SQR (a[0+i*NPAR]-f1);
        sqra1 =  SQR (a[1+i*NPAR]);
        sqra2 = SQR (a[2+i*NPAR]-f2);
        sqra3 =  SQR (a[3+i*NPAR]);

        y += a4*sqra3/4. / (sqra2 + (sqra3/4.0)) * exp(-c2*sqra0/sqra1);
    }
    return y;
}

void gausslore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr)
{
    VecDoub aplus(a), aminus(a);
    Doub STEP;

    y = gausslorecore(f1, f2, f3, a, nOL, nArr);

    for (Int i=0; i<nOL*NPAR; i++) {
        STEP = 1.e-6*a[i];
        aplus[i] += STEP;
        aminus[i] -= STEP;
        if (i%NPAR<4 || i%NPAR-3==f3)
            dyda[i] = ( galorecore(f1, f2, f3, aplus, nOL, nArr) - galorecore(f1, f2, f3, aminus, nOL, nArr) ) / (2.*STEP);
        else
            dyda[i] = 0.;
        aplus[i] -= STEP;
        aminus[i] += STEP;
    }
}


Doub loregausscore(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, const Int nOL, const Int nArr)
{
    Int i;
    const Doub c2  = .772588722;	 // needed to get correctly defined linewidth
    Doub y, a0, a1, a2, a3, a4;
    Doub sqra0, sqra1, sqra2, sqra3;

    for (y=0, i=0; i<nOL; i++) {
        a0 = a[0+i*NPAR]-f1;
        a1 = a[1+i*NPAR];
        a2 = a[2+i*NPAR]-f2;
        a3 = a[3+i*NPAR];
        a4 = a[3+f3+i*NPAR];
        sqra0 = SQR (a[0+i*NPAR]-f1);
        sqra1 =  SQR (a[1+i*NPAR]);
        sqra2 = SQR (a[2+i*NPAR]-f2);
        sqra3 =  SQR (a[3+i*NPAR]);

        y += a4 * sqra1/4. / (sqra0 + (sqra1/4.0)) * exp(-c2*sqra2/sqra3);
    }
    return y;

}

void loregauss(const Doub f1, const Doub f2, const Int f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr)
{
    VecDoub aplus(a), aminus(a);
    Doub STEP;

    y = loregausscore(f1, f2, f3, a, nOL, nArr);

    for (Int i=0; i<nOL*NPAR; i++) {
        STEP = 1.e-6*a[i];
        aplus[i] += STEP;
        aminus[i] -= STEP;
        if (i%NPAR<4 || i%NPAR-3==f3)
            dyda[i] = ( galorecore(f1, f2, f3, aplus, nOL, nArr) - galorecore(f1, f2, f3, aminus, nOL, nArr) ) / (2.*STEP);
        else
            dyda[i] = 0.;
        aplus[i] -= STEP;
        aminus[i] += STEP;
    }
}
#undef NPAR
*/

////////////////////////////////////////////////////////////////////////////////////
/////////////// HERE ARE FUNCTIONS FOR FITTING 3D LINE SHAPES //////////////////////
////////////////////////////////////////////////////////////////////////////////////

/*
#define NPAR 7
Doub gaussian3Dcore(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, const Int nOL, const Int nArr)
{
    Int i;

    const Doub c2 = 2.772588722;	 // needed to get correctly defined linewidth
    Doub y, a0, a1, a2, a3, a4, a5, a6;
    Doub sqra0, sqra1, sqra2, sqra3, sqra4, sqra5;


    for (y=0, i=0; i<nOL; i++) {
        a0 = a[0+i*NPAR]-f1;
        a1 =  a[1+i*NPAR];
        a2 = a[2+i*NPAR]-f2;
        a3 =  a[3+i*NPAR];
        a4 = a[4+i*NPAR]-f3;
        a5 =  a[5+i*NPAR];
        a6 =  a[6+i*NPAR];
        sqra0 = SQR (a[0+i*NPAR]-f1);
        sqra1 =  SQR (a[1+i*NPAR]);
        sqra2 = SQR (a[2+i*NPAR]-f2);
        sqra3 =  SQR (a[3+i*NPAR]);
        sqra4 = SQR (a[4+i*NPAR]-f3);
        sqra5 =  SQR (a[5+i*NPAR]);
        y += a6*exp(-c2*sqra0/sqra1 - c2*sqra2/sqra3 - c2*sqra4/sqra5);
    }
    return y;
}

void gaussian3D(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr)
{
    VecDoub aplus(a), aminus(a);
    Doub STEP;

    y = gaussian3Dcore(f1, f2, f3, a, nOL, nArr);

    for (Int i=0; i<nOL*NPAR; i++) {
        STEP = 1.e-6*a[i];
        aplus[i] += STEP;
        aminus[i] -= STEP;
        dyda[i] = ( gaussian3Dcore(f1, f2, f3, aplus, nOL, nArr) - gaussian3Dcore(f1, f2, f3, aminus, nOL, nArr) ) / (2.*STEP);
        aplus[i] -= STEP;
        aminus[i] += STEP;
    }
}
#undef NPAR


#define NPAR 7
Doub lorentzian3Dcore(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, const Int nOL, const Int nArr)
{
    Int i;
    Doub y, a0, a1, a2, a3, a4, a5, a6;
    Doub sqra0, sqra1, sqra2, sqra3, sqra4, sqra5;

    for (y=0, i=0; i<nOL; i++) {
        a0 = a[0+i*NPAR]-f1;
        a1 = a[1+i*NPAR];
        a2 = a[2+i*NPAR]-f2;
        a3 = a[3+i*NPAR];
        a4 = a[4+i*NPAR]-f3;
        a5 = a[5+i*NPAR];
        a6 = a[6+i*NPAR];
        sqra0 = SQR (a[0+i*NPAR]-f1);
        sqra1 =  SQR (a[1+i*NPAR]);
        sqra2 = SQR (a[2+i*NPAR]-f2);
        sqra3 =  SQR (a[3+i*NPAR]);
        sqra4 = SQR (a[4+i*NPAR]-f3);
        sqra5 =  SQR (a[5+i*NPAR]);
        y += a6*sqra1*sqra3*sqra5/64. / (sqra0 + (sqra1/4.0)) / (sqra2 + (sqra3/4.0)) / (sqra4 + (sqra5/4.0));
    }
    return y;
}


void lorentzian3D(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr)
{
    VecDoub aplus(a), aminus(a);
    Doub STEP;

    y = lorentzian3Dcore(f1, f2, f3, a, nOL, nArr);

    for (Int i=0; i<nOL*NPAR; i++) {
        STEP = 1.e-6*a[i];
        aplus[i] += STEP;
        aminus[i] -= STEP;
        dyda[i] = ( lorentzian3Dcore(f1, f2, f3, aplus, nOL, nArr) - lorentzian3Dcore(f1, f2, f3, aminus, nOL, nArr) ) / (2.*STEP);
        aplus[i] -= STEP;
        aminus[i] += STEP;
    }
}
#undef NPAR


#define NPAR 10
Doub galore3Dcore(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, const Int nOL, const Int nArr)
{

    Int i;
    const Doub c2 = 2.772588722;	 // needed to get correctly defined linewidth
    Doub a0, a1, a2, a3, a4, a5, a6, a7, a8, a9;
    Doub sqra0, sqra1, sqra2, sqra3, sqra4, sqra5;
    Doub y, Lf1, Lf2, Lf3, Gf1, Gf2, Gf3;

    for (y=0,i=0; i<nOL; i++) {
        a0 = (a[0+i*NPAR]-f1);
        a1 =  (a[1+i*NPAR]);
        a2 = (a[2+i*NPAR]-f2);
        a3 =  (a[3+i*NPAR]);
        a4 = (a[4+i*NPAR]-f3);
        a5 =  (a[5+i*NPAR]);
        a6 =  (a[6+i*NPAR]);
        a7 =  (a[7+i*NPAR]);
        a8 =  (a[8+i*NPAR]);
        a9 =  (a[9+i*NPAR]);
        sqra0 = SQR(a[0+i*NPAR]-f1);
        sqra1 =  SQR(a[1+i*NPAR]);
        sqra2 = SQR(a[2+i*NPAR]-f2);
        sqra3 =  SQR(a[3+i*NPAR]);
        sqra4 = SQR(a[4+i*NPAR]-f3);
        sqra5 =  SQR(a[5+i*NPAR]);

        Lf1 = a6*sqra1/4. / (sqra0 + (sqra1/4.0));
        Lf2 = a7*sqra3/4. / (sqra2 + (sqra3/4.0));
        Lf3 = a8*sqra5/4. / (sqra4 + (sqra5/4.0));
        Gf1 = (1.-a6)*exp(-c2*sqra0/sqra1);
        Gf2 = (1.-a7)*exp(-c2*sqra2/sqra3);
        Gf3 = (1.-a8)*exp(-c2*sqra4/sqra5);
        y += a9*(Lf1*Lf2*Lf3 + Lf1*Lf2*Gf3 + Lf1*Lf3*Gf2 + Lf2*Lf3*Gf1 + Lf1*Gf2*Gf3 + Lf2*Gf1*Gf3 + Lf3*Gf1*Gf2 + Gf1*Gf2*Gf3);
    }
    return y;
}


void galore3D(const Doub f1, const Doub f2, const Doub f3, VecDoub_I &a, Doub &y, VecDoub_O &dyda, const Int nOL, const Int nArr)
{
    VecDoub aplus(a), aminus(a);
    Doub STEP;

    y = galore3Dcore(f1, f2, f3, a, nOL, nArr);

    for (Int i=0; i<nOL*NPAR; i++) {
        STEP = 1.e-6*a[i];
        aplus[i] += STEP;
        aminus[i] -= STEP;
        dyda[i] = ( galore3Dcore(f1, f2, f3, aplus, nOL, nArr) - galore3Dcore(f1, f2, f3, aminus, nOL, nArr) ) / (2.*STEP);
        aplus[i] -= STEP;
        aminus[i] += STEP;
    }
}
#undef NPAR
*/


/////////////////////////////////////////////////////////////////////////////////////////////
/////// BELOW IS FUNCTIONS FOR FITTING EXTRACTED VOLUMES TO VARIOUS EXPRESSIONS  ////////////
/////////////////////////////////////////////////////////////////////////////////////////////

void exponential(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    y = a[0]*exp(a[1]*x);

    dyda[0] = y/a[0];
    dyda[1] = x*y;
}

void linear(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    y = a[0] + a[1]*x;

    dyda[0] = 1.;
    dyda[1] = x;
}

void expoffset(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    y = a[0]*exp(a[1]*x) + a[2];

    dyda[0] = (y-a[2])/a[0];
    dyda[1] = x*(y-a[2]);
    dyda[2] = 1.;
}

void biexponential(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    y =  a[0]*exp(a[1]*x) + a[2]*exp(a[3]*x);

    dyda[0] = exp(a[1]*x);
    dyda[1] = x*a[0]*exp(a[1]*x);
    dyda[2] = exp(a[3]*x);
    dyda[3] = x*a[2]*exp(a[3]*x);
}

void invrecover(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    y = a[0]*(1.-2.*exp(a[1]*x));

    dyda[0] = y/a[0];
    dyda[1] = -x*2.*a[0]*exp(a[1]*x);
}

void satrecover(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    y = a[0]*(1.0-exp(a[1]*x));

    dyda[0] = y/a[0];
    dyda[1] = -x*a[0]*exp(a[1]*x);
}

void tanhyp(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    y = tanh(a[0]*x);

    dyda[0] = 1. - SQR(tanh(a[0]*x));
}

void constant(const Doub x __attribute__((unused)), VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    y = a[0];

    dyda[0] = 1;
}


inline complex<Doub> acosh_complex(complex<Doub> z) {
    return log(z + sqrt(z-1.)*sqrt(z+1.));
}

Doub RexCR(Doub R20, Doub DW, Doub PA, Doub KEX, Doub time_T2, Doub nuCP)
{
// R20 = (R2A + R2B)/2

    complex<Doub> psi, zeta, np, nm, Dp, Dm, dp, dm, zp, zm, mdp, mdm, mzp, mzm;
    complex<Doub> I(0.,1.);
    Doub tmp;
    Doub PB = 1.-PA;
    Doub tauCP = 0.25/nuCP;
    Doub R;

    psi = SQR(-PA*KEX+PB*KEX)-SQR(DW)+4.*PA*PB*SQR(KEX);
    zeta = 2.*DW*(-PA*KEX+PB*KEX);
    np = sqrt(2.)*tauCP*sqrt(sqrt(SQR(psi) + SQR(zeta)) + psi);
    nm = sqrt(2.)*tauCP*sqrt(sqrt(SQR(psi) + SQR(zeta)) - psi);
    Dp = 0.5*((psi + 2.*SQR(DW))/sqrt(SQR(psi) + SQR(zeta)) + 1.);
    Dm = 0.5*((psi + 2.*SQR(DW))/sqrt(SQR(psi) + SQR(zeta)) - 1.);
    tmp = fabs(real(acosh_complex(Dp*cosh(np)-Dm*cos(nm))));
    R = 0.5*(2.*R20+KEX-1./(2.*tauCP)*tmp);


    dp = DW + I*KEX;
    dm = DW - I*KEX;
    zp = -DW + I*KEX;
    zm = -DW - I*KEX;
    mdp = (I*KEX*sqrt(PA*PB)/(dp*zp))*(zp+2*DW*sin(zp*tauCP)/sin((dp+zp)*tauCP));
    mzp =-(I*KEX*sqrt(PA*PB)/(dm*zm))*(dm-2*DW*sin(dm*tauCP)/sin((dm+zm)*tauCP));
    R = R - (1./time_T2)*log(real(1. - mdp*mdp - mzp*mzp + mdp*mzp + 0.5*(mdp + mzp)*sqrt(PB/PA)));

    return R;
}

void carverrichards(const Doub x, VecDoub_I &a, Doub &y, VecDoub_O &dyda)
{
    const Doub STEP = 1.0e-3;
    Doub R20 = a[0];
    Doub KEX = a[1];
    Doub PA = a[2];
    Doub DW = a[3];
    Doub time_T2 = a[4]; // of course just a parameter

    //cout << time_T2 << " ";

    y = RexCR(R20, DW, PA, KEX, time_T2, x);

    dyda[0] = (RexCR((1.+STEP)*R20, DW, PA, KEX, time_T2, x) -  \
               RexCR((1.-STEP)*R20, DW, PA, KEX, time_T2, x)) / (2.*STEP*R20);
    dyda[1] = (RexCR(R20, DW, PA, (1.+STEP)*KEX, time_T2, x) -  \
               RexCR(R20, DW, PA, (1.-STEP)*KEX, time_T2, x)) / (2.*STEP*KEX);
    dyda[2] = (RexCR(R20, DW, (1.+STEP)*PA, KEX, time_T2, x) -  \
               RexCR(R20, DW, (1.-STEP)*PA, KEX, time_T2, x)) / (2.*STEP*PA);
    dyda[3] = (RexCR(R20, (1.+STEP)*DW, PA, KEX, time_T2, x) - \
               RexCR(R20, (1.-STEP)*DW, PA, KEX, time_T2, x)) / (2.*STEP*DW);
    dyda[4] = 0.;
}


Doub galoreLWfunc(Doub a, Doub b, Doub x)
{
    // Solve for x, to get true linewidth, i.e.
    // full width at half height, for either
    // dimension of GLORE lineshapes
    // N.B. LW is actually 2*x

    // a is the fitted "linewidth"
    // b is the fraction lorentzian

    return b*SQR(a/2.)/(SQR(a/2.) + SQR(x)) + (1.-b)*exp(-4*log(2)*SQR(x)/SQR(a)) - 0.5;
}
