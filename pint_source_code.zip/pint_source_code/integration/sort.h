// sort.h

#ifndef _SORT
#define _SORT

#include "pint.h"

template<class T>
void sort(PINTvector<T> &arr, Int m=-1)
{
    static const Int M=7, NSTACK=64;
    Int i,ir,j,k,jstack=-1,l=0,n=arr.size();
    T a;
    VecInt istack(NSTACK);
    if (m>0) n = std::min(m,n);
    ir=n-1;
    for (;;) {
        if (ir-l < M) {
            for (j=l+1; j<=ir; j++) {
                a=arr[j];
                for (i=j-1; i>=l; i--) {
                    if (arr[i] <= a) break;
                    arr[i+1]=arr[i];
                }
                arr[i+1]=a;
            }
            if (jstack < 0) break;
            ir=istack[jstack--];
            l=istack[jstack--];
        } else {
            k=(l+ir) >> 1;
            swap(arr[k],arr[l+1]);
            if (arr[l] > arr[ir]) {
                swap(arr[l],arr[ir]);
            }
            if (arr[l+1] > arr[ir]) {
                swap(arr[l+1],arr[ir]);
            }
            if (arr[l] > arr[l+1]) {
                swap(arr[l],arr[l+1]);
            }
            i=l+1;
            j=ir;
            a=arr[l+1];
            for (;;) {
                do i++;
                while (arr[i] < a);
                do j--;
                while (arr[j] > a);
                if (j < i) break;
                swap(arr[i],arr[j]);
            }
            arr[l+1]=arr[j];
            arr[j]=a;
            jstack += 2;
            if (jstack >= NSTACK) throw("NSTACK too small in sort.");
            if (ir-i+1 >= j-l) {
                istack[jstack]=ir;
                istack[jstack-1]=i;
                ir=j-1;
            } else {
                istack[jstack]=j-1;
                istack[jstack-1]=l;
                l=i;
            }
        }
    }
}

template<class T, class U>
inline void assign2(T &t1, const T &t2, U &u1, const U &u2)
{
    t1 = t2;
    u1 = u2;
}

template<class T, class U>
inline void swap2(T &t1, T &t2, U &u1, U &u2)
{
    swap(t1, t2);
    swap(u1, u2);
}

template<class T, class U>
void sort2(PINTvector<T> &arr, PINTvector<U> &brr)
{
    const Int M=7,NSTACK=64;
    Int i,ir,j,k,jstack=-1,l=0,n=arr.size();
    T a; U b;
    VecInt istack(NSTACK);
    ir=n-1;
    for (;;) {
        if (ir-l < M) {
            for (j=l+1; j<=ir; j++) {
                assign2(a, arr[j], b, brr[j]);
                for (i=j-1; i>=l; i--) {
                    if (arr[i] <= a) break;
                    assign2(arr[i+1], arr[i], brr[i+1], brr[i]);
                }
                assign2(arr[i+1], a, brr[i+1], b);
            }
            if (jstack < 0) break;
            ir=istack[jstack--];
            l=istack[jstack--];
        } else {
            k=(l+ir) >> 1;
            swap2(arr[k],arr[l+1], brr[k],brr[l+1]);
            if (arr[l] > arr[ir]) {
                swap2(arr[l],arr[ir], brr[l],brr[ir]);
            }
            if (arr[l+1] > arr[ir]) {
                swap2(arr[l+1],arr[ir], brr[l+1],brr[ir]);
            }
            if (arr[l] > arr[l+1]) {
                swap2(arr[l],arr[l+1], brr[l],brr[l+1]);
            }
            i=l+1;
            j=ir;
            assign2(a, arr[l+1], b, brr[l+1]);
            for (;;) {
                do i++;
                while (arr[i] < a);
                do j--;
                while (arr[j] > a);
                if (j < i) break;
                swap2(arr[i],arr[j], brr[i],brr[j]);
            }
            assign2(arr[l+1], arr[j], brr[l+1], brr[j]);
            assign2(arr[j], a, brr[j], b);
            jstack += 2;
            if (jstack >= NSTACK) throw("NSTACK too small in sort2.");
            if (ir-i+1 >= j-l) {
                istack[jstack]=ir;
                istack[jstack-1]=i;
                ir=j-1;
            } else {
                istack[jstack]=j-1;
                istack[jstack-1]=l;
                l=i;
            }
        }
    }
}

template<class T, class U, class V>
inline void assign3(T &t1, const T &t2, U &u1, const U &u2, V &v1, const V &v2)
{
    t1 = t2;
    u1 = u2;
    v1 = v2;
}

template<class T, class U, class V>
inline void swap3(T &t1, T &t2, U &u1, U &u2, V &v1, V &v2)
{
    swap(t1, t2);
    swap(u1, u2);
    swap(v1, v2);
}

template<class T, class U, class V>
void sort3(PINTvector<T> &arr, PINTvector<U> &brr, PINTvector<V> &crr)
{
    const Int M=7,NSTACK=64;
    Int i,ir,j,k,jstack=-1,l=0,n=arr.size();
    T a; U b; V c;
    VecInt istack(NSTACK);
    ir=n-1;
    for (;;) {
        if (ir-l < M) {
            for (j=l+1; j<=ir; j++) {
                assign3(a, arr[j], b, brr[j], c, crr[j]);
                for (i=j-1; i>=l; i--) {
                    if (arr[i] <= a) break;
                    assign3(arr[i+1], arr[i], brr[i+1], brr[i], crr[i+1], crr[i]);
                }
                assign3(arr[i+1], a, brr[i+1], b, crr[i+1], c);
            }
            if (jstack < 0) break;
            ir=istack[jstack--];
            l=istack[jstack--];
        } else {
            k=(l+ir) >> 1;
            swap3(arr[k],arr[l+1], brr[k],brr[l+1], crr[k],crr[l+1]);
            if (arr[l] > arr[ir]) {
                swap3(arr[l],arr[ir], brr[l],brr[ir], crr[l],crr[ir]);
            }
            if (arr[l+1] > arr[ir]) {
                swap3(arr[l+1],arr[ir], brr[l+1],brr[ir], crr[l+1],crr[ir]);
            }
            if (arr[l] > arr[l+1]) {
                swap3(arr[l],arr[l+1], brr[l],brr[l+1], crr[l],crr[l+1]);
            }
            i=l+1;
            j=ir;
            assign3(a, arr[l+1], b, brr[l+1], c, crr[l+1]);
            for (;;) {
                do i++;
                while (arr[i] < a);
                do j--;
                while (arr[j] > a);
                if (j < i) break;
                swap3(arr[i],arr[j], brr[i],brr[j], crr[i],crr[j]);
            }
            assign3(arr[l+1], arr[j], brr[l+1], brr[j], crr[l+1], crr[j]);
            assign3(arr[j], a, brr[j], b, crr[j], c);
            jstack += 2;
            if (jstack >= NSTACK) throw("NSTACK too small in sort3.");
            if (ir-i+1 >= j-l) {
                istack[jstack]=ir;
                istack[jstack-1]=i;
                ir=j-1;
            } else {
                istack[jstack]=j-1;
                istack[jstack-1]=l;
                l=i;
            }
        }
    }
}

template<class T, class U, class V, class W>
inline void assign4(T &t1, const T &t2, U &u1, const U &u2, V &v1, const V &v2, W &w1,  const W &w2)
{
    t1 = t2;
    u1 = u2;
    v1 = v2;
    w1 = w2;
}



template<class T, class U, class V, class W>
inline void swap4(T &t1, T &t2, U &u1, U &u2, V &v1, V &v2, W &w1,  W &w2)
{
    swap(t1, t2);
    swap(u1, u2);
    swap(v1, v2);
    swap(w1, w2);
}

template<class T, class U, class V, class W>
void sort4(PINTvector<T> &arr, PINTvector<U> &brr, PINTvector<V> &crr, PINTvector<W> &drr)
{
    const Int M=7,NSTACK=64;
    Int i,ir,j,k,jstack=-1,l=0,n=arr.size();
    T a; U b; V c; W d;
    VecInt istack(NSTACK);
    ir=n-1;
    for (;;) {
        if (ir-l < M) {
            for (j=l+1; j<=ir; j++) {
                assign4(a, arr[j], b, brr[j], c, crr[j], d, drr[j]);
                for (i=j-1; i>=l; i--) {
                    if (arr[i] <= a) break;
                    assign4(arr[i+1], arr[i], brr[i+1], brr[i], crr[i+1], crr[i], drr[i+1], drr[i]);
                }
                assign4(arr[i+1], a, brr[i+1], b, crr[i+1], c, drr[i+1], d);
            }
            if (jstack < 0) break;
            ir=istack[jstack--];
            l=istack[jstack--];
        } else {
            k=(l+ir) >> 1;
            swap4(arr[k],arr[l+1], brr[k],brr[l+1], crr[k],crr[l+1], drr[k],drr[l+1]);
            if (arr[l] > arr[ir])
                swap4(arr[l],arr[ir], brr[l],brr[ir], crr[l],crr[ir], drr[l],drr[ir]);
            if (arr[l+1] > arr[ir])
                swap4(arr[l+1],arr[ir], brr[l+1],brr[ir], crr[l+1],crr[ir], drr[l+1],drr[ir]);
            if (arr[l] > arr[l+1])
                swap4(arr[l],arr[l+1], brr[l],brr[l+1], crr[l],crr[l+1], drr[l],drr[l+1]);
            i=l+1;
            j=ir;
            assign4(a, arr[l+1], b, brr[l+1], c, crr[l+1], d, drr[l+1]);
            for (;;) {
                do i++;
                while (arr[i] < a);
                do j--;
                while (arr[j] > a);
                if (j < i) break;
                swap4(arr[i],arr[j], brr[i],brr[j], crr[i],crr[j], drr[i],drr[j]);
            }
            assign4(arr[l+1], arr[j], brr[l+1], brr[j], crr[l+1], crr[j], drr[l+1], drr[j]);
            assign4(arr[j], a, brr[j], b, crr[j], c, drr[j], d);
            jstack += 2;
            if (jstack >= NSTACK) throw("NSTACK too small in sort5.");
            if (ir-i+1 >= j-l) {
                istack[jstack]=ir;
                istack[jstack-1]=i;
                ir=j-1;
            } else {
                istack[jstack]=j-1;
                istack[jstack-1]=l;
                l=i;
            }
        }
    }
}


template<class T, class U, class V, class W, class X>
inline void assign5(T &t1, const T &t2, U &u1, const U &u2, V &v1, const V &v2, W &w1,  const W &w2, X &x1, const X &x2)
{
    t1 = t2;
    u1 = u2;
    v1 = v2;
    w1 = w2;
    x1 = x2;
}



template<class T, class U, class V, class W, class X>
inline void swap5(T &t1, T &t2, U &u1, U &u2, V &v1, V &v2, W &w1,  W &w2, X &x1, X &x2)
{
    swap(t1, t2);
    swap(u1, u2);
    swap(v1, v2);
    swap(w1, w2);
    swap(x1, x2);
}

template<class T, class U, class V, class W, class X>
void sort5(PINTvector<T> &arr, PINTvector<U> &brr, PINTvector<V> &crr, PINTvector<W> &drr, PINTvector<X> &err)
{
    const Int M=7,NSTACK=64;
    Int i,ir,j,k,jstack=-1,l=0,n=arr.size();
    T a; U b; V c; W d; X e;
    VecInt istack(NSTACK);
    ir=n-1;
    for (;;) {
        if (ir-l < M) {
            for (j=l+1; j<=ir; j++) {
                assign5(a, arr[j], b, brr[j], c, crr[j], d, drr[j], e, err[j]);
                for (i=j-1; i>=l; i--) {
                    if (arr[i] <= a) break;
                    assign5(arr[i+1], arr[i], brr[i+1], brr[i], crr[i+1], crr[i], drr[i+1], drr[i], err[i+1], err[i]);
                }
                assign5(arr[i+1], a, brr[i+1], b, crr[i+1], c, drr[i+1], d, err[i+1], e);
            }
            if (jstack < 0) break;
            ir=istack[jstack--];
            l=istack[jstack--];
        } else {
            k=(l+ir) >> 1;
            swap5(arr[k],arr[l+1], brr[k],brr[l+1], crr[k],crr[l+1], drr[k],drr[l+1], err[k],err[l+1]);
            if (arr[l] > arr[ir])
                swap5(arr[l],arr[ir], brr[l],brr[ir], crr[l],crr[ir], drr[l],drr[ir], err[l],err[ir]);
            if (arr[l+1] > arr[ir])
                swap5(arr[l+1],arr[ir], brr[l+1],brr[ir], crr[l+1],crr[ir], drr[l+1],drr[ir], err[l+1],err[ir]);
            if (arr[l] > arr[l+1])
                swap5(arr[l],arr[l+1], brr[l],brr[l+1], crr[l],crr[l+1], drr[l],drr[l+1], err[l],err[l+1]);
            i=l+1;
            j=ir;
            assign5(a, arr[l+1], b, brr[l+1], c, crr[l+1], d, drr[l+1], e, err[l+1]);
            for (;;) {
                do i++;
                while (arr[i] < a);
                do j--;
                while (arr[j] > a);
                if (j < i) break;
                swap5(arr[i],arr[j], brr[i],brr[j], crr[i],crr[j], drr[i],drr[j], err[i],err[j]);
            }
            assign5(arr[l+1], arr[j], brr[l+1], brr[j], crr[l+1], crr[j], drr[l+1], drr[j], err[l+1], err[j]);
            assign5(arr[j], a, brr[j], b, crr[j], c, drr[j], d, err[j], e);
            jstack += 2;
            if (jstack >= NSTACK) throw("NSTACK too small in sort5.");
            if (ir-i+1 >= j-l) {
                istack[jstack]=ir;
                istack[jstack-1]=i;
                ir=j-1;
            } else {
                istack[jstack]=j-1;
                istack[jstack-1]=l;
                l=i;
            }
        }
    }
}


template <class T>
void remove_dup(PINTvector<T> &v)
{
    // removes duplicates from a vector
    sort(v);
    PINTvector<T> tempv;
    for (Int i=0; i<v.size();) {
        tempv.push_back(v[i]);
        while (++i<v.size() && tempv[tempv.size()-1] == v[i])
            ;
    }
    v = tempv;
}
#endif
