// parser.h

#ifndef _PARSER
#define _PARSER


#define GNUPLOT 0
#define MATLAB 1

#include "pint.h"
#include "peak.h"

struct ParserType
{
    string parFile;         // name of parameter file
    string outDir;          // directory where output is written
    string progname;        // name of the application itself
    string procparName;     // Varian style procpar file
    string vdlistName;      // Bruker style vdlist/vclist file
    string peakListName;    // name of the peak list file
    string r1List;          // list with R1 and dR1 for the peaks
    VecString specName;     // vector with all loaded spectra
    VecString peakWithIndError;     // exclude these peaks from fitting
    VecString peakToFitOnly;		// only fit these peaks
    VecString peakToExclude;		// exclude these peaks from fitting
    VecString peakToNotReport;		// exclude these peaks from fitting
    VecString lineShape;

    Int assiCol;
    Int F1Col;
    Int F2Col;
    Int intMode;          // line shape
    Int skipLines;        // no. header lines in peak list
    Int sort;		      // sorts pseudo3D data low to high
    Int invert;           // (changes array from (1,2,3,4...) to (2,1,4,3,...)
    Int nDim;
    Int r1rhoDim;           // dimension the spinlock is applied in (1 indirect, 2 direct)
    Int planeToPlot;
    Int planeToFitFirst;
    Int plotMode;            // 0: gnuplot, nothing else implemented
    Int nthreads;            // number of threads in threaded part of application
    Int fjack, fboot, fmc;   // simulate errrors by different methods
    VecInt planeToExclude;		    // exclude these planes from fitting

    Doub time_T2;		     // for CPMG experiments to calc. R2,eff
    Doub timeFactor;	     // for R1/2 experiments to calculate time from arrayed param
    Doub tanh;
    Doub eps;
    Doub b1, db1;			// spinlock field and its uncertainty in Hz
    Doub carrierPPM;		// carrier position for spinlock field in ppm
    VecDoub arr;	                // the actual array in dim. 3

    Bool noIntegration;     // read previously integrated data and only do downstream fitting
    Bool resno;
    Bool silent;
    Bool autoOverLap;		// automatically assigns peaks to overlapped groups
    Bool trosy;             // use flag if peak positions are trosy but spinlock is not
    bool pipeData;		    // true for data processed with NMRpipe. false for TopSpin data

    Llong maxdata;

    PeakType peak;

    OverRideType OR;

    vector<DoubIntType> jcouplingF1;		// size of guessed jcoupling to generate multiple peak lists in Hz
    vector<DoubIntType> jcouplingF2;		// size of guessed jcoupling to generate multiple peak lists in Hz

    vector<PeakListType> group;

    ParserType();

    ParserType(const string &parfile, const string &_outdir, const string &_progname);

    Int parse(VecString &error_msg);

    Int getArray(const string &procparName, const string &arrayPar, VecDoub &arr, VecString &error_msg);

    Int get_vdlist(const string &vdlistName, VecDoub &arr, VecString &error_msg);

    Bool EmptyLine(VecString_I &word);
};

#endif
