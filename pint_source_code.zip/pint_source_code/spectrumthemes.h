#ifndef SPECTRUMTHEMES_H
#define SPECTRUMTHEMES_H
#include <QColor>
#include <QString>
#include <QLinearGradient>

class spectrumThemes
{
public:
    spectrumThemes();
    ~spectrumThemes();
    bool builtin;
    QString style;
    QColor labelBorderColor;
    QColor labelBgColor;
    QColor foldedBorderColor;
    QColor foldedBgColor;
    QColor selectedBorderColor;
    QColor selectedBgColor;
    QColor moveBorderColor;
    QColor moveBgColor;
    QColor selectionPointerColor;
    QColor gridlineColor;
    QColor gridBgColor;
    QColor areaColor;
    QColor axisColor;
    QColor axisTextColor;
    QColor markerColor;
    bool gridToggled;
    QColor color1;
    QColor color2;
    QColor color3;
    QColor color4;
    QColor color5;
    QColor color6;
    double stop1;
    double stop2;
    double stop3;
    double stop4;
    double stop5;
    double stop6;
    QLinearGradient plotGradient;
    QString gradientButtonStylesheet;
};

#endif // SPECTRUMTHEMES_H
