#ifndef CUSTOMSPINBOX_H
#define CUSTOMSPINBOX_H

#include <QSpinBox>

class customSpinBox : public QSpinBox
{
    Q_OBJECT
public:
    customSpinBox(QWidget *parent = 0);
    ~customSpinBox();
    void mousePressEvent(QMouseEvent* event);
};

#endif // CUSTOMSPINBOX_H
