#include "mainscreen.h"
#include "ui_mainscreen.h"
#include <QMessageBox>
#include <QPointer>
#include "player.h"


MainScreen::MainScreen(QWidget *parent) :
    QMainWindow(parent), widget_about(NULL), widget_changelog(NULL), widget_main(NULL), widget_load_project(NULL),
    widget_new_project(NULL),widget_workspace(NULL),newProject(false), templateFile(""),scaleFactor(1.0),
    ui(new Ui::MainScreen)
{

    ui->setupUi(this);

    //Handle resolution scaling
    QRect rec = QApplication::desktop()->availableGeometry();
    double height = rec.height();
    double width = rec.width();
    scaleFactor=((width/1920+height/1050)/2.0);

    renderMainWidget();
}

MainScreen::~MainScreen()
{
    delete ui;
}

void MainScreen::renderAbout()
{
    widget_about = new aboutWidget(this, scaleFactor);
    disconnect(widget_about, SIGNAL(goBack()), this, SLOT(renderMainWidget()));
    connect(widget_about, SIGNAL(goBack()), this, SLOT(renderMainWidget()));

    MainScreen::setCentralWidget(widget_about);
}

void MainScreen::renderChangelog()
{
    widget_changelog= new widgetChangelog(this, scaleFactor);


    disconnect(widget_changelog, SIGNAL(goBack()), this, SLOT(renderMainWidget()));
    connect(widget_changelog, SIGNAL(goBack()), this, SLOT(renderMainWidget()));

    MainScreen::setCentralWidget(widget_changelog);
}

void MainScreen::renderMainWidget()
{
    widget_main = new mainWidget(this, scaleFactor);


    disconnect(widget_main);//Disconnecting everything before re-connecting avoids multiple connections to the same slot
    connect(widget_main, SIGNAL(closeApp()), this, SLOT(close()));
    connect(widget_main, SIGNAL(openAbout()), this, SLOT(renderAbout()));
    connect(widget_main, SIGNAL(openChange()), this, SLOT(renderChangelog()));
    connect(widget_main, SIGNAL(openLoadProject()), this, SLOT(renderLoadProject()));
    connect(widget_main, SIGNAL(openNewProject()), this, SLOT(renderNewProject()));
    connect(widget_main, SIGNAL(openPlayer()), this, SLOT(openPlayer()));
    connect(widget_main, SIGNAL(closeApp()), widget_main, SLOT(deleteLater()));

    MainScreen::setCentralWidget(widget_main);
}

void MainScreen::exitToMain()
{
    QMessageBox dlg;
    dlg.setText("The current project will be closed. Any unsaved data will be lost.\nDo you want to continue?");
    dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    dlg.setDefaultButton(QMessageBox::No);
    dlg.setWindowTitle("PINT");
    int ret = dlg.exec();
    switch(ret)
    {
    case QMessageBox::Yes:
        exitThenMain();
        break;
    default:
        break;
    }
}

void MainScreen::exitToLoad()
{
    QMessageBox dlg;
    dlg.setText("The current project will be closed. Any unsaved data will be lost.\nDo you want to continue?");
    dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    dlg.setDefaultButton(QMessageBox::No);
    dlg.setWindowTitle("PINT");
    int ret = dlg.exec();
    switch(ret)
    {
    case QMessageBox::Yes:
        exitThenLoad();
        break;
    default:
        break;
    }
}

void MainScreen::exitThenLoad()
{
    renderLoadProject();
}

void MainScreen::exitThenMain()
{
    renderMainWidget();
}

void MainScreen::quitApp()
{
    QMessageBox::StandardButton dlg;
    dlg = QMessageBox::warning(this, "PINT",
                               "The current project will be closed. Any unsaved data will be lost.",
                               QMessageBox::Ok | QMessageBox::Cancel);
    if(dlg==QMessageBox::Cancel)
        return;

    qApp->quit();
}

void MainScreen::renderLoadProject()
{
    widget_load_project = new loadProjectWidget(this, scaleFactor);

    disconnect(widget_load_project);
    connect(widget_load_project, SIGNAL(goBack()), this, SLOT(renderMainWidget()));
    connect(widget_load_project, SIGNAL(openProject(projectTemplate)), this, SLOT(renderWorkspace(projectTemplate)));

    MainScreen::setCentralWidget(widget_load_project);
}

void MainScreen::renderNewProject()
{
    widget_new_project = new newProjectWidget(this, scaleFactor);

    disconnect(widget_new_project);
    connect(widget_new_project, SIGNAL(goBack()), this, SLOT(renderMainWidget()));
    connect(widget_new_project, SIGNAL(loadWorkspace(projectTemplate)), this, SLOT(toggleBool(projectTemplate)));

    MainScreen::setCentralWidget(widget_new_project);
}

void MainScreen::renderWorkspace(projectTemplate tmplate)
{
    widget_workspace = new workspace(this, tmplate, newProject);
    disconnect(widget_workspace);
    connect(widget_workspace, SIGNAL(goToMain()), this, SLOT(exitToMain()));
    connect(widget_workspace, SIGNAL(goToLoad()), this, SLOT(exitToLoad()));
    connect(widget_workspace, SIGNAL(quitApp()), this, SLOT(quitApp()));
    newProject = false;

    MainScreen::setCentralWidget(widget_workspace);
}

void MainScreen::toggleBool( projectTemplate tmplate)
{
    newProject = true;
    renderWorkspace(tmplate);
}

void MainScreen::openPlayer()
{
    Player *play = new Player();
    play->setAttribute(Qt::WA_DeleteOnClose);
    play->setWindowModality(Qt::ApplicationModal);
    play->showMaximized();
}
