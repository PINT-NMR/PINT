#include "screendialog.h"
#include "ui_screendialog.h"
#include "qshortcut.h"


screenDialog::screenDialog(QWidget *parent) :
    QDialog(parent), ui(new Ui::screenDialog), movie(new QMovie(":img/centering.gif", QByteArray(), this)),
    ctrlInt(16777249)
{
#ifdef Q_OS_MAC
    ctrlInt = 16777250;
#endif

    ui->setupUi(this);
    ui->gridLayout->installEventFilter(this);   
    QSize size;
    size.setHeight(100);
    size.setWidth(100);
    movie->setScaledSize(size);
    ui->movieLabel->setMovie(movie);
    movie->start();
}

bool screenDialog::eventFilter(QObject *obj, QEvent *event)
{
    if(event->type() == QEvent::KeyPress && obj)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == ctrlInt) emit ctrl(true);
    }
    else if(event->type() == QEvent::KeyRelease)
    {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        if(keyEvent->key() == ctrlInt) emit ctrl(false);
    }
    return QWidget::event(event);
}

screenDialog::~screenDialog()
{
    delete ui;
}
