#ifndef PLOTGRAPH_H
#define PLOTGRAPH_H
#include <QtDataVisualization/Q3DSurface>
#include <QtDataVisualization/QSurface3DSeries>
#include <QtDataVisualization/QSurfaceDataProxy>
#include <QtWidgets/QSlider>
#include <cstdlib>
#include <QListWidgetItem>
#include <QtDataVisualization/QCustom3DLabel>
#include <QPropertyAnimation>
#include <QTimer>
#include <QStringList>
#include <QVector>
#include "customitemproperties.h"
#include "spectrumthemes.h"
#include <QTableWidgetItem>

using namespace QtDataVisualization;
using namespace std;

class plotGraph : public QObject
{
    Q_OBJECT
public:
    explicit plotGraph(QObject *parent, Q3DSurface *surface);
    ~plotGraph();
    Q3DSurface *plot_graph;
    spectrumThemes activeTheme;
    QSurfaceDataProxy *plot_renderPlotProxy;
    QSurfaceDataProxy *plot_renderPlotProxy2;
    QSurfaceDataProxy *plot_renderPlotProxy3;
    int index;
    void toggleItems();
    void toggleDiffPlot();

private:
    QSurface3DSeries *plot_renderPlotSeries;
    QSurface3DSeries *plot_renderPlotSeries2;
    QSurface3DSeries *plot_renderPlotSeries3;
    QSurfaceDataRow *newRow;
    float minIntensity;
    float maxIntensity;
    float marginal;
    float minF1;
    float maxF1;
    float minF2;
    float maxF2;
    QPropertyAnimation *m_animationCameraX;
    QVector3D target;
    bool moveForward;
    bool moveBackward;
    bool moveRight;
    bool moveLeft;
    bool moveYFlag;
    bool moveXFlag;
    QTimer *cameraTimer;
    QPropertyAnimation *m_selectionAnimation;
    QCustom3DItem *m_previouslyAnimatedItem;
    QCustom3DItem *m_previouslyAnimatedItem2;
    QCustom3DItem *m_selectionItem;
    void centerCamera(QCustom3DItem *item);
    bool selectedSeries;
    bool disabled;
    void setAxisF1Range(float min, float max);
    void setAxisF2Range(float min, float max);
    float m_stepF1;
    float m_stepF2;
    QString currentTitle;

    float m_rangeMinX;
    float m_rangeMinZ;
    float m_stepX;
    float m_stepZ;
    QLinearGradient gradientDiff;
    QColor color1;
    QColor color2;
    bool diffActive;
    bool itemsActive;
    bool gridActive;
    bool gridActive2;
    bool gridActive3;

public slots:
    void handleElementSelected(QAbstract3DGraph::ElementType type, QString label);
    void renderPlot(QTableWidgetItem* item, std::string plotDir, int graphNo, QVector<QStringList> overlapVec, QString peaklist);
    void setAxisIntensityRange(double min, double max);
    void adjustIntensityMin(double min);
    void setupVisuals();
    void overrideCamera();
    bool eventFilter(QObject *obj, QEvent *event);
    void customCamera();
    void clearPlots();
    void changeTheme(spectrumThemes theme);
    void setColor(QColor color, int model);
    void toggleGrid(int model);

private slots:
    void addCustomLabel(QString label, float F1, float F2);
    void addCustomErrorLabel(QString str);
    void autoZoom();

signals:
    void infoPeakMode(QString str, bool timerEnabled);
    void redraw(int index);
};


#endif // PLOTGRAPH_H
