#include "integrationstatusdialog.h"
#include "ui_integrationstatusdialog.h"


integrationStatusDialog::integrationStatusDialog(QWidget *parent) :
    QDialog(parent), elapsed(""), updateTimer(new QTimer(this)), progressTimer(QTime()),
    ui(new Ui::integrationStatusDialog), lst(0)
{
    ui->setupUi(this);
    progressTimer.start();
    updateTimer->setInterval(1000);
    connect(updateTimer, SIGNAL(timeout()), this, SLOT(elapsedUpdate()));
    updateTimer->start();
}

integrationStatusDialog::~integrationStatusDialog()
{
    delete ui;
}

void integrationStatusDialog::on_abortButton_clicked()
{
    reject();
}

void integrationStatusDialog::updateLabel(QString str)
{
    QString format("<html><head/><body><p><span style=\" color:#ffffff;\">%1</span></p></body></html>");
    ui->integrationProgressLabel->setText(format.arg(str));
}

void integrationStatusDialog::updateProgress(int value)
{
    ui->progressBar->setValue(value);
}

void integrationStatusDialog::hideProgressBar()
{
    ui->progressBar->hide();
}

void integrationStatusDialog::hideElements()
{
    ui->statusBrowser->hide();
    ui->intLabel->hide();
    ui->elapsedTimerLabel->hide();
    ui->abortButton->hide();
    ui->cancelLabel->hide();
}

void integrationStatusDialog::elapsedUpdate()
{
    QString str("<html><head/><body><p><span style=\" color:#ffffff;\">Elapsed time: %1 min, %2 sec</span></p></body></html>");
    int sec(progressTimer.elapsed()/1000);
    int min(0);
    while(sec>59)
    {
        min++;
        sec-=60;
    }
    QString msg(str.arg(QString::number(min)).arg(QString::number(sec)));
    ui->elapsedTimerLabel->setText(msg);
    elapsed=msg;
}

void integrationStatusDialog::updateProgressString(QString str)
{
    lst << "<html>&bull;"+str.trimmed()+"<br></html>";
    ui->statusBrowser->clear();
    for(int i(0); i<lst.size(); ++i)
        ui->statusBrowser->append(lst.at(i));
}

void integrationStatusDialog::removeProgressString(QString str)
{
    for(int i(0); i<lst.size(); ++i)
        if(lst.at(i)=="<html>&bull;"+str.trimmed()+"<br></html>")
        {
            lst.removeAt(i);
            break;
        }
    ui->statusBrowser->clear();
    for(int i(0); i<lst.size(); ++i)
        ui->statusBrowser->append(lst.at(i));
}

void integrationStatusDialog::updateLabels()
{
    ui->intLabel->hide();
    ui->statusBrowser->hide();
    QVBoxLayout *ly = new QVBoxLayout();
    ui->gridLayout_3->addLayout(ly,0,0);
    ly->addSpacerItem(new QSpacerItem(0,0,QSizePolicy::Fixed,QSizePolicy::Expanding));
}
