#ifndef FOLDDIALOG_H
#define FOLDDIALOG_H

#include <QDialog>

namespace Ui {
class foldDialog;
}

class foldDialog : public QDialog
{
    Q_OBJECT

public:
    explicit foldDialog(QWidget *parent = 0);
    ~foldDialog();
    int foldF1;
    int foldF2;

private slots:
    void on_okButton_clicked();
    void on_cancelButton_clicked();
    void on_downF1Button_clicked();
    void on_upF1Button_clicked();
    void on_downF2Button_clicked();
    void on_upF2Button_clicked();

private:
    Ui::foldDialog *ui;
};

#endif // FOLDDIALOG_H
