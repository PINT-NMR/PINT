#include "newprojectwidget.h"
#include "ui_newprojectwidget.h"
#include "textstyle.h"
#include <QDir>
#include <QFileDialog>
#include <QMessageBox>
#include <QMovie>
#include <QTextStream>


newProjectWidget::newProjectWidget(QWidget *parent, double sF) :
    QWidget(parent), scaleFactor(sF), previousDir(QDir::currentPath()),
    movie(new QMovie(":img/warning.gif", QByteArray(), this)), ui(new Ui::newProjectWidget)
{
    ui->setupUi(this);
    setupCosmeticChanges();
    if(scaleFactor!=1.0)
        scaleWidget();
    connect(ui->projectEdit, SIGNAL(textChanged(QString)), ui->warningNameLabel, SLOT(clear()));
    QFile file(qApp->applicationDirPath()+"/settings.txt");
    if(!file.exists())
    {
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT",
                                   "PINT could not detect a directory dedicated for PINT projects.\nDo you want to specify a default folder for all of your projects now?",
                                   QMessageBox::Yes | QMessageBox::No);
        if(dlg==QMessageBox::Yes)
        {
            QString directory = QFileDialog::getExistingDirectory(this,tr("Choose project directory"), previousDir);
            if (!directory.isEmpty())
            {
                if(file.open(QIODevice::WriteOnly | QIODevice::Text))
                {
                    QTextStream out(&file);
                    out << directory;
                    file.close();
                    ui->directoryEdit->setText(directory);
                    QMessageBox::StandardButton infoDlg;
                    infoDlg = QMessageBox::information(this, "PINT", "If you need to change the default path in the future, please delete or modify "+qApp->applicationDirPath()+"/settings.txt", QMessageBox::Ok);
                    Q_UNUSED(infoDlg)
                }
            }
        }
    }
    else
    {
        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QTextStream in(&file);
            QString line(in.readLine());
            file.close();
            QDir dirCheck(line);
            if(dirCheck.exists())
                ui->directoryEdit->setText(line);
            else
            {
                QMessageBox::StandardButton dlg;
                dlg = QMessageBox::warning(this, "PINT",
                                           "The default directory does not exists.\nDo you want to specify a new default folder for all of your projects now?",
                                           QMessageBox::Yes | QMessageBox::No);
                if(dlg==QMessageBox::Yes)
                {
                    QString directory = QFileDialog::getExistingDirectory(this,tr("Choose project directory"), previousDir);
                    if (directory.isEmpty())
                        ui->directoryEdit->setText(qApp->applicationDirPath());
                    else
                    {
                        if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
                            ui->directoryEdit->setText(qApp->applicationDirPath());
                        else
                        {
                            QTextStream out(&file);
                            out << directory;
                            file.close();
                            ui->directoryEdit->setText(directory);
                            QMessageBox::StandardButton infoDlg;
                            infoDlg = QMessageBox::information(this, "PINT", "If you need to change the default path in the future, please delete or modify "+qApp->applicationDirPath()+"/settings.txt", QMessageBox::Ok);
                            Q_UNUSED(infoDlg)
                        }
                    }
                }
                else
                    ui->directoryEdit->setText(qApp->applicationDirPath());
            }
        }
        else
        {
            QMessageBox::StandardButton warn;
            warn=  QMessageBox::warning(this,"PINT", "Your application directory is read/write protected. This may cause the software to fail reading certain files.\nTo fix this, edit the read/write properties of the "+qApp->applicationDirPath()+" folder and its contents.", QMessageBox::Ok);
            if(warn == QMessageBox::Ok)
                ui->directoryEdit->setText(qApp->applicationDirPath());
        }
    }
    previousDir = ui->directoryEdit->text();
}

newProjectWidget::~newProjectWidget()
{
    delete ui;
}

void newProjectWidget::on_cancelButton_clicked()
{
    emit goBack();
}

void newProjectWidget::setupCosmeticChanges()
{
    //Text shadow effect

    textStyle *style = new textStyle(this);
    textStyle *style2= new textStyle(this);
    textStyle *style3= new textStyle(this);
    ui->labelPINT->setGraphicsEffect(style->shadow);
    ui->labelVersion->setGraphicsEffect(style2->shadow);
    ui->label_LoadProject->setGraphicsEffect(style3->shadow);
}

void newProjectWidget::on_okButton_clicked()
{
    bool ret(false);
    QSize size;
    size.setHeight(20);
    size.setWidth(20);
    movie->setScaledSize(size);
    if(ui->directoryEdit->text().isEmpty())
    {
        ui->warningDirLabel->setMovie(movie);
        ret=true;
    }
    if(ui->projectEdit->text().isEmpty())
    {
        ui->warningNameLabel->setMovie(movie);
        ret=true;
    }
    else
    {
        QString illegalChars(" /?<>\\:*|\".,^:;+()[]%¤#!@£$€{}'´`~¨");
        for(int i(0); i< ui->projectEdit->text().size(); i++)
        {
            for(int j(0); j<illegalChars.size(); j++)
                if(ui->projectEdit->text()[i]==illegalChars[j])
                {
                    QMessageBox::StandardButton dlg;
                    QString msg("The project name includes an illegal character ('");
                    msg+=illegalChars[j];
                    msg+="')";
                    dlg = QMessageBox::warning(this, "PINT", msg, QMessageBox::Ok);
                    Q_UNUSED(dlg)
                    ui->warningNameLabel->setMovie(movie);
                    movie->start();
                    return;
                }
        }
    }
    if(ret)
    {
        movie->start();
        return;
    }
    projectTemplate tmplate;
    tmplate.projectRootDirectory = ui->directoryEdit->text();
    tmplate.projectName = ui->projectEdit->text();
    tmplate.projectDirectory = ui->directoryEdit->text() + "/" + tmplate.projectName;
    tmplate.saveFile = ui->directoryEdit->text() + "/" + tmplate.projectName + "/" + tmplate.projectName + ".ppro";
    tmplate.paramFile = tmplate.projectRootDirectory + "/" + tmplate.projectName + "/param.pint";
    tmplate.peakCenterParamFile = tmplate.projectRootDirectory + "/" + tmplate.projectName + "/paramCenterPeak.pint";
    tmplate.outDirectory = tmplate.projectRootDirectory + "/" + tmplate.projectName + "/out";
    tmplate.plotDirectory = tmplate.projectRootDirectory + "/" + tmplate.projectName + "/plot";
    tmplate.tmpOutDirectory = tmplate.projectRootDirectory + "/" + tmplate.projectName + "/tmp_out";
    tmplate.tmpPlotDirectory = tmplate.projectRootDirectory + "/" + tmplate.projectName + "/tmp_plot";
    tmplate.centerPeakList = tmplate.projectRootDirectory + "/" + tmplate.projectName + "/centerPeakList.list";
    tmplate.integratePeakList = tmplate.projectRootDirectory + "/" + tmplate.projectName + "/peaklist.list";
    tmplate.currentPeakID="0";
    if(ui->pipeButton->isChecked())
        tmplate.pipeData = true;
    else
        tmplate.pipeData = false;
    int tmplateStatus(checkTemplateErrors(tmplate));
    switch(tmplateStatus)
    {
    case 0:
        //No errors
        removeDir(tmplate.projectDirectory);
        removeDir(tmplate.outDirectory);
        removeDir(tmplate.plotDirectory);
        QDir().mkdir(tmplate.projectDirectory);
        QDir().mkdir(tmplate.outDirectory);
        QDir().mkdir(tmplate.plotDirectory);
        if(QFile(tmplate.paramFile).exists())
            QFile(tmplate.paramFile).remove();
        emit loadWorkspace(tmplate);
        break;
    case 1:
    {
        //Error occurred
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT",
                                   "The project directory does not exist. Please select a valid project directory.",
                                   QMessageBox::Ok);
        if(dlg==QMessageBox::Ok)
            return;
        break;
    }
    default:
        //Print no message
        break;
    }
}

bool newProjectWidget::removeDir(const QString & dirName)
{
    bool result = true;
    QDir dir(dirName);
    if (dir.exists(dirName)) {
        Q_FOREACH(QFileInfo info, dir.entryInfoList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden  | QDir::AllDirs | QDir::Files, QDir::DirsFirst)) {
            if (info.isDir()) {
                result = removeDir(info.absoluteFilePath());
            }
            else {
                result = QFile::remove(info.absoluteFilePath());
            }

            if (!result) {
                return result;
            }
        }
        result = dir.rmdir(dirName);
    }
    return result;
}

int newProjectWidget::checkTemplateErrors(projectTemplate tmplate)
{
    //Validate user settings
    QDir dir(tmplate.projectRootDirectory);
    if(!dir.exists())
        return 1;
    QFile file(tmplate.paramFile);
    QDir out(tmplate.outDirectory);
    QDir plot(tmplate.plotDirectory);
    if(file.exists() || out.exists() || plot.exists())
    {
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT",
                                   "The selected project directory already includes project files. Files will be deleted. Do you want to continue?",
                                   QMessageBox::Yes | QMessageBox::No);
        if(dlg==QMessageBox::No)
            return -1;
    }
    return 0;
}

void newProjectWidget::on_browseButton_clicked()
{
    QString directory = QFileDialog::getExistingDirectory(this,tr("Choose project directory"), previousDir);
    if (!directory.isEmpty())
    {
        previousDir = directory;
        ui->directoryEdit->setText(directory);
        ui->warningDirLabel->clear();
    }
}

void newProjectWidget::scaleWidget()
{
    //Buttons
    ui->browseButton->setMinimumSize(ui->browseButton->minimumSize().width()*scaleFactor, ui->browseButton->minimumSize().height()*scaleFactor);
    ui->browseButton->setMaximumSize(ui->browseButton->minimumSize());
    ui->browseButton->setIconSize(ui->browseButton->iconSize()*scaleFactor);
    ui->cancelButton->setMinimumSize(ui->cancelButton->minimumSize().width()*scaleFactor, ui->cancelButton->minimumSize().height()*scaleFactor);
    ui->cancelButton->setMaximumSize(ui->cancelButton->minimumSize());
    ui->cancelButton->setIconSize(ui->cancelButton->iconSize()*scaleFactor);
    ui->okButton->setMinimumSize(ui->okButton->minimumSize().width()*scaleFactor, ui->okButton->minimumSize().height()*scaleFactor);
    ui->okButton->setMaximumSize(ui->okButton->minimumSize());
    ui->okButton->setIconSize(ui->okButton->iconSize()*scaleFactor);

    //Labels
    ui->browseLabel->setFont(scaleFont(ui->browseLabel->font()));
    ui->cancelLabel->setFont(scaleFont(ui->cancelLabel->font()));
    ui->dummyLabel->setFont(scaleFont(ui->dummyLabel->font()));
    ui->labelDirectory->setFont(scaleFont(ui->labelDirectory->font()));
    ui->labelDirectory_2->setFont(scaleFont(ui->labelDirectory_2->font()));
    ui->labelExtension->setFont(scaleFont(ui->labelExtension->font()));
    ui->labelPINT->setFont(scaleFont(ui->labelPINT->font()));
    ui->labelProject->setFont(scaleFont(ui->labelProject->font()));
    ui->labelVersion->setFont(scaleFont(ui->labelVersion->font()));
    ui->label_LoadProject->setFont(scaleFont(ui->label_LoadProject->font()));
    ui->okLabel->setFont(scaleFont(ui->okLabel->font()));
    ui->warningDirLabel->setFont(scaleFont(ui->warningDirLabel->font()));
    ui->warningNameLabel->setFont(scaleFont(ui->warningNameLabel->font()));
    ui->pipeButton->setFont(scaleFont(ui->pipeButton->font()));
    ui->topspinButton->setFont(scaleFont(ui->topspinButton->font()));

    ui->directoryEdit->setFont(scaleFont(ui->directoryEdit->font()));
    ui->projectEdit->setFont(scaleFont(ui->projectEdit->font()));
    ui->labelDirectory->setMinimumSize(ui->labelDirectory->minimumWidth()*scaleFactor,ui->labelDirectory->minimumHeight()*scaleFactor);
    ui->labelProject->setMinimumSize(ui->labelProject->minimumWidth()*scaleFactor,ui->labelProject->minimumHeight()*scaleFactor);
    ui->projectEdit->setMinimumSize(ui->projectEdit->minimumWidth()*scaleFactor,ui->projectEdit->minimumHeight()*scaleFactor);
    ui->directoryEdit->setMinimumSize(ui->directoryEdit->minimumWidth()*scaleFactor,ui->directoryEdit->minimumHeight()*scaleFactor);
}

QFont newProjectWidget::scaleFont(QFont fnt)
{
    fnt.setPointSizeF(fnt.pointSizeF()*scaleFactor);
    return fnt;
}
