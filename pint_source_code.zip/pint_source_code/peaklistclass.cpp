#include "peaklistclass.h"
peaklistClass::peaklistClass() :
    spectrum(""), peaklist(0)
{
}

peaklistClass::~peaklistClass()
{
}
