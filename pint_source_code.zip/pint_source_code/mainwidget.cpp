#include "mainwidget.h"
#include "ui_mainwidget.h"
#include "QTextDocument"
#include "QDesktopServices"
#include "textstyle.h"



mainWidget::mainWidget(QWidget *parent, double sF) :
    QWidget(parent), scaleFactor(sF),
    ui(new Ui::mainWidget)
{
    ui->setupUi(this);
    setupCosmeticChanges();
    checkUpdates();
    if(scaleFactor!=1.0)
        scaleWidget();
}

mainWidget::~mainWidget()
{
    delete ui;
}

void mainWidget::setupCosmeticChanges()
{
    //Applies cosmetical changes to the GUI

    //Text shadow effect

    textStyle *style = new textStyle(this);
    textStyle *style2= new textStyle(this);
    textStyle *style3= new textStyle(this);
    textStyle *style4= new textStyle(this); //Intentional, QGraphicsDropShadowEffect does not allow for multiple renders at once
    ui->label_NewProject->setGraphicsEffect(style->shadow);
    ui->label_LoadProject->setGraphicsEffect(style2->shadow);
    ui->labelPINT->setGraphicsEffect(style3->shadow);
    ui->labelVersion->setGraphicsEffect(style4->shadow);
    ui->updateButton->hide();
}

void mainWidget::checkUpdates()
{
    //Checks online for updates
    //If found --> GUI indication
    //If current version / no network access --> No indication
    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)),this, SLOT(replyFinished(QNetworkReply*)));
    manager->get(QNetworkRequest(QUrl("http://www.liu.se/forskning/foass/tidigare-foass/patrik-lundstrom/software?l=en#PINT")));
}

void mainWidget::replyFinished(QNetworkReply* reply)
{
    QByteArray bts = reply->readAll();
    QString str(bts);
    QString version("PINT ");
    QTextDocument doc;
    doc.setHtml(ui->labelVersion->text());
    version+=doc.toPlainText();
    if(str.size()>0 && !str.contains(version))
    {
        //Update is available
        ui->updateButton->show();
    }
}

void mainWidget::on_updateButton_clicked(){QDesktopServices::openUrl(QUrl("http://www.liu.se/forskning/foass/tidigare-foass/patrik-lundstrom/software?l=en#PINT"));}

void mainWidget::on_aboutButton_clicked(){emit openAbout();}

void mainWidget::on_exitButton_clicked(){emit closeApp();}

void mainWidget::on_loadButton_clicked(){emit openLoadProject();}

void mainWidget::on_newButton_clicked(){emit openNewProject();}

void mainWidget::on_changelogButton_clicked(){emit openChange();}

void mainWidget::scaleWidget()
{
    //Buttons
    ui->tutorialButton->setMinimumSize(ui->tutorialButton->minimumSize().width()*scaleFactor, ui->aboutButton->minimumSize().height()*scaleFactor);
    ui->tutorialButton->setMaximumSize(ui->tutorialButton->minimumSize());
    ui->tutorialButton->setIconSize(ui->tutorialButton->iconSize()*scaleFactor);
    ui->changelogButton->setMinimumSize(ui->changelogButton->minimumSize().width()*scaleFactor, ui->aboutButton->minimumSize().height()*scaleFactor);
    ui->changelogButton->setMaximumSize(ui->changelogButton->minimumSize());
    ui->changelogButton->setIconSize(ui->changelogButton->iconSize()*scaleFactor);
    ui->aboutButton->setMinimumSize(ui->aboutButton->minimumSize().width()*scaleFactor, ui->aboutButton->minimumSize().height()*scaleFactor);
    ui->aboutButton->setMaximumSize(ui->aboutButton->minimumSize());
    ui->aboutButton->setIconSize(ui->aboutButton->iconSize()*scaleFactor);
    ui->exitButton->setMinimumSize(ui->exitButton->minimumSize().width()*scaleFactor, ui->exitButton->minimumSize().height()*scaleFactor);
    ui->exitButton->setMaximumSize(ui->exitButton->minimumSize());
    ui->exitButton->setIconSize(ui->exitButton->iconSize()*scaleFactor);
    ui->loadButton->setMinimumSize(ui->loadButton->minimumSize().width()*scaleFactor, ui->loadButton->minimumSize().height()*scaleFactor);
    ui->loadButton->setMaximumSize(ui->loadButton->minimumSize());
    ui->loadButton->setIconSize(ui->loadButton->iconSize()*scaleFactor);
    ui->newButton->setMinimumSize(ui->newButton->minimumSize().width()*scaleFactor, ui->newButton->minimumSize().height()*scaleFactor);
    ui->newButton->setMaximumSize(ui->newButton->minimumSize());
    ui->newButton->setIconSize(ui->newButton->iconSize()*scaleFactor);

    //Labels
    ui->labelPINT->setFont(scaleFont(ui->labelPINT->font()));
    ui->aboutLabel->setFont(scaleFont(ui->aboutLabel->font()));
    ui->changelogLabel->setFont(scaleFont(ui->changelogLabel->font()));
    ui->tutorialLabel->setFont(scaleFont(ui->tutorialLabel->font()));
    ui->bugLabel->setFont(scaleFont(ui->bugLabel->font()));
    ui->exitLabel->setFont(scaleFont(ui->exitLabel->font()));
    ui->labelVersion->setFont(scaleFont(ui->labelVersion->font()));
    ui->label_LoadProject->setFont(scaleFont(ui->label_LoadProject->font()));
    ui->label_NewProject->setFont(scaleFont(ui->label_NewProject->font()));
    ui->openLabel->setFont(scaleFont(ui->openLabel->font()));
    ui->okLabel_2->setFont(scaleFont(ui->okLabel_2->font()));

}

QFont mainWidget::scaleFont(QFont fnt)
{
    fnt.setPointSizeF(fnt.pointSizeF()*scaleFactor);
    return fnt;
}

void mainWidget::on_tutorialButton_clicked()
{
    emit openPlayer();
}
