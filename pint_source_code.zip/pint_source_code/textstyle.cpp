#include "textstyle.h"
textStyle::textStyle(QObject *parent)
    :QObject(parent), shadow(new QGraphicsDropShadowEffect(this)),
      shadow2(new QGraphicsDropShadowEffect(this))
{
    blurEffect();
}

textStyle::~textStyle()
{
}

void textStyle::blurEffect()
{
    //Creates a blur effect used for QLabel shadows
    shadow->setBlurRadius(15);
    shadow->setXOffset(5);
    shadow->setYOffset(5);
    shadow->setColor(QColor("black"));
    shadow2->setBlurRadius(4);
    shadow2->setXOffset(1);
    shadow2->setYOffset(1);
    shadow2->setColor(QColor("black"));
}
