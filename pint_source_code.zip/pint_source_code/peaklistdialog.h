#ifndef PEAKLISTDIALOG_H
#define PEAKLISTDIALOG_H

#include <QDialog>
#include <QDir>
#include <QModelIndex>
#include <QVector>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDirIterator>

namespace Ui {
class peaklistDialog;
}

class peaklistDialog : public QDialog
{
    Q_OBJECT

public:
    explicit peaklistDialog(QWidget *parent = 0);
    ~peaklistDialog();
    int header;
    int assignment;
    int f1;
    int f2;

private:
    Ui::peaklistDialog *ui;
    QVector<QVector<int> > presetVec;
    bool validFormat;

private slots:
    void updateBrowserText();
    void loadTemplate(QModelIndex item);
    void loadDefaultTemplate();
    void loadAllTemplates();
    void acceptEvent();
    bool saveDefaultTemplate();
    void savePreset();
    bool fileExists(QString path);
    void deletePreset();
};

#endif // PEAKLISTDIALOG_H
