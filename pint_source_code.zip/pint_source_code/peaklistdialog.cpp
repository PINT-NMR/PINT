#include "peaklistdialog.h"
#include "ui_peaklistdialog.h"
#include <QShortcut>


peaklistDialog::peaklistDialog(QWidget *parent) :
    QDialog(parent), header(0), assignment(0), f1(0), f2(0),
    ui(new Ui::peaklistDialog), presetVec(0), validFormat(false)
{
    ui->setupUi(this);
    loadAllTemplates();
    loadDefaultTemplate();
    updateBrowserText();
    connect(ui->assBox, SIGNAL(valueChanged(int)), this, SLOT(updateBrowserText()));
    connect(ui->f1Box, SIGNAL(valueChanged(int)), this, SLOT(updateBrowserText()));
    connect(ui->f2Box, SIGNAL(valueChanged(int)), this, SLOT(updateBrowserText()));
    connect(ui->headerBox, SIGNAL(valueChanged(int)), this, SLOT(updateBrowserText()));
    connect(ui->savePresetButton, SIGNAL(clicked(bool)), this, SLOT(savePreset()));
    connect(ui->okButton, SIGNAL(clicked(bool)), this, SLOT(acceptEvent()));
    connect(ui->cancelButton, SIGNAL(clicked(bool)), this, SLOT(reject()));
    connect(ui->presetList, SIGNAL(doubleClicked(QModelIndex)), this, SLOT(loadTemplate(QModelIndex)));
    QShortcut *scDeletePreset = new QShortcut(this);
    scDeletePreset->setKey(Qt::Key_Delete);
    connect(scDeletePreset, SIGNAL(activated()), this, SLOT(deletePreset()));
}

peaklistDialog::~peaklistDialog()
{
    delete ui;
}

void peaklistDialog::updateBrowserText()
{
    ui->previewBrowser->setText("");
    QString text("");
    int colF1(ui->f1Box->value()), colF2(ui->f2Box->value()), colAss(ui->assBox->value());
    if(colF1==colF2 || colF1==colAss || colF2==colAss)
    {
        ui->previewBrowser->setText("INVALID FORMAT\nAssignment, F1 and F2 columns must be unique.");
        validFormat = false;
        return;
    }
    int max(colF1);
    if(colF2>max)
        max = colF2;
    if(colAss>max)
        max = colAss;
    for(int i(0); i<ui->headerBox->value(); i++)
        text+="SKIPPED HEADER LINE #"+QString::number(i+1)+"\n";
    QString text2("");
    for(int i(1); i<=max; i++)
    {
        if(colF1 == i)
            text2+="F1";
        else if(colF2 == i)
            text2+="F2";
        else if(colAss == i)
            text2+="ASSIGNMENT";
        else
            text2+="*";
        text2+="  ";
    }
    for(int i(0); i<5; i++)
        text+=text2+"\n";
    text+="...\nDATA WILL BE IMPORTED UNTIL:\n1:END OF FILE\n2:BAD FORMAT\n...";
    ui->previewBrowser->setText(text);
    validFormat = true;
}

void peaklistDialog::loadDefaultTemplate()
{
    QString fileName(qApp->applicationDirPath() + "/defaultPeaklistTemplate.dat");
    QFile file(fileName);
    if(file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream in(&file);
        QString line = in.readLine();
        int counter(0);
        while(!line.isNull())
        {
            bool ok(true);
            switch(counter)
            {
            case 0:
            {
                int val = (int)line.toDouble(&ok);
                if(ok)
                    ui->headerBox->setValue(val);
                break;
            }
            case 1:
            {
                int val = (int)line.toDouble(&ok);
                if(ok)
                    ui->assBox->setValue(val);
                break;
            }
            case 2:
            {
                int val = (int)line.toDouble(&ok);
                if(ok)
                    ui->f1Box->setValue(val);
                break;
            }
            case 3:
            {
                int val = (int)line.toDouble(&ok);
                if(ok)
                    ui->f2Box->setValue(val);
                break;
            }
            default: break;
            }
            counter++;
            if(counter>3)
                break;
            line = in.readLine();
        }
        file.close();
    }
}

void peaklistDialog::savePreset()
{
    QString dirName(qApp->applicationDirPath() + "/peaklist_formats/");
    QDir dir(dirName);
    if(!dir.exists())
        dir.mkpath(dirName);

    QString presetName(ui->presetEdit->text());
    QString errMsg("");
    if(presetName.isEmpty())
    {
        errMsg = "Enter a valid name for the preset";
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
        if(dlg==QMessageBox::Ok)
            return;
    }
    else
    {
        for(int i(0); i<ui->presetList->count(); i++)
        {
            if(ui->presetList->item(i)->text()  == presetName)
            {
                errMsg = "Enter a unique name for the preset";
                QMessageBox::StandardButton dlg;
                dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
                if(dlg==QMessageBox::Ok)
                    return;
            }
        }
        QString illegalChars(" /?<>\\:*|\".,^:;+()[]%¤#!@£$€{}'´`~¨");
        for(int l(0); l<presetName.length(); l++)
        {
            for(int m(0); m<illegalChars.length(); m++)
            {
                if(presetName[l]==illegalChars[m])
                {
                    QChar chr(illegalChars[m]);
                    errMsg = "Preset name contains an illegal character \""+(QString)chr+"\".\nAborting.";
                    QMessageBox::StandardButton dlg;
                    dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
                    if(dlg==QMessageBox::Ok)
                        return;
                }
            }
        }
    }
    QFile file(dirName+presetName+".tmplt");
    if(file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream out(&file);
        out<<presetName<<"\n";
        out<<QString::number(ui->headerBox->value())<<"\n";
        out<<QString::number(ui->assBox->value())<<"\n";
        out<<QString::number(ui->f1Box->value())<<"\n";
        out<<QString::number(ui->f2Box->value());
        file.close();
        QVector<int> tmpVec;
        tmpVec.push_back(ui->headerBox->value());
        tmpVec.push_back(ui->assBox->value());
        tmpVec.push_back(ui->f1Box->value());
        tmpVec.push_back(ui->f2Box->value());
        presetVec.push_back(tmpVec);
        ui->presetList->addItem(presetName);
    }
    else
    {
        errMsg = "Could not save to the application directory.\nCheck your folder properties.";
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
        if(dlg==QMessageBox::Ok)
            return;
    }
}

bool peaklistDialog::fileExists(QString path)
{
    QFileInfo check_file(path);
    return (check_file.exists() && check_file.isFile());
}

bool peaklistDialog::saveDefaultTemplate()
{
    //Saves before closing dialog
    if(!validFormat)
    {
        QString errMsg = "The preset format is not valid. Aborting.";
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
        if(dlg==QMessageBox::Ok)
            return false;
    }
    QString fileName(qApp->applicationDirPath() + "/defaultPeaklistTemplate.dat");
    QFile file(fileName);
    if(file.open(QIODevice::WriteOnly| QIODevice::Text))
    {
        QTextStream out(&file);
        out<<QString::number(ui->headerBox->value())<<"\n"<<QString::number(ui->assBox->value())<<"\n"<<QString::number(ui->f1Box->value())<<"\n"<<QString::number(ui->f2Box->value());
        file.close();
    }
    else
    {
        QString errMsg = "Could not save to the application directory.\nCheck your folder properties.";
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
        if(dlg==QMessageBox::Ok)
            return false;
    }
    return true;
}

void peaklistDialog::loadTemplate(QModelIndex item)
{
    ui->headerBox->setValue(presetVec.at(item.row()).at(0));
    ui->assBox->setValue(presetVec.at(item.row()).at(1));
    ui->f1Box->setValue(presetVec.at(item.row()).at(2));
    ui->f2Box->setValue(presetVec.at(item.row()).at(3));
}

void peaklistDialog::loadAllTemplates()
{
    QVector<int> templateVec;
    templateVec.push_back(2); //Header
    templateVec.push_back(1); //Assignment
    templateVec.push_back(2); //f1
    templateVec.push_back(3); //f2
    presetVec.push_back(templateVec);

    QString dirName(qApp->applicationDirPath() + "/peaklist_formats/");
    QDir dir(dirName);
    if(!dir.exists())
        return;
    QStringList nameFilters;
    nameFilters << "*.tmplt";
    QDirIterator it(dirName, nameFilters, QDir::Files | QDir::NoSymLinks);
    while (it.hasNext())
    {

        QVector<int> templateVec2;
        QString fname(it.next());
        if(fileExists(fname))
        {
            QFile file(fname);
            QString name("");
            bool ok(true);
            if(file.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                int count(0);
                QString line = file.readLine();
                while (!line.isNull())
                {
                    if(count == 0)
                        name = line.simplified();
                    else if(count<5)
                    {
                        templateVec2.push_back(line.toInt(&ok));
                        if(!ok)
                            break;
                    }
                    else
                        break;
                    count++;
                    line = file.readLine();
                }
                file.close();
                if(ok)
                {
                    ui->presetList->addItem(name);
                    presetVec.push_back(templateVec2);
                }
            }
        }
    }
}

void peaklistDialog::acceptEvent()
{
    bool ok(saveDefaultTemplate());
    if(ok)
    {
        header = ui->headerBox->value();
        assignment = ui->assBox->value();
        f1 = ui->f1Box->value();
        f2 = ui->f2Box->value();
        accept();
    }
}

void peaklistDialog::deletePreset()
{
    if(ui->presetList->selectedItems().count()>0)
    {
        if(ui->presetList->item(0)->isSelected())
        {
            QString errMsg = "Cannot delete a built-in preset.\nAborting.";
            QMessageBox::StandardButton dlg;
            dlg = QMessageBox::warning(this, "PINT", errMsg, QMessageBox::Ok);
            if(dlg==QMessageBox::Ok)
                return;
        }
        for(int i(0); i<ui->presetList->count(); i++)
        {
            if(ui->presetList->item(i)->isSelected())
            {
                QString dirName(qApp->applicationDirPath() + "/peaklist_formats/");
                dirName+= ui->presetList->item(i)->text();
                dirName+=".tmplt";
                QFile file(dirName);
                if(file.exists())
                    file.remove();
                QListWidgetItem* item = ui->presetList->takeItem(i);
                delete item;
                QVector<int> iVec = presetVec.takeAt(i);
                iVec.clear();
                return;
            }
        }
    }
}
