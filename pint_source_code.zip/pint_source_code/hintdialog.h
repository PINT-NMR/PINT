#ifndef HINTDIALOG_H
#define HINTDIALOG_H

#include <QDialog>

namespace Ui {
class hintDialog;
}

class hintDialog : public QDialog
{
    Q_OBJECT

public:
    explicit hintDialog(QWidget *parent = 0);
    ~hintDialog();

private slots:
    void on_hideHintButton_clicked();

private:
    Ui::hintDialog *ui;
};

#endif // HINTDIALOG_H
