#include "themeclass.h"
#include <QDir>
#include <QDirIterator>
#include <QApplication>

themeClass::themeClass() : themeVector(0)
{
    spectrumThemes theme;
    //Create PINT theme
    theme.builtin=true;
    theme.style="PINT";
    theme.labelBorderColor = Qt::black;
    theme.labelBgColor = Qt::white;
    theme.foldedBorderColor = Qt::black;
    theme.foldedBgColor = QColor(111, 137, 160);
    theme.selectedBorderColor = Qt::white;
    theme.selectedBgColor = Qt::red;
    theme.moveBorderColor = Qt::black;
    theme.moveBgColor = QColor(239, 216, 168);
    theme.selectionPointerColor = Qt::blue;
    theme.gridlineColor = Qt::black;
    theme.gridBgColor = Qt::white;
    theme.areaColor = Qt::white;
    theme.axisColor = Qt::white;
    theme.axisTextColor = Qt::black;
    theme.gridToggled = true;
    theme.color1 = Qt::darkRed;
    theme.color2 = Qt::red;
    theme.color3 = Qt::yellow;
    theme.color4 = Qt::green;
    theme.color5 = Qt::white;
    theme.color6 = Qt::white;
    theme.stop1 = 1.0;
    theme.stop2 = .6;
    theme.stop3 = .4;
    theme.stop4 = .1;
    theme.stop5 = .05;
    theme.stop6 = .0;
    QLinearGradient gr;
    gr.setColorAt(0.0, Qt::white);
    gr.setColorAt(0.05, Qt::white);
    gr.setColorAt(0.1, Qt::green);
    gr.setColorAt(0.4, Qt::yellow);
    gr.setColorAt(0.6, Qt::red);
    gr.setColorAt(1.0, Qt::darkRed);
    theme.plotGradient = gr;
    theme.gradientButtonStylesheet = "QPushButton#gradientButton {\nbackground-color: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 rgb(255,255,255), stop:0.05 rgb(255, 255, 255), stop:0.1 rgb(0, 255, 0), stop:0.4 rgb(255, 255, 0), stop:0.6 rgb(255, 0, 0), stop:1 rgb(165, 0, 0));\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}\nQPushButton#gradientButton:pressed {\n border-style: inset;\n}\nQPushButton#gradientButton:hover:!pressed {\n border-style: outset;\nborder-radius: 10px;\nborder-width: 1px;\nborder-color: gray;\n}";
    themeVector.push_back(theme);
    //Create Dark gray theme
    theme.style="Dark gray";
    theme.gridlineColor = Qt::black;
    theme.gridBgColor = QColor(94, 94, 97);
    theme.areaColor = QColor(77, 77, 79);
    theme.axisColor = QColor(183, 183, 183);
    theme.gridToggled = true;
    themeVector.push_back(theme);
    //Create Light gray theme
    theme.style="Light gray";
    theme.gridlineColor = Qt::black;
    theme.gridBgColor = QColor(225, 226, 227);
    theme.areaColor = QColor(213, 214, 215);
    theme.axisColor = QColor(225, 226, 227);
    theme.gridToggled = false;
    themeVector.push_back(theme);
    //Create Black theme
    theme.style="Black";
    theme.gridlineColor = Qt::black;
    theme.gridBgColor = QColor(39,39,39);
    theme.areaColor = QColor(36, 36, 36);
    theme.axisColor = QColor(167,167,167);
    theme.gridToggled = true;
    theme.markerColor = Qt::black;
    themeVector.push_back(theme);
    //Load custom themes
    theme.builtin = false;
    QString dirName(qApp->applicationDirPath() + "/themes/");
    QDir dir(dirName);
    if (!dir.exists())
        return;
    QStringList nameFilters;
    nameFilters << "*.thm";
    QDirIterator it(dirName, nameFilters, QDir::Files | QDir::NoSymLinks);
    while (it.hasNext())
    {
        QString fname(it.next());
        if(fileExists(fname))
        {
            QFile file(fname);
            if(file.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                QTextStream in(&file);
                int counter(-1);
                int subCounter(0);
                double r(.0), g(.0), b(.0);
                QString line = in.readLine();
                bool ok(true), ok2(false);
                theme.gradientButtonStylesheet = "";
                while(!line.isNull())
                {
                    if(line=="#PARAM")
                        counter++;
                    else
                    {
                        switch (counter)
                        {
                        case 1:
                            theme.style = line;
                            break;
                        case 2:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.labelBorderColor = QColor(r,g,b);
                                if(!theme.labelBorderColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 3:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.labelBgColor = QColor(r,g,b);
                                if(!theme.labelBgColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 4:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.foldedBorderColor = QColor(r,g,b);
                                if(!theme.foldedBorderColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 5:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.foldedBgColor = QColor(r,g,b);
                                if(!theme.foldedBgColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 6:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.selectedBorderColor = QColor(r,g,b);
                                if(!theme.selectedBorderColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 7:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.selectedBgColor = QColor(r,g,b);
                                if(!theme.selectedBgColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 8:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.moveBorderColor = QColor(r,g,b);
                                if(!theme.moveBorderColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 9:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.moveBgColor = QColor(r,g,b);
                                if(!theme.moveBgColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 10:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.selectionPointerColor= QColor(r,g,b);
                                if(!theme.selectionPointerColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 11:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.gridlineColor = QColor(r,g,b);
                                if(!theme.gridlineColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 12:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.gridBgColor= QColor(r,g,b);
                                if(!theme.gridBgColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 13:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.areaColor = QColor(r,g,b);
                                if(!theme.areaColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 14:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.axisColor= QColor(r,g,b);
                                if(!theme.axisColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 15:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.axisTextColor = QColor(r,g,b);
                                if(!theme.axisTextColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 16:
                            if(line=="0")
                                theme.gridToggled= false;
                            else if(line=="1")
                                theme.gridToggled= true;
                            else
                                ok = false;
                            break;
                        case 17:
                            theme.color1 = QColor(r,g,b);
                            if(!theme.color1.isValid())
                                ok = false;
                            break;
                        case 18:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.color2 = QColor(r,g,b);
                                if(!theme.color2.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 19:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.color3 = QColor(r,g,b);
                                if(!theme.color3.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 20:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.color4 = QColor(r,g,b);
                                if(!theme.color4.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 21:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.color5 = QColor(r,g,b);
                                if(!theme.color5.isValid())
                                    ok = false;
                                break;
                            }
                            subCounter++;
                        case 22:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.color6 = QColor(r,g,b);
                                if(!theme.color6.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        case 23:
                            theme.stop1 = line.toDouble(&ok);
                            break;
                        case 24:
                            theme.stop2 = line.toDouble(&ok);
                            break;
                        case 25:
                            theme.stop3 = line.toDouble(&ok);
                            break;
                        case 26:
                            theme.stop4 = line.toDouble(&ok);
                            break;
                        case 27:
                            theme.stop5 = line.toDouble(&ok);
                            break;
                        case 28:
                            theme.stop6 = line.toDouble(&ok);
                            break;
                        case 29:
                            theme.gradientButtonStylesheet+=line;
                            break;
                        case 30:
                            if(subCounter>2)
                                subCounter=0;
                            if(subCounter==0)
                                r = line.toDouble(&ok);
                            else if(subCounter==1)
                                g = line.toDouble(&ok);
                            else if(subCounter==2)
                            {
                                b = line.toDouble(&ok);
                                theme.markerColor = QColor(r,g,b);
                                if(!theme.markerColor.isValid())
                                    ok = false;
                            }
                            subCounter++;
                            break;
                        default:
                            break;
                        }
                        if(!ok)
                        {
                            break;
                        }
                    }
                    line = in.readLine();
                }
                file.close();
                if(counter==30)
                    ok2 = true;
                if(ok && ok2)
                {
                    QLinearGradient gr2;
                    gr2.setColorAt(theme.stop6, theme.color6);
                    gr2.setColorAt(theme.stop5, theme.color5);
                    gr2.setColorAt(theme.stop4, theme.color4);
                    gr2.setColorAt(theme.stop3, theme.color3);
                    gr2.setColorAt(theme.stop2, theme.color2);
                    gr2.setColorAt(theme.stop1, theme.color1);
                    theme.plotGradient = gr2;
                    themeVector.push_back(theme);
                }
            }
        }
    }
}

themeClass::~themeClass()
{
}

bool themeClass::fileExists(QString path)
{
    QFileInfo check_file(path);
    return (check_file.exists() && check_file.isFile());
}
